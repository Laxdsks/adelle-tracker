package com.komiklingo.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.graphics.*;
import android.graphics.pdf.PdfRenderer;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import android.util.LruCache;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.nl.translate.*;
import com.google.mlkit.common.model.DownloadConditions;
import org.json.*;
import java.util.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
 private final Handler main=new Handler(Looper.getMainLooper());
 private final ExecutorService io=Executors.newSingleThreadExecutor();
 private final TextRecognizer ocr=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
 private final Translator translator=Translation.getClient(new TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.INDONESIAN).build());
 private final LruCache<String,String> cache=new LruCache<>(400);
 private LinearLayout root,bar;private FrameLayout stage;private WebView web;private ScrollView local;
 private ImageView picture;private BubbleOverlay overlay;private EditText address;private TextView status;
 private Button autoButton,originalButton;private boolean automatic=false,original=false,ready=false,busy=false,destroyed=false;
 private volatile boolean fileMode=false;private List<Boolean> sourceCaps=new ArrayList<>();private long generation=0;private int emptyRetries=0;private List<String> latestTranslations=new ArrayList<>();private PdfRenderer pdf;private ParcelFileDescriptor pdfFile;private int page=0;
 private final Runnable settled=()->translateViewport();
 private android.content.SharedPreferences prefs;
 private String documentId=UUID.randomUUID().toString();
 private String home="https://kaynscans.com/series/comic/chronicle-of-runes/chapter/48";
 @Override public void onCreate(Bundle state){super.onCreate(state);prefs=getSharedPreferences("reader",MODE_PRIVATE);automatic=prefs.getBoolean("automatic",true);
  getWindow().setStatusBarColor(Color.rgb(15,23,42));getWindow().setNavigationBarColor(Color.rgb(15,23,42));
  root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(15,23,42));
  root.setOnApplyWindowInsetsListener((v,in)->{v.setPadding(in.getSystemWindowInsetLeft(),in.getSystemWindowInsetTop(),in.getSystemWindowInsetRight(),in.getSystemWindowInsetBottom());return in;});setContentView(root);
  LinearLayout top=row();TextView brand=label("KomikLingo",18);brand.setTypeface(null,Typeface.BOLD);top.addView(brand,new LinearLayout.LayoutParams(0,dp(48),1));top.addView(button("Hasil",v->showResults()));top.addView(button("File",v->chooseFile()));top.addView(button("⋮",v->settings()));root.addView(top);
  bar=row();address=new EditText(this);address.setSingleLine();address.setTextColor(Color.WHITE);address.setTextSize(12);address.setHintTextColor(0xff94a3b8);address.setHint("Tempel tautan komik atau novel");address.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);bar.addView(address,new LinearLayout.LayoutParams(0,dp(48),1));bar.addView(button("Buka",v->open(address.getText().toString())));root.addView(bar);
  stage=new FrameLayout(this);root.addView(stage,new LinearLayout.LayoutParams(-1,0,1));
  web=new WebView(this);WebSettings ws=web.getSettings();ws.setJavaScriptEnabled(true);ws.setDomStorageEnabled(true);ws.setAllowFileAccess(false);ws.setAllowContentAccess(false);ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);ws.setBuiltInZoomControls(true);ws.setUseWideViewPort(true);ws.setLoadWithOverviewMode(true);ws.setDisplayZoomControls(false);ws.setSupportMultipleWindows(false);
  web.setWebViewClient(new WebViewClient(){
   @Override public void onScaleChanged(WebView w,float old,float next){changed();}
   @Override public void onPageStarted(WebView w,String url,Bitmap icon){if(!url.startsWith("https://reader.invalid/"))fileMode=false;changed();}
   @Override public WebResourceResponse shouldInterceptRequest(WebView w,WebResourceRequest r){if(fileMode&&r.getUrl().toString().equals("https://reader.invalid/image.png")){try{return new WebResourceResponse("image/png",null,new FileInputStream(new File(getCacheDir(),"reader.png")));}catch(Exception ignored){}}return null;}
@Override public void onPageFinished(WebView w,String url){if(!fileMode)address.setText(url);else{address.setText("");address.setHint("File pribadi · cubit untuk zoom");}changed();message("Halaman siap. Berhenti menggulir sebentar untuk menerjemahkan.");}@Override public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){String s=r.getUrl().getScheme();return !"https".equals(s)&&!"http".equals(s);}@Override public void onReceivedError(WebView w,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame())message("Halaman belum terbuka. Periksa internet atau buka tautan lain.");}});
  web.setOnScrollChangeListener((v,x,y,ox,oy)->changed());stage.addView(web,new FrameLayout.LayoutParams(-1,-1));
  local=new ScrollView(this);local.setFillViewport(true);picture=new ImageView(this);picture.setAdjustViewBounds(true);picture.setScaleType(ImageView.ScaleType.FIT_CENTER);local.addView(picture,new ScrollView.LayoutParams(-1,-2));local.setVisibility(View.GONE);local.setOnScrollChangeListener((v,x,y,ox,oy)->changed());stage.addView(local,new FrameLayout.LayoutParams(-1,-1));
  overlay=new BubbleOverlay(this);stage.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
  status=label("Menyiapkan pembaca…",12);status.setPadding(dp(12),dp(7),dp(12),dp(7));root.addView(status);
  LinearLayout controls=row();controls.addView(button("Terjemahkan",v->{original=false;originalButton.setText("Lihat asli");translateViewport();}),new LinearLayout.LayoutParams(0,dp(48),1));autoButton=button(automatic?"Otomatis: aktif":"Otomatis: mati",v->{automatic=!automatic;prefs.edit().putBoolean("automatic",automatic).apply();autoButton.setText(automatic?"Otomatis: aktif":"Otomatis: mati");if(automatic)changed();});controls.addView(autoButton,new LinearLayout.LayoutParams(0,dp(48),1));originalButton=button("Lihat asli",v->{original=!original;overlay.setVisibility(original?View.INVISIBLE:View.VISIBLE);originalButton.setText(original?"Lihat Indonesia":"Lihat asli");});controls.addView(originalButton,new LinearLayout.LayoutParams(0,dp(48),1));root.addView(controls);
  message("Unduh model bahasa sekali. Setelah itu, mode dasar bisa tanpa internet untuk file.");
  translator.downloadModelIfNeeded(new DownloadConditions.Builder().build()).addOnSuccessListener(v->{ready=true;message("Mode dasar siap · Inggris → Indonesia");if(automatic)changed();}).addOnFailureListener(e->message("Model bahasa belum terunduh. Buka menu → Unduh model dan periksa internet."));
  String shared=getIntent().getStringExtra(Intent.EXTRA_TEXT);String initial=shared!=null?shared:prefs.getString("url",home);address.setText(initial);open(initial);
 }
 private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private LinearLayout row(){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(8),0,dp(8),0);return r;}
 private TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(0xffe2e8f0);t.setTextSize(size);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
 private Button button(String s,View.OnClickListener click){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(11);b.setTextColor(0xffd9f99d);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff1e293b));b.setOnClickListener(click);return b;}
 private void message(String s){if(!destroyed)status.setText(s);}
 private void open(String s){s=s.trim();if(!s.startsWith("https://")){message("Gunakan tautan HTTPS yang lengkap.");return;}try{Uri u=Uri.parse(s);if(u.getHost()==null)throw new Exception();}catch(Exception e){message("Tautan belum benar.");return;}documentId=UUID.randomUUID().toString();fileMode=false;closePdf();changed();web.setVisibility(View.VISIBLE);local.setVisibility(View.GONE);web.loadUrl(s);prefs.edit().putString("url",s).apply();}
 private void changed(){generation++;emptyRetries=0;latestTranslations.clear();overlay.clear();main.removeCallbacks(settled);if(automatic&&!original)main.postDelayed(settled,1000);}
 private void translateViewport(){
  if(destroyed||original)return;if(busy){if(automatic)main.postDelayed(settled,700);return;}
  String endpoint=prefs.getString("server","");boolean ai=!endpoint.isEmpty();
  if(!ai&&!ready){message("Model bahasa sedang disiapkan. Periksa internet; coba menu Unduh model.");return;}
  View content=local.getVisibility()==View.VISIBLE?local:web;int w=content.getWidth(),h=content.getHeight();if(w<1||h<1)return;
  long ticket=++generation;busy=true;overlay.clear();overlay.setVisibility(View.VISIBLE);message("Membaca teks pada bagian yang terlihat…");
  float scale=(float)Math.min(Math.min(3f,2048f/w),Math.sqrt(8000000.0/((double)w*h)));Bitmap frame;try{frame=Bitmap.createBitmap(Math.max(1,(int)(w*scale)),Math.max(1,(int)(h*scale)),Bitmap.Config.ARGB_8888);}catch(OutOfMemoryError e){busy=false;message("Memori HP penuh. Tutup tab lain atau baca bagian yang lebih kecil.");return;}final Bitmap shot=frame;Canvas canvas=new Canvas(shot);canvas.scale(scale,scale);content.draw(canvas);
  ocr.process(InputImage.fromBitmap(shot,0)).addOnSuccessListener(result->{
   if(destroyed||ticket!=generation){shot.recycle();busy=false;if(automatic&&!destroyed)main.postDelayed(settled,500);return;}
   ArrayList<String> texts=new ArrayList<>();sourceCaps=new ArrayList<>();ArrayList<RectF> boxes=new ArrayList<>();ArrayList<Integer> colors=new ArrayList<>();
   ArrayList<Text.TextBlock> ordered=new ArrayList<>(result.getTextBlocks());ordered.sort((a,b)->{Rect ra=a.getBoundingBox(),rb=b.getBoundingBox();return ra==null||rb==null?0:Integer.compare(ra.top,rb.top);});
   for(Text.TextBlock block:ordered){
    String text=block.getText().replace('\n',' ').replaceAll("\\s+"," ").trim();Rect r=block.getBoundingBox();
    if(r==null||text.length()<3||!text.matches("(?s).*[a-zA-Z].*")||r.width()<10||r.height()<8)continue;
    texts.add(text);sourceCaps.add(text.replaceAll("[^A-Za-z]","").length()>=3&&text.equals(text.toUpperCase(java.util.Locale.ROOT)));RectF rect=new RectF(r);rect.inset(-5*scale,-4*scale);rect.left=Math.max(0,rect.left/scale);rect.right=Math.min(w,rect.right/scale);rect.top=Math.max(0,rect.top/scale);rect.bottom=Math.min(h,rect.bottom/scale);boxes.add(rect);colors.add(background(shot,r));
    if(texts.size()>=40)break;
   }
   shot.recycle();if(texts.isEmpty()){busy=false;if(automatic&&emptyRetries++<2)main.postDelayed(settled,1800);message("Belum ada teks terbaca. Perbesar gambar, tunggu gambar muncul, lalu coba lagi.");return;}
   message(ai?"Menerjemahkan dialog dengan AI…":"Menerjemahkan di HP…");
   if(ai){translateAi(endpoint,texts,boxes,colors,ticket);return;}
   ArrayList<String> translated=new ArrayList<>(Collections.nCopies(texts.size(),""));int[] remaining={texts.size()},failures={0};
   for(int i=0;i<texts.size();i++){final int at=i;String source=texts.get(i);String found=cache.get(source);
    if(found!=null){translated.set(at,found);if(--remaining[0]==0)finish(translated,boxes,colors,ticket,failures[0]);continue;}
    translator.translate(source).addOnSuccessListener(t->{cache.put(source,t);translated.set(at,t);}).addOnFailureListener(e->failures[0]++).addOnCompleteListener(t->{if(--remaining[0]==0)finish(translated,boxes,colors,ticket,failures[0]);});
   }
  }).addOnFailureListener(e->{shot.recycle();if(ticket==generation){busy=false;message("Teks belum terbaca. Coba gambar yang lebih jelas atau bagian lain.");}});
 }
 private int background(Bitmap b,Rect r){HashMap<Integer,Integer> hist=new HashMap<>();for(int x=r.left-6;x<=r.right+6;x+=3)for(int y=r.top-6;y<=r.bottom+6;y+=3){if(x<0||y<0||x>=b.getWidth()||y>=b.getHeight())continue;if(x>r.left+1&&x<r.right-1&&y>r.top+1&&y<r.bottom-1)continue;int c=b.getPixel(x,y);int key=((Color.red(c)/16)<<8)|((Color.green(c)/16)<<4)|(Color.blue(c)/16);hist.put(key,hist.getOrDefault(key,0)+1);}int key=0xfff,count=0;for(Map.Entry<Integer,Integer> e:hist.entrySet())if(e.getValue()>count){count=e.getValue();key=e.getKey();}if(key==0xfff)return Color.WHITE;if(key==0)return Color.BLACK;return Color.rgb(((key>>8)&15)*16+7,((key>>4)&15)*16+7,(key&15)*16+7);}
 private void finish(List<String> translated,List<RectF> boxes,List<Integer> colors,long ticket,int failed){if(destroyed)return;if(ticket!=generation){busy=false;if(automatic)main.postDelayed(settled,500);return;}busy=false;latestTranslations=new ArrayList<>(translated);ArrayList<BubbleOverlay.Bubble> results=new ArrayList<>();for(int i=0;i<translated.size();i++)if(!translated.get(i).isEmpty()){boolean caps=i<sourceCaps.size()&&sourceCaps.get(i);results.add(new BubbleOverlay.Bubble(boxes.get(i),caps?translated.get(i).toUpperCase(new java.util.Locale("id")):translated.get(i),colors.get(i),caps));}overlay.show(results);message(results.size()+" bagian diterjemahkan"+(failed>0?" · sebagian gagal, coba lagi":" · ketuk Lihat asli untuk membandingkan"));}
 private void translateAi(String endpoint,List<String> texts,List<RectF> boxes,List<Integer> colors,long ticket){String token=prefs.getString("token",""), doc=documentId;io.execute(()->{try{HttpsURLConnectionHelper reply=new HttpsURLConnectionHelper(endpoint,token,texts,doc);List<String> out=reply.result;main.post(()->finish(out,boxes,colors,ticket,0));}catch(Exception e){main.post(()->{busy=false;if(ticket==generation){message("Server AI belum bisa dipakai. Periksa pengaturan atau kosongkan server untuk mode dasar.");}});}});}
 private static class HttpsURLConnectionHelper { List<String> result=new ArrayList<>();HttpsURLConnectionHelper(String endpoint,String token,List<String> texts,String documentId)throws Exception{
  URL url=new URL(endpoint);if(!safeServer(endpoint))throw new IOException();HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(120000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Authorization","Bearer "+token);byte[] payload=new JSONObject().put("documentId",documentId).put("texts",new JSONArray(texts)).toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);try(OutputStream out=c.getOutputStream()){out.write(payload);}try{if(c.getResponseCode()!=200)throw new IOException();ByteArrayOutputStream body=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){body.write(buf,0,n);if(body.size()>200000)throw new IOException();}}JSONArray translated=new JSONObject(body.toString("UTF-8")).getJSONArray("translations");if(translated.length()!=texts.size())throw new IOException();for(int i=0;i<translated.length();i++){String t=translated.getString(i);if(t.length()>10000)throw new IOException();result.add(t);}}finally{c.disconnect();}
 }}
 private void chooseFile(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","application/pdf","text/plain"});i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,41);}
 @Override protected void onActivityResult(int req,int code,Intent data){super.onActivityResult(req,code,data);if(req!=41||code!=RESULT_OK||data==null)return;Uri uri=data.getData();documentId=UUID.randomUUID().toString();changed();closePdf();String type=getContentResolver().getType(uri);try{
  if("application/pdf".equals(type)){pdfFile=getContentResolver().openFileDescriptor(uri,"r");pdf=new PdfRenderer(pdfFile);page=0;showPdf();return;}
  if("text/plain".equals(type)){byte[] bytes=readLimited(uri,2*1024*1024);String text=new String(bytes,java.nio.charset.StandardCharsets.UTF_8);web.setVisibility(View.VISIBLE);local.setVisibility(View.GONE);web.loadDataWithBaseURL("https://reader.invalid/","<html><meta name='viewport' content='width=device-width'><body style='padding:18px;font:20px/1.8 sans-serif;white-space:pre-wrap'>"+android.text.TextUtils.htmlEncode(text)+"</body></html>","text/html","UTF-8",null);return;}
  BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,bounds);}if(bounds.outWidth<1||bounds.outHeight<1)throw new IOException();BitmapFactory.Options options=new BitmapFactory.Options();while(bounds.outWidth/Math.max(1,options.inSampleSize)>2048||bounds.outHeight/Math.max(1,options.inSampleSize)>16000||(long)(bounds.outWidth/Math.max(1,options.inSampleSize))*(bounds.outHeight/Math.max(1,options.inSampleSize))>8000000)options.inSampleSize=options.inSampleSize==0?2:options.inSampleSize*2;
  Bitmap image;try(InputStream in=getContentResolver().openInputStream(uri)){image=BitmapFactory.decodeStream(in,null,options);}if(image==null)throw new IOException();showImage(image);message("File siap. Geser gambar lalu tekan Terjemahkan.");
 }catch(Exception|OutOfMemoryError e){message("File belum dapat dibuka. Pilih JPG, PNG, WebP, PDF atau TXT yang lebih kecil.");}}
 private byte[] readLimited(Uri uri,int max)throws IOException{try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>max)throw new IOException();}return out.toByteArray();}}
 private void showImage(Bitmap image){changed();message("Membuka gambar…");io.execute(()->{try{File file=new File(getCacheDir(),"reader.png");try(OutputStream out=new FileOutputStream(file)){image.compress(Bitmap.CompressFormat.PNG,100,out);}image.recycle();main.post(()->{if(destroyed)return;fileMode=true;web.setVisibility(View.VISIBLE);local.setVisibility(View.GONE);web.loadDataWithBaseURL("https://reader.invalid/","<html><head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=6, user-scalable=yes\"></head><body style=\"margin:0;background:#fff\"><img src=\"https://reader.invalid/image.png\" style=\"width:100%;height:auto\"></body></html>","text/html","UTF-8",null);});}catch(Exception e){main.post(()->message("Gambar gagal dibuka."));}});}
 private void showPdf(){if(pdf==null)return;try(PdfRenderer.Page p=pdf.openPage(page)){int width=1400,height=Math.round(width*(float)p.getHeight()/p.getWidth());if(height>12000)throw new IOException();Bitmap b=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);new Canvas(b).drawColor(Color.WHITE);p.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);showImage(b);message("PDF halaman "+(page+1)+"/"+pdf.getPageCount()+" · pindah halaman lewat menu ⋮");}catch(Exception e){message("Halaman PDF gagal dibuka.");}}
 private void closePdf(){if(pdf!=null){pdf.close();pdf=null;}if(pdfFile!=null){try{pdfFile.close();}catch(Exception ignored){}pdfFile=null;}}
 private void showResults(){new AlertDialog.Builder(this).setTitle("Hasil terjemahan").setMessage(latestTranslations.isEmpty()?"Belum ada hasil. Buka komik lalu tunggu setelah berhenti menggulir.":android.text.TextUtils.join("\n\n",latestTranslations)).setPositiveButton("Tutup",null).show();}
 private void settings(){String[] items={"Pengaturan terjemahan AI","Unduh model bahasa","PDF: halaman sebelumnya","PDF: halaman berikutnya","Cara pakai","Buka contoh komik"};new AlertDialog.Builder(this).setTitle("KomikLingo").setItems(items,(d,n)->{switch(n){case 0:aiSettings();break;case 1:message("Mengunduh model…");translator.downloadModelIfNeeded().addOnSuccessListener(v->{ready=true;message("Model Inggris–Indonesia siap.");}).addOnFailureListener(e->message("Unduhan gagal. Periksa internet lalu coba lagi."));break;case 2:if(pdf!=null&&page>0){page--;showPdf();}break;case 3:if(pdf!=null&&page+1<pdf.getPageCount()){page++;showPdf();}break;case 4:new AlertDialog.Builder(this).setTitle("Baca dalam bahasa Indonesia").setMessage("1. Tempel tautan HTTPS atau pilih File.\n2. Tekan Terjemahkan untuk bagian layar yang terlihat.\n3. Aktifkan Otomatis agar aplikasi membaca ulang setelah kamu berhenti menggulir.\n4. Tekan Lihat asli untuk membandingkan.\n\nMode dasar diproses di HP setelah model diunduh; hasil bisa kaku. Mode AI memerlukan server sendiri.\n\nHuruf kecil, teks miring, warna dan efek komik bisa salah dibaca. Perbesar gambar jika perlu. Terjemahan menutup area teks yang terdeteksi; gambar asli tidak diubah. Situs yang memblokir WebView mungkin perlu dibaca melalui file. Foto/gambar di situs tetap memerlukan internet.").setPositiveButton("Mengerti",null).show();break;case 5:address.setText(home);open(home);}}).show();}
 private static boolean safeServer(String value){try{URL u=new URL(value);return u.getProtocol().equals("https")||(u.getProtocol().equals("http")&&(u.getHost().equals("127.0.0.1")||u.getHost().equals("localhost")));}catch(Exception e){return false;}}
 private void aiSettings(){LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(20),dp(8),dp(20),0);EditText url=new EditText(this);url.setHint("https://server-kamu/translate");url.setText(prefs.getString("server",""));url.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);form.addView(url);EditText token=new EditText(this);token.setHint("Kode akses server AI");token.setText(prefs.getString("token",""));token.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);form.addView(token);new AlertDialog.Builder(this).setTitle("AI untuk dialog lebih alami").setMessage("AI gratis memerlukan komputer sendiri dengan Ollama. Teks yang terbaca dikirim ke komputer itu. Kosongkan alamat untuk memakai mode dasar di HP.").setView(form).setPositiveButton("Simpan",(d,w)->{String s=url.getText().toString().trim();if(!s.isEmpty()&&!safeServer(s)){message("Gunakan HTTPS, atau http://127.0.0.1:8765/translate lewat USB.");return;}prefs.edit().putString("server",s).putString("token",token.getText().toString()).apply();changed();message(s.isEmpty()?"Mode dasar dipilih.":"Mode AI dipilih. Teks OCR akan dikirim ke server.");}).setNegativeButton("Batal",null).show();}
 @Override public void onBackPressed(){if(web.getVisibility()==View.VISIBLE&&web.canGoBack()){changed();web.goBack();}else super.onBackPressed();}
 @Override protected void onDestroy(){destroyed=true;main.removeCallbacksAndMessages(null);ocr.close();translator.close();closePdf();fileMode=false;new File(getCacheDir(),"reader.png").delete();web.destroy();io.shutdownNow();super.onDestroy();}
}
