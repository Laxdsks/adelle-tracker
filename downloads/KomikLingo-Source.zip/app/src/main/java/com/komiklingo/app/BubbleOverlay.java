package com.komiklingo.app;

import android.content.Context;
import android.graphics.*;
import android.text.*;
import android.view.View;
import java.util.*;

/** Draws only OCR text rectangles. Coordinates refer to the captured viewport. */
public final class BubbleOverlay extends View {
 public static final class Bubble { public RectF box; public String text; public int color; public boolean bold; public Bubble(RectF b,String t,int c,boolean weight){box=b;text=t;color=c;bold=weight;} }
 private final ArrayList<Bubble> bubbles=new ArrayList<>();
 private final Paint fill=new Paint(Paint.ANTI_ALIAS_FLAG);
 private final TextPaint text=new TextPaint(Paint.ANTI_ALIAS_FLAG);
 public BubbleOverlay(Context c){super(c);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
 public void show(List<Bubble> next){bubbles.clear();bubbles.addAll(next);invalidate();}
 public void clear(){bubbles.clear();invalidate();}
 @Override protected void onDraw(Canvas c){
  for(Bubble b:bubbles){
   RectF r=b.box;fill.setColor(b.color);c.drawRoundRect(r,3,3,fill);
   double light=.2126*Color.red(b.color)+.7152*Color.green(b.color)+.0722*Color.blue(b.color);
   text.setColor(light>140?Color.rgb(24,24,28):Color.WHITE);text.setTypeface(Typeface.create(b.bold?"sans-serif-condensed":"sans-serif",b.bold?Typeface.BOLD:Typeface.NORMAL));
   int w=Math.max(1,(int)r.width()-8);StaticLayout layout=null;
   float low=5,high=Math.min(38,r.height()*.6f);
   for(int i=0;i<12;i++){float size=(low+high)/2;text.setTextSize(size);StaticLayout trial=layout(b.text,w);if(trial.getHeight()<=r.height()-6)low=size;else high=size;}
   text.setTextSize(low);layout=layout(b.text,w);
   if(layout.getHeight()>r.height()-6){text.setTextSize(8);layout=layout("Lihat Hasil",w);}
   c.save();c.clipRect(r);c.translate(r.left+4,r.top+Math.max(2,(r.height()-layout.getHeight())/2));layout.draw(c);c.restore();
  }
 }
 private StaticLayout layout(String s,int width){StaticLayout.Builder b=StaticLayout.Builder.obtain(s,0,s.length(),text,width).setAlignment(Layout.Alignment.ALIGN_CENTER).setIncludePad(false);if(android.os.Build.VERSION.SDK_INT>=29)b.setBreakStrategy(android.graphics.text.LineBreaker.BREAK_STRATEGY_HIGH_QUALITY);return b.build();}
}
