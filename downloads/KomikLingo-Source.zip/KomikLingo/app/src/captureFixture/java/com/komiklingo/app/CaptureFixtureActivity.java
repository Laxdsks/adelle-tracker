package com.komiklingo.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.webkit.*;
import android.widget.*;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.util.concurrent.CountDownLatch;

/** Offline image fixture for the GPU capture regression, never part of a release build. */
public class CaptureFixtureActivity extends Activity {
 public WebView reader;
 public final CountDownLatch ready=new CountDownLatch(1);
 @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON|android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|android.view.WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
  TextView header=new TextView(this);header.setText("PRIVATE HEADER");header.setTextSize(30);root.addView(header,new LinearLayout.LayoutParams(-1,96));
  reader=new WebView(this);root.addView(reader,new LinearLayout.LayoutParams(-1,0,1));
  TextView footer=new TextView(this);footer.setText("PRIVATE FOOTER");footer.setTextSize(30);root.addView(footer,new LinearLayout.LayoutParams(-1,96));setContentView(root);
  Bitmap image=Bitmap.createBitmap(900,3000,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(image);c.drawColor(Color.WHITE);
  Paint ink=new Paint(Paint.ANTI_ALIAS_FLAG);ink.setColor(Color.BLACK);ink.setTextSize(66);ink.setTypeface(Typeface.create("casual",Typeface.BOLD));
  c.drawText("...IF THAT HAPPENS",65,180,ink);
  c.drawText("I DON'T THINK I'D HAVE",50,1900,ink);c.drawText("A REASON TO EXIST IN",55,1990,ink);c.drawText("THIS WORLD EITHER.",65,2080,ink);
  ByteArrayOutputStream bytes=new ByteArrayOutputStream();image.compress(Bitmap.CompressFormat.PNG,100,bytes);image.recycle();
  reader.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView w,String url){w.postVisualStateCallback(1,new WebView.VisualStateCallback(){@Override public void onComplete(long id){ready.countDown();}});}});
  reader.loadDataWithBaseURL("https://reader.invalid/","<html><meta name='viewport' content='width=device-width, initial-scale=1'><body style='margin:0'><img style='width:100%' src='data:image/png;base64,"+Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP)+"'></body></html>","text/html","UTF-8",null);
 }
 @Override public void onDestroy(){reader.destroy();super.onDestroy();}
}
