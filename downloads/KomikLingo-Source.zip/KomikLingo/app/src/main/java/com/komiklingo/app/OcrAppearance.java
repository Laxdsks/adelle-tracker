package com.komiklingo.app;

import android.graphics.*;
import com.google.mlkit.vision.text.Text;
import java.util.*;

/** Estimates visible ink and type size from OCR glyph regions, not the entire picture. */
public final class OcrAppearance {
 public static final class Paragraph {
  public final String source;public final Rect bounds;public final int background,ink;
  public final float sourceSize;public final boolean leftAligned;
  Paragraph(String source,Rect bounds,int background,int ink,float sourceSize,boolean leftAligned){this.source=source;this.bounds=bounds;this.background=background;this.ink=ink;this.sourceSize=sourceSize;this.leftAligned=leftAligned;}
 }
 public static List<Paragraph> paragraphs(Bitmap bitmap,Text.TextBlock block){return paragraphs(bitmap,block,Collections.emptyList());}
 public static List<Paragraph> paragraphs(Bitmap bitmap,Text.TextBlock block,List<String> names){
  List<Text.Line> lines=new ArrayList<>(block.getLines());List<Paragraph> result=new ArrayList<>();
  lines.removeIf(line->line.getBoundingBox()==null||line.getText().trim().isEmpty());
  lines.sort(Comparator.comparingInt(line->line.getBoundingBox().top));if(lines.isEmpty())return result;
  List<Integer> heights=new ArrayList<>();for(Text.Line line:lines)heights.add(line.getBoundingBox().height());Collections.sort(heights);float median=heights.get(heights.size()/2);
  List<Text.Line> current=new ArrayList<>();Text.Line previous=null;
  for(Text.Line line:lines){
   if(previous!=null&&line.getBoundingBox().top-previous.getBoundingBox().bottom>Math.max(8,median*.9f)){result.add(describe(bitmap,current,names));current=new ArrayList<>();}
   current.add(line);previous=line;
  }
  if(!current.isEmpty())result.add(describe(bitmap,current,names));return result;
 }
 private static Paragraph describe(Bitmap bitmap,List<Text.Line> lines,List<String> names){
  Rect bounds=new Rect(lines.get(0).getBoundingBox());List<String> source=new ArrayList<>();List<Rect> glyphs=new ArrayList<>();List<Integer> heights=new ArrayList<>();
  float minLeft=Float.MAX_VALUE,maxLeft=-1,minCenter=Float.MAX_VALUE,maxCenter=-1;
  for(Text.Line line:lines){Rect r=line.getBoundingBox();bounds.union(r);source.add(line.getText());heights.add(r.height());minLeft=Math.min(minLeft,r.left);maxLeft=Math.max(maxLeft,r.left);minCenter=Math.min(minCenter,r.exactCenterX());maxCenter=Math.max(maxCenter,r.exactCenterX());for(Text.Element element:line.getElements())if(element.getBoundingBox()!=null)glyphs.add(element.getBoundingBox());}
  Collections.sort(heights);float size=heights.get(heights.size()/2)*1.30f;
  int background=background(bitmap,bounds);int ink=foreground(bitmap,glyphs,background);
  boolean left=lines.size()>1&&maxLeft-minLeft<Math.max(5,size*.3f)&&maxCenter-minCenter>size*.3f;
  return new Paragraph(ReadingText.joinLines(source,names),bounds,background,ink,size,left);
 }
 public static int background(Bitmap bitmap,Rect bounds){
  Map<Integer,Integer> histogram=new HashMap<>();
  int step=Math.max(1,Math.min(bounds.width(),bounds.height())/50);
  for(int x=bounds.left-5;x<=bounds.right+5;x+=step)for(int y=bounds.top-5;y<=bounds.bottom+5;y+=step){
   if(x<0||y<0||x>=bitmap.getWidth()||y>=bitmap.getHeight()||(x>bounds.left&&x<bounds.right&&y>bounds.top&&y<bounds.bottom))continue;
   count(histogram,bitmap.getPixel(x,y));
  }
  return dominant(histogram,Color.WHITE);
 }
 public static int foreground(Bitmap bitmap,List<Rect> glyphs,int background){
  Map<Integer,Integer> histogram=new HashMap<>();
  for(Rect glyph:glyphs){Rect r=new Rect(glyph);if(!r.intersect(0,0,bitmap.getWidth(),bitmap.getHeight()))continue;
   int step=Math.max(1,(int)Math.sqrt(Math.max(1,(long)r.width()*r.height()/5000)));
   for(int y=r.top;y<r.bottom;y+=step)for(int x=r.left;x<r.right;x+=step){int color=bitmap.getPixel(x,y);if((contrast(color,background)>=1.55||chroma(color)>80)&&distance(color,background)>55)count(histogram,color);}
  }
  int fallback=luminance(background)>.4?Color.rgb(24,24,28):Color.WHITE;
  int ink=dominant(histogram,fallback);return contrast(ink,background)<1.55&&chroma(ink)<=80?fallback:ink;
 }
 private static void count(Map<Integer,Integer> histogram,int color){int key=((Color.red(color)/16)<<8)|((Color.green(color)/16)<<4)|(Color.blue(color)/16);histogram.put(key,histogram.getOrDefault(key,0)+1);}
 private static int dominant(Map<Integer,Integer> histogram,int fallback){int best=-1,count=0;for(var item:histogram.entrySet())if(item.getValue()>count){count=item.getValue();best=item.getKey();}if(best<0)return fallback;if(best==0xfff)return Color.WHITE;if(best==0)return Color.BLACK;return Color.rgb(((best>>8)&15)*16+8,((best>>4)&15)*16+8,(best&15)*16+8);}
 private static int chroma(int color){return Math.max(Color.red(color),Math.max(Color.green(color),Color.blue(color)))-Math.min(Color.red(color),Math.min(Color.green(color),Color.blue(color)));}
 private static int distance(int a,int b){return Math.max(Math.abs(Color.red(a)-Color.red(b)),Math.max(Math.abs(Color.green(a)-Color.green(b)),Math.abs(Color.blue(a)-Color.blue(b))));}
 private static double linear(int channel){double s=channel/255.0;return s<=.04045?s/12.92:Math.pow((s+.055)/1.055,2.4);}
 private static double luminance(int color){return .2126*linear(Color.red(color))+.7152*linear(Color.green(color))+.0722*linear(Color.blue(color));}
 static double contrast(int a,int b){double la=luminance(a),lb=luminance(b);return (Math.max(la,lb)+.05)/(Math.min(la,lb)+.05);}
}
