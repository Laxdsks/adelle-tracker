package com.komiklingo.app;

import android.content.Context;
import android.graphics.*;
import android.text.*;
import android.text.style.LineHeightSpan;
import android.view.View;
import java.util.*;

/** Fits legible text once per result, preserving estimated source color, size and paragraph spacing. */
public final class BubbleOverlay extends View {
 public static final class Appearance {
  public final int ink;public final float sourceSize;public final boolean leftAligned;
  public Appearance(int ink,float sourceSize,boolean leftAligned){this.ink=ink;this.sourceSize=sourceSize;this.leftAligned=leftAligned;}
 }
 public static final class Bubble {
  public final RectF box;public final String text;public final int color;public final boolean bold;public final Appearance appearance;
  public Bubble(RectF box,String text,int color,boolean bold){this(box,text,color,bold,null);}
  public Bubble(RectF box,String text,int color,boolean bold,Appearance appearance){this.box=new RectF(box);this.text=text;this.color=color;this.bold=bold;this.appearance=appearance;}
 }
 static final class Rendered {
  final Bubble bubble;final StaticLayout layout;final float padding;final boolean overflow;
  Rendered(Bubble bubble,StaticLayout layout,float padding,boolean overflow){this.bubble=bubble;this.layout=layout;this.padding=padding;this.overflow=overflow;}
 }
 private static final class ParagraphGap implements LineHeightSpan {
  private final int end,gap;ParagraphGap(int end,int gap){this.end=end;this.gap=gap;}
  @Override public void chooseHeight(CharSequence text,int start,int end,int spanstartv,int v,Paint.FontMetricsInt fm){if(end>=this.end){fm.descent+=gap;fm.bottom=Math.max(fm.bottom,fm.descent);}}
 }
 private final ArrayList<Rendered> rendered=new ArrayList<>();
 private final Paint fill=new Paint(Paint.ANTI_ALIAS_FLAG);
 public BubbleOverlay(Context context){super(context);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
 public void show(List<Bubble> next){rendered.clear();for(Bubble bubble:next)rendered.add(fit(bubble));invalidate();}
 public void clear(){rendered.clear();invalidate();}
 private Rendered fit(Bubble bubble){
  RectF r=bubble.box;float density=getResources().getDisplayMetrics().scaledDensity;
  float padding=Math.min(5*density,Math.max(1,Math.min(r.width(),r.height())*.035f));
  int width=Math.max(1,(int)(r.width()-padding*2));float height=Math.max(1,r.height()-padding*2);
  float minimum=9*density;
  // Remove the old 38-pixel cap: large original lettering keeps its relative emphasis.
  float desired=bubble.appearance==null?Math.min(r.height()*.65f,28*density):bubble.appearance.sourceSize*1.10f;
  desired=Math.max(minimum,desired);StaticLayout smallest=layout(bubble,width,minimum,false);
  if(!fits(smallest,height,width))return new Rendered(bubble,layout(bubble,width,minimum,true),padding,true);
  float low=minimum,high=desired;for(int i=0;i<13;i++){float size=(low+high)/2;if(fits(layout(bubble,width,size,false),height,width))low=size;else high=size;}
  return new Rendered(bubble,layout(bubble,width,low,false),padding,false);
 }
 private boolean fits(StaticLayout layout,float height,int width){if(layout.getHeight()>height)return false;for(int i=0;i<layout.getLineCount();i++)if(layout.getLineWidth(i)>width+.5f)return false;return true;}
 private StaticLayout layout(Bubble bubble,int width,float size,boolean badge){
  TextPaint paint=new TextPaint(Paint.ANTI_ALIAS_FLAG);paint.setTextSize(size);paint.setTypeface(Typeface.create(bubble.bold?"sans-serif-condensed":"sans-serif",bubble.bold?Typeface.BOLD:Typeface.NORMAL));
  double light=.2126*Color.red(bubble.color)+.7152*Color.green(bubble.color)+.0722*Color.blue(bubble.color);
  paint.setColor(bubble.appearance==null?(light>140?Color.rgb(24,24,28):Color.WHITE):bubble.appearance.ink);
  if(OcrAppearance.contrast(paint.getColor(),bubble.color)<3)paint.setShadowLayer(Math.max(1,size*.045f),0,0,light>140?Color.BLACK:Color.WHITE);
  String[] paragraphs=ReadingText.paragraphs(badge?"Hasil ↗":bubble.text).split("\\n\\n");SpannableStringBuilder text=new SpannableStringBuilder();
  for(int i=0;i<paragraphs.length;i++){int start=text.length();text.append(paragraphs[i]);if(i+1<paragraphs.length){text.append('\n');text.setSpan(new ParagraphGap(text.length(),Math.round(size*.38f)),start,text.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}}
  StaticLayout.Builder builder=StaticLayout.Builder.obtain(text,0,text.length(),paint,width).setAlignment(bubble.appearance!=null&&bubble.appearance.leftAligned?Layout.Alignment.ALIGN_NORMAL:Layout.Alignment.ALIGN_CENTER).setIncludePad(false).setLineSpacing(0,1.12f).setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE);
  if(android.os.Build.VERSION.SDK_INT>=29)builder.setBreakStrategy(android.graphics.text.LineBreaker.BREAK_STRATEGY_HIGH_QUALITY);
  return builder.build();
 }
 @Override protected void onDraw(Canvas canvas){
  for(Rendered item:rendered){RectF r=item.bubble.box;canvas.save();canvas.clipRect(r);
   if(item.overflow){
    // Keep the source visible when a translation cannot fit at a legible size.
    float height=Math.min(r.height(),item.layout.getHeight()+item.padding*2);RectF badge=new RectF(r.left,r.bottom-height,r.right,r.bottom);fill.setColor(item.bubble.color);canvas.drawRoundRect(badge,3,3,fill);canvas.translate(r.left+item.padding,badge.top+item.padding);
   }else{fill.setColor(item.bubble.color);canvas.drawRoundRect(r,3,3,fill);canvas.translate(r.left+item.padding,r.top+Math.max(item.padding,(r.height()-item.layout.getHeight())/2));}
   item.layout.draw(canvas);canvas.restore();
  }
 }
}
