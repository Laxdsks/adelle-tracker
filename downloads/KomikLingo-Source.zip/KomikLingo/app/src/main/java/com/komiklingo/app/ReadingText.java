package com.komiklingo.app;

import java.util.*;
import java.util.regex.*;

/** Conservative OCR cleanup and an explicit reading register, not a story-understanding model. */
public final class ReadingText {
 public static final String DIALOGUE="dialogue", NEUTRAL="neutral", FORMAL="formal";
 private static final Pattern MERGED_I=Pattern.compile("\\b(AFTER|BEFORE|WHEN|IF|SINCE|WHILE)I(?=\\s+(?:WENT|HAVE|HAD|GO|DID|WAS|AM|WILL|WOULD|DON['’]T|DIDN['’]T)\\b)",Pattern.CASE_INSENSITIVE);
 private static final Set<String> KNOWN=new HashSet<>(Arrays.asList("suddenly","everyone","everything","something","nothing","because","through","yourself","myself","anything"));
 public static String cleanOcr(String source){
  String s=source.replace('\u2019','\'').replaceAll("\\s+"," ").trim();
  s=MERGED_I.matcher(s).replaceAll("$1 I");
  Matcher words=Pattern.compile("[A-Za-z]+").matcher(s);StringBuffer out=new StringBuffer();
  while(words.find()){
   String word=words.group(),lower=word.toLowerCase(Locale.ROOT),candidate=lower;
   // Correct a duplicated final OCR letter only when it yields a known common word.
   if(lower.length()>6&&lower.charAt(lower.length()-1)==lower.charAt(lower.length()-2)&&KNOWN.contains(lower.substring(0,lower.length()-1)))candidate=lower.substring(0,lower.length()-1);
   if(candidate.equals(lower)&&lower.startsWith("fe")&&KNOWN.contains(lower.substring(1)))candidate=lower.substring(1);
   if(candidate.equals(lower)){words.appendReplacement(out,Matcher.quoteReplacement(word));continue;}
   if(word.equals(word.toUpperCase(Locale.ROOT)))candidate=candidate.toUpperCase(Locale.ROOT);
   else if(Character.isUpperCase(word.charAt(0)))candidate=Character.toUpperCase(candidate.charAt(0))+candidate.substring(1);
   words.appendReplacement(out,Matcher.quoteReplacement(candidate));
  }
  words.appendTail(out);return out.toString();
 }
 public static String style(String source,String target,String requested){
  if(target==null)return "";
  String style=requested;
  // A visible direct honorific is evidence to keep the basic engine's formal register.
  if(DIALOGUE.equals(style)&&Pattern.compile("\\b(?:your majesty|your highness|sir|madam)\\b",Pattern.CASE_INSENSITIVE).matcher(source).find())style=FORMAL;
  String result=target.trim();
  if(!FORMAL.equals(style))result=replaceWord(result,"anda","kamu");
  else result=replaceWord(result,"kamu","Anda");
  if(DIALOGUE.equals(style))result=replaceWord(result,"saya","aku");
  else result=replaceWord(result,"aku","saya");
  // Normalize duplicated OCR/engine whitespace, leaving emphasis and punctuation intact.
  return result.replaceAll("[ \\t]+"," ");
 }
 private static String replaceWord(String text,String from,String to){
  Matcher m=Pattern.compile("(?iu)(?<![\\p{L}\\p{N}_])"+from+"(?![\\p{L}\\p{N}_])").matcher(text);StringBuffer b=new StringBuffer();
  while(m.find()){String word=m.group(),replacement=to;if(word.equals(word.toUpperCase(Locale.ROOT)))replacement=to.toUpperCase(Locale.ROOT);else if(Character.isUpperCase(word.charAt(0))&&(text.substring(0,m.start()).trim().isEmpty()||text.substring(0,m.start()).matches("(?s).*[.!?:\\n][\\s\"“]*")))replacement=Character.toUpperCase(to.charAt(0))+to.substring(1);m.appendReplacement(b,Matcher.quoteReplacement(replacement));}
  m.appendTail(b);return b.toString();
 }
 public static List<String> splitBatch(String output,int expected){
  if(output==null)return null;String[] parts=output.trim().split("\\n\\s*\\n",-1);
  if(parts.length!=expected)return null;List<String> result=new ArrayList<>();
  for(String p:parts){if(p.trim().isEmpty())return null;result.add(p.trim());}return result;
 }
}
