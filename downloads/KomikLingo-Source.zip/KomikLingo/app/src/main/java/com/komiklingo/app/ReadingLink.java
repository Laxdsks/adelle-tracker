package com.komiklingo.app;

import java.net.URI;
import java.util.Locale;
import java.util.regex.*;

public final class ReadingLink {
 public static boolean isSearchPage(String url){try{String host=new URI(url).getHost();return host!=null&&(host.equalsIgnoreCase("duckduckgo.com")||host.equalsIgnoreCase("www.duckduckgo.com")||host.equalsIgnoreCase("html.duckduckgo.com"));}catch(Exception e){return false;}}
 public static String resolve(String input){
  if(input==null||input.trim().isEmpty()||input.length()>2000)throw new IllegalArgumentException();String s=input.trim();
  if(Pattern.compile("https?://",Pattern.CASE_INSENSITIVE).matcher(s).find())return normalize(s);
  if(s.matches("(?is)^(?:javascript|data|file|content|intent|mailto):.*")||s.contains("://"))throw new IllegalArgumentException();
  if(s.matches("(?i)^(?:[a-z0-9-]+\\.)+[a-z]{2,}(?::[0-9]+)?(?:[/#?][^\\s]*)?$"))return normalize(s);
  try{return "https://duckduckgo.com/?q="+java.net.URLEncoder.encode(s,"UTF-8")+"&ia=web";}catch(java.io.UnsupportedEncodingException impossible){throw new IllegalArgumentException(impossible);}
 }
 public static String displayAddress(String url){
  if(!isSearchPage(url))return url;
  try{String query=new URI(url).getRawQuery();if(query!=null)for(String part:query.split("&")){int equal=part.indexOf('=');if(equal>0&&part.substring(0,equal).equals("q"))return java.net.URLDecoder.decode(part.substring(equal+1),"UTF-8");}}catch(Exception ignored){}
  return "";
 }
 public static String normalize(String input){
  if(input==null)throw new IllegalArgumentException();String s=input.trim();
  Matcher link=Pattern.compile("https?://[^\\s<>\\\"]+",Pattern.CASE_INSENSITIVE).matcher(s);
  if(link.find())s=link.group();else if(s.contains("://")||s.contains(" ")||s.contains("\n"))throw new IllegalArgumentException();
  else s="https://"+s;
  while(s.endsWith(".")||s.endsWith(","))s=s.substring(0,s.length()-1);
  while(s.endsWith(")")&&count(s,')')>count(s,'('))s=s.substring(0,s.length()-1);
  if(s.regionMatches(true,0,"http://",0,7))s="https://"+s.substring(7);
  try{URI uri=new URI(s);String host=uri.getHost();if(!"https".equalsIgnoreCase(uri.getScheme())||host==null||host.isEmpty()||uri.getUserInfo()!=null||host.equalsIgnoreCase("reader.invalid"))throw new IllegalArgumentException();return uri.toASCIIString();}
  catch(java.net.URISyntaxException e){throw new IllegalArgumentException();}
 }
 private static int count(String text,char letter){int result=0;for(int i=0;i<text.length();i++)if(text.charAt(i)==letter)result++;return result;}
 public static String storyKey(String url){
  try{
   URI uri=new URI(url);String path=uri.getPath()==null?"":uri.getPath();
   Matcher m=Pattern.compile("(?i)^(.*?)/(?:chapters?|episodes?)(?:/|[-_])").matcher(path);
   if(m.find()){
    String prefix=m.group(1);
    if(!prefix.isEmpty()&&!java.util.Arrays.asList("/novel","/comic","/comics","/manga","/series","/reader").contains(prefix.toLowerCase(Locale.ROOT)))return uri.getHost().toLowerCase(Locale.ROOT)+prefix;
   }
   return uri.getHost().toLowerCase(Locale.ROOT)+path+(uri.getRawQuery()==null?"":"?"+uri.getRawQuery());
  }catch(Exception e){return "local";}
 }
}
