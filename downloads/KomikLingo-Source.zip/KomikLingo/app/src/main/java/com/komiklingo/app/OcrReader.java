package com.komiklingo.app;

import android.graphics.*;
import android.os.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.*;
import java.util.*;
import java.util.concurrent.Executor;
import java.util.function.BooleanSupplier;

/** One optional contrast retry for weak OCR. Always measures styles on the untouched screenshot. */
public final class OcrReader {
 public interface Result {void success(Text text);void failure(Exception error);}
 public static boolean weak(Text text){
  if(text.getText().replaceAll("[^A-Za-z]","").length()<5)return true;
  for(Text.TextBlock block:text.getTextBlocks())for(Text.Line line:block.getLines()){float c=line.getConfidence();if(c>0&&c<.65f)return true;}
  return false;
 }
 public static void read(TextRecognizer recognizer,Bitmap original,Executor worker,BooleanSupplier active,Result callback){
  recognizer.process(InputImage.fromBitmap(original,0)).addOnSuccessListener(first->{
   if(!active.getAsBoolean()||!weak(first)){callback.success(first);return;}
   worker.execute(()->{
    Bitmap enhanced;
    try{enhanced=contrast(original);}catch(OutOfMemoryError|RuntimeException error){new Handler(Looper.getMainLooper()).post(()->callback.success(first));return;}
    new Handler(Looper.getMainLooper()).post(()->{
     if(!active.getAsBoolean()){enhanced.recycle();callback.success(first);return;}
     recognizer.process(InputImage.fromBitmap(enhanced,0)).addOnSuccessListener(second->{enhanced.recycle();callback.success(merge(first,second));}).addOnFailureListener(error->{enhanced.recycle();callback.success(first);});
    });
   });
  }).addOnFailureListener(callback::failure);
 }
 public static Bitmap contrast(Bitmap source){
  Bitmap target=Bitmap.createBitmap(source.getWidth(),source.getHeight(),Bitmap.Config.ARGB_8888);ColorMatrix gray=new ColorMatrix();gray.setSaturation(0);
  ColorMatrix boost=new ColorMatrix(new float[]{1.65f,0,0,0,-55,0,1.65f,0,0,-55,0,0,1.65f,0,-55,0,0,0,1,0});gray.postConcat(boost);
  Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setColorFilter(new ColorMatrixColorFilter(gray));new Canvas(target).drawBitmap(source,0,0,paint);return target;
 }
 private static float quality(Text.TextBlock block){
  int length=block.getText().replaceAll("[^\\p{L}]","").length();float weighted=0,total=0;
  for(Text.Line line:block.getLines()){int chars=line.getText().length();weighted+=(line.getConfidence()>0?line.getConfidence():.5f)*chars;total+=chars;}
  return (total==0?.5f:weighted/total)*(float)Math.sqrt(length);
 }
 private static boolean overlaps(Rect a,Rect b){if(a==null||b==null)return false;Rect intersection=new Rect(a);return intersection.intersect(b)&&((long)intersection.width()*intersection.height())>.55*Math.min((long)a.width()*a.height(),(long)b.width()*b.height());}
 public static Text merge(Text first,Text second){
  List<Text.TextBlock> blocks=new ArrayList<>(first.getTextBlocks());
  for(Text.TextBlock candidate:second.getTextBlocks()){
   List<Text.TextBlock> matches=new ArrayList<>();float previous=0;
   for(Text.TextBlock block:blocks)if(overlaps(candidate.getBoundingBox(),block.getBoundingBox())){matches.add(block);previous+=quality(block);}
   if(matches.isEmpty()||quality(candidate)>previous*1.08f){blocks.removeAll(matches);blocks.add(candidate);}
  }
  blocks.sort(Comparator.comparingInt(block->block.getBoundingBox()==null?Integer.MAX_VALUE:block.getBoundingBox().top));StringBuilder content=new StringBuilder();for(Text.TextBlock block:blocks){if(content.length()>0)content.append('\n');content.append(block.getText());}return new Text(content.toString(),blocks);
 }
}
