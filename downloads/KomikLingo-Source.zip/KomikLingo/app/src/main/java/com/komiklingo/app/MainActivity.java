package com.komiklingo.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.graphics.*;
import android.graphics.pdf.PdfRenderer;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import android.util.LruCache;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.nl.translate.*;
import com.google.mlkit.common.model.DownloadConditions;
import org.json.*;
import java.util.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
 private final Handler main=new Handler(Looper.getMainLooper());
 private final ExecutorService io=Executors.newSingleThreadExecutor();
 private final TextRecognizer ocr=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
 private final Translator translator=Translation.getClient(new TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.INDONESIAN).build());
 private final LruCache<String,String> cache=new LruCache<>(400);
 private LinearLayout root,bar,controls;private ScrollView homeScreen;private boolean homeVisible=true,pageReady=false,restoring=false;private ReadingHistory history;private long pageVisit=0,restoreTicket=0;private float resumeCss=0;private String resumeUrl="",navigationUrl="";
 private final Runnable saveProgress=()->saveReadingPosition();private FrameLayout stage;private WebView web;private ScrollView local;
 private ImageView picture;private BubbleOverlay overlay;private EditText address;private TextView status;
 private Button autoButton,originalButton;private boolean automatic=false,original=false,ready=false,busy=false,destroyed=false;
 private boolean paused=false;private volatile boolean fileMode=false;private List<Boolean> sourceCaps=new ArrayList<>();private long generation=0;private int emptyRetries=0;private List<String> latestTranslations=new ArrayList<>();private PdfRenderer pdf;private ParcelFileDescriptor pdfFile;private int page=0;
 private final Runnable settled=()->translateViewport();
 private android.content.SharedPreferences prefs;
 private String activeStory="local";private List<String> readingSources=new ArrayList<>(),latestSources=new ArrayList<>();
 private List<ProtectedTerms.Plan> readingPlans=new ArrayList<>();
 private List<BubbleOverlay.Appearance> readingAppearance=new ArrayList<>();private int clippedText=0;
 private String documentId=UUID.randomUUID().toString();
 private String home="https://kaynscans.com/series/comic/chronicle-of-runes/chapter/48";
 @Override public void onCreate(Bundle state){super.onCreate(state);prefs=getSharedPreferences("reader",MODE_PRIVATE);automatic=prefs.getBoolean("automatic",true);history=new ReadingHistory(prefs);if(history.entries().isEmpty())history.record(prefs.getString("url",""),"",0,0);io.execute(()->{try{OcrQuality.load(getAssets().open("english-ocr-words.txt"));TessFallback.prepare(this);}catch(IOException ignored){}});
  getWindow().setStatusBarColor(Color.rgb(15,23,42));getWindow().setNavigationBarColor(Color.rgb(15,23,42));
  root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(15,23,42));
  root.setOnApplyWindowInsetsListener((v,in)->{v.setPadding(in.getSystemWindowInsetLeft(),in.getSystemWindowInsetTop(),in.getSystemWindowInsetRight(),in.getSystemWindowInsetBottom());return in;});setContentView(root);
  LinearLayout top=row();TextView brand=label("⌂ KomikLingo",16);brand.setTypeface(null,Typeface.BOLD);brand.setContentDescription("Beranda KomikLingo");brand.setOnClickListener(v->showHome());top.addView(brand,new LinearLayout.LayoutParams(0,dp(48),1));top.addView(button("Hasil",v->showResults()));top.addView(button("File",v->chooseFile()));top.addView(button("⋮",v->settings()));root.addView(top);
  bar=row();address=new EditText(this);address.setSingleLine();address.setSelectAllOnFocus(true);address.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);address.setOnEditorActionListener((v,action,event)->{if(action==android.view.inputmethod.EditorInfo.IME_ACTION_GO||action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH){open(address.getText().toString());return true;}return false;});address.setTextColor(Color.WHITE);address.setTextSize(12);address.setHintTextColor(0xff94a3b8);address.setHint("Cari komik di DuckDuckGo atau tempel tautan");address.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);bar.addView(address,new LinearLayout.LayoutParams(0,dp(48),1));Button clear=button("×",v->address.setText(""));clear.setContentDescription("Hapus alamat untuk membuka situs lain");bar.addView(clear,new LinearLayout.LayoutParams(dp(38),dp(48)));bar.addView(button("Cari",v->open(address.getText().toString())));root.addView(bar);
  stage=new FrameLayout(this);root.addView(stage,new LinearLayout.LayoutParams(-1,0,1));
  web=new WebView(this);WebSettings ws=web.getSettings();ws.setJavaScriptEnabled(true);ws.setDomStorageEnabled(true);ws.setAllowFileAccess(false);ws.setAllowContentAccess(false);ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);ws.setBuiltInZoomControls(true);ws.setUseWideViewPort(true);ws.setLoadWithOverviewMode(true);ws.setDisplayZoomControls(false);ws.setSupportMultipleWindows(false);
  web.setWebViewClient(new WebViewClient(){
   @Override public void onScaleChanged(WebView w,float old,float next){changed();}
   @Override public void onPageStarted(WebView w,String url,Bitmap icon){pageReady=false;main.removeCallbacks(saveProgress);pageVisit=System.currentTimeMillis();navigationUrl=url;if(!url.startsWith("https://reader.invalid/")){fileMode=false;updateStory(url);if(!homeVisible)history.record(url,"",restoring&&url.equals(resumeUrl)?resumeCss:0,pageVisit);}changed();}
   @Override public WebResourceResponse shouldInterceptRequest(WebView w,WebResourceRequest r){if(fileMode&&r.getUrl().toString().equals("https://reader.invalid/image.png")){try{return new WebResourceResponse("image/png",null,new FileInputStream(new File(getCacheDir(),"reader.png")));}catch(Exception ignored){}}return null;}
@Override public void onPageFinished(WebView w,String url){
   if(homeVisible||!url.equals(w.getUrl())||!url.equals(navigationUrl))return;pageReady=true;
   if(!fileMode){address.setText(ReadingLink.displayAddress(url));try{prefs.edit().putString("url",ReadingLink.normalize(url)).apply();}catch(IllegalArgumentException ignored){}if(restoring&&url.equals(resumeUrl))restorePosition(++restoreTicket,0);else{restoring=false;saveReadingPosition();}}
   else{address.setText("");address.setHint("File pribadi · cubit untuk zoom");}
   changed();message(ReadingLink.isSearchPage(url)?"Hasil DuckDuckGo · pilih situs untuk mulai membaca.":"Halaman siap. Berhenti menggulir sebentar untuk menerjemahkan.");}
@Override public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){String s=r.getUrl().getScheme();return !"https".equals(s)&&!"http".equals(s);}@Override public void onReceivedError(WebView w,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame())message("Halaman belum terbuka. Periksa internet atau buka tautan lain.");}});
  web.setOnScrollChangeListener((v,x,y,ox,oy)->{changed();main.removeCallbacks(saveProgress);if(!homeVisible&&!restoring)main.postDelayed(saveProgress,600);});web.setOnTouchListener((v,event)->{if(event.getActionMasked()==MotionEvent.ACTION_DOWN&&restoring){restoreTicket++;restoring=false;}return false;});stage.addView(web,new FrameLayout.LayoutParams(-1,-1));
  local=new ScrollView(this);local.setFillViewport(true);picture=new ImageView(this);picture.setAdjustViewBounds(true);picture.setScaleType(ImageView.ScaleType.FIT_CENTER);local.addView(picture,new ScrollView.LayoutParams(-1,-2));local.setVisibility(View.GONE);local.setOnScrollChangeListener((v,x,y,ox,oy)->changed());stage.addView(local,new FrameLayout.LayoutParams(-1,-1));
  overlay=new BubbleOverlay(this);stage.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
  status=label("Menyiapkan pembaca…",12);status.setPadding(dp(12),dp(7),dp(12),dp(7));root.addView(status);
  controls=row();controls.addView(button("Terjemahkan",v->{original=false;originalButton.setText("Lihat asli");translateViewport();}),new LinearLayout.LayoutParams(0,dp(48),1));autoButton=button(automatic?"Otomatis: aktif":"Otomatis: mati",v->{automatic=!automatic;prefs.edit().putBoolean("automatic",automatic).apply();autoButton.setText(automatic?"Otomatis: aktif":"Otomatis: mati");if(automatic)changed();});controls.addView(autoButton,new LinearLayout.LayoutParams(0,dp(48),1));originalButton=button("Lihat asli",v->{original=!original;overlay.setVisibility(original?View.INVISIBLE:View.VISIBLE);originalButton.setText(original?"Lihat Indonesia":"Lihat asli");});controls.addView(originalButton,new LinearLayout.LayoutParams(0,dp(48),1));root.addView(controls);
  message("Unduh model bahasa sekali. Setelah itu, mode dasar bisa tanpa internet untuk file.");
  translator.downloadModelIfNeeded(new DownloadConditions.Builder().build()).addOnSuccessListener(v->{ready=true;message("Mode dasar siap · Inggris → Indonesia");if(automatic)changed();}).addOnFailureListener(e->message("Model bahasa belum terunduh. Buka menu → Unduh model dan periksa internet."));
  String shared=getIntent().getStringExtra(Intent.EXTRA_TEXT);getIntent().removeExtra(Intent.EXTRA_TEXT);if(shared!=null&&!shared.trim().isEmpty())open(shared);else showHome();
 }
 private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private LinearLayout row(){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(8),0,dp(8),0);return r;}
 private TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(0xffe2e8f0);t.setTextSize(size);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
 private Button button(String s,View.OnClickListener click){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(11);b.setTextColor(0xffd9f99d);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff1e293b));b.setOnClickListener(click);return b;}
 private void message(String s){if(!destroyed)status.setText(s);}
 private void showReader(){homeVisible=false;if(homeScreen!=null)homeScreen.setVisibility(View.GONE);bar.setVisibility(View.VISIBLE);controls.setVisibility(View.VISIBLE);status.setVisibility(View.VISIBLE);web.setVisibility(View.VISIBLE);web.onResume();}
 private void showHome(){
  saveReadingPosition();homeVisible=true;restoreTicket++;restoring=false;main.removeCallbacks(saveProgress);main.removeCallbacks(settled);generation++;overlay.clear();web.stopLoading();web.onPause();web.setVisibility(View.GONE);local.setVisibility(View.GONE);bar.setVisibility(View.GONE);controls.setVisibility(View.GONE);status.setVisibility(View.GONE);
  if(homeScreen!=null)stage.removeView(homeScreen);homeScreen=new ScrollView(this);LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(20),dp(24),dp(20),dp(32));homeScreen.addView(page);stage.addView(homeScreen,new FrameLayout.LayoutParams(-1,-1));
  TextView title=label("Mau baca apa hari ini?",26);title.setTypeface(null,Typeface.BOLD);page.addView(title);TextView intro=label("Cari komik baru atau lanjutkan bacaanmu.",15);intro.setPadding(0,dp(8),0,dp(24));page.addView(intro);
  EditText query=new EditText(this);query.setSingleLine();query.setTextColor(Color.WHITE);query.setHintTextColor(0xff94a3b8);query.setHint("Judul komik atau tautan situs");query.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);query.setOnEditorActionListener((v,action,event)->{if(action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH){open(query.getText().toString());return true;}return false;});page.addView(query,new LinearLayout.LayoutParams(-1,dp(56)));page.addView(button("Cari komik / buka tautan",v->open(query.getText().toString())),new LinearLayout.LayoutParams(-1,dp(54)));
  List<ReadingHistory.Entry> entries=history.entries();if(!entries.isEmpty()){
   ReadingHistory.Entry latest=entries.get(0);TextView heading=label("Lanjutkan bacaan",19);heading.setTypeface(null,Typeface.BOLD);heading.setPadding(0,dp(28),0,dp(8));page.addView(heading);
   Button resume=button("Lanjutkan · "+latest.title,v->open(latest.url,latest.scroll));resume.setSingleLine(false);resume.setMaxLines(3);page.addView(resume,new LinearLayout.LayoutParams(-1,dp(80)));
   TextView listTitle=label("Riwayat bab",19);listTitle.setPadding(0,dp(24),0,dp(8));page.addView(listTitle);
   for(ReadingHistory.Entry entry:entries){Button chapter=button(entry.title,v->open(entry.url,entry.scroll));chapter.setSingleLine(false);chapter.setMaxLines(2);page.addView(chapter,new LinearLayout.LayoutParams(-1,dp(64)));}
  }else{TextView empty=label("Belum ada bacaan. Cari judul atau tempel tautan di atas untuk mulai.",16);empty.setPadding(0,dp(28),0,0);page.addView(empty);}
 }
 private void saveReadingPosition(){
  if(history==null||homeVisible||!pageReady||fileMode||restoring||web.getUrl()==null)return;float scale=Math.max(.1f,web.getScale());history.record(web.getUrl(),web.getTitle(),web.getScrollY()/scale,pageVisit);
 }
 private void restorePosition(long ticket,int attempt){
  if(destroyed||homeVisible||ticket!=restoreTicket||!restoring)return;
  web.postDelayed(()->{if(destroyed||homeVisible||ticket!=restoreTicket||!restoring)return;int wanted=Math.round(resumeCss*web.getScale());web.scrollTo(0,wanted);if(attempt<4&&Math.abs(web.getScrollY()-wanted)>8)restorePosition(ticket,attempt+1);else{restoring=false;saveReadingPosition();}},attempt==0?200:400);
 }
 private void open(String input){open(input,0);}
 private void open(String input,float scroll){
  String url;try{url=ReadingLink.resolve(input);}catch(IllegalArgumentException error){message("Ketik nama komik atau tautan situs yang benar.");android.widget.Toast.makeText(this,"Ketik nama komik atau tautan dulu.",android.widget.Toast.LENGTH_SHORT).show();return;}
  saveReadingPosition();showReader();pageReady=false;restoreTicket++;resumeUrl=url;navigationUrl=url;resumeCss=Math.max(0,scroll);restoring=resumeCss>0;pageVisit=System.currentTimeMillis();history.record(url,"",resumeCss,pageVisit);
  documentId=UUID.randomUUID().toString();updateStory(url);fileMode=false;closePdf();changed();local.setVisibility(View.GONE);address.setText(url);web.stopLoading();web.loadUrl(url);prefs.edit().putString("url",url).apply();
 }
 @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);String shared=intent.getStringExtra(Intent.EXTRA_TEXT);intent.removeExtra(Intent.EXTRA_TEXT);if(shared!=null&&!shared.trim().isEmpty())open(shared);else showHome();}
 private void updateStory(String url){try{String key=ReadingLink.storyKey(ReadingLink.normalize(url));if(!key.equals(activeStory)){activeStory=key;documentId=UUID.randomUUID().toString();}}catch(IllegalArgumentException ignored){}}
 private String readingStyle(){return prefs.getString("style:"+activeStory,ReadingText.DIALOGUE);}
 private void openAddressDialog(){EditText input=new EditText(this);input.setSingleLine();input.setHint("Nama komik, kata kunci, atau alamat situs");input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);new AlertDialog.Builder(this).setTitle("Cari komik dengan DuckDuckGo").setMessage("Ketik judul untuk mencari. Kalau berupa alamat situs, aplikasi langsung membukanya. Hasil pencarian tetap dibuka di KomikLingo.").setView(input).setPositiveButton("Cari / buka",(d,w)->open(input.getText().toString())).setNegativeButton("Batal",null).show();}
 private void styleSettings(){String[] titles={"Dialog akrab · aku–kamu","Netral · saya–kamu","Formal · saya–Anda"};String[] values={ReadingText.DIALOGUE,ReadingText.NEUTRAL,ReadingText.FORMAL};int selected=java.util.Arrays.asList(values).indexOf(readingStyle());new AlertDialog.Builder(this).setTitle("Gaya bahasa cerita ini").setSingleChoiceItems(titles,Math.max(0,selected),(d,n)->{prefs.edit().putString("style:"+activeStory,values[n]).apply();documentId=UUID.randomUUID().toString();changed();message("Gaya bahasa disimpan untuk cerita ini.");d.dismiss();}).setNegativeButton("Tutup",null).show();}
 private List<String> storyTerms(){
  String key="terms:"+activeStory;
  if(!prefs.getBoolean("names-seeded:"+activeStory,false)){
   List<String> existing=ProtectedTerms.parse(prefs.getString(key,""));
   for(String term:ProtectedTerms.defaults(activeStory))if(!containsTerm(existing,term)&&existing.size()<80)existing.add(term);
   prefs.edit().putString(key,android.text.TextUtils.join("\n",existing)).putBoolean("names-seeded:"+activeStory,true).apply();
  }
  return ProtectedTerms.parse(prefs.getString(key,""));
 }
 private static boolean containsTerm(List<String> terms,String term){for(String value:terms)if(value.equalsIgnoreCase(term))return true;return false;}
 private List<String> learnNames(List<String> texts){
  List<String> terms=storyTerms();
  if(prefs.getBoolean("auto-names:"+activeStory,true)){
   Set<String> ignored=prefs.getStringSet("ignored-terms:"+activeStory,Collections.emptySet());
   for(String name:ProtectedTerms.discover(texts))if(terms.size()<80&&!containsTerm(terms,name)&&!ignored.contains(name.toLowerCase(Locale.ROOT)))terms.add(name);
   prefs.edit().putString("terms:"+activeStory,android.text.TextUtils.join("\n",terms)).apply();
  }
  return terms;
 }
 private AlertDialog nameSettings(){
  final String story=activeStory;List<String> before=storyTerms();
  LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(20),0,dp(20),0);
  EditText names=new EditText(this);names.setHint("Ban\nLinda\nMoon Blade\nEldoria");names.setText(android.text.TextUtils.join("\n",before));names.setMinLines(4);names.setMaxLines(9);names.setGravity(Gravity.TOP);names.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);form.addView(names);
  CheckBox auto=new CheckBox(this);auto.setText("Kenali nama dari sapaan/perkenalan");auto.setChecked(prefs.getBoolean("auto-names:"+story,true));form.addView(auto);
  ScrollView scroll=new ScrollView(this);scroll.addView(form);
  AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Nama & istilah tetap").setMessage("Untuk cerita yang sedang dibuka. Satu nama tokoh, tempat, atau barang khusus per baris. Ejaannya dipertahankan.\n\nPengenalan otomatis masih bisa keliru, terutama huruf kapital semua. Periksa daftar ini; nama yang dihapus tidak ditambahkan otomatis lagi.").setView(scroll).setPositiveButton("Simpan",null).setNegativeButton("Batal",null).create();
  dialog.setOnShowListener(v->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(button->{try{
   List<String> terms=ProtectedTerms.parse(names.getText().toString());Set<String> ignored=new HashSet<>(prefs.getStringSet("ignored-terms:"+story,Collections.emptySet()));
   for(String old:before)if(!containsTerm(terms,old))ignored.add(old.toLowerCase(Locale.ROOT));
   for(String term:terms)ignored.remove(term.toLowerCase(Locale.ROOT));
   prefs.edit().putString("terms:"+story,android.text.TextUtils.join("\n",terms)).putStringSet("ignored-terms:"+story,ignored).putBoolean("auto-names:"+story,auto.isChecked()).apply();
   cache.evictAll();documentId=UUID.randomUUID().toString();changed();message("Nama disimpan. Terjemahan berikutnya memakai daftar ini.");dialog.dismiss();
  }catch(IllegalArgumentException error){names.setError(error.getMessage());}}));dialog.show();return dialog;
 }
 private void queueRead(long delay){main.removeCallbacks(settled);if(automatic&&!homeVisible&&!original&&!destroyed&&!paused&&!ReadingLink.isSearchPage(web.getUrl()))main.postDelayed(settled,delay);}
 private void changed(){generation++;emptyRetries=0;latestTranslations.clear();latestSources.clear();overlay.clear();queueRead(1000);}
 private void translateViewport(){
  if(destroyed||homeVisible||original||paused)return;if(busy){queueRead(700);return;}
  String endpoint=prefs.getString("server","");boolean ai=!endpoint.isEmpty();
  if(!ai&&!ready){message("Model bahasa sedang disiapkan. Periksa internet; coba menu Unduh model.");return;}
  View content=local.getVisibility()==View.VISIBLE?local:web;int w=content.getWidth(),h=content.getHeight();if(w<1||h<1)return;
  long ticket=++generation;busy=true;overlay.clear();overlay.setVisibility(View.VISIBLE);message("Membaca teks pada bagian yang terlihat…");
  ViewportCapture.capture(getWindow(),content,new ViewportCapture.Callback(){
   @Override public void success(Bitmap shot,float scale){recognizeViewport(shot,scale,ticket,ai,endpoint,w,h);}
   @Override public void failure(int reason){busy=false;if(destroyed)return;if(ticket!=generation){queueRead(500);return;}message(reason==ViewportCapture.NO_MEMORY?"Memori HP penuh. Tutup aplikasi lain lalu coba lagi.":"Gambar layar belum bisa diambil. Tunggu halaman tampil, lalu tekan Terjemahkan lagi.");}
  });
 }
 private void recognizeViewport(Bitmap shot,float scale,long ticket,boolean ai,String endpoint,int w,int h){
  if(destroyed||ticket!=generation){shot.recycle();busy=false;queueRead(500);return;}
  OcrReader.read(ocr,shot,io,()->!destroyed&&ticket==generation,storyTerms(),new OcrReader.Result(){@Override public void success(Text result){
   if(destroyed||ticket!=generation){shot.recycle();busy=false;queueRead(500);return;}
   ArrayList<String> texts=new ArrayList<>();sourceCaps=new ArrayList<>();readingAppearance=new ArrayList<>();clippedText=0;ArrayList<RectF> boxes=new ArrayList<>();ArrayList<Integer> colors=new ArrayList<>();
   ArrayList<Text.TextBlock> ordered=new ArrayList<>(result.getTextBlocks());ordered.sort((a,b)->{Rect ra=a.getBoundingBox(),rb=b.getBoundingBox();return ra==null||rb==null?0:Integer.compare(ra.top,rb.top);});
   List<String> knownNames=storyTerms();
   for(Text.TextBlock block:ordered){
    for(OcrAppearance.Paragraph paragraph:OcrAppearance.paragraphs(shot,block,knownNames)){
     String text=paragraph.source;Rect r=paragraph.bounds;
     float edge=Math.max(2,scale*2);if(r.top<=edge||r.bottom>=shot.getHeight()-edge){clippedText++;continue;}
     if(text.length()<3||!text.matches("(?s).*[a-zA-Z].*")||r.width()<10||r.height()<8)continue;
     texts.add(text);sourceCaps.add(text.replaceAll("[^A-Za-z]","").length()>=3&&text.equals(text.toUpperCase(Locale.ROOT)));
     RectF rect=new RectF(r);rect.inset(-5*scale,-4*scale);rect.left=Math.max(0,rect.left/scale);rect.right=Math.min(w,rect.right/scale);rect.top=Math.max(0,rect.top/scale);rect.bottom=Math.min(h,rect.bottom/scale);boxes.add(rect);colors.add(paragraph.background);
     readingAppearance.add(new BubbleOverlay.Appearance(paragraph.ink,paragraph.sourceSize/scale,paragraph.leftAligned));if(texts.size()>=40)break;
    }
    if(texts.size()>=40)break;
   }
   shot.recycle();if(texts.isEmpty()){busy=false;if(clippedText==0&&emptyRetries++<2)queueRead(1800);message(clippedText>0?"Teks terpotong di tepi layar. Gulir sedikit agar balonnya terlihat utuh.":"Teks belum dikenali. Perbesar huruf atau berhenti di balon yang utuh.");return;}
   message(ai?"Menerjemahkan dialog dengan AI…":"Menerjemahkan di HP…");
   List<String> terms=learnNames(texts);readingPlans=new ArrayList<>();int nameIndex=0;
   for(int i=0;i<texts.size();i++){String clean=ProtectedTerms.cleanOcr(texts.get(i),terms);texts.set(i,clean);ProtectedTerms.Plan plan=ProtectedTerms.prepare(clean,terms,nameIndex);readingPlans.add(plan);nameIndex+=plan.names().size()+1;}
   readingSources=new ArrayList<>(texts);ArrayList<String> masked=new ArrayList<>();for(ProtectedTerms.Plan plan:readingPlans)masked.add(plan.masked);
   if(ai){translateAi(endpoint,masked,boxes,colors,ticket);return;}
   translateGrouped(masked,boxes,colors,ticket);
  }@Override public void failure(Exception error){shot.recycle();busy=false;if(destroyed)return;if(ticket!=generation){queueRead(500);return;}message("Pembaca teks gagal memproses gambar. Coba lagi atau buka file gambar.");}});
 }
 private final NameTranslation.Engine localEngine=(source,result)->{
  String cached=cache.get(source);if(cached!=null){result.done(cached,null);return;}
  translator.translate(source).addOnSuccessListener(value->{cache.put(source,value);result.done(value,null);}).addOnFailureListener(error->result.done(null,error));
 };
 private void translateGrouped(List<String> texts,List<RectF> boxes,List<Integer> colors,long ticket){
  TranslationFlow.translate(readingPlans,localEngine,()->{
   if(destroyed)return false;if(ticket!=generation){busy=false;queueRead(500);return false;}return true;
  },(values,failed)->finish(values,boxes,colors,ticket,failed));
 }
 private void finish(List<String> translated,List<RectF> boxes,List<Integer> colors,long ticket,int failed){
  if(destroyed)return;if(ticket!=generation){busy=false;queueRead(500);return;}busy=false;
  List<String> adjusted=new ArrayList<>();boolean ai=!prefs.getString("server","").isEmpty();
  for(int i=0;i<translated.size();i++){
   String raw=translated.get(i),source=i<readingSources.size()?readingSources.get(i):"";String value="";
   if(i<readingPlans.size()&&readingPlans.get(i).valid(raw)){
    ProtectedTerms.Plan plan=readingPlans.get(i);String styled=ai?ReadingText.paragraphs(raw):ReadingText.style(source,raw,readingStyle());
    if(plan.valid(styled)){value=plan.restore(styled);if(!ai)value=ReadingText.emotion(source,value);}
   }
   if(value.isEmpty()&&!raw.isEmpty())failed++;adjusted.add(value);
  }
  latestSources=new ArrayList<>(readingSources);latestTranslations=new ArrayList<>(adjusted);ArrayList<BubbleOverlay.Bubble> results=new ArrayList<>();
  for(int i=0;i<adjusted.size();i++)if(!adjusted.get(i).isEmpty()){boolean caps=i<sourceCaps.size()&&sourceCaps.get(i);results.add(new BubbleOverlay.Bubble(boxes.get(i),caps?adjusted.get(i).toUpperCase(new Locale("id")):adjusted.get(i),colors.get(i),caps,i<readingAppearance.size()?readingAppearance.get(i):null));}
  overlay.show(results);message(results.size()+" bagian diterjemahkan"+(failed>0?" · sebagian gagal, teks asli tetap ditampilkan. Coba lagi.":" · ketuk Lihat asli untuk membandingkan")+(clippedText>0?" · Ada teks di tepi layar; gulir agar terlihat utuh.":""));
 }
 private void translateAi(String endpoint,List<String> texts,List<RectF> boxes,List<Integer> colors,long ticket){String token=prefs.getString("token",""), doc=documentId, style=readingStyle(),notes=prefs.getString("notes:"+activeStory,"");List<ProtectedTerms.Plan> plans=new ArrayList<>(readingPlans);io.execute(()->{try{HttpsURLConnectionHelper reply=new HttpsURLConnectionHelper(endpoint,token,texts,doc,style,notes,plans);List<String> out=reply.result;main.post(()->finish(out,boxes,colors,ticket,0));}catch(Exception e){main.post(()->{busy=false;if(ticket!=generation){queueRead(500);return;}if(ticket==generation){message("Server AI belum bisa dipakai. Periksa pengaturan atau kosongkan server untuk mode dasar.");}});}});}
 private static class HttpsURLConnectionHelper { List<String> result=new ArrayList<>();HttpsURLConnectionHelper(String endpoint,String token,List<String> texts,String documentId,String style,String notes,List<ProtectedTerms.Plan> plans)throws Exception{
  JSONArray names=new JSONArray();for(ProtectedTerms.Plan plan:plans)names.put(new JSONObject(plan.names()));
  URL url=new URL(endpoint);if(!safeServer(endpoint))throw new IOException();HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(120000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Authorization","Bearer "+token);byte[] payload=new JSONObject().put("documentId",documentId).put("style",style).put("storyNotes",notes).put("texts",new JSONArray(texts)).put("protectedTerms",names).toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);try(OutputStream out=c.getOutputStream()){out.write(payload);}try{if(c.getResponseCode()!=200)throw new IOException();ByteArrayOutputStream body=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){body.write(buf,0,n);if(body.size()>200000)throw new IOException();}}JSONArray translated=new JSONObject(body.toString("UTF-8")).getJSONArray("translations");if(translated.length()!=texts.size())throw new IOException();for(int i=0;i<translated.length();i++){String t=translated.getString(i);if(t.length()>10000||!plans.get(i).valid(t))throw new IOException();result.add(t);}}finally{c.disconnect();}
 }}
 private void chooseFile(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","application/pdf","text/plain"});i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,41);}
 @Override protected void onActivityResult(int req,int code,Intent data){super.onActivityResult(req,code,data);if(req!=41||code!=RESULT_OK||data==null)return;Uri uri=data.getData();showReader();activeStory="file:"+UUID.nameUUIDFromBytes(uri.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));documentId=UUID.randomUUID().toString();changed();closePdf();String type=getContentResolver().getType(uri);try{
  if("application/pdf".equals(type)){pdfFile=getContentResolver().openFileDescriptor(uri,"r");pdf=new PdfRenderer(pdfFile);page=0;showPdf();return;}
  if("text/plain".equals(type)){byte[] bytes=readLimited(uri,2*1024*1024);String text=new String(bytes,java.nio.charset.StandardCharsets.UTF_8);web.setVisibility(View.VISIBLE);local.setVisibility(View.GONE);web.loadDataWithBaseURL("https://reader.invalid/","<html><meta name='viewport' content='width=device-width'><body style='padding:18px;font:20px/1.8 sans-serif;white-space:pre-wrap'>"+android.text.TextUtils.htmlEncode(text)+"</body></html>","text/html","UTF-8",null);return;}
  BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,bounds);}if(bounds.outWidth<1||bounds.outHeight<1)throw new IOException();BitmapFactory.Options options=new BitmapFactory.Options();while(bounds.outWidth/Math.max(1,options.inSampleSize)>2048||bounds.outHeight/Math.max(1,options.inSampleSize)>16000||(long)(bounds.outWidth/Math.max(1,options.inSampleSize))*(bounds.outHeight/Math.max(1,options.inSampleSize))>8000000)options.inSampleSize=options.inSampleSize==0?2:options.inSampleSize*2;
  Bitmap image;try(InputStream in=getContentResolver().openInputStream(uri)){image=BitmapFactory.decodeStream(in,null,options);}if(image==null)throw new IOException();showImage(image);message("File siap. Geser gambar lalu tekan Terjemahkan.");
 }catch(Exception|OutOfMemoryError e){message("File belum dapat dibuka. Pilih JPG, PNG, WebP, PDF atau TXT yang lebih kecil.");}}
 private byte[] readLimited(Uri uri,int max)throws IOException{try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>max)throw new IOException();}return out.toByteArray();}}
 private void showImage(Bitmap image){changed();message("Membuka gambar…");io.execute(()->{try{File file=new File(getCacheDir(),"reader.png");try(OutputStream out=new FileOutputStream(file)){image.compress(Bitmap.CompressFormat.PNG,100,out);}image.recycle();main.post(()->{if(destroyed)return;fileMode=true;web.setVisibility(View.VISIBLE);local.setVisibility(View.GONE);web.loadDataWithBaseURL("https://reader.invalid/","<html><head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=6, user-scalable=yes\"></head><body style=\"margin:0;background:#fff\"><img src=\"https://reader.invalid/image.png\" style=\"width:100%;height:auto\"></body></html>","text/html","UTF-8",null);});}catch(Exception e){main.post(()->message("Gambar gagal dibuka."));}});}
 private void showPdf(){if(pdf==null)return;try(PdfRenderer.Page p=pdf.openPage(page)){int width=1400,height=Math.round(width*(float)p.getHeight()/p.getWidth());if(height>12000)throw new IOException();Bitmap b=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);new Canvas(b).drawColor(Color.WHITE);p.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);showImage(b);message("PDF halaman "+(page+1)+"/"+pdf.getPageCount()+" · pindah halaman lewat menu ⋮");}catch(Exception e){message("Halaman PDF gagal dibuka.");}}
 private void closePdf(){if(pdf!=null){pdf.close();pdf=null;}if(pdfFile!=null){try{pdfFile.close();}catch(Exception ignored){}pdfFile=null;}}
 private void showResults(){
  if(homeVisible){android.widget.Toast.makeText(this,"Buka bacaan dulu untuk melihat hasil.",android.widget.Toast.LENGTH_SHORT).show();return;}
  LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(20),dp(12),dp(20),dp(20));
  if(latestTranslations.isEmpty()){TextView empty=label("Belum ada hasil. Buka komik lalu berhenti menggulir sebentar.",16);content.addView(empty);}
  for(int i=0;i<latestTranslations.size();i++){
   TextView source=label((i+1)+" · ASLI\n"+(i<latestSources.size()?latestSources.get(i):""),13);source.setTextColor(0xff94a3b8);source.setTextIsSelectable(true);source.setLineSpacing(dp(2),1.12f);content.addView(source);
   TextView target=label(latestTranslations.get(i).isEmpty()?"Belum berhasil. Teks asli tetap ditampilkan.":latestTranslations.get(i),18);target.setTextColor(0xffe2e8f0);target.setPadding(0,dp(8),0,dp(24));target.setTextIsSelectable(true);target.setLineSpacing(dp(3),1.15f);content.addView(target);
  }
  ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(0xff0f172a);scroll.addView(content);new AlertDialog.Builder(this).setTitle("Hasil terjemahan").setView(scroll).setPositiveButton("Tutup",null).show();
 }
 private void settings(){String[] items={"Beranda","Cari komik / buka situs","Gaya bahasa cerita","Nama & istilah tetap","Pengaturan AI gratis (opsional)","Unduh model bahasa","PDF: halaman sebelumnya","PDF: halaman berikutnya","Cara pakai","Buka contoh komik"};new AlertDialog.Builder(this).setTitle("KomikLingo").setItems(items,(d,n)->{switch(n){case 0:showHome();break;case 1:openAddressDialog();break;case 2:styleSettings();break;case 3:nameSettings();break;case 4:aiSettings();break;case 5:message("Mengunduh model…");translator.downloadModelIfNeeded().addOnSuccessListener(v->{ready=true;message("Model Inggris–Indonesia siap.");changed();}).addOnFailureListener(e->message("Unduhan gagal. Periksa internet lalu coba lagi."));break;case 6:if(pdf!=null&&page>0){page--;showPdf();}break;case 7:if(pdf!=null&&page+1<pdf.getPageCount()){page++;showPdf();}break;case 8:new AlertDialog.Builder(this).setTitle("Baca komik dari situs lain").setMessage("Ketik judul komik di kolom atas untuk mencari lewat DuckDuckGo, atau tempel tautan untuk langsung membuka situs. Tautan tanpa https:// juga boleh. Pilih Bagikan → KomikLingo di browser untuk membuka tautan langsung.\n\nBerhenti menggulir sebentar agar teks diterjemahkan. Gaya bawaan aku–kamu cocok untuk dialog akrab; ubah Gaya bahasa cerita bila butuh bahasa formal. Hasil menampilkan teks Inggris yang terbaca dan terjemahannya. Nama tokoh, tempat, dan barang khusus disimpan per cerita lewat Nama & istilah tetap. Periksa daftar bila nama belum dikenal atau keliru.\n\nMode dasar di HP belum memahami hubungan tokoh atau seluruh cerita. AI lokal opsional dapat memakai konteks dialog dan catatan cerita. Situs yang memblokir WebView tetap dapat menolak akses. Huruf rusak/dekoratif masih bisa salah dibaca.").setPositiveButton("Mengerti",null).show();break;case 9:open(home);}}).show();}
 private static boolean safeServer(String value){try{URL u=new URL(value);return u.getProtocol().equals("https")||(u.getProtocol().equals("http")&&(u.getHost().equals("127.0.0.1")||u.getHost().equals("localhost")));}catch(Exception e){return false;}}
 private void aiSettings(){LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(20),dp(8),dp(20),0);EditText url=new EditText(this);url.setHint("https://server-kamu/translate");url.setText(prefs.getString("server",""));url.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);form.addView(url);EditText token=new EditText(this);token.setHint("Kode akses server AI");token.setText(prefs.getString("token",""));token.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);form.addView(token);EditText notes=new EditText(this);notes.setHint("Catatan cerita untuk AI, misalnya pasangan memakai aku–kamu (opsional)");notes.setText(prefs.getString("notes:"+activeStory,""));notes.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(800)});form.addView(notes);new AlertDialog.Builder(this).setTitle("AI untuk dialog lebih alami").setMessage("AI gratis memerlukan komputer sendiri dengan Ollama. Teks yang terbaca dikirim ke komputer itu. Kosongkan alamat untuk memakai mode dasar di HP.").setView(form).setPositiveButton("Simpan",(d,w)->{String s=url.getText().toString().trim();if(!s.isEmpty()&&!safeServer(s)){message("Gunakan HTTPS, atau http://127.0.0.1:8765/translate lewat USB.");return;}prefs.edit().putString("server",s).putString("token",token.getText().toString()).putString("notes:"+activeStory,notes.getText().toString()).apply();documentId=UUID.randomUUID().toString();changed();message(s.isEmpty()?"Mode dasar dipilih.":"Mode AI dipilih. Teks OCR akan dikirim ke server.");}).setNegativeButton("Batal",null).show();}
 @Override public void onBackPressed(){if(web.getVisibility()==View.VISIBLE&&web.canGoBack()){changed();web.goBack();}else if(!homeVisible)showHome();else super.onBackPressed();}
 @Override protected void onPause(){saveReadingPosition();main.removeCallbacks(saveProgress);paused=true;generation++;overlay.clear();main.removeCallbacks(settled);super.onPause();}
 @Override protected void onResume(){super.onResume();paused=false;if(overlay!=null)changed();}
 @Override public void onConfigurationChanged(android.content.res.Configuration config){super.onConfigurationChanged(config);changed();}
 @Override protected void onDestroy(){destroyed=true;main.removeCallbacksAndMessages(null);ocr.close();translator.close();closePdf();fileMode=false;new File(getCacheDir(),"reader.png").delete();web.destroy();io.shutdownNow();super.onDestroy();}
}
