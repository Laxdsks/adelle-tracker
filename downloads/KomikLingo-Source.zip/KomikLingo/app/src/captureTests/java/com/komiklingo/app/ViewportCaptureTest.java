package com.komiklingo.app;

import android.content.Intent;
import android.graphics.Bitmap;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class ViewportCaptureTest {
 private int sequence=0;
 @Test public void detachedViewReturnsFailureRatherThanAFalseEmptyOcrResult() throws Exception {
  var instrumentation=InstrumentationRegistry.getInstrumentation();CountDownLatch done=new CountDownLatch(1);AtomicReference<Integer> reason=new AtomicReference<>();
  instrumentation.runOnMainSync(()->ViewportCapture.capture(null,new android.view.View(instrumentation.getTargetContext()),new ViewportCapture.Callback(){
   @Override public void success(Bitmap bitmap,float scale){bitmap.recycle();reason.set(99);done.countDown();}
   @Override public void failure(int error){reason.set(error);done.countDown();}
  }));assertTrue(done.await(5,TimeUnit.SECONDS));assertEquals(Integer.valueOf(ViewportCapture.NOT_VISIBLE),reason.get());
 }
 @Test public void gpuImageTextIsReadFromVisibleViewportBeforeAndAfterScroll() throws Exception {
  var instrumentation=InstrumentationRegistry.getInstrumentation();
  CaptureFixtureActivity activity=(CaptureFixtureActivity)instrumentation.startActivitySync(new Intent(instrumentation.getTargetContext(),CaptureFixtureActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
  try{
   assertTrue("WebView image did not render",activity.ready.await(60,TimeUnit.SECONDS));
   assertTrue("Fixture must use the GPU rendering path",activity.reader.isHardwareAccelerated());
   String before=read(activity,recognizer);
   assertTrue("Visible image text missing: "+before,before.contains("HAPPENS"));
   assertFalse("App header leaked into OCR",before.contains("PRIVATE HEADER"));
   assertFalse("App footer leaked into OCR",before.contains("PRIVATE FOOTER"));
   instrumentation.runOnMainSync(()->{int target=Math.max(0,(int)(activity.reader.getContentHeight()*activity.reader.getScale())-activity.reader.getHeight());activity.reader.scrollTo(0,target);android.util.Log.i("CaptureRegression","scroll="+activity.reader.getScrollY()+" target="+target+" content="+activity.reader.getContentHeight()+" scale="+activity.reader.getScale()+" height="+activity.reader.getHeight());});
   instrumentation.waitForIdleSync();
   String after=read(activity,recognizer);
   assertTrue("Scrolled image text missing: "+after,after.contains("REASON"));
   assertFalse("Old viewport was read after scroll",after.contains("HAPPENS"));
  }finally{recognizer.close();instrumentation.runOnMainSync(activity::finish);}
 }
 private String read(CaptureFixtureActivity activity,TextRecognizer recognizer)throws Exception{
  var instrumentation=InstrumentationRegistry.getInstrumentation();
  CountDownLatch done=new CountDownLatch(1);AtomicReference<String> result=new AtomicReference<>();AtomicReference<Throwable> error=new AtomicReference<>();
  instrumentation.runOnMainSync(()->ViewportCapture.capture(activity.getWindow(),activity.reader,new ViewportCapture.Callback(){
   @Override public void success(Bitmap bitmap,float scale){try(java.io.FileOutputStream output=new java.io.FileOutputStream(new java.io.File(activity.getCacheDir(),"capture-"+(sequence++)+".png"))){bitmap.compress(Bitmap.CompressFormat.PNG,100,output);}catch(Exception ignored){}recognizer.process(InputImage.fromBitmap(bitmap,0)).addOnSuccessListener(text->result.set(text.getText().toUpperCase(java.util.Locale.ROOT))).addOnFailureListener(error::set).addOnCompleteListener(task->{bitmap.recycle();done.countDown();});}
   @Override public void failure(int reason){error.set(new AssertionError("PixelCopy failed: "+reason));done.countDown();}
  }));
  assertTrue("Capture/OCR timeout",done.await(90,TimeUnit.SECONDS));
  if(error.get()!=null)throw new AssertionError(error.get());return result.get();
 }
}
