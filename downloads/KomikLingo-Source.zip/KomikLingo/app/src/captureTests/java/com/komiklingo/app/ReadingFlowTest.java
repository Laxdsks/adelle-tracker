package com.komiklingo.app;

import android.content.*;
import android.webkit.*;
import android.widget.EditText;
import android.view.inputmethod.EditorInfo;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import java.io.ByteArrayInputStream;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class ReadingFlowTest {
 @Test public void addressGoOpensDifferentSitesAndKeepsStoryStylesSeparate()throws Exception{
  var instrumentation=InstrumentationRegistry.getInstrumentation();Context context=instrumentation.getTargetContext();
  var prefs=context.getSharedPreferences("reader",Context.MODE_PRIVATE);boolean auto=prefs.getBoolean("automatic",true);String oldUrl=prefs.getString("url","");
  String first="https://one.example/series/book/chapter/1",second="https://two.example/novel/chapter/9";
  prefs.edit().putBoolean("automatic",false).putString("style:"+ReadingLink.storyKey(first),"formal").remove("style:"+ReadingLink.storyKey(second)).commit();
  MainActivity activity=(MainActivity)instrumentation.startActivitySync(new Intent(context,MainActivity.class).putExtra(Intent.EXTRA_TEXT,first).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  var webField=MainActivity.class.getDeclaredField("web");webField.setAccessible(true);WebView web=(WebView)webField.get(activity);
  var inputField=MainActivity.class.getDeclaredField("address");inputField.setAccessible(true);EditText input=(EditText)inputField.get(activity);
  var style=MainActivity.class.getDeclaredMethod("readingStyle");style.setAccessible(true);
  AtomicReference<CountDownLatch> loaded=new AtomicReference<>();AtomicReference<String> expected=new AtomicReference<>();
  try{
   instrumentation.runOnMainSync(()->{
    activity.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON|android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
    WebViewClient original=web.getWebViewClient();web.setWebViewClient(new WebViewClient(){
     @Override public void onPageStarted(WebView w,String url,android.graphics.Bitmap icon){original.onPageStarted(w,url,icon);}
     @Override public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){return original.shouldOverrideUrlLoading(w,r);}
     @Override public WebResourceResponse shouldInterceptRequest(WebView w,WebResourceRequest r){return new WebResourceResponse("text/html","UTF-8",new ByteArrayInputStream(("<html><meta name='viewport' content='width=device-width'><body>Reading fixture "+r.getUrl().getHost()+"<a id=\"result\" href=\"https://comic.example/series/new/chapter/1\">Read comic</a></body></html>").getBytes(java.nio.charset.StandardCharsets.UTF_8)));}
     @Override public void onPageFinished(WebView w,String url){original.onPageFinished(w,url);CountDownLatch latch=loaded.get();if(latch!=null&&url.equals(expected.get()))latch.countDown();}
    });
   });
   for(String url:new String[]{first,second}){
    CountDownLatch ready=new CountDownLatch(1);loaded.set(ready);expected.set(url);
    instrumentation.runOnMainSync(()->{input.setText(url.equals(second)?"two.example/novel/chapter/9":url);input.onEditorAction(EditorInfo.IME_ACTION_GO);});
    assertTrue("Page did not load",ready.await(90,TimeUnit.SECONDS));
    AtomicReference<String> actual=new AtomicReference<>(),body=new AtomicReference<>();CountDownLatch evaluated=new CountDownLatch(1);
    instrumentation.runOnMainSync(()->{actual.set(web.getUrl());web.evaluateJavascript("document.body.textContent",value->{body.set(value);evaluated.countDown();});});
    assertTrue(evaluated.await(15,TimeUnit.SECONDS));assertEquals(url,actual.get());assertTrue(body.get().contains(url.equals(first)?"one.example":"two.example"));
    assertEquals(url.equals(first)?"formal":"dialogue",style.invoke(activity));
   }
   String query="Chronicle of Runes komik Indonesia",search=ReadingLink.resolve(query),comic="https://comic.example/series/new/chapter/1";
   CountDownLatch searchReady=new CountDownLatch(1);loaded.set(searchReady);expected.set(search);
   instrumentation.runOnMainSync(()->{input.setText(query);input.onEditorAction(EditorInfo.IME_ACTION_SEARCH);});
   assertTrue("DuckDuckGo search did not open",searchReady.await(90,TimeUnit.SECONDS));
   AtomicReference<String> shown=new AtomicReference<>();instrumentation.runOnMainSync(()->shown.set(input.getText().toString()));assertEquals(query,shown.get());
   CountDownLatch comicReady=new CountDownLatch(1);loaded.set(comicReady);expected.set(comic);
   instrumentation.runOnMainSync(()->web.evaluateJavascript("document.getElementById('result').click()",null));
   assertTrue("Search result did not stay inside the reader",comicReady.await(90,TimeUnit.SECONDS));
   instrumentation.runOnMainSync(()->shown.set(web.getUrl()));assertEquals(comic,shown.get());
  }finally{
   instrumentation.runOnMainSync(activity::finish);
   prefs.edit().putBoolean("automatic",auto).putString("url",oldUrl).remove("style:"+ReadingLink.storyKey(first)).remove("style:"+ReadingLink.storyKey(second)).commit();
  }
 }
}
