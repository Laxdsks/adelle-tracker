package com.komiklingo.app;

import android.content.*;
import android.graphics.RectF;
import android.os.*;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.lang.reflect.*;
import java.util.*;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class ProtectedNamesFlowTest {
 private Object invoke(Object target,String name,Class<?>[] types,Object... args){try{Method m=target.getClass().getDeclaredMethod(name,types);m.setAccessible(true);return m.invoke(target,args);}catch(Exception e){throw new AssertionError(e);}}
 private void set(Object target,String field,Object value){try{Field f=target.getClass().getDeclaredField(field);f.setAccessible(true);f.set(target,value);}catch(Exception e){throw new AssertionError(e);}}
 private Object get(Object target,String field){try{Field f=target.getClass().getDeclaredField(field);f.setAccessible(true);return f.get(target);}catch(Exception e){throw new AssertionError(e);}}
 private android.widget.EditText findEditor(android.view.View root){if(root instanceof android.widget.EditText)return (android.widget.EditText)root;if(root instanceof android.view.ViewGroup){var group=(android.view.ViewGroup)root;for(int i=0;i<group.getChildCount();i++){var found=findEditor(group.getChildAt(i));if(found!=null)return found;}}return null;}
 private void edit(MainActivity activity,String text)throws Exception{
  var ins=InstrumentationRegistry.getInstrumentation();var dialog=new java.util.concurrent.atomic.AtomicReference<android.app.AlertDialog>();
  ins.runOnMainSync(()->dialog.set((android.app.AlertDialog)invoke(activity,"nameSettings",new Class<?>[]{})));ins.waitForIdleSync();
  ins.runOnMainSync(()->{var editor=findEditor(dialog.get().getWindow().getDecorView());assertNotNull("Glossary editor",editor);assertTrue("Editor is visible",editor.isShown());assertTrue("Editor has height",editor.getHeight()>0);editor.setText(text);dialog.get().getButton(android.app.AlertDialog.BUTTON_POSITIVE).performClick();assertFalse(dialog.get().isShowing());});
 }
 @Test public void glossarySurvivesRestartIsolatesTitlesAndProtectsRenderedNames()throws Exception{
  var ins=InstrumentationRegistry.getInstrumentation();Context context=ins.getTargetContext();var prefs=context.getSharedPreferences("reader",Context.MODE_PRIVATE);
  String url="https://kaynscans.com/series/comic/chronicle-of-runes/chapter/48",story=ReadingLink.storyKey(url),other="https://other.example/series/another-title/chapter/1";
  Map<String,?> backup=new HashMap<>(prefs.getAll());prefs.edit().clear().putBoolean("automatic",false).commit();
  MainActivity activity=(MainActivity)ins.startActivitySync(new Intent(context,MainActivity.class).putExtra(Intent.EXTRA_TEXT,url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  try{
   MainActivity initial=activity;
   ins.runOnMainSync(()->{initial.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON|android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);invoke(initial,"updateStory",new Class<?>[]{String.class},url);});
   assertTrue(((List<?>)invoke(activity,"storyTerms",new Class<?>[]{})).contains("Ban"));
   edit(activity,"Ban\nLinda\nMoon Blade\nEldoria\nSaya");
   assertEquals("Ban\nLinda\nMoon Blade\nEldoria\nSaya",prefs.getString("terms:"+story,""));
   MainActivity first=activity;ins.runOnMainSync(first::finish);
   activity=(MainActivity)ins.startActivitySync(new Intent(context,MainActivity.class).putExtra(Intent.EXTRA_TEXT,url.replace("48","49")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));MainActivity current=activity;
   ins.runOnMainSync(()->{invoke(current,"updateStory",new Class<?>[]{String.class},url);assertTrue(((List<?>)invoke(current,"storyTerms",new Class<?>[]{})).contains("Linda"));});
   edit(activity,"Linda\nMoon Blade\nEldoria\nSaya");
   assertTrue(prefs.getStringSet("ignored-terms:"+story,Set.of()).contains("ban"));
   ins.runOnMainSync(()->{
    assertFalse(((List<?>)invoke(current,"learnNames",new Class<?>[]{List.class},List.of("BAN, IF ONE DAY YOU WERE ALONE"))).contains("BAN"));
    invoke(current,"updateStory",new Class<?>[]{String.class},other);assertTrue(((List<?>)invoke(current,"storyTerms",new Class<?>[]{})).isEmpty());
    List<?> learned=(List<?>)invoke(current,"learnNames",new Class<?>[]{List.class},List.of("MY NAME IS LUNA."));assertTrue(learned.contains("LUNA"));assertFalse(learned.contains("Linda"));
    var plan=ProtectedTerms.prepare("Saya, help Linda.",List.of("Saya","Linda"));set(current,"readingSources",new ArrayList<>(List.of(plan.source)));set(current,"readingPlans",new ArrayList<>(List.of(plan)));set(current,"sourceCaps",new ArrayList<>(List.of(false)));
    long ticket=(Long)get(current,"generation");invoke(current,"finish",new Class<?>[]{List.class,List.class,List.class,long.class,int.class},List.of("ZXQNAME0QXZ, Saya membantu ZXQNAME1QXZ."),List.of(new RectF(10,10,200,100)),List.of(-1),ticket,0);
    assertEquals(List.of("Saya, aku membantu Linda."),get(current,"latestTranslations"));
    invoke(current,"finish",new Class<?>[]{List.class,List.class,List.class,long.class,int.class},List.of("Larangan, Saya membantu Linda."),List.of(new RectF(10,10,200,100)),List.of(-1),ticket,0);assertEquals(List.of(""),get(current,"latestTranslations"));
   });
  }finally{
   MainActivity last=activity;ins.runOnMainSync(last::finish);var editor=prefs.edit().clear();for(var entry:backup.entrySet()){Object v=entry.getValue();String k=entry.getKey();if(v instanceof String)editor.putString(k,(String)v);else if(v instanceof Boolean)editor.putBoolean(k,(Boolean)v);else if(v instanceof Set)editor.putStringSet(k,(Set<String>)v);}editor.commit();
  }
 }
}
