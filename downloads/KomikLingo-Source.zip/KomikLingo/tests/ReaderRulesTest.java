import com.komiklingo.app.ReadingLink;
import com.komiklingo.app.ReadingText;
public class ReaderRulesTest {
 static void same(Object a,Object b){if(!java.util.Objects.equals(a,b))throw new AssertionError(a+" != "+b);}
 public static void main(String[] args){
  same(ReadingText.cleanOcr("AFTERI WENT THROUGH ALL THE TROUBLE"),"AFTER I WENT THROUGH ALL THE TROUBLE");
  same(ReadingText.cleanOcr("Suddenlyy? Linda and all the villagers?"),"Suddenly? Linda and all the villagers?");
  same(ReadingText.cleanOcr("YES, FEVERYONE"),"YES, EVERYONE");
  same(ReadingText.style("you","Andalan dan sandaran","dialogue"),"Andalan dan sandaran");
  same(ReadingText.style("You stay.","Kamu tetap di sini.","formal"),"Anda tetap di sini.");
  same(ReadingText.cleanOcr("Andi and Linda, nooo!"),"Andi and Linda, nooo!");
  same(ReadingText.style("You have to stay alive.","Anda harus tetap hidup.","dialogue"),"Kamu harus tetap hidup.");
  same(ReadingText.style("I will protect you!","Saya akan melindungi Anda!","dialogue"),"Aku akan melindungi kamu!");
  same(ReadingText.style("I will protect you!","Saya akan melindungi Anda!","neutral"),"Saya akan melindungi kamu!");
  same(ReadingText.style("Sir, I need your help.","Saya butuh bantuan Anda.","dialogue"),"Saya butuh bantuan Anda.");
  same(ReadingText.style("you","sandaran dan pandangan","dialogue"),"sandaran dan pandangan");
  same(ReadingText.splitBatch("Satu\n\nDua",2).get(1),"Dua");same(ReadingText.splitBatch("Satu Dua",2),null);
  same(ReadingLink.normalize("example.org/comic/2"),"https://example.org/comic/2");
  same(ReadingLink.normalize("Baca https://other.example/novel/chapter/8 sekarang"),"https://other.example/novel/chapter/8");
  same(ReadingLink.normalize("https://other.example/Story_(Book)"),"https://other.example/Story_(Book)");
  same(ReadingLink.storyKey("https://a.example/book/runes/chapter/1"),ReadingLink.storyKey("https://a.example/book/runes/chapter/2"));
  if(ReadingLink.storyKey("https://b.example/book/runes/chapter/1").equals(ReadingLink.storyKey("https://a.example/book/runes/chapter/1")))throw new AssertionError("Mixed sites");
  for(String bad:new String[]{"javascript:alert(1)","file:///tmp/x","https://user:secret@example.org/a","https://reader.invalid/image.png"}){try{ReadingLink.normalize(bad);throw new AssertionError(bad);}catch(IllegalArgumentException expected){}}
  same(ReadingLink.resolve("Chronicle of Runes komik"),"https://duckduckgo.com/?q=Chronicle+of+Runes+komik&ia=web");
  same(ReadingLink.resolve("Naruto"),"https://duckduckgo.com/?q=Naruto&ia=web");
  same(ReadingLink.resolve("site:kaynscans.com runes"),"https://duckduckgo.com/?q=site%3Akaynscans.com+runes&ia=web");
  same(ReadingLink.resolve("other.example/novel/3"),"https://other.example/novel/3");
  same(ReadingLink.displayAddress(ReadingLink.resolve("komik cinta & petualangan")),"komik cinta & petualangan");
  same(ReadingLink.isSearchPage("https://duckduckgo.com.evil.example/?q=x"),false);
  for(String bad:new String[]{"javascript:alert(1)","file:///tmp/x","data:text/plain,x"}){try{ReadingLink.resolve(bad);throw new AssertionError(bad);}catch(IllegalArgumentException expected){}}
  if(ReadingLink.storyKey("https://a.example/chapter/uuid-a").equals(ReadingLink.storyKey("https://a.example/chapter/uuid-b")))throw new AssertionError("Mixed unknown chapter identities");
  if(ReadingLink.storyKey("https://a.example/reader?book=a").equals(ReadingLink.storyKey("https://a.example/reader?book=b")))throw new AssertionError("Mixed query-based books");
  System.out.println("Reader rules passed: OCR repairs, explicit pronouns, honorifics, names, batch order and other-site URLs.");
 }
}
