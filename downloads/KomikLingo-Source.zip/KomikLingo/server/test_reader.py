import json, threading, unittest, urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from reader_server import ReaderServer

class Model(BaseHTTPRequestHandler):
    received=[]
    def log_message(self,*a):pass
    def do_POST(self):
        body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        request=json.loads(body['messages'][1]['content']);self.received.append(request)
        translations=['Kamu mau ke mana?' for _ in request['texts']]
        if request['texts']==['bad']:translations=[]
        if request['texts']==['ZXQNAME0QXZ, stay.']:translations=['ZXQNAME0QXZ, tetap di sini.']
        if request['texts']==['ZXQNAME0QXZ, lost.']:translations=['Larangan, hilang.']
        if request['texts']==['ZXQNAME0QXZ, double.']:translations=['ZXQNAME0QXZ ZXQNAME0QXZ']
        data=json.dumps({'message':{'content':json.dumps({'translations':translations})}}).encode()
        self.send_response(200);self.end_headers();self.wfile.write(data)
class Integration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model=ThreadingHTTPServer(('127.0.0.1',0),Model)
        cls.server=ReaderServer(('127.0.0.1',0),'test-access',f'http://127.0.0.1:{cls.model.server_port}')
        for s in [cls.model,cls.server]:threading.Thread(target=s.serve_forever,daemon=True).start()
    @classmethod
    def tearDownClass(cls):
        for s in [cls.model,cls.server]:s.shutdown();s.server_close()
    def call(self,texts,doc='story-a',token='test-access',style='dialogue',notes='',names=None):
        payload={'texts':texts,'documentId':doc,'style':style,'storyNotes':notes}
        if names is not None:payload['protectedTerms']=names
        r=urllib.request.Request(f'http://127.0.0.1:{self.server.server_port}/translate',data=json.dumps(payload).encode(),headers={'Authorization':'Bearer '+token})
        try:
            with urllib.request.urlopen(r) as result:return result.status,json.load(result)
        except urllib.error.HTTPError as e:return e.code,json.load(e)
    def test_context_security_and_reply_contract(self):
        self.assertEqual(self.call(['hello'],token='wrong')[0],401)
        self.assertEqual(self.call(['hello'],style='invalid')[0],400)
        self.assertEqual(self.call(['hello'],notes='x'*1001)[0],400)
        self.assertEqual(self.call(['x'*18001])[0],400)
        self.assertEqual(self.call(['Where are you going?'])[1]['translations'],['Kamu mau ke mana?'])
        self.assertEqual(Model.received[-1]['previous_dialogue'],[])
        self.assertEqual(self.call(['Wait!'])[0],200)
        self.assertEqual(len(Model.received[-1]['previous_dialogue']),1)
        self.assertEqual(Model.received[-1]['style'],'dialogue')
        self.assertEqual(self.call(['Respectful'],style='formal')[0],200)
        self.assertEqual(Model.received[-1]['previous_dialogue'],[])
        self.assertEqual(self.call(['Family'],notes='Two spouses use aku/kamu')[0],200)
        self.assertEqual(Model.received[-1]['story_notes'],'Two spouses use aku/kamu')
        self.assertEqual(Model.received[-1]['previous_dialogue'],[])
        self.assertEqual(self.call(['Another story'],doc='story-b')[0],200)
        self.assertEqual(Model.received[-1]['previous_dialogue'],[])
        self.assertEqual(self.call(['bad'])[0],502)
    def test_protected_names_contract_and_history(self):
        names=[{'ZXQNAME0QXZ':'Ban'}]
        self.assertEqual(self.call(['ZXQNAME0QXZ, stay.'],doc='names-a',names=names)[1]['translations'],['ZXQNAME0QXZ, tetap di sini.'])
        self.assertEqual(Model.received[-1]['protected_terms'],names)
        self.assertEqual(self.call(['Hello'],doc='names-a')[0],200)
        self.assertEqual(Model.received[-1]['previous_dialogue'],[['Ban, stay.','Ban, tetap di sini.']])
        self.assertEqual(self.call(['ZXQNAME0QXZ, lost.'],names=names)[0],502)
        self.assertEqual(self.call(['ZXQNAME0QXZ, double.'],names=names)[0],502)
        for text,mapping in [('No marker',names),('ZXQNAME0QXZ',[]),('ZXQNAME0QXZ',[{'ZXQNAME1QXZ':'Ban'}]),('ZXQNAME0QXZ',[{'ZXQNAME0QXZ':'x'*65}])]:
            self.assertEqual(self.call([text],names=mapping)[0],400)
if __name__=='__main__':unittest.main()
