#!/usr/bin/env bash
set -euo pipefail
cd /workspace/komiklingo
export JAVA_HOME="$(cat /workspace/.comic-toolchain/jdk-home.txt)"
export ANDROID_USER_HOME=/workspace/.comic-toolchain/android-user
unset ANDROID_PREFS_ROOT
mkdir -p "$ANDROID_USER_HOME"
export GRADLE_USER_HOME=/workspace/.comic-toolchain/gradle-home
# Use the inherited session proxy and Java CA trust; never disable TLS checks.
read -r proxy_host proxy_port < <(python3 - <<'PY'
import os,urllib.parse
u=urllib.parse.urlparse(os.environ.get('HTTPS_PROXY','http://proxy:8080'))
print(u.hostname,u.port or 8080)
PY
)
if [ "$#" -eq 0 ]; then set -- :app:assembleDebug; fi
/workspace/.comic-toolchain/gradle-8.9/bin/gradle --no-daemon -Dhttps.proxyHost="$proxy_host" -Dhttps.proxyPort="$proxy_port" -Dhttp.proxyHost="$proxy_host" -Dhttp.proxyPort="$proxy_port" -Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts "$@"
