#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
reader_test_classes="$(mktemp -d)"
trap 'rm -rf -- "$reader_test_classes"' EXIT
javac -d "$reader_test_classes" app/src/main/java/com/komiklingo/app/ReadingText.java app/src/main/java/com/komiklingo/app/ReadingLink.java tests/ReaderRulesTest.java
java -cp "$reader_test_classes" ReaderRulesTest
