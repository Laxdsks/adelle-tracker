# Data yang digunakan

OCR dan mode terjemahan dasar bekerja di perangkat. Unduhan model bahasa menggunakan layanan ML Kit/Google dan jaringan; situs yang dibuka menerima permintaan normal WebView serta cookie situs. Aplikasi tidak menambahkan analytics atau iklan sendiri. SDK ML Kit dapat mengirim data diagnostik/penggunaan sesuai ketentuan Google, terpisah dari pemrosesan OCR lokal.

Mode AI hanya saat alamat server diisi. Teks OCR bagian layar dikirim ke alamat itu, bersama ID dokumen acak; gambar dan cookie situs tidak ikut dikirim. Server contoh menyimpan konteks sementara di RAM dan mengirimnya ke Ollama lokal. Jangan memasukkan server yang tidak dipercaya. Token akses server tersimpan dalam ruang privat aplikasi dan cadangan Android dinonaktifkan. HTTPS wajib, kecuali localhost lewat USB. Kunci penyedia AI tidak dibutuhkan.

Izin jaringan: internet dan pemeriksaan koneksi. Ada izin penerima internal yang hanya boleh dipakai aplikasi sendiri. File dipilih sendiri melalui pemilih Android; aplikasi tidak meminta akses seluruh penyimpanan, kamera, mikrofon atau aksesibilitas. Gambar/file asli tidak diubah. APK pengembangan ini belum diaudit keamanannya dan belum dirilis di Play Store.

Cookie/cache situs dan pengaturan lokal dapat dihapus melalui Pengaturan Android → Aplikasi → TCD → Penyimpanan → Hapus data.

Pilihan gaya bahasa disimpan lokal per kunci situs/cerita. Jika mode AI dipakai, gaya dan Catatan cerita opsional ikut dikirim ke server yang dipilih dan menjadi bagian konteks sementara. URL situs tidak ikut dikirim sebagai ID dokumen; aplikasi memakai ID acak.

Jika kolom atas diisi kata kunci, aplikasi membuka situs DuckDuckGo dan mengirim pencarian itu melalui URL HTTPS. DuckDuckGo dan situs hasil yang dipilih mengikuti kebijakan/cookie mereka. Tidak ada API pencarian atau log pencarian milik pembuat aplikasi; URL terakhir tersimpan lokal seperti riwayat pembaca sebelumnya.

Daftar nama/istilah tetap, pilihan pengenalan otomatis dan nama yang diabaikan disimpan lokal per cerita. Identitas file lokal memakai ID turunan URI file, bukan isi file; tidak dikirim ke server AI. Dalam mode AI, teks memakai penanda nama beserta pemetaan ejaan istilah yang cocok. Nama juga menjadi bagian konteks sementara server pilihan pengguna. Tidak ada pencarian nama ke layanan lain pada mode dasar.

Percobaan ulang OCR dengan kontras dan penilaian warna/ukuran huruf dilakukan di perangkat. Gambar hasil kontras hanya sementara di memori, tidak diunggah oleh fitur ini. Pengelompokan terjemahan dasar dan koreksi pemenggalan baris tetap lokal. Server AI opsional menerima teks seperti sebelumnya; gambar/warna dan cookie situs tidak dikirim.

Beranda menyimpan riwayat maksimal 30 halaman web secara lokal: judul, URL, waktu kunjungan dan posisi gulir. Pencarian DuckDuckGo tidak masuk daftar bab ini. Daftar kosakata OCR dibundel di APK dan tidak mengirim kata ke layanan pemeriksa ejaan. Potongan untuk normalisasi/pelurusan huruf hanya sementara di memori. Riwayat dan pengaturan dapat dihapus lewat pengaturan penyimpanan aplikasi Android.

OCR cadangan Tesseract LSTM dijalankan di HP untuk maksimal dua baris yang belum jelas. Model English sekitar 4 MB dibundel di APK dan disalin ke folder privat aplikasi. Gambar baris hanya di memori selama pembacaan; model ini tidak mengirim teks/gambar ke server. Model dan lisensi ikut dalam paket.
