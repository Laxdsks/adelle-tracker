package com.komiklingo.app;
public class FixturePageActivity extends MainActivity {
 public static volatile int requests=0;public static volatile boolean fail=false;public static volatile String suffix="";public static final java.util.List<String> inputs=java.util.Collections.synchronizedList(new java.util.ArrayList<>());
 @Override protected void prepareLanguage(Runnable ready,Runnable failed){ready.run();}
 @Override protected void translateLocal(String source,NameTranslation.Result result){requests++;inputs.add(source);if(fail){result.done(null,new IllegalStateException("Fixture failure"));return;}result.done((source+suffix).replace("HELLO","HALO").replace("WORLD","DUNIA"),null);}
}
