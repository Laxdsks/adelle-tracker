package com.komiklingo.app;
import android.content.*;
import android.graphics.*;
import android.webkit.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.*;
import org.junit.runner.RunWith;
import java.util.*;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class DialogueContextTest {
 private static final String FIRST="THEY PLAN TO TRANSPORT THEM TO THE BAHAIN KINGDOM AS SOON AS THE COLLECTION OF THE BODIES IS FINISHED-";
 private static final String NEXT="SO THAT THEIR FUNERALS CAN BE HELD IN THEIR HOMELAND.";
 private Object field(Object target,String name){try{var f=MainActivity.class.getDeclaredField(name);f.setAccessible(true);return f.get(target);}catch(Exception e){throw new AssertionError(e);}}
 private void set(Object target,String name,Object value){try{var f=MainActivity.class.getDeclaredField(name);f.setAccessible(true);f.set(target,value);}catch(Exception e){throw new AssertionError(e);}}
 private void call(Object target,String name,Class<?>[] types,Object... values){try{var m=MainActivity.class.getDeclaredMethod(name,types);m.setAccessible(true);m.invoke(target,values);}catch(Exception e){throw new AssertionError(e);}}
 @Test public void followingContextIsNearbyInSameColumnAndClearedWithDocument(){
  PageTranslations saved=new PageTranslations();RectF current=new RectF(30,40,230,150);
  saved.put("SIDE COLUMN","Samping",new RectF(350,180,550,230),Color.WHITE,false,null,1,0,0);
  saved.put("FAR AWAY","Jauh",new RectF(30,1300,230,1400),Color.WHITE,false,null,1,0,0);
  saved.put("OVERLAPPING","Tumpang tindih",new RectF(30,100,230,170),Color.WHITE,false,null,1,0,0);
  assertNull(saved.following(current,300));var next=saved.put(NEXT,"Agar bisa dimakamkan.",new RectF(40,200,250,290),Color.WHITE,false,null,1,0,0);assertSame(next,saved.following(current,300));
  // CSS coordinates keep the same choice after scrolling/zooming.
  RectF css=PageTranslations.css(new RectF(60,60,460,280),2,0,20);assertEquals(current,css);assertSame(next,saved.following(css,300));saved.clear();assertNull(saved.following(current,300));
 }
 @Test public void singleParagraphRetryUsesStoredSourceAndPreservesOtherResult()throws Exception{
  var ins=InstrumentationRegistry.getInstrumentation();var context=ins.getTargetContext();var prefs=context.getSharedPreferences("reader",Context.MODE_PRIVATE);prefs.edit().putBoolean("automatic",false).putString("server","").commit();FixturePageActivity.fail=false;FixturePageActivity.suffix="";FixturePageActivity.inputs.clear();FixturePageActivity.outputMapper=input->{assertTrue(input,input.contains("gathering of the dead bodies"));return "Mereka akan membawanya ke ZXQNAME0QXZ kerajaan setelah koleksi tubuh selesai.";};
  FixturePageActivity a=(FixturePageActivity)ins.startActivitySync(new Intent(context,FixturePageActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  try{ins.runOnMainSync(()->call(a,"showReader",new Class<?>[]{}));ins.waitForIdleSync();ins.runOnMainSync(()->{set(a,"pageCacheEnabled",true);WebView web=(WebView)field(a,"web");assertTrue(web.getHeight()>0);var plan=ProtectedTerms.prepare(FIRST,List.of("Bahain"));set(a,"readingPlans",new ArrayList<>(List.of(plan)));set(a,"readingSources",new ArrayList<>(List.of(FIRST)));set(a,"sourceCaps",new ArrayList<>(List.of(false)));set(a,"readingAppearance",new ArrayList<>());
   PageTranslations saved=(PageTranslations)field(a,"pageTranslations");float scale=web.getScale();saved.clear();var previous=saved.put(FIRST,"Hasil lama",new RectF(30,40,310,140),Color.WHITE,false,null,scale,0,0);var other=saved.put(NEXT,"Agar mereka dimakamkan di tanah air mereka.",new RectF(30,190,310,280),Color.WHITE,false,null,scale,0,0);set(a,"retryEntryId",previous.id);
   call(a,"translateGrouped",new Class<?>[]{List.class,List.class,List.class,long.class},List.of(plan.masked),List.of(new RectF(30,40,310,140)),List.of(Color.WHITE),(Long)field(a,"generation"));
   assertEquals(2,saved.size());assertSame(other,saved.get(other.id));assertTrue(saved.entries().stream().anyMatch(e->e.source.equals(FIRST)&&e.target.contains("kerajaan Bahain")&&e.target.contains("pengumpulan jenazah")));assertEquals(1,FixturePageActivity.inputs.size());assertFalse(FixturePageActivity.inputs.get(0).contains("FUNERALS"));
  });}finally{FixturePageActivity.outputMapper=null;ins.runOnMainSync(a::finish);}
 }
}
