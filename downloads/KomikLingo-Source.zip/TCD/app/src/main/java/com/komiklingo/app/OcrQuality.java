package com.komiklingo.app;
import java.util.*;
import java.util.regex.*;
import java.io.*;

/** Recognition evidence only. Never replaces a word with a dictionary guess. */
public final class OcrQuality {
 private static volatile Set<String> words=Collections.emptySet();
 public static synchronized void load(InputStream input)throws IOException{try(BufferedReader reader=new BufferedReader(new InputStreamReader(input,java.nio.charset.StandardCharsets.UTF_8))){if(!words.isEmpty())return;Set<String> loaded=new HashSet<>();String line;while((line=reader.readLine())!=null)loaded.add(line.trim());words=Collections.unmodifiableSet(loaded);}}
 public static double knownRatio(String text){
  Matcher tokens=Pattern.compile("[A-Za-z0-9]+(?:['’][A-Za-z]+)?").matcher(text);double known=0,total=0;
  while(tokens.find()){String word=tokens.group().toLowerCase(Locale.ROOT).replace('’','\'');if(word.matches("[0-9]+"))continue;total++;if(words.isEmpty()||words.contains(word))known++;}
  return total==0?0:known/total;
 }
 public static boolean mixedGlyphs(String text){return Pattern.compile("(?i)(?:[a-z]+[0-9]+[a-z0-9]*|[0-9]+[a-z]+)").matcher(text).find();}
 public static boolean caps(String text){String letters=text.replaceAll("[^A-Za-z]","");return letters.length()>5&&letters.equals(letters.toUpperCase(Locale.ROOT));}
 public static double score(String text,double confidence){return confidence*.60+knownRatio(text)*.40;}
 public static boolean keepsNames(String original,String candidate,List<String> names){for(String name:names){Pattern match=Pattern.compile("(?iu)(?<![\\p{L}\\p{N}])"+Pattern.quote(name)+"(?![\\p{L}\\p{N}])");if(match.matcher(original).find()&&!match.matcher(candidate).find())return false;}return true;}
}
