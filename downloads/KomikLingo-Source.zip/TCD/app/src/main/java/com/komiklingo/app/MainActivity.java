package com.komiklingo.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.graphics.*;
import android.graphics.pdf.PdfRenderer;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import android.util.LruCache;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.nl.translate.*;
import com.google.mlkit.common.model.DownloadConditions;
import org.json.*;
import java.util.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
 private final Handler main=new Handler(Looper.getMainLooper());
 private final ExecutorService io=Executors.newSingleThreadExecutor();
 private final TextRecognizer ocr=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
 private final Translator translator=Translation.getClient(new TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.INDONESIAN).build());
 private final LruCache<String,String> cache=new LruCache<>(400);
 private LinearLayout root,bar,controls,homeHeader;private ImageButton readerTools;private boolean toolsHidden=false;private boolean capturing=false;private ScrollView homeScreen;private boolean homeVisible=true,pageReady=false,restoring=false;private ReadingHistory history;private long pageVisit=0,restoreTicket=0;private float resumeCss=0;private String resumeUrl="",navigationUrl="";
 private final Runnable saveProgress=()->saveReadingPosition();private FrameLayout stage;private WebView web;private ScrollView local;
 private ImageView picture;private BubbleOverlay overlay;private EditText address;private TextView status;
 private Button originalButton;private boolean automatic=false,original=false,ready=false,busy=false,destroyed=false;
 private boolean paused=false;private volatile boolean fileMode=false;private List<Boolean> sourceCaps=new ArrayList<>();private volatile long generation=0;private int emptyRetries=0;private List<String> latestTranslations=new ArrayList<>();private PdfRenderer pdf;private ParcelFileDescriptor pdfFile;private int page=0;
 private final Runnable settled=()->translateViewport();
 private final PageTranslations pageTranslations=new PageTranslations();private boolean fullPageActive=false,pageCacheEnabled=false,pageComplete=false;private int scanSteps=0,scanFailures=0;private float scanSavedCss=0;private String scanUrl="";private long scanImageWait=0;private int scanEndHeight=-1;private float scanCutTop=Float.NaN;private LinearLayout scanBar;private TextView scanStatus;
 private final Runnable scanStep=()->scanViewport();
 private long retryEntryId=0;private RectF retryArea;
 private android.content.SharedPreferences prefs;
 private String activeStory="local";private List<String> readingSources=new ArrayList<>(),latestSources=new ArrayList<>();
 private List<ProtectedTerms.Plan> readingPlans=new ArrayList<>();
 private List<BubbleOverlay.Appearance> readingAppearance=new ArrayList<>();private int clippedText=0;
 private String documentId=UUID.randomUUID().toString();

 @Override public void onCreate(Bundle state){super.onCreate(state);prefs=getSharedPreferences("reader",MODE_PRIVATE);automatic=prefs.getBoolean("automatic",true);toolsHidden=prefs.getBoolean("reader-tools-hidden",false);history=new ReadingHistory(prefs);if(history.entries().isEmpty())history.record(prefs.getString("url",""),"",0,0);io.execute(()->{try{OcrQuality.load(getAssets().open("english-ocr-words.txt"));TessFallback.prepare(this);}catch(IOException ignored){}});
  getWindow().setStatusBarColor(Color.rgb(15,23,42));getWindow().setNavigationBarColor(Color.rgb(15,23,42));
  root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(15,23,42));
  root.setOnApplyWindowInsetsListener((v,in)->{v.setPadding(in.getSystemWindowInsetLeft(),in.getSystemWindowInsetTop(),in.getSystemWindowInsetRight(),in.getSystemWindowInsetBottom());return in;});setContentView(root);
  homeHeader=row();TextView homeBrand=label("TCD",26);homeBrand.setTypeface(null,Typeface.BOLD);homeBrand.setOnClickListener(v->showHome());homeHeader.addView(homeBrand,new LinearLayout.LayoutParams(0,dp(58),1));homeHeader.addView(AppUi.icon(this,R.drawable.ic_more_tools,"Menu",v->settings()),new LinearLayout.LayoutParams(dp(40),dp(40)));root.addView(homeHeader);
  bar=row();TextView brand=label(getString(R.string.home_brand),16);brand.setTypeface(null,Typeface.BOLD);brand.setTextColor(AppUi.ACCENT);brand.setContentDescription("Beranda");brand.setOnClickListener(v->showHome());bar.addView(brand,new LinearLayout.LayoutParams(dp(48),dp(48)));
  address=new EditText(this);address.setSingleLine();address.setSelectAllOnFocus(true);address.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);address.setOnEditorActionListener((v,action,event)->{if(action==android.view.inputmethod.EditorInfo.IME_ACTION_GO||action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH){open(address.getText().toString());return true;}return false;});address.setTextColor(AppUi.TEXT);address.setTextSize(13);address.setHintTextColor(AppUi.MUTED);address.setHint("Alamat situs atau pencarian");address.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);bar.addView(address,new LinearLayout.LayoutParams(0,dp(48),1));bar.addView(AppUi.icon(this,R.drawable.ic_search_tools,"Cari atau buka",v->open(address.getText().toString())),new LinearLayout.LayoutParams(dp(40),dp(40)));ImageButton more=AppUi.icon(this,R.drawable.ic_more_tools,"Menu",v->settings());LinearLayout.LayoutParams moreLayout=new LinearLayout.LayoutParams(dp(40),dp(40));moreLayout.leftMargin=dp(4);bar.addView(more,moreLayout);root.addView(bar,new LinearLayout.LayoutParams(-1,dp(52)));
  scanBar=row();scanStatus=label("Memindai halaman…",12);scanBar.addView(scanStatus,new LinearLayout.LayoutParams(0,dp(44),1));scanBar.addView(button("Berhenti",v->stopFullPage(true,"Pemindaian dihentikan. Hasil yang sudah dibaca tetap tersedia.")));scanBar.setVisibility(View.GONE);root.addView(scanBar);
  stage=new FrameLayout(this);root.addView(stage,new LinearLayout.LayoutParams(-1,0,1));
  web=new WebView(this);WebSettings ws=web.getSettings();ws.setJavaScriptEnabled(true);ws.setDomStorageEnabled(true);ws.setAllowFileAccess(false);ws.setAllowContentAccess(false);ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);ws.setBuiltInZoomControls(true);ws.setUseWideViewPort(true);ws.setLoadWithOverviewMode(true);ws.setDisplayZoomControls(false);ws.setSupportMultipleWindows(false);
  web.setWebViewClient(new WebViewClient(){
   @Override public void onScaleChanged(WebView w,float old,float next){changed();}
   @Override public void onPageStarted(WebView w,String url,Bitmap icon){resetPageTranslations();pageReady=false;main.removeCallbacks(saveProgress);pageVisit=System.currentTimeMillis();navigationUrl=url;if(!url.startsWith("https://reader.invalid/")){fileMode=false;updateStory(url);if(!homeVisible)history.record(url,"",restoring&&url.equals(resumeUrl)?resumeCss:0,pageVisit);}changed();}
   @Override public WebResourceResponse shouldInterceptRequest(WebView w,WebResourceRequest r){if(fileMode&&r.getUrl().toString().equals("https://reader.invalid/image.png")){try{return new WebResourceResponse("image/png",null,new FileInputStream(new File(getCacheDir(),"reader.png")));}catch(Exception ignored){}}return null;}
@Override public void onPageFinished(WebView w,String url){
   if(homeVisible||!url.equals(w.getUrl())||!url.equals(navigationUrl))return;pageReady=true;
   if(!fileMode){address.setText(ReadingLink.displayAddress(url));try{prefs.edit().putString("url",ReadingLink.normalize(url)).apply();}catch(IllegalArgumentException ignored){}if(restoring&&url.equals(resumeUrl))restorePosition(++restoreTicket,0);else{restoring=false;saveReadingPosition();}}
   else{address.setText("");address.setHint("File terbuka");}
   changed();message(ReadingLink.isSearchPage(url)?"Pilih situs dari hasil pencarian":"Halaman siap");}
@Override public void doUpdateVisitedHistory(WebView w,String url,boolean reload){if(!homeVisible&&!fileMode&&!sameDocumentUrl(url,navigationUrl)){resetPageTranslations();navigationUrl=url;pageVisit=System.currentTimeMillis();updateStory(url);history.record(url,w.getTitle(),0,pageVisit);prefs.edit().putString("url",url).apply();changed();}}
@Override public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){String s=r.getUrl().getScheme();return !"https".equals(s)&&!"http".equals(s);}@Override public void onReceivedError(WebView w,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame())message("Halaman belum terbuka. Periksa internet atau buka tautan lain.");}});
  web.setOnScrollChangeListener((v,x,y,ox,oy)->{changed();main.removeCallbacks(saveProgress);if(!homeVisible&&!restoring)main.postDelayed(saveProgress,600);});web.setOnTouchListener((v,event)->{if(event.getActionMasked()==MotionEvent.ACTION_DOWN&&fullPageActive)stopFullPage(false,"Pemindaian dihentikan. Hasil yang sudah dibaca tetap tersedia.");if(event.getActionMasked()==MotionEvent.ACTION_DOWN&&restoring){restoreTicket++;restoring=false;}return false;});stage.addView(web,new FrameLayout.LayoutParams(-1,-1));
  local=new ScrollView(this);local.setFillViewport(true);picture=new ImageView(this);picture.setAdjustViewBounds(true);picture.setScaleType(ImageView.ScaleType.FIT_CENTER);local.addView(picture,new ScrollView.LayoutParams(-1,-2));local.setVisibility(View.GONE);local.setOnScrollChangeListener((v,x,y,ox,oy)->changed());stage.addView(local,new FrameLayout.LayoutParams(-1,-1));
  overlay=new BubbleOverlay(this);overlay.setResetListener(this::resetSingleTranslation,web);stage.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
  status=label("",12);status.setGravity(Gravity.CENTER);status.setMaxLines(2);status.setEllipsize(android.text.TextUtils.TruncateAt.END);status.setPadding(dp(12),dp(8),dp(12),dp(8));status.setBackground(AppUi.panel(this,0xed0f172a,12));FrameLayout.LayoutParams statusLayout=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);statusLayout.setMargins(dp(12),0,dp(12),dp(8));stage.addView(status,statusLayout);status.setVisibility(View.GONE);
  readerTools=AppUi.icon(this,R.drawable.ic_expand_tools,"Sembunyikan alat",v->setReaderToolsHidden(!toolsHidden));readerTools.setAlpha(.84f);FrameLayout.LayoutParams toolLayout=new FrameLayout.LayoutParams(dp(40),dp(40),Gravity.RIGHT|Gravity.CENTER_VERTICAL);toolLayout.rightMargin=dp(8);stage.addView(readerTools,toolLayout);installToolDrag();stage.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{readerTools.setTranslationX(Math.max(-readerTools.getLeft(),Math.min(stage.getWidth()-readerTools.getRight(),readerTools.getTranslationX())));readerTools.setTranslationY(Math.max(-readerTools.getTop(),Math.min(stage.getHeight()-readerTools.getBottom(),readerTools.getTranslationY())));});
  controls=row();Button translate=button("Terjemahkan",v->{original=false;originalButton.setText("Lihat asli");translateViewport();});translate.setTextColor(AppUi.BACKGROUND);translate.setBackgroundTintList(android.content.res.ColorStateList.valueOf(AppUi.ACCENT));controls.addView(translate,new LinearLayout.LayoutParams(0,dp(48),1));originalButton=button("Lihat asli",v->{original=!original;overlay.setVisibility(original?View.INVISIBLE:View.VISIBLE);originalButton.setText(original?"Terjemahan":"Lihat asli");if(!original)drawPageTranslations();});controls.addView(originalButton,new LinearLayout.LayoutParams(0,dp(48),1));controls.addView(button("Hasil",v->showResults()),new LinearLayout.LayoutParams(dp(70),dp(48)));root.addView(controls);
  message("Unduh model bahasa sekali. Setelah itu, mode dasar bisa tanpa internet untuk file.");
  prepareLanguage(()->{ready=true;message("Mode dasar siap · Inggris → Indonesia");if(automatic)changed();},()->message("Model bahasa belum terunduh. Buka menu → Unduh model dan periksa internet."));
  String shared=getIntent().getStringExtra(Intent.EXTRA_TEXT);getIntent().removeExtra(Intent.EXTRA_TEXT);if(shared!=null&&!shared.trim().isEmpty())handleShared(shared);else showHome();
 }
 private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private LinearLayout row(){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(8),0,dp(8),0);return r;}
 private TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(0xffe2e8f0);t.setTextSize(size);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
 private Button button(String text,View.OnClickListener click){return AppUi.button(this,text,click);}
 private final Runnable hideStatus=()->{if(status!=null&&!busy)status.setVisibility(View.GONE);};
 private void message(String text){if(destroyed||status==null)return;status.setText(text);main.removeCallbacks(hideStatus);if(homeVisible||capturing){status.setVisibility(View.GONE);return;}status.setVisibility(View.VISIBLE);if(!busy)main.postDelayed(hideStatus,3200);}
 private void systemBars(boolean hide){
  getWindow().setStatusBarColor(AppUi.BACKGROUND);getWindow().setNavigationBarColor(AppUi.BACKGROUND);
  if(android.os.Build.VERSION.SDK_INT>=30){WindowInsetsController controller=getWindow().getInsetsController();if(controller!=null){controller.setSystemBarsAppearance(0,WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);if(hide)controller.hide(WindowInsets.Type.systemBars());else controller.show(WindowInsets.Type.systemBars());}}
  else getWindow().getDecorView().setSystemUiVisibility(hide?View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE:View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
 }
 private void applyReaderChrome(){if(readerTools==null)return;overlay.setResetControlsVisible(!homeVisible&&!toolsHidden);if(toolsHidden&&!busy)status.setVisibility(View.GONE);homeHeader.setVisibility(homeVisible?View.VISIBLE:View.GONE);bar.setVisibility(homeVisible||toolsHidden?View.GONE:View.VISIBLE);controls.setVisibility(homeVisible||toolsHidden?View.GONE:View.VISIBLE);readerTools.setVisibility(homeVisible||capturing?View.GONE:View.VISIBLE);readerTools.setImageResource(toolsHidden?R.drawable.ic_menu_tools:R.drawable.ic_expand_tools);readerTools.setContentDescription(toolsHidden?"Tampilkan alat":"Sembunyikan alat");readerTools.setTooltipText(readerTools.getContentDescription());systemBars(!homeVisible&&toolsHidden);root.requestApplyInsets();}
 private void setReaderToolsHidden(boolean hidden){toolsHidden=hidden;prefs.edit().putBoolean("reader-tools-hidden",hidden).apply();if(hidden){address.clearFocus();((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);}applyReaderChrome();web.post(this::changed);}
 private void installToolDrag(){readerTools.setOnTouchListener(new View.OnTouchListener(){float startX,startY,originalX,originalY;boolean moved;public boolean onTouch(View view,MotionEvent event){switch(event.getActionMasked()){case MotionEvent.ACTION_DOWN:startX=event.getRawX();startY=event.getRawY();originalX=view.getTranslationX();originalY=view.getTranslationY();moved=false;return true;case MotionEvent.ACTION_MOVE:float dx=event.getRawX()-startX,dy=event.getRawY()-startY;if(Math.hypot(dx,dy)>dp(7))moved=true;if(moved){view.setTranslationX(Math.max(-view.getLeft(),Math.min(stage.getWidth()-view.getRight(),originalX+dx)));view.setTranslationY(Math.max(-view.getTop(),Math.min(stage.getHeight()-view.getBottom(),originalY+dy)));}return true;case MotionEvent.ACTION_UP:if(!moved)view.performClick();return true;case MotionEvent.ACTION_CANCEL:return true;default:return false;}}});}
 private void showReader(){homeVisible=false;if(homeScreen!=null)homeScreen.setVisibility(View.GONE);web.setVisibility(View.VISIBLE);web.onResume();applyReaderChrome();}
 private AlertDialog showHistory(){List<ReadingHistory.Entry> entries=history.entries();String[] titles=new String[entries.size()];for(int i=0;i<titles.length;i++)titles[i]=entries.get(i).title;return new AlertDialog.Builder(this).setTitle("Riwayat").setItems(titles,(dialog,which)->{ReadingHistory.Entry entry=entries.get(which);open(entry.url,entry.scroll);}).setNegativeButton("Tutup",null).show();}
 private void openTextEditor(){startActivity(new Intent(this,TextTranslationActivity.class));}
 private void showHome(){
  if(fullPageActive)stopFullPage(false,"");saveReadingPosition();homeVisible=true;restoreTicket++;restoring=false;main.removeCallbacks(saveProgress);main.removeCallbacks(settled);main.removeCallbacks(hideStatus);generation++;overlay.clear();web.stopLoading();web.onPause();web.setVisibility(View.GONE);local.setVisibility(View.GONE);status.setVisibility(View.GONE);applyReaderChrome();
  if(homeScreen!=null)stage.removeView(homeScreen);homeScreen=new ScrollView(this);homeScreen.setFillViewport(true);LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(20),dp(28),dp(20),dp(28));homeScreen.addView(page);stage.addView(homeScreen,new FrameLayout.LayoutParams(-1,-1));
  TextView language=label("Inggris → Indonesia",17);language.setTextColor(AppUi.MUTED);page.addView(language,new LinearLayout.LayoutParams(-1,dp(40)));
  LinearLayout choices=row();choices.setPadding(0,dp(16),0,dp(16));choices.addView(button("Teks",v->openTextEditor()),new LinearLayout.LayoutParams(0,dp(70),1));choices.addView(button("Gambar & file",v->chooseFile()),new LinearLayout.LayoutParams(0,dp(70),1));page.addView(choices);
  LinearLayout search=row();search.setPadding(0,dp(8),0,dp(8));EditText query=new EditText(this);query.setSingleLine();query.setTextColor(AppUi.TEXT);query.setHintTextColor(AppUi.MUTED);query.setTextSize(15);query.setHint("Alamat situs atau kata kunci");query.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);query.setOnEditorActionListener((v,action,event)->{if(action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH){open(query.getText().toString());return true;}return false;});search.addView(query,new LinearLayout.LayoutParams(0,dp(56),1));search.addView(AppUi.icon(this,R.drawable.ic_search_tools,"Cari atau buka situs",v->open(query.getText().toString())),new LinearLayout.LayoutParams(dp(44),dp(44)));page.addView(search);
  page.addView(button("Terjemahan layar",v->startActivity(new Intent(this,FloatingSetupActivity.class))),new LinearLayout.LayoutParams(-1,dp(54)));
  List<ReadingHistory.Entry> entries=history.entries();if(!entries.isEmpty()){ReadingHistory.Entry latest=entries.get(0);TextView heading=label("Terakhir dibuka",16);heading.setTextColor(AppUi.MUTED);heading.setPadding(0,dp(24),0,0);page.addView(heading,new LinearLayout.LayoutParams(-1,dp(58)));Button resume=button("Lanjutkan · "+latest.title,v->open(latest.url,latest.scroll));resume.setSingleLine(false);resume.setMaxLines(2);page.addView(resume,new LinearLayout.LayoutParams(-1,dp(70)));page.addView(button("Riwayat",v->showHistory()),new LinearLayout.LayoutParams(-1,dp(48)));}
 }
 private void saveReadingPosition(){
  if(history==null||homeVisible||!pageReady||fileMode||restoring||web.getUrl()==null)return;float scale=Math.max(.1f,web.getScale());history.record(web.getUrl(),web.getTitle(),web.getScrollY()/scale,pageVisit);
 }
 private void restorePosition(long ticket,int attempt){
  if(destroyed||homeVisible||ticket!=restoreTicket||!restoring)return;
  web.postDelayed(()->{if(destroyed||homeVisible||ticket!=restoreTicket||!restoring)return;int wanted=Math.round(resumeCss*web.getScale());web.scrollTo(0,wanted);if(attempt<4&&Math.abs(web.getScrollY()-wanted)>8)restorePosition(ticket,attempt+1);else{restoring=false;saveReadingPosition();}},attempt==0?200:400);
 }
 private void open(String input){open(input,0);}
 private void open(String input,float scroll){
  String url;try{url=ReadingLink.resolve(input);}catch(IllegalArgumentException error){message("Masukkan alamat situs atau kata kunci.");android.widget.Toast.makeText(this,"Masukkan alamat atau kata kunci dulu.",android.widget.Toast.LENGTH_SHORT).show();return;}
  saveReadingPosition();resetPageTranslations();showReader();pageReady=false;restoreTicket++;resumeUrl=url;navigationUrl=url;resumeCss=Math.max(0,scroll);restoring=resumeCss>0;pageVisit=System.currentTimeMillis();history.record(url,"",resumeCss,pageVisit);
  documentId=UUID.randomUUID().toString();updateStory(url);fileMode=false;closePdf();changed();local.setVisibility(View.GONE);address.setText(url);web.stopLoading();web.loadUrl(url);prefs.edit().putString("url",url).apply();
 }
 @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);String shared=intent.getStringExtra(Intent.EXTRA_TEXT);intent.removeExtra(Intent.EXTRA_TEXT);if(shared!=null&&!shared.trim().isEmpty())handleShared(shared);else showHome();}
 private void handleShared(String shared){if(ReadingLink.sharedAsUrl(shared))open(shared);else{showHome();startActivity(new Intent(this,TextTranslationActivity.class).putExtra(Intent.EXTRA_TEXT,shared));}}
 private void updateStory(String url){try{String key=ReadingLink.storyKey(ReadingLink.normalize(url));if(!key.equals(activeStory)){activeStory=key;documentId=UUID.randomUUID().toString();}}catch(IllegalArgumentException ignored){}}
 private String readingStyle(){return prefs.getString("style:"+activeStory,ReadingText.DIALOGUE);}
 private void openAddressDialog(){EditText input=new EditText(this);input.setSingleLine();input.setHint("Alamat situs atau kata kunci");input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);new AlertDialog.Builder(this).setTitle("Cari atau buka situs").setMessage("Masukkan alamat situs atau kata kunci. Pencarian memakai DuckDuckGo.").setView(input).setPositiveButton("Cari / buka",(d,w)->open(input.getText().toString())).setNegativeButton("Batal",null).show();}
 private void styleSettings(){String[] titles={"Natural · aku–kamu","Netral · saya–kamu","Formal · saya–Anda"};String[] values={ReadingText.DIALOGUE,ReadingText.NEUTRAL,ReadingText.FORMAL};int selected=java.util.Arrays.asList(values).indexOf(readingStyle());new AlertDialog.Builder(this).setTitle("Gaya bahasa").setSingleChoiceItems(titles,Math.max(0,selected),(d,n)->{prefs.edit().putString("style:"+activeStory,values[n]).apply();documentId=UUID.randomUUID().toString();resetPageTranslations();changed();message("Gaya bahasa disimpan.");d.dismiss();}).setNegativeButton("Tutup",null).show();}
 private List<String> storyTerms(){
  String key="terms:"+activeStory;
  if(!prefs.getBoolean("names-seeded:"+activeStory,false)){
   List<String> existing=ProtectedTerms.parse(prefs.getString(key,""));
   for(String term:ProtectedTerms.defaults(activeStory))if(!containsTerm(existing,term)&&existing.size()<80)existing.add(term);
   prefs.edit().putString(key,android.text.TextUtils.join("\n",existing)).putBoolean("names-seeded:"+activeStory,true).apply();
  }
  return ProtectedTerms.parse(prefs.getString(key,""));
 }
 private static boolean containsTerm(List<String> terms,String term){for(String value:terms)if(value.equalsIgnoreCase(term))return true;return false;}
 private List<String> learnNames(List<String> texts){
  List<String> terms=storyTerms();
  if(prefs.getBoolean("auto-names:"+activeStory,true)){
   Set<String> ignored=prefs.getStringSet("ignored-terms:"+activeStory,Collections.emptySet());
   for(String name:ProtectedTerms.discover(texts))if(terms.size()<80&&!containsTerm(terms,name)&&!ignored.contains(name.toLowerCase(Locale.ROOT)))terms.add(name);
   prefs.edit().putString("terms:"+activeStory,android.text.TextUtils.join("\n",terms)).apply();
  }
  return terms;
 }
 private AlertDialog nameSettings(){
  final String story=activeStory;List<String> before=storyTerms();
  LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(20),0,dp(20),0);
  EditText names=new EditText(this);names.setHint("Nama atau istilah\nSatu per baris");names.setText(android.text.TextUtils.join("\n",before));names.setMinLines(4);names.setMaxLines(9);names.setGravity(Gravity.TOP);names.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);form.addView(names);
  CheckBox auto=new CheckBox(this);auto.setText("Kenali nama dari sapaan/perkenalan");auto.setChecked(prefs.getBoolean("auto-names:"+story,true));form.addView(auto);
  ScrollView scroll=new ScrollView(this);scroll.addView(form);
  AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Nama & istilah tetap").setMessage("Untuk sumber yang sedang dibuka. Satu nama atau istilah per baris. Ejaannya dipertahankan.\n\nPengenalan otomatis masih bisa keliru, terutama huruf kapital semua. Periksa daftar ini; nama yang dihapus tidak ditambahkan otomatis lagi.").setView(scroll).setPositiveButton("Simpan",null).setNegativeButton("Batal",null).create();
  dialog.setOnShowListener(v->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(button->{try{
   List<String> terms=ProtectedTerms.parse(names.getText().toString());Set<String> ignored=new HashSet<>(prefs.getStringSet("ignored-terms:"+story,Collections.emptySet()));
   for(String old:before)if(!containsTerm(terms,old))ignored.add(old.toLowerCase(Locale.ROOT));
   for(String term:terms)ignored.remove(term.toLowerCase(Locale.ROOT));
   prefs.edit().putString("terms:"+story,android.text.TextUtils.join("\n",terms)).putStringSet("ignored-terms:"+story,ignored).putBoolean("auto-names:"+story,auto.isChecked()).apply();
   cache.evictAll();documentId=UUID.randomUUID().toString();resetPageTranslations();changed();message("Nama disimpan. Terjemahan berikutnya memakai daftar ini.");dialog.dismiss();
  }catch(IllegalArgumentException error){names.setError(error.getMessage());}}));dialog.show();return dialog;
 }
 protected void prepareLanguage(Runnable success,Runnable failure){translator.downloadModelIfNeeded(new DownloadConditions.Builder().build()).addOnSuccessListener(v->success.run()).addOnFailureListener(e->failure.run());}
 protected void translateLocal(String source,NameTranslation.Result result){translator.translate(source).addOnSuccessListener(value->result.done(value,null)).addOnFailureListener(error->result.done(null,error));}
 private static boolean sameDocumentUrl(String first,String second){if(first==null||second==null)return java.util.Objects.equals(first,second);return first.split("#",2)[0].equals(second.split("#",2)[0]);}
 private void resetPageTranslations(){cancelSingleRetry();fullPageActive=false;main.removeCallbacks(scanStep);pageTranslations.clear();pageCacheEnabled=true;pageComplete=false;if(scanBar!=null)scanBar.setVisibility(View.GONE);enableControls(true);}
 private void enableControls(boolean enabled){if(controls!=null)for(int i=0;i<controls.getChildCount();i++)controls.getChildAt(i).setEnabled(enabled);}
 private void drawPageTranslations(){if(pageCacheEnabled&&!fullPageActive&&!original&&web.getVisibility()==View.VISIBLE)overlay.show(pageTranslations.visible(web.getScale(),web.getScrollX(),web.getScrollY(),web.getWidth(),web.getHeight()));}
 private void beginFullPage(){
  if(homeVisible||web.getVisibility()!=View.VISIBLE||ReadingLink.isSearchPage(web.getUrl())){message("Buka sumber yang ingin diterjemahkan dulu.");return;}
  if(!ready&&prefs.getString("server","").isEmpty()){message("Model bahasa belum siap. Tunggu unduhan model selesai.");return;}
  if(fullPageActive)return;if(busy){message("Tunggu bagian yang sedang diterjemahkan selesai dulu.");return;}cancelSingleRetry();original=false;originalButton.setText("Lihat asli");pageCacheEnabled=true;pageComplete=false;fullPageActive=true;scanSteps=0;scanFailures=0;scanEndHeight=-1;scanSavedCss=web.getScrollY()/Math.max(.1f,web.getScale());scanUrl=web.getUrl();scanImageWait=0;scanBar.setVisibility(View.VISIBLE);enableControls(false);generation++;web.scrollTo(0,0);scheduleScan(450);
 }
 private void scheduleScan(long delay){main.removeCallbacks(scanStep);if(fullPageActive&&!paused&&!destroyed)main.postDelayed(scanStep,delay);}
 private void scanViewport(){
  if(!fullPageActive||paused||destroyed)return;if(!sameDocumentUrl(scanUrl,web.getUrl())){resetPageTranslations();return;}if(busy){scheduleScan(300);return;}
  if(scanImageWait==0)scanImageWait=android.os.SystemClock.uptimeMillis();final long stepTicket=generation;
  web.evaluateJavascript("JSON.stringify({y:scrollY,h:innerHeight,total:document.scrollingElement.scrollHeight,ready:Array.from(document.images).filter(i=>{const r=i.getBoundingClientRect();return r.bottom>0&&r.top<innerHeight}).every(i=>i.complete)})",value->{
   if(!fullPageActive)return;if(stepTicket!=generation){scheduleScan(300);return;}
   try{JSONObject info=new JSONObject((String)new JSONTokener(value).nextValue());int height=info.getInt("total");boolean end=info.getDouble("y")+info.getDouble("h")>=height-2;
    if(scanEndHeight==height&&end){pageComplete=scanFailures==0;stopFullPage(true,"Pemindaian selesai · "+pageTranslations.size()+" bagian"+(scanFailures>0?"; sebagian perlu dicoba lagi.":". Hasil tetap ada saat digulir."));return;}
    int percent=(int)Math.min(100,100*info.getDouble("y")/Math.max(1,height-info.getDouble("h")));scanStatus.setText("Memindai 1 halaman · "+percent+"% · "+pageTranslations.size()+" bagian");
    if(!info.getBoolean("ready")&&android.os.SystemClock.uptimeMillis()-scanImageWait<7000){scheduleScan(500);return;}scanImageWait=0;translateViewport();
   }catch(Exception error){stopFullPage(true,"Halaman ini belum bisa dipindai otomatis. Gunakan Terjemahkan pada bagian yang terlihat.");}
  });
 }
 private void advanceFullPage(){
  if(!fullPageActive)return;scanSteps++;if(scanSteps>=400||pageTranslations.size()>=6000){stopFullPage(true,"Halaman sangat panjang. Batas pemindaian tercapai; bagian yang terbaca tetap tersedia.");return;}
  final long stepTicket=generation;final float cutCss=Float.isNaN(scanCutTop)?Float.NaN:scanCutTop/Math.max(.1f,web.getScale());
  web.evaluateJavascript("JSON.stringify({y:scrollY,h:innerHeight,total:document.scrollingElement.scrollHeight})",value->{
   if(!fullPageActive)return;if(stepTicket!=generation){scheduleScan(300);return;}
   try{JSONObject info=new JSONObject((String)new JSONTokener(value).nextValue());double y=info.getDouble("y"),height=info.getDouble("h");int total=info.getInt("total");
    if(y+height>=total-2){scanEndHeight=total;scheduleScan(650);return;}
    scanEndHeight=-1;double distance=Math.max(50,height*.55);if(!Float.isNaN(cutCss)&&cutCss>16)distance=Math.max(20,Math.min(distance,cutCss-8));
    web.evaluateJavascript("window.scrollTo(0,"+Math.min(total-height,y+distance)+")",ignored->scheduleScan(350));
   }catch(Exception error){stopFullPage(true,"Pemindaian berhenti. Hasil yang sudah dibaca tetap tersedia.");}
  });
 }
 private void stopFullPage(boolean restore,String reason){
  if(!fullPageActive)return;fullPageActive=false;main.removeCallbacks(scanStep);generation++;scanBar.setVisibility(View.GONE);enableControls(true);if(restore)web.scrollTo(0,Math.round(scanSavedCss*web.getScale()));drawPageTranslations();message(reason);web.post(this::drawPageTranslations);
 }
 private void queueRead(long delay){main.removeCallbacks(settled);if(fullPageActive){scheduleScan(delay);return;}if(pageCacheEnabled&&pageComplete)return;if(automatic&&!homeVisible&&!original&&!destroyed&&!paused&&!ReadingLink.isSearchPage(web.getUrl())&&!pageTranslations.scanned(web.getScale(),web.getScrollX(),web.getScrollY(),web.getWidth(),web.getHeight()))main.postDelayed(settled,delay);}
 private void changed(){cancelSingleRetry();generation++;emptyRetries=0;latestTranslations.clear();latestSources.clear();if(fullPageActive||!pageCacheEnabled)overlay.clear();else drawPageTranslations();queueRead(1000);}
 private void cancelSingleRetry(){if(retryEntryId!=0){PageTranslations.Entry entry=pageTranslations.get(retryEntryId);if(entry!=null)entry.pending=false;}retryEntryId=0;retryArea=null;}
 private void resetSingleTranslation(long id){
  if(busy||fullPageActive){message("Tunggu terjemahan yang sedang berjalan selesai dulu.");android.widget.Toast.makeText(this,"Tunggu sebentar, teks sedang diproses.",android.widget.Toast.LENGTH_SHORT).show();return;}
  if(!ready&&prefs.getString("server","").isEmpty()){message("Tunggu model bahasa siap sebelum Reset.");return;}PageTranslations.Entry entry=pageTranslations.get(id);if(entry==null||homeVisible)return;
  if(entry.css.top*web.getScale()<web.getScrollY()+dp(12)||entry.css.bottom*web.getScale()>web.getScrollY()+web.getHeight()-dp(12))web.scrollTo(web.getScrollX(),Math.max(0,Math.round(entry.css.centerY()*web.getScale()-web.getHeight()/2f)));
  final long pageTicket=generation;main.removeCallbacks(settled);main.postDelayed(()->{if(destroyed||paused||pageTicket!=generation||pageTranslations.get(id)!=entry)return;retryEntryId=id;retryArea=new RectF(entry.css);entry.pending=true;cache.evictAll();original=false;originalButton.setText("Lihat asli");drawPageTranslations();translateViewport();},300);
 }
 private void restoreCachedOverlay(){if(destroyed)return;capturing=false;applyReaderChrome();if(!homeVisible&&!status.getText().toString().isEmpty()){status.setVisibility(View.VISIBLE);if(!busy)main.postDelayed(hideStatus,3200);}overlay.setVisibility(original?View.INVISIBLE:View.VISIBLE);drawPageTranslations();}
 private void translateViewport(){
  if(destroyed||homeVisible||original||paused)return;if(busy){queueRead(700);return;}
  String endpoint=prefs.getString("server","");boolean ai=!endpoint.isEmpty();
  if(!ai&&!ready){message("Model bahasa sedang disiapkan. Periksa internet; coba menu Unduh model.");return;}
  View content=local.getVisibility()==View.VISIBLE?local:web;int w=content.getWidth(),h=content.getHeight();if(w<1||h<1)return;
  if(retryEntryId==0&&pageTranslations.scanned(web.getScale(),web.getScrollX(),web.getScrollY(),w,h)){drawPageTranslations();if(fullPageActive)advanceFullPage();else message("Hasil tersimpan");return;}
  long ticket=++generation;busy=true;overlay.setVisibility(View.INVISIBLE);message("Membaca teks pada bagian yang terlihat…");
  capturing=true;readerTools.setVisibility(View.INVISIBLE);status.setVisibility(View.INVISIBLE);
  ViewportCapture.capture(getWindow(),content,new ViewportCapture.Callback(){
   @Override public void success(Bitmap shot,float scale){restoreCachedOverlay();recognizeViewport(shot,scale,ticket,ai,endpoint,w,h);}
   @Override public void failure(int reason){busy=false;cancelSingleRetry();restoreCachedOverlay();if(destroyed)return;if(ticket!=generation){queueRead(500);return;}if(fullPageActive){stopFullPage(true,"Pemindaian berhenti karena layar belum bisa dibaca. Hasil sebelumnya tetap ada; coba lagi.");return;}message(reason==ViewportCapture.NO_MEMORY?"Memori HP penuh. Tutup aplikasi lain lalu coba lagi.":"Gambar layar belum bisa diambil. Tunggu halaman tampil, lalu tekan Terjemahkan lagi.");}
  });
 }
 private void recognizeViewport(Bitmap shot,float scale,long ticket,boolean ai,String endpoint,int w,int h){
  if(destroyed||ticket!=generation){shot.recycle();busy=false;queueRead(500);return;}
  readPageText(shot,ticket,new OcrReader.Result(){@Override public void success(Text result){
   if(destroyed||ticket!=generation){shot.recycle();busy=false;queueRead(500);return;}
   final boolean scanning=fullPageActive;final long selectedId=retryEntryId;final RectF selected=retryArea==null?null:new RectF(retryArea);final float pageScale=web.getScale();final int scrollX=web.getScrollX(),scrollY=web.getScrollY();final List<RectF> cachedAreas=new ArrayList<>();for(PageTranslations.Entry saved:pageTranslations.entries())cachedAreas.add(new RectF(saved.css));final List<String> knownNames=storyTerms();io.execute(()->{
   ArrayList<String> texts=new ArrayList<>();ArrayList<Boolean> caps=new ArrayList<>();ArrayList<BubbleOverlay.Appearance> appearances=new ArrayList<>();int clipped=0;float cutTop=Float.NaN;ArrayList<RectF> boxes=new ArrayList<>();ArrayList<Integer> colors=new ArrayList<>();
   for(OcrAppearance.Paragraph paragraph:OcrAppearance.readingParagraphs(shot,result,knownNames,scanning)){
     String text=paragraph.source;Rect r=paragraph.bounds;
     float edge=Math.max(2,scale*2);if(r.top<=edge||r.bottom>=shot.getHeight()-edge){clipped++;if(scanning&&r.top>edge&&r.bottom>=shot.getHeight()-edge)cutTop=Float.isNaN(cutTop)?r.top/scale:Math.min(cutTop,r.top/scale);continue;}
     if(ContextMeaning.dangling(text,knownNames)){clipped++;continue;}
     if(text.length()<2||!text.matches("(?s).*[a-zA-Z].*")||r.width()<10||r.height()<8)continue;
     RectF rect=new RectF(r);float extraX=Math.max(7*scale,Math.min(15*scale,paragraph.sourceSize*(paragraph.italic?.23f:.12f))),extraY=Math.max(5*scale,Math.min(9*scale,paragraph.sourceSize*.12f));rect.inset(-extraX,-extraY);rect.left=Math.max(0,rect.left/scale);rect.right=Math.min(w,rect.right/scale);rect.top=Math.max(0,rect.top/scale);rect.bottom=Math.min(h,rect.bottom/scale);RectF area=PageTranslations.css(rect,pageScale,scrollX,scrollY);if(selected!=null){if(PageTranslations.overlap(area,selected)<.45f)continue;}else{boolean saved=false;for(RectF previous:cachedAreas){RectF shared=new RectF(area);if(shared.intersect(previous)&&shared.width()*shared.height()>=area.width()*area.height()*.86f){saved=true;break;}}if(saved)continue;}
     texts.add(text);caps.add(text.replaceAll("[^A-Za-z]","").length()>=2&&text.equals(text.toUpperCase(Locale.ROOT)));boxes.add(rect);colors.add(paragraph.background);
     appearances.add(new BubbleOverlay.Appearance(paragraph.ink,paragraph.sourceSize/scale,paragraph.leftAligned,paragraph.italic));if(texts.size()>=40)break;
   }
   final int cutCount=clipped;final float cutEdge=cutTop;main.post(()->{if(destroyed||ticket!=generation){shot.recycle();busy=false;queueRead(500);return;}sourceCaps=caps;readingAppearance=appearances;clippedText=cutCount;scanCutTop=cutEdge;
   shot.recycle();if(texts.isEmpty()){busy=false;if(selectedId!=0){cancelSingleRetry();drawPageTranslations();message("Bagian itu belum terbaca ulang. Hasil sebelumnya tetap disimpan; perbesar teks lalu tekan Reset lagi.");return;}if(fullPageActive){advanceFullPage();return;}if(!pageTranslations.visible(web.getScale(),web.getScrollX(),web.getScrollY(),w,h).isEmpty()){drawPageTranslations();message("Hasil tersimpan");return;}if(clippedText==0&&emptyRetries++<2)queueRead(1800);message(clippedText>0?"Kalimat belum utuh. Gulir sedikit agar seluruh balonnya terlihat.":"Teks belum dikenali. Perbesar huruf atau berhenti di balon yang utuh.");return;}
   message(ai?"Menerjemahkan dialog dengan AI…":"Menerjemahkan di HP…");
   List<String> terms=learnNames(texts);readingPlans=new ArrayList<>();int nameIndex=0;
   for(int i=0;i<texts.size();i++){String clean=ProtectedTerms.cleanOcr(texts.get(i),terms);texts.set(i,clean);ProtectedTerms.Plan plan=ProtectedTerms.prepare(clean,terms,nameIndex);readingPlans.add(plan);nameIndex+=plan.names().size()+1;}
   readingSources=new ArrayList<>(texts);ArrayList<String> masked=new ArrayList<>();for(ProtectedTerms.Plan plan:readingPlans)masked.add(plan.masked);
   if(ai){translateAi(endpoint,masked,boxes,colors,ticket);return;}
   translateGrouped(masked,boxes,colors,ticket);
   });});
  }@Override public void failure(Exception error){shot.recycle();busy=false;cancelSingleRetry();restoreCachedOverlay();if(destroyed)return;if(ticket!=generation){queueRead(500);return;}if(fullPageActive){scanFailures++;advanceFullPage();return;}message("Pembaca teks gagal memproses gambar. Coba lagi atau buka file gambar.");}});
 }
 private void readPageText(Bitmap shot,long ticket,OcrReader.Result callback){
  Rect region=new Rect(0,0,shot.getWidth(),shot.getHeight());Bitmap input=shot;
  if(retryArea!=null){float viewScale=web.getScale(),imageScale=shot.getWidth()/(float)Math.max(1,web.getWidth());RectF area=new RectF(retryArea);area.left=(area.left*viewScale-web.getScrollX())*imageScale;area.right=(area.right*viewScale-web.getScrollX())*imageScale;area.top=(area.top*viewScale-web.getScrollY())*imageScale;area.bottom=(area.bottom*viewScale-web.getScrollY())*imageScale;area.inset(-12*imageScale,-10*imageScale);area.roundOut(region);if(!region.intersect(0,0,shot.getWidth(),shot.getHeight())){callback.failure(new IllegalStateException("Bagian di luar layar"));return;}try{input=Bitmap.createBitmap(shot,region.left,region.top,region.width(),region.height());}catch(RuntimeException|OutOfMemoryError error){callback.failure(new IllegalStateException("Bagian belum bisa dibaca"));return;}}
  final Bitmap cropped=input;final int x=region.left,y=region.top;OcrReader.read(ocr,cropped,io,()->!destroyed&&ticket==generation,storyTerms(),new OcrReader.Result(){public void success(Text text){if(cropped!=shot)cropped.recycle();callback.success(x==0&&y==0?text:OcrReader.offset(text,x,y));}public void failure(Exception error){if(cropped!=shot)cropped.recycle();callback.failure(error);}});
 }
 private final NameTranslation.Engine localEngine=(source,result)->{
  String cached=cache.get(source);if(cached!=null){result.done(cached,null);return;}
  translateLocal(source,(value,error)->{if(error==null&&value!=null)cache.put(source,value);result.done(value,error);});
 };
 private void translateGrouped(List<String> texts,List<RectF> boxes,List<Integer> colors,long ticket){
  TranslationFlow.translate(readingPlans,localEngine,()->{
   if(destroyed)return false;if(ticket!=generation){busy=false;queueRead(500);return false;}return true;
  },(values,failed)->finish(values,boxes,colors,ticket,failed));
 }
 private void finish(List<String> translated,List<RectF> boxes,List<Integer> colors,long ticket,int failed){
  if(destroyed)return;if(ticket!=generation){busy=false;queueRead(500);return;}busy=false;
  List<String> adjusted=new ArrayList<>();boolean ai=!prefs.getString("server","").isEmpty();
  for(int i=0;i<translated.size();i++){
   String raw=translated.get(i),source=i<readingSources.size()?readingSources.get(i):"";String value="";
   if(i<readingPlans.size()&&readingPlans.get(i).valid(raw)){
    ProtectedTerms.Plan plan=readingPlans.get(i);String styled=ai?ReadingText.paragraphs(raw):ReadingText.style(source,raw,readingStyle());
    if(plan.valid(styled)){value=plan.restore(styled);if(!ai)value=ReadingText.emotion(source,value);}
   }
   if(value.isEmpty()&&!raw.isEmpty())failed++;adjusted.add(value);
  }
  latestSources=new ArrayList<>(readingSources);latestTranslations=new ArrayList<>(adjusted);ArrayList<BubbleOverlay.Bubble> results=new ArrayList<>();
  for(int i=0;i<adjusted.size();i++)if(!adjusted.get(i).isEmpty()){boolean caps=i<sourceCaps.size()&&sourceCaps.get(i);results.add(new BubbleOverlay.Bubble(boxes.get(i),caps?adjusted.get(i).toUpperCase(new Locale("id")):adjusted.get(i),colors.get(i),caps,i<readingAppearance.size()?readingAppearance.get(i):null));}
  boolean retried=retryEntryId!=0;boolean resetWorked=retried&&failed==0&&!adjusted.isEmpty()&&adjusted.stream().allMatch(value->!value.isEmpty());if(resetWorked)pageTranslations.remove(retryEntryId);
  if(pageCacheEnabled&&(!retried||resetWorked)){for(int i=0;i<adjusted.size();i++)pageTranslations.put(readingSources.get(i),adjusted.get(i),boxes.get(i),colors.get(i),i<sourceCaps.size()&&sourceCaps.get(i),i<readingAppearance.size()?readingAppearance.get(i):null,web.getScale(),web.getScrollX(),web.getScrollY(),retried);}
  if(!retried&&failed==0&&clippedText==0&&adjusted.size()<40)pageTranslations.markScanned(web.getScale(),web.getScrollX(),web.getScrollY(),web.getWidth(),web.getHeight());cancelSingleRetry();
  if(fullPageActive){scanFailures+=failed;advanceFullPage();return;}if(pageCacheEnabled)drawPageTranslations();else overlay.show(results);if(retried){message(resetWorked?"Bagian diperbarui":"Belum berhasil membaca ulang. Hasil sebelumnya tetap disimpan; coba Reset lagi.");return;}message(failed>0?"Sebagian belum berhasil. Coba ulang.":clippedText>0?"Ada kalimat terpotong. Gulir agar terlihat utuh.":"Terjemahan tersimpan");
 }
 private void translateAi(String endpoint,List<String> texts,List<RectF> boxes,List<Integer> colors,long ticket){String token=prefs.getString("token",""), doc=documentId, style=readingStyle(),notes=prefs.getString("notes:"+activeStory,"");List<ProtectedTerms.Plan> plans=new ArrayList<>(readingPlans);io.execute(()->{try{HttpsURLConnectionHelper reply=new HttpsURLConnectionHelper(endpoint,token,texts,doc,style,notes,plans);List<String> out=reply.result;main.post(()->finish(out,boxes,colors,ticket,0));}catch(Exception e){main.post(()->{busy=false;cancelSingleRetry();restoreCachedOverlay();if(ticket!=generation){queueRead(500);return;}if(ticket==generation){if(fullPageActive){stopFullPage(true,"Pemindaian berhenti karena server AI belum tersambung. Hasil sebelumnya tetap ada.");return;}message("Server AI belum bisa dipakai. Periksa pengaturan atau kosongkan server untuk mode dasar.");}});}});}
 private static class HttpsURLConnectionHelper { List<String> result=new ArrayList<>();HttpsURLConnectionHelper(String endpoint,String token,List<String> texts,String documentId,String style,String notes,List<ProtectedTerms.Plan> plans)throws Exception{
  JSONArray names=new JSONArray();for(ProtectedTerms.Plan plan:plans)names.put(new JSONObject(plan.names()));
  URL url=new URL(endpoint);if(!safeServer(endpoint))throw new IOException();HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(120000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Authorization","Bearer "+token);byte[] payload=new JSONObject().put("documentId",documentId).put("style",style).put("storyNotes",notes).put("texts",new JSONArray(texts)).put("protectedTerms",names).toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);try(OutputStream out=c.getOutputStream()){out.write(payload);}try{if(c.getResponseCode()!=200)throw new IOException();ByteArrayOutputStream body=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){body.write(buf,0,n);if(body.size()>200000)throw new IOException();}}JSONArray translated=new JSONObject(body.toString("UTF-8")).getJSONArray("translations");if(translated.length()!=texts.size())throw new IOException();for(int i=0;i<translated.length();i++){String t=translated.getString(i);if(t.length()>10000||!plans.get(i).valid(t))throw new IOException();result.add(t);}}finally{c.disconnect();}
 }}
 private void chooseFile(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","application/pdf","text/plain"});i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,41);}
 @Override protected void onActivityResult(int req,int code,Intent data){super.onActivityResult(req,code,data);if(req!=41||code!=RESULT_OK||data==null)return;Uri uri=data.getData();resetPageTranslations();showReader();activeStory="file:"+UUID.nameUUIDFromBytes(uri.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));documentId=UUID.randomUUID().toString();changed();closePdf();String type=getContentResolver().getType(uri);try{
  if("application/pdf".equals(type)){pdfFile=getContentResolver().openFileDescriptor(uri,"r");pdf=new PdfRenderer(pdfFile);page=0;showPdf();return;}
  if("text/plain".equals(type)){byte[] bytes=readLimited(uri,2*1024*1024);String text=new String(bytes,java.nio.charset.StandardCharsets.UTF_8);web.setVisibility(View.VISIBLE);local.setVisibility(View.GONE);web.loadDataWithBaseURL("https://reader.invalid/","<html><meta name='viewport' content='width=device-width'><body style='padding:18px;font:20px/1.8 sans-serif;white-space:pre-wrap'>"+android.text.TextUtils.htmlEncode(text)+"</body></html>","text/html","UTF-8",null);return;}
  BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,bounds);}if(bounds.outWidth<1||bounds.outHeight<1)throw new IOException();BitmapFactory.Options options=new BitmapFactory.Options();while(bounds.outWidth/Math.max(1,options.inSampleSize)>2048||bounds.outHeight/Math.max(1,options.inSampleSize)>16000||(long)(bounds.outWidth/Math.max(1,options.inSampleSize))*(bounds.outHeight/Math.max(1,options.inSampleSize))>8000000)options.inSampleSize=options.inSampleSize==0?2:options.inSampleSize*2;
  Bitmap image;try(InputStream in=getContentResolver().openInputStream(uri)){image=BitmapFactory.decodeStream(in,null,options);}if(image==null)throw new IOException();showImage(image);message("File siap. Geser gambar lalu tekan Terjemahkan.");
 }catch(Exception|OutOfMemoryError e){message("File belum dapat dibuka. Pilih JPG, PNG, WebP, PDF atau TXT yang lebih kecil.");}}
 private byte[] readLimited(Uri uri,int max)throws IOException{try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>max)throw new IOException();}return out.toByteArray();}}
 private void showImage(Bitmap image){changed();message("Membuka gambar…");io.execute(()->{try{File file=new File(getCacheDir(),"reader.png");try(OutputStream out=new FileOutputStream(file)){image.compress(Bitmap.CompressFormat.PNG,100,out);}image.recycle();main.post(()->{if(destroyed)return;fileMode=true;web.setVisibility(View.VISIBLE);local.setVisibility(View.GONE);web.loadDataWithBaseURL("https://reader.invalid/","<html><head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=6, user-scalable=yes\"></head><body style=\"margin:0;background:#fff\"><img src=\"https://reader.invalid/image.png\" style=\"width:100%;height:auto\"></body></html>","text/html","UTF-8",null);});}catch(Exception e){main.post(()->message("Gambar gagal dibuka."));}});}
 private void showPdf(){if(pdf==null)return;try(PdfRenderer.Page p=pdf.openPage(page)){int width=1400,height=Math.round(width*(float)p.getHeight()/p.getWidth());if(height>12000)throw new IOException();Bitmap b=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);new Canvas(b).drawColor(Color.WHITE);p.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);showImage(b);message("PDF halaman "+(page+1)+"/"+pdf.getPageCount()+" · pindah halaman lewat menu ⋮");}catch(Exception e){message("Halaman PDF gagal dibuka.");}}
 private void closePdf(){if(pdf!=null){pdf.close();pdf=null;}if(pdfFile!=null){try{pdfFile.close();}catch(Exception ignored){}pdfFile=null;}}
 private void showResults(){
  if(homeVisible){android.widget.Toast.makeText(this,"Buka bacaan dulu untuk melihat hasil.",android.widget.Toast.LENGTH_SHORT).show();return;}
  if(pageCacheEnabled&&pageTranslations.size()>0){
   List<PageTranslations.Entry> entries=pageTranslations.entries();final AlertDialog[] dialog=new AlertDialog[1];BaseAdapter adapter=new BaseAdapter(){
    public int getCount(){return entries.size();}public Object getItem(int i){return entries.get(i);}public long getItemId(int i){return entries.get(i).id;}
    public View getView(int i,View reused,ViewGroup parent){LinearLayout row;if(reused instanceof LinearLayout)row=(LinearLayout)reused;else{row=new LinearLayout(MainActivity.this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(18),dp(12),dp(18),dp(16));row.setBackgroundColor(0xff0f172a);TextView text=label("",17);text.setTextIsSelectable(true);text.setLineSpacing(dp(2),1.12f);row.addView(text);row.addView(button("Reset bagian ini",v->{}));}PageTranslations.Entry entry=entries.get(i);((TextView)row.getChildAt(0)).setText("Inggris: "+entry.source+"\n\nIndonesia: "+entry.target+(entry.updated?"\n\nDiperbarui":""));Button reset=(Button)row.getChildAt(1);reset.setEnabled(!entry.pending);reset.setOnClickListener(v->{dialog[0].dismiss();resetSingleTranslation(entry.id);});return row;}
   };dialog[0]=new AlertDialog.Builder(this).setTitle("Hasil tersimpan di halaman ini").setAdapter(adapter,null).setPositiveButton("Tutup",null).create();dialog[0].show();return;
  }
  LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(20),dp(12),dp(20),dp(20));
  if(latestTranslations.isEmpty()){TextView empty=label("Belum ada hasil. Buka sumber lalu tekan Terjemahkan.",16);content.addView(empty);}
  for(int i=0;i<latestTranslations.size();i++){
   TextView source=label((i+1)+" · ASLI\n"+(i<latestSources.size()?latestSources.get(i):""),13);source.setTextColor(0xff94a3b8);source.setTextIsSelectable(true);source.setLineSpacing(dp(2),1.12f);content.addView(source);
   TextView target=label(latestTranslations.get(i).isEmpty()?"Belum berhasil. Teks asli tetap ditampilkan.":latestTranslations.get(i),18);target.setTextColor(0xffe2e8f0);target.setPadding(0,dp(8),0,dp(24));target.setTextIsSelectable(true);target.setLineSpacing(dp(3),1.15f);content.addView(target);
  }
  ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(0xff0f172a);scroll.addView(content);new AlertDialog.Builder(this).setTitle("Hasil terjemahan").setView(scroll).setPositiveButton("Tutup",null).show();
 }
 private void toggleAutomatic(){automatic=!automatic;prefs.edit().putBoolean("automatic",automatic).apply();message(automatic?"Otomatis aktif":"Otomatis nonaktif");if(automatic)changed();}
 private void settings(){if(homeVisible){new AlertDialog.Builder(this).setTitle("TCD").setItems(new String[]{"Riwayat","Pengaturan"},(d,n)->{if(n==0)showHistory();else advancedSettings();}).show();return;}String[] items={"Buka situs","Buka file","Teks","Terjemahkan 1 halaman",automatic?"Otomatis: aktif":"Otomatis: nonaktif","Pengaturan"};new AlertDialog.Builder(this).setTitle("TCD").setItems(items,(d,n)->{switch(n){case 0:openAddressDialog();break;case 1:chooseFile();break;case 2:openTextEditor();break;case 3:beginFullPage();break;case 4:toggleAutomatic();break;case 5:advancedSettings();break;}}).show();}
 private void advancedSettings(){List<String> items=new ArrayList<>(Arrays.asList("Gaya bahasa","Nama & istilah","AI opsional","Unduh bahasa","Bantuan"));if(pdf!=null){items.add("PDF sebelumnya");items.add("PDF berikutnya");}new AlertDialog.Builder(this).setTitle("Pengaturan").setItems(items.toArray(new String[0]),(d,n)->{switch(n){case 0:styleSettings();break;case 1:nameSettings();break;case 2:aiSettings();break;case 3:message("Mengunduh bahasa…");translator.downloadModelIfNeeded().addOnSuccessListener(v->{ready=true;message("Bahasa siap");changed();}).addOnFailureListener(e->message("Unduhan belum selesai. Periksa internet."));break;case 4:new AlertDialog.Builder(this).setTitle("Cara pakai").setMessage("Buka situs atau file, lalu tekan Terjemahkan. Hasil tetap tersimpan saat digulir. Reset membaca ulang satu bagian.\n\nTombol kecil di sisi layar menyembunyikan atau menampilkan alat; tombolnya bisa digeser.\n\nTerjemahan otomatis dapat keliru. Bandingkan melalui Lihat asli atau Hasil.").setPositiveButton("Mengerti",null).show();break;case 5:if(pdf!=null&&page>0){page--;showPdf();}break;case 6:if(pdf!=null&&page+1<pdf.getPageCount()){page++;showPdf();}break;}}).show();}
 private static boolean safeServer(String value){try{URL u=new URL(value);return u.getProtocol().equals("https")||(u.getProtocol().equals("http")&&(u.getHost().equals("127.0.0.1")||u.getHost().equals("localhost")));}catch(Exception e){return false;}}
 private void aiSettings(){LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(20),dp(8),dp(20),0);EditText url=new EditText(this);url.setHint("https://server-kamu/translate");url.setText(prefs.getString("server",""));url.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);form.addView(url);EditText token=new EditText(this);token.setHint("Kode akses server AI");token.setText(prefs.getString("token",""));token.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);form.addView(token);EditText notes=new EditText(this);notes.setHint("Konteks singkat untuk terjemahan (opsional)");notes.setText(prefs.getString("notes:"+activeStory,""));notes.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(800)});form.addView(notes);new AlertDialog.Builder(this).setTitle("AI untuk dialog lebih alami").setMessage("AI gratis memerlukan komputer sendiri dengan Ollama. Teks yang terbaca dikirim ke komputer itu. Kosongkan alamat untuk memakai mode dasar di HP.").setView(form).setPositiveButton("Simpan",(d,w)->{String s=url.getText().toString().trim();if(!s.isEmpty()&&!safeServer(s)){message("Gunakan HTTPS, atau http://127.0.0.1:8765/translate lewat USB.");return;}prefs.edit().putString("server",s).putString("token",token.getText().toString()).putString("notes:"+activeStory,notes.getText().toString()).apply();documentId=UUID.randomUUID().toString();resetPageTranslations();changed();message(s.isEmpty()?"Mode dasar dipilih.":"Mode AI dipilih. Teks OCR akan dikirim ke server.");}).setNegativeButton("Batal",null).show();}
 @Override public void onBackPressed(){if(!homeVisible&&web.getVisibility()==View.VISIBLE&&web.canGoBack()){resetPageTranslations();changed();web.goBack();}else if(!homeVisible)showHome();else super.onBackPressed();}
 @Override protected void onPause(){if(fullPageActive)stopFullPage(false,"");saveReadingPosition();main.removeCallbacks(saveProgress);paused=true;generation++;overlay.clear();main.removeCallbacks(settled);cancelSingleRetry();super.onPause();}
 @Override protected void onResume(){super.onResume();paused=false;if(overlay!=null){applyReaderChrome();changed();}}
 @Override public void onConfigurationChanged(android.content.res.Configuration config){super.onConfigurationChanged(config);changed();}
 @Override protected void onDestroy(){destroyed=true;main.removeCallbacksAndMessages(null);ocr.close();translator.close();closePdf();fileMode=false;new File(getCacheDir(),"reader.png").delete();web.destroy();io.shutdown();super.onDestroy();}
}
