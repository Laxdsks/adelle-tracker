package com.komiklingo.app;
import android.content.Context;
import android.graphics.*;
import android.view.*;

/** Temporary touch surface; removed before monitoring or resuming the game. */
public final class LiveAreaPicker extends View {
 private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);private final RectF area=new RectF();private float startX,startY;private boolean initialized;
 public LiveAreaPicker(Context context){super(context);setContentDescription("Seret untuk memilih kotak dialog game");}
 @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){if(!initialized){area.set(w*.06f,h*.65f,w*.94f,h*.88f);initialized=true;}}
 @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);paint.setColor(0x99000000);canvas.drawRect(0,0,getWidth(),area.top,paint);canvas.drawRect(0,area.bottom,getWidth(),getHeight(),paint);canvas.drawRect(0,area.top,area.left,area.bottom,paint);canvas.drawRect(area.right,area.top,getWidth(),area.bottom,paint);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(4);paint.setColor(0xffd9f99d);canvas.drawRect(area,paint);paint.setStyle(Paint.Style.FILL);}
 @Override public boolean onTouchEvent(MotionEvent event){switch(event.getActionMasked()){case MotionEvent.ACTION_DOWN:startX=event.getX();startY=event.getY();return true;case MotionEvent.ACTION_MOVE:case MotionEvent.ACTION_UP:area.set(Math.max(0,Math.min(startX,event.getX())),Math.max(0,Math.min(startY,event.getY())),Math.min(getWidth(),Math.max(startX,event.getX())),Math.min(getHeight(),Math.max(startY,event.getY())));invalidate();return true;default:return true;}}
 public RectF screenArea(){int[] location=new int[2];getLocationOnScreen(location);RectF result=new RectF(area);result.offset(location[0],location[1]);return result;}
}
