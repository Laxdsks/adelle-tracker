package com.komiklingo.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import com.google.mlkit.nl.translate.*;
import java.util.*;

/** A visible, user-initiated permission flow. Projection tokens are never persisted. */
public class FloatingSetupActivity extends Activity {
 private static final int OVERLAY=91,NOTIFICATIONS=92,CAPTURE=93;
 private TextView status;private Button start;private EditText terms;private Spinner style;private boolean flow=false,alive=true,resumed=false;
 private final Translator translator=Translation.getClient(new TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.INDONESIAN).build());
 protected Class<? extends FloatingTranslateService> serviceClass(){return FloatingTranslateService.class;}
 protected void prepareLanguage(Runnable ready,Runnable failed){translator.downloadModelIfNeeded().addOnSuccessListener(v->ready.run()).addOnFailureListener(e->failed.run());}
 @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(0xff0f172a);getWindow().setNavigationBarColor(0xff0f172a);
  ScrollView scroll=new ScrollView(this);LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(22),dp(28),dp(22),dp(28));page.setBackgroundColor(0xff0f172a);scroll.addView(page);setContentView(scroll);
  page.addView(text("Terjemahan layar",25));page.addView(text("Inggris → Indonesia",16));
  page.addView(text("Ketuk balon untuk menerjemahkan layar aplikasi lain. Informasi pribadi yang terlihat dapat ikut terbaca. Diproses di HP; cuplikan tidak disimpan atau dikirim ke server AI.",16));
  page.addView(text("Memerlukan izin tampil di atas aplikasi lain dan tangkap layar Android. Hentikan lewat notifikasi. Layar yang dilindungi tidak bisa dibaca.",15));
  page.addView(text("Untuk game: buka game, tahan balon → Game otomatis · pilih area. Seret kotak pada dialog, lalu Mulai otomatis. Subtitle diperbarui saat teks stabil. Ketuk balon untuk jeda/lanjut. Tahan balon untuk menu. Balon berhenti saat layar dikunci.",15));
  var prefs=getSharedPreferences("reader",MODE_PRIVATE);LinearLayout advanced=new LinearLayout(this);advanced.setOrientation(LinearLayout.VERTICAL);advanced.setVisibility(View.GONE);page.addView(button("Pilihan bahasa dan nama",v->advanced.setVisibility(advanced.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE)));page.addView(advanced);advanced.addView(text("Gaya bahasa",15));style=new Spinner(this);style.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Natural · aku–kamu","Netral · saya–kamu","Formal · saya–Anda"}){@Override public View getView(int position,View reused,ViewGroup parent){TextView value=(TextView)super.getView(position,reused,parent);value.setTextColor(0xffe2e8f0);return value;}});String saved=prefs.getString("floating-style",ReadingText.DIALOGUE);style.setSelection(saved.equals(ReadingText.FORMAL)?2:saved.equals(ReadingText.NEUTRAL)?1:0);advanced.addView(style);
  advanced.addView(text("Nama yang tidak diterjemahkan (opsional, satu per baris)",14));terms=new EditText(this);terms.setTextColor(Color.WHITE);terms.setHintTextColor(0xff94a3b8);terms.setHint("Nama atau istilah yang dipertahankan");terms.setMinLines(2);terms.setMaxLines(5);terms.setGravity(Gravity.TOP);terms.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);terms.setText(prefs.getString("floating-terms",""));advanced.addView(terms);
  status=text("Tekan Mulai, lalu izinkan akses yang diminta Android.",15);page.addView(status);
  start=button("Mulai",v->begin());page.addView(start,new LinearLayout.LayoutParams(-1,dp(54)));page.addView(button("Hentikan balon",v->{startService(new Intent(this,serviceClass()).setAction(FloatingTranslateService.STOP));status.setText("Balon dihentikan.");}),new LinearLayout.LayoutParams(-1,dp(52)));page.addView(button("Kembali",v->finish()));
 }
 private void begin(){if(flow)return;if(FloatingTranslateService.isRunning()){status.setText("Balon sudah aktif. Buka aplikasi lain lalu ketuk balon TCD.");return;}try{List<String> names=ProtectedTerms.parse(terms.getText().toString());String[] values={ReadingText.DIALOGUE,ReadingText.NEUTRAL,ReadingText.FORMAL};getSharedPreferences("reader",MODE_PRIVATE).edit().putString("floating-terms",android.text.TextUtils.join("\n",names)).putString("floating-style",values[style.getSelectedItemPosition()]).apply();}catch(IllegalArgumentException error){terms.setError(error.getMessage());return;}
  flow=true;start.setEnabled(false);continuePermissions();
 }
 private void continuePermissions(){
  if(!Settings.canDrawOverlays(this)){status.setText("Di pengaturan Android, pilih TCD dan izinkan tampil di atas aplikasi lain. Setelah itu kembali ke sini.");try{startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())),OVERLAY);}catch(ActivityNotFoundException error){endFlow("Pengaturan balon tidak tersedia di perangkat ini.");}return;}
  var prefs=getSharedPreferences("reader",MODE_PRIVATE);
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED&&!prefs.getBoolean("floating-notification-asked",false)){prefs.edit().putBoolean("floating-notification-asked",true).apply();requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATIONS);return;}
  status.setText("Menyiapkan model terjemahan di HP…");prepareLanguage(()->{if(!alive)return;if(!resumed){endFlow("Model siap. Tekan Mulai saat kembali ke TCD.");return;}status.setText("Izinkan tangkap layar Android untuk memulai balon.");try{MediaProjectionManager manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);Intent request=Build.VERSION.SDK_INT>=34?manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay()):manager.createScreenCaptureIntent();startActivityForResult(request,CAPTURE);}catch(RuntimeException error){endFlow("Izin tangkap layar belum bisa dibuka. Coba lagi.");}},()->{if(alive)endFlow("Model belum siap. Periksa internet lalu coba lagi.");});
 }
 @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(request==NOTIFICATIONS&&flow)continuePermissions();}
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
  if(request==OVERLAY){if(flow&&Settings.canDrawOverlays(this))continuePermissions();else endFlow("Izin balon belum aktif. Tekan Mulai untuk mencoba lagi.");}
  if(request==CAPTURE){if(result!=RESULT_OK||data==null){endFlow("Tangkap layar dibatalkan. Balon tidak diaktifkan.");return;}try{Intent service=new Intent(this,serviceClass()).putExtra(FloatingTranslateService.GRANT,data).putExtra(FloatingTranslateService.RESULT,result);startForegroundService(service);endFlow("Balon aktif. Buka aplikasi lain, lalu ketuk balon TCD. Hentikan dari notifikasi atau tahan balon.");}catch(RuntimeException error){endFlow("Balon belum bisa dimulai. Buka TCD lalu coba lagi.");}}
 }
 private void endFlow(String message){flow=false;start.setEnabled(true);status.setText(message);}
 private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
 private TextView text(String value,int size){TextView view=new TextView(this);view.setText(value);view.setTextSize(size);view.setTextColor(0xffe2e8f0);view.setPadding(0,dp(8),0,dp(8));return view;}
 private Button button(String value,View.OnClickListener listener){Button button=new Button(this);button.setText(value);button.setAllCaps(false);button.setTextColor(0xffd9f99d);button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff1e293b));button.setOnClickListener(listener);return button;}
 @Override protected void onResume(){super.onResume();resumed=true;}
 @Override protected void onPause(){resumed=false;super.onPause();}
 @Override protected void onDestroy(){alive=false;translator.close();super.onDestroy();}
}
