package com.komiklingo.app;

import android.content.Context;
import android.graphics.*;
import android.text.*;
import android.text.style.LineHeightSpan;
import android.view.*;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.util.function.LongConsumer;
import java.util.*;

/** Fits legible text once per result, preserving estimated source color, size and paragraph spacing. */
public final class BubbleOverlay extends FrameLayout {
 public static final class Appearance {
  public final int ink;public final float sourceSize;public final boolean leftAligned,italic;
  public Appearance(int ink,float sourceSize,boolean leftAligned){this(ink,sourceSize,leftAligned,false);}
  public Appearance(int ink,float sourceSize,boolean leftAligned,boolean italic){this.ink=ink;this.sourceSize=sourceSize;this.leftAligned=leftAligned;this.italic=italic;}
 }
 public static final class Bubble {
  public final long id;public final boolean pending,updated;public final RectF box;public final String text;public final int color;public final boolean bold;public final Appearance appearance;
  public Bubble(RectF box,String text,int color,boolean bold){this(box,text,color,bold,null);}
  public Bubble(RectF box,String text,int color,boolean bold,Appearance appearance){this(box,text,color,bold,appearance,0,false,false);}
  public Bubble(RectF box,String text,int color,boolean bold,Appearance appearance,long id,boolean pending,boolean updated){this.id=id;this.pending=pending;this.updated=updated;this.box=new RectF(box);this.text=text;this.color=color;this.bold=bold;this.appearance=appearance;}
 }
 static final class Rendered {
  final Bubble bubble;final StaticLayout layout;final float padding;final boolean overflow;
  Rendered(Bubble bubble,StaticLayout layout,float padding,boolean overflow){this.bubble=bubble;this.layout=layout;this.padding=padding;this.overflow=overflow;}
 }
 private static final class ParagraphGap implements LineHeightSpan {
  private final int end,gap;ParagraphGap(int end,int gap){this.end=end;this.gap=gap;}
  @Override public void chooseHeight(CharSequence text,int start,int end,int spanstartv,int v,Paint.FontMetricsInt fm){if(end>=this.end){fm.descent+=gap;fm.bottom=Math.max(fm.bottom,fm.descent);}}
 }
 private final ArrayList<Rendered> rendered=new ArrayList<>();
 private final android.util.LruCache<String,Rendered> layouts=new android.util.LruCache<>(160);
 private final Paint fill=new Paint(Paint.ANTI_ALIAS_FLAG);
 private boolean resetControlsVisible=true;private LongConsumer resetListener;private View scrollTarget;private MotionEvent touchDown;private boolean forwarding=false;
 private final Map<Long,TextView> resetButtons=new HashMap<>();
 public BubbleOverlay(Context context){super(context);setWillNotDraw(false);setClipChildren(true);}
 public void setResetControlsVisible(boolean visible){if(resetControlsVisible!=visible){resetControlsVisible=visible;updateResetButtons();}}
 public void setResetListener(LongConsumer listener,View scrollTarget){resetListener=listener;this.scrollTarget=scrollTarget;}
 public void resetTouchState(){if(touchDown!=null){touchDown.recycle();touchDown=null;}forwarding=false;}
 @Override public boolean dispatchTouchEvent(MotionEvent event){
  int action=event.getActionMasked();if(action==MotionEvent.ACTION_DOWN){resetTouchState();touchDown=MotionEvent.obtain(event);boolean handled=super.dispatchTouchEvent(event);if(!handled)resetTouchState();return handled;}
  if(touchDown!=null&&!forwarding&&action==MotionEvent.ACTION_MOVE&&scrollTarget!=null&&Math.hypot(event.getX()-touchDown.getX(),event.getY()-touchDown.getY())>ViewConfiguration.get(getContext()).getScaledTouchSlop()){
   MotionEvent cancel=MotionEvent.obtain(event);cancel.setAction(MotionEvent.ACTION_CANCEL);super.dispatchTouchEvent(cancel);cancel.recycle();forwarding=true;scrollTarget.dispatchTouchEvent(touchDown);
  }
  boolean handled=forwarding&&scrollTarget!=null?scrollTarget.dispatchTouchEvent(event):super.dispatchTouchEvent(event);if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL)resetTouchState();return handled;
 }
 @Override protected void onDetachedFromWindow(){resetTouchState();super.onDetachedFromWindow();}
 public void show(List<Bubble> next){rendered.clear();for(Bubble bubble:next){String key=bubble.text+"|"+Math.round(bubble.box.width()*10)+"|"+Math.round(bubble.box.height()*10)+"|"+bubble.color+"|"+bubble.bold+(bubble.appearance==null?"":("|"+bubble.appearance.ink+"|"+bubble.appearance.sourceSize+"|"+bubble.appearance.leftAligned+"|"+bubble.appearance.italic));Rendered cached=layouts.get(key);if(cached==null){cached=fit(bubble);layouts.put(key,cached);}rendered.add(new Rendered(bubble,cached.layout,cached.padding,cached.overflow));}updateResetButtons();invalidate();}
 public void clear(){rendered.clear();removeAllViews();resetButtons.clear();invalidate();}
 private Rendered fit(Bubble bubble){
  RectF r=bubble.box;float density=getResources().getDisplayMetrics().scaledDensity;
  float padding=Math.min(7*density,Math.max(2*density,Math.min(r.width(),r.height())*.045f));
  int width=Math.max(1,(int)(r.width()-padding*2));float height=Math.max(1,r.height()-padding*2);
  float minimum=9*density;
  // Remove the old 38-pixel cap: large original lettering keeps its relative emphasis.
  float desired=bubble.appearance==null?Math.min(r.height()*.65f,28*density):bubble.appearance.sourceSize*1.10f;
  desired=Math.max(minimum,desired);StaticLayout smallest=layout(bubble,width,minimum,false);
  if(!fits(smallest,height,width))return new Rendered(bubble,layout(bubble,width,minimum,true),padding,true);
  float low=minimum,high=desired;for(int i=0;i<13;i++){float size=(low+high)/2;if(fits(layout(bubble,width,size,false),height,width))low=size;else high=size;}
  return new Rendered(bubble,layout(bubble,width,low,false),padding,false);
 }
 private boolean fits(StaticLayout layout,float height,int width){if(layout.getHeight()>height)return false;for(int i=0;i<layout.getLineCount();i++)if(layout.getLineWidth(i)>width+.5f)return false;return true;}
 private StaticLayout layout(Bubble bubble,int width,float size,boolean badge){
  TextPaint paint=new TextPaint(Paint.ANTI_ALIAS_FLAG);paint.setTextSize(size);paint.setTypeface(Typeface.create(bubble.bold?"sans-serif-condensed":"sans-serif",bubble.appearance!=null&&bubble.appearance.italic?(bubble.bold?Typeface.BOLD_ITALIC:Typeface.ITALIC):(bubble.bold?Typeface.BOLD:Typeface.NORMAL)));
  double light=.2126*Color.red(bubble.color)+.7152*Color.green(bubble.color)+.0722*Color.blue(bubble.color);
  paint.setColor(bubble.appearance==null?(light>140?Color.rgb(24,24,28):Color.WHITE):bubble.appearance.ink);
  if(OcrAppearance.contrast(paint.getColor(),bubble.color)<3)paint.setShadowLayer(Math.max(1,size*.045f),0,0,light>140?Color.BLACK:Color.WHITE);
  String[] paragraphs=ReadingText.paragraphs(badge?"Hasil ↗":bubble.text).split("\\n\\n");SpannableStringBuilder text=new SpannableStringBuilder();
  for(int i=0;i<paragraphs.length;i++){int start=text.length();text.append(paragraphs[i]);if(i+1<paragraphs.length){text.append('\n');text.setSpan(new ParagraphGap(text.length(),Math.round(size*.38f)),start,text.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}}
  StaticLayout.Builder builder=StaticLayout.Builder.obtain(text,0,text.length(),paint,width).setAlignment(bubble.appearance!=null&&bubble.appearance.leftAligned?Layout.Alignment.ALIGN_NORMAL:Layout.Alignment.ALIGN_CENTER).setIncludePad(false).setLineSpacing(0,1.12f).setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE);
  if(android.os.Build.VERSION.SDK_INT>=29)builder.setBreakStrategy(android.graphics.text.LineBreaker.BREAK_STRATEGY_HIGH_QUALITY);
  return builder.build();
 }
 private int dp(float value){return Math.round(value*getResources().getDisplayMetrics().density);}
 @Override protected void onSizeChanged(int w,int h,int oldW,int oldH){super.onSizeChanged(w,h,oldW,oldH);updateResetButtons();}
 private void updateResetButtons(){
  Set<Long> visible=new HashSet<>();List<RectF> footerAreas=new ArrayList<>();if(resetListener!=null&&resetControlsVisible)for(Rendered item:rendered){Bubble bubble=item.bubble;if(bubble.id==0)continue;int width=dp(bubble.updated?76:60),height=dp(32);float y=bubble.box.bottom+dp(3);if(y<0||y+height>getHeight())continue;
   RectF place=null;float[] anchors={bubble.box.right-width,bubble.box.left};for(float anchor:anchors){float x=Math.max(dp(3),Math.min(getWidth()-width-dp(3),anchor));RectF candidate=new RectF(x,y,x+width,y+height);boolean blocked=false;for(Rendered other:rendered)if(other!=item&&RectF.intersects(candidate,other.bubble.box)){blocked=true;break;}if(!blocked)for(RectF footer:footerAreas)if(RectF.intersects(candidate,footer)){blocked=true;break;}if(!blocked){place=candidate;break;}}
   if(place==null)continue;footerAreas.add(place);visible.add(bubble.id);TextView button=resetButtons.get(bubble.id);if(button==null){button=new TextView(getContext());button.setTextSize(11);button.setTextColor(0xffd9f99d);button.setGravity(Gravity.CENTER);button.setPadding(0,0,0,0);GradientDrawable background=new GradientDrawable();background.setColor(0xee0f172a);background.setCornerRadius(dp(8));background.setStroke(dp(1),0xff64748b);button.setBackground(background);final long id=bubble.id;button.setOnClickListener(v->{if(resetListener!=null)resetListener.accept(id);});addView(button,new FrameLayout.LayoutParams(width,height,Gravity.TOP|Gravity.LEFT));resetButtons.put(id,button);}
   if(button.getLayoutParams().width!=width){button.getLayoutParams().width=width;button.requestLayout();}button.setText(bubble.pending?"Ulang…":bubble.updated?"Reset ✓":"Reset");button.setEnabled(!bubble.pending);button.setContentDescription("Reset bagian terjemahan ini"+(bubble.updated?", sudah diperbarui":""));button.setTranslationX(place.left);button.setTranslationY(place.top);
  }
  for(Iterator<Map.Entry<Long,TextView>> it=resetButtons.entrySet().iterator();it.hasNext();){var entry=it.next();if(!visible.contains(entry.getKey())){removeView(entry.getValue());it.remove();}}
 }
 @Override protected void onDraw(Canvas canvas){
  // Paint every source cover first. A later cover must never erase a neighbour's new text.
  for(Rendered item:rendered){RectF r=item.bubble.box;fill.setColor(item.bubble.color);if(item.overflow){float height=Math.min(r.height(),item.layout.getHeight()+item.padding*2);canvas.drawRect(r.left,r.bottom-height,r.right,r.bottom,fill);}else canvas.drawRect(r,fill);}
  for(Rendered item:rendered){RectF r=item.bubble.box;canvas.save();canvas.clipRect(r);if(item.overflow){float height=Math.min(r.height(),item.layout.getHeight()+item.padding*2);canvas.translate(r.left+item.padding,r.bottom-height+item.padding);}else canvas.translate(r.left+item.padding,r.top+Math.max(item.padding,(r.height()-item.layout.getHeight())/2));item.layout.draw(canvas);canvas.restore();}
 }
}
