package com.komiklingo.app;

import java.util.*;
import java.util.regex.*;

/** Bounded pragmatic cues. Ambiguous obligations, negations and literal objects stay intact. */
public final class ConversationMeaning {
 private static final String SUBJECT="(?:the\\s+others|he|she|they|we|i|you|it|ZXQNAMEX*\\d+QXZ)";
 private static final String STATES="(?:waiting|wondering|joking|kidding|dreaming|tired|exhausted|hungry|thirsty|sleepy|lonely|worried|afraid|scared|upset|confused|mistaken)";
 private static final Pattern MUST_STATE=Pattern.compile("(?iu)\\b("+SUBJECT+")\\s+must\\s+be\\s+((?:(?:already|still|really|very|so)\\s+)*)("+STATES+")\\b");
 private static final Pattern DUTY=Pattern.compile("(?iu)\\b(?:rules?|regulations?|orders?|ordered|orders|required|requirement|mandatory|obligatory|duty|duties|instructed|instructions?|ensure|make\\s+sure|always|never|every|whenever|until|before|after|by|at\\s+\\d|to\\s+(?:enter|qualify|apply|join|pass|receive))\\b");
 private static final Pattern APOLOGY=Pattern.compile("(?iu)(?:^|[.!?]\\s+)(?:(?:my|our)\\s+apologies(?=\\s+(?:for|if)\\b|\\s*[,!.…;:]|\\s*$)|(?:i|we)\\s+apologi[sz]e\\b|(?:i['’]m|i\\s+am|we['’]re|we\\s+are)\\s+sorry\\b|sorry\\b)");
 private static final Pattern APOLOGY_PREFIX=Pattern.compile("(?iu)^\\s*(my|our)\\s+apologies\\s+for\\b");
 private static final Pattern THANKS=Pattern.compile("(?iu)^\\s*(?:thank\\s+you|thanks)\\b(?!\\s+for\\s+nothing\\b)");
 private static final Pattern NOT_AT_ALL=Pattern.compile("(?iu)^\\s*not\\s+at\\s+all(?=\\s*[,!.…;:]|\\s*$)");
 private static final Pattern ARRIVAL=Pattern.compile("(?iu)\\b(i|we|you|they|he|she)\\s+(have|has|had)\\s+(only\\s+just|just|only\\s+recently)\\s+arrived\\s+(myself|ourselves|yourself|yourselves|themselves|himself|herself)(?=\\s*(?:[.!?,;…]|$))");
 private static final Pattern RAMBLE=Pattern.compile("(?iu)\\bi(?:(\\s+have)|(['’]ve))?\\s+rambled\\s+on\\s+for\\s+too\\s+long\\b");
 private static final Pattern WALKING=Pattern.compile("(?iu)\\b(?:walk|walked|walking|hike|hiked|hiking|trail|woods|countryside|forest)\\b");
 private static final Pattern FIGURES=Pattern.compile("(?iu)\\b(key|leading|prominent|important)\\s+figures\\b");
 private static final Pattern ASSEMBLED=Pattern.compile("(?iu)\\b(?:are|were|have\\s+been)\\s+(?:(?:mostly|already|all|now)\\s+)*(?:gathered|assembled|present|attending)\\b");
 private static final Pattern NUMERIC_OR_OBJECT=Pattern.compile("(?iu)\\b(?:numbers?|statistics?|data|tables?|spreadsheets?|sales|revenue|profits?|budget|financial|percent|calculate|average|totals?|sculptures?|statues?|figurines?|miniatures?|dolls?|chess|diagrams?|charts?|illustrations?)\\b|[%$€]");
 private static final Pattern HERETICS=Pattern.compile("(?iu)\\bamong\\s+(?:the\\s+)?heretics\\b");
 private static final String BELIEF_NOUN="(?:doctrine|belief|opinion|view|conviction)";
 private static final Pattern HELD_BELIEF=Pattern.compile("(?iu)\\b("+SUBJECT+")\\s+(hold|holds|held)\\s+((?:(?:a|an|the)\\s+)?(?:(?:extremely|very|radical|firm|strong|religious|political|different|strange|certain|particular|common|deep|unusual)\\s+){0,4}"+BELIEF_NOUN+")\\b");
 private static final Pattern PHYSICAL_BELIEF=Pattern.compile("(?iu)\\b(?:book|scroll|paper|document|printed|hands?|fingers?|cover|page|sword|shield|bottle|cup|object)\\b");
 public static boolean holdContinuation(String left,String right){return left.matches("(?isu).*\\b(?:hold|holds|held)\\s+(?:a|an|the)\\s+(?:(?:extremely|very|radical|firm|religious|political|strange|different)\\s*){1,4}$")&&right.trim().matches("(?isu)^"+BELIEF_NOUN+"\\b.*")&&!PHYSICAL_BELIEF.matcher(left).find();}
 private static boolean belief(String source){return HELD_BELIEF.matcher(source).find()&&!PHYSICAL_BELIEF.matcher(source).find();}
 private static final Pattern STREET_THUGS=Pattern.compile("(?iu)\\bback[- ]alley\\s+(?:thugs|gangsters|criminals)\\b");
 private static final Pattern REFERENTIAL_MEAN=Pattern.compile("(?iu)\\bdo\\s+you\\s+happen\\s+to\\s+mean(?=\\s*(?:\\.{2,}|…+)\\s*\\??\\s*$)");
 private static final Pattern SHIELDING=Pattern.compile("(?iu)\\b(shield|shields|shielded|shielding)(?=\\s+(?:(?:a|an|the|that|this|their)\\s+)?(?:(?:heretical|religious|political|innocent|small)\\s+){0,4}(?:group|faction|people|child|children|refugees|cult)\\b)");
 private static final Pattern HEGEMON=Pattern.compile("(?iu)\\bhegemonic\\s+nation\\b");
 private static final String MARKER="ZXQNAMEX*\\d+QXZ";
 private static final Pattern OBJECT_RELATIVE=Pattern.compile("(?iu)\\b(?:that|which)\\s+((?:the\\s+)?(?:kingdom|empire|city|village)\\s+of\\s+"+MARKER+"|"+MARKER+"|i|you|he|she|we|they)\\s+(?:am|is|are)\\s+(creating|making|building|developing|producing)\\b");
 private static final Pattern PRECISE=Pattern.compile("(?iu),\\s*that\\s+is\\s*([.!]?)\\s*$");
 private static final Pattern NAMED_CULT=Pattern.compile("(?iu)\\b("+MARKER+")\\s+cult\\b");
 private static final Pattern GOOD_GRIEF=Pattern.compile("(?iu)^\\s*good\\s+grief(?=\\s*(?:[.!?…]|$))");
 private static final Pattern BOGGLING=Pattern.compile("(?iu)\\bmind[- ]boggling\\b");
 private static final Pattern GRAVE_MATTER=Pattern.compile("(?iu)\\bgrave\\s+and\\s+solemn(?=\\s+(?:matter|issue|situation)\\b)");
 private static final Pattern FATE_BALANCE=Pattern.compile("(?iu)\\b(hangs?|hung)\\s+(the\\s+fate\\s+of\\s+[^.!?;\\r\\n]{1,90}?)\\s+in\\s+the\\s+balance\\b");
 private static final Pattern SLACKING=Pattern.compile("(?iu)\\bslacking\\s+off\\b");
 private static final Pattern ROPE=Pattern.compile("(?iu)\\b(?:rope|cable|sail|tension|brake|valve)\\b");
 private static final Pattern BIO_RACE=Pattern.compile("(?iu)\\b(elven|elvish|human|dwarven|orcish)\\s+race\\b");
 private static boolean biological(String source){return BIO_RACE.matcher(source).find()&&Pattern.compile("(?iu)\\b(?:fertility|reproductive|genes|species|lifespan|extinction|ancestry)\\b").matcher(source).find()&&!Pattern.compile("(?iu)\\b(?:finish\\s+line|marathon|tournament|grand\\s+prix|racetrack)\\b").matcher(source).find();}
 private static final Pattern VOCABULARY=Pattern.compile("(?iu)\\b(vocabulary\\s+(?:is|was)\\s+(?:(?:surprisingly|very|rather)\\s+)?)sophisticated\\b");
 private static final Pattern FRIVOLOUS=Pattern.compile("(?iu)\\bsomeone\\s+(?:who\\s+is\\s+)?behaving\\s+(?:so|very)\\s+frivolously\\b");
 private static final Pattern SUGARCOAT=Pattern.compile("(?iu)\\b(sugar[- ]?coat(?:s|ed|ing)?)\\s+(it|this|the\\s+truth)\\b");
 private static final Pattern THIS_INSTANT=Pattern.compile("(?iu)\\bthis\\s+instant(?=\\s*(?:[.!?,;]|$))");
 private static final Pattern SUBDUED_OBJECT=Pattern.compile("(?iu)\\b("+SUBJECT+")\\s+(had|have|has)\\s+(him|her|them|me|us|you|"+MARKER+")\\s+((?:(?:almost|nearly|completely|totally|fully)\\s+){0,3})subdued\\b");
 private static final Pattern WRAP=Pattern.compile("(?iu)\\b(wrap|wraps|wrapped|wrapping)\\s+(it|this|that|things|everything)\\s+up\\b");
 private static final Pattern PACKAGING=Pattern.compile("(?iu)\\b(?:paper|gift|present|parcel|package|ribbon|blanket|foil|sandwich)\\b");
 private static final Pattern SHOW_RESTRAINT=Pattern.compile("(?iu)(^\\s*(?:please[,\\s]+)?(?:just\\s+)?)show\\s+(?:some|a\\s+little)\\s+restraint\\b");
 private static final Pattern AWAY_FROM_POST=Pattern.compile("(?iu)\\baway\\s+from\\s+my\\s+post\\b");
 private static final Pattern LONG_AWAY_FROM_POST=Pattern.compile("(?iu)\\b(aku|saya)\\s+(?:telah|sudah)\\s+jauh\\s+dari\\s+posting\\s+(?:aku|saya)\\s+terlalu\\s+lama\\b");
 private static final Pattern STAY_ANY_LONGER=Pattern.compile("(?iu)\\bstay\\s+here\\s+any\\s+longer\\b");
 private static final Pattern DALLY_WITH=Pattern.compile("(?iu)\\bdally\\s+around\\s+with\\b");
 private static final Pattern SLY_ELF=Pattern.compile("(?iu)\\bthat\\s+sly\\s+fox\\s+of\\s+an\\s+elf\\b");
 private static final Pattern GET_LOST=Pattern.compile("(?iu)\\b(hurry\\s+up\\s+and\\s+)get\\s+lost(?=\\s*(?:[.!?,;…]|$))");
 private static final Pattern SEE_AROUND=Pattern.compile("(?iu)(^|[.!?]\\s+)(see\\s+you\\s+around)(?=\\s*(?:[.!?,;…]|$))");
 private static final Pattern CRUSH_BENEATH=Pattern.compile("(?iu)\\bcrush\\s+(?:him|her|them|you|me|us|it)\\s+beneath\\s+my\\s+feet\\b");
 private static final Pattern URGENT_MATTERS=Pattern.compile("(?iu)\\b(had|have|has)\\s+some\\s+urgent\\s+matters\\s+to\\s+attend\\s+to\\b");
 private static final Pattern OCEAN_GRACE=Pattern.compile("(?iu)\\byour\\s+majesty['’]s\\s+ocean[- ]like\\s+grace\\b");
 private static final Pattern PRESERVE_MY_LIFE=Pattern.compile("(?iu)\\bi\\s+was\\s+able\\s+to\\s+preserve\\s+my\\s+life\\b");
 private static String raceName(String kind){switch(kind.toLowerCase(Locale.ROOT)){case "human":return "manusia";case "dwarven":return "Dwarf";case "orcish":return "Orc";default:return "Elf";}}
 private static boolean groupGrowth(String source){return Pattern.compile("(?iu)\\b(?:faction|gang|organization|army|group)\\b").matcher(source).find()&&Pattern.compile("(?iu)\\b(?:grown|grew|growing)\\s+rapidly\\b").matcher(source).find()&&!Pattern.compile("(?iu)\\b(?:children|child|plants|trees|crops|height|taller)\\b").matcher(source).find();}
 private static boolean heretics(String source){return HERETICS.matcher(source).find()&&!Pattern.compile("(?iu)\\b(?:heresy|band|album|song|team)\\b").matcher(source).find();}
 private static String previousClause(String text){String clean=text==null?"":text.trim();return clean.substring(Math.max(0,clean.length()-700));}
 private static boolean inferred(String source,String previous,Matcher state){
  if(source.indexOf('?')>=0||DUTY.matcher(source).find()||DUTY.matcher(previousClause(previous)).find())return false;
  if(state.group(1).equalsIgnoreCase("you")||state.group(1).equalsIgnoreCase("we"))return state.group(3).matches("(?iu)joking|kidding|dreaming|mistaken");
  return true;
 }
 private static int response(String source,String previous){if(!NOT_AT_ALL.matcher(source).find())return 0;String prior=previousClause(previous);if(APOLOGY.matcher(prior).find())return 1;if(THANKS.matcher(prior).find())return 2;return 0;}
 private static boolean emphatic(Matcher arrival){String subject=arrival.group(1).toLowerCase(Locale.ROOT),reflexive=arrival.group(4).toLowerCase(Locale.ROOT);return subject.equals("i")&&reflexive.equals("myself")||subject.equals("we")&&reflexive.equals("ourselves")||subject.equals("they")&&reflexive.equals("themselves")||subject.equals("he")&&reflexive.equals("himself")||subject.equals("she")&&reflexive.equals("herself")||subject.equals("you")&&(reflexive.equals("yourself")||reflexive.equals("yourselves"));}
 private static boolean people(String source){return FIGURES.matcher(source).find()&&ASSEMBLED.matcher(source).find()&&!NUMERIC_OR_OBJECT.matcher(source).find();}
 public static String normalize(String source,String previous){
  String result=source;
  Matcher state=MUST_STATE.matcher(result);StringBuffer clarified=new StringBuffer();while(state.find())if(inferred(result,previous,state)){String subject=state.group(1),lower=subject.toLowerCase(Locale.ROOT);String be=lower.equals("i")?"am":lower.matches("they|we|you|the others")?"are":"is";state.appendReplacement(clarified,Matcher.quoteReplacement(subject+" "+be+" certainly "+state.group(2)+state.group(3)));}state.appendTail(clarified);result=clarified.toString();
  Matcher apology=APOLOGY_PREFIX.matcher(result);if(apology.find())result=apology.replaceFirst(apology.group(1).equalsIgnoreCase("our")?"We apologize for":"I apologize for");
  int reply=response(result,previous);if(reply!=0)result=NOT_AT_ALL.matcher(result).replaceFirst(reply==1?"It is okay":"You are welcome");
  Matcher arrival=ARRIVAL.matcher(result);StringBuffer arrivals=new StringBuffer();while(arrival.find())if(emphatic(arrival))arrival.appendReplacement(arrivals,Matcher.quoteReplacement(arrival.group(1)+" too "+arrival.group(2)+" "+arrival.group(3)+" arrived"));arrival.appendTail(arrivals);result=arrivals.toString();
  if(!WALKING.matcher(result).find()){Matcher ramble=RAMBLE.matcher(result);StringBuffer speech=new StringBuffer();while(ramble.find())ramble.appendReplacement(speech,Matcher.quoteReplacement("I "+(ramble.group(1)!=null||ramble.group(2)!=null?"have ":"")+"talked for too long"));ramble.appendTail(speech);result=speech.toString();}
  if(people(result))result=FIGURES.matcher(result).replaceAll("important people");
  if(heretics(result))result=HERETICS.matcher(result).replaceAll("among people who follow heretical teachings");
  if(belief(result)){Matcher held=HELD_BELIEF.matcher(result);StringBuffer beliefs=new StringBuffer();while(held.find())held.appendReplacement(beliefs,Matcher.quoteReplacement(held.group(1)+" "+(held.group(2).equalsIgnoreCase("held")?"followed":held.group(2).equalsIgnoreCase("holds")?"follows":"follow")+" "+held.group(3)));held.appendTail(beliefs);result=beliefs.toString();}
  result=STREET_THUGS.matcher(result).replaceAll("street thugs");
  if(REFERENTIAL_MEAN.matcher(result).find())result=REFERENTIAL_MEAN.matcher(result).replaceAll("are you referring to");
  result=HEGEMON.matcher(result).replaceAll("dominant country");
  Matcher shield=SHIELDING.matcher(result);StringBuffer protection=new StringBuffer();while(shield.find()){String verb=shield.group(1).toLowerCase(Locale.ROOT);shield.appendReplacement(protection,verb.equals("shielding")?"protecting":verb.equals("shielded")?"protected":verb.equals("shields")?"protects":"protect");}shield.appendTail(protection);result=protection.toString();
  Matcher relative=OBJECT_RELATIVE.matcher(result);StringBuffer relatives=new StringBuffer();while(relative.find()){String agent=relative.group(1),participle;switch(relative.group(2).toLowerCase(Locale.ROOT)){case "creating":participle="created";break;case "making":participle="made";break;case "building":participle="built";break;case "developing":participle="developed";break;default:participle="produced";}switch(agent.toLowerCase(Locale.ROOT)){case "i":agent="me";break;case "he":agent="him";break;case "she":agent="her";break;case "we":agent="us";break;case "they":agent="them";}relative.appendReplacement(relatives,Matcher.quoteReplacement("being "+participle+" by "+agent));}relative.appendTail(relatives);result=relatives.toString();
  Matcher precise=PRECISE.matcher(result);if(precise.find())result="To be precise, "+result.substring(0,precise.start())+precise.group(1);
  result=NAMED_CULT.matcher(result).replaceAll("cult of $1");
  result=GOOD_GRIEF.matcher(result).replaceFirst("Oh dear");
  result=Pattern.compile("(?iu)\\b(every\\s*thing\\s+about\\s+(?:this|that))\\s+((?:utterly|really|truly|so)\\s+mind[- ]boggling)\\b").matcher(result).replaceAll("$1 is $2");
  result=BOGGLING.matcher(result).replaceAll("difficult to comprehend");
  result=GRAVE_MATTER.matcher(result).replaceAll("very serious");
  result=Pattern.compile("(?iu)\\b(discussions?)\\s+regarding\\b").matcher(result).replaceAll("$1 about");
  Matcher balance=FATE_BALANCE.matcher(result);StringBuffer stakes=new StringBuffer();while(balance.find())balance.appendReplacement(stakes,Matcher.quoteReplacement((balance.group(1).equalsIgnoreCase("hangs")?"puts":"put")+" "+balance.group(2)+" at stake"));balance.appendTail(stakes);result=stakes.toString();
  if(!ROPE.matcher(result).find())result=SLACKING.matcher(result).replaceAll("being lazy");
  if(biological(result)){Matcher race=BIO_RACE.matcher(result);StringBuffer races=new StringBuffer();while(race.find())race.appendReplacement(races,Matcher.quoteReplacement((race.group(1).equalsIgnoreCase("human")?"human":raceName(race.group(1)))+" species"));race.appendTail(races);result=races.toString();}
  result=VOCABULARY.matcher(result).replaceAll("$1advanced");
  result=FRIVOLOUS.matcher(result).replaceAll("someone who does not take things seriously");
  Matcher sugar=SUGARCOAT.matcher(result);StringBuffer softening=new StringBuffer();while(sugar.find()){String verb=sugar.group(1).toLowerCase(Locale.ROOT);sugar.appendReplacement(softening,Matcher.quoteReplacement((verb.endsWith("ing")?"making":verb.endsWith("ed")?"made":verb.endsWith("s")?"makes":"make")+" "+sugar.group(2)+" sound less bad"));}sugar.appendTail(softening);result=softening.toString();
  result=THIS_INSTANT.matcher(result).replaceAll("right now");
  Matcher subdued=SUBDUED_OBJECT.matcher(result);StringBuffer control=new StringBuffer();while(subdued.find())subdued.appendReplacement(control,Matcher.quoteReplacement(subdued.group(1)+" "+subdued.group(2)+" "+subdued.group(4)+"overpowered "+subdued.group(3)));subdued.appendTail(control);result=control.toString();
  if(!PACKAGING.matcher(result).find()){Matcher wrap=WRAP.matcher(result);StringBuffer ending=new StringBuffer();while(wrap.find()){String verb=wrap.group(1).toLowerCase(Locale.ROOT);wrap.appendReplacement(ending,Matcher.quoteReplacement((verb.equals("wrapped")?"finished":verb.equals("wrapping")?"finishing":verb.equals("wraps")?"finishes":"finish")+" "+wrap.group(2)));}wrap.appendTail(ending);result=ending.toString();}
  result=SHOW_RESTRAINT.matcher(result).replaceAll("$1control yourself");
  result=AWAY_FROM_POST.matcher(result).replaceAll("away from my duty post");
  result=STAY_ANY_LONGER.matcher(result).replaceAll("remain here any longer");
  result=DALLY_WITH.matcher(result).replaceAll("spend time with");
  result=SLY_ELF.matcher(result).replaceAll("that cunning elf");
  Matcher lost=GET_LOST.matcher(result);StringBuffer departures=new StringBuffer();while(lost.find())lost.appendReplacement(departures,Matcher.quoteReplacement((lost.group(1)==null?"":lost.group(1))+"leave"));lost.appendTail(departures);result=departures.toString();
  result=SEE_AROUND.matcher(result).replaceAll("$1see you again");
  Matcher urgent=URGENT_MATTERS.matcher(result);StringBuffer matters=new StringBuffer();while(urgent.find())urgent.appendReplacement(matters,Matcher.quoteReplacement(urgent.group(1)+" to handle some urgent matters"));urgent.appendTail(matters);result=matters.toString();
  result=OCEAN_GRACE.matcher(result).replaceAll("your majesty's boundless mercy");
  result=PRESERVE_MY_LIFE.matcher(result).replaceAll("I survived");
  return result;
 }
 public static String polish(String source,String previous,String target){
  if(target==null)return "";String result=target;
  Matcher state=MUST_STATE.matcher(source);int modals=0;Matcher must=Pattern.compile("(?iu)\\bmust\\b").matcher(source);while(must.find())modals++;
  // Do not change an unrelated obligation when one source contains several clauses.
  if(modals==1&&state.find()&&inferred(source,previous,state)){
   String predicate;switch(state.group(3).toLowerCase(Locale.ROOT)){case "waiting":predicate="menunggu";break;case "wondering":predicate="bertanya-tanya";break;case "joking":case "kidding":predicate="bercanda";break;case "dreaming":predicate="bermimpi";break;case "tired":case "exhausted":predicate="(?:lelah|kelelahan|capek)";break;case "hungry":predicate="lapar";break;case "thirsty":predicate="haus";break;case "sleepy":predicate="mengantuk";break;case "lonely":predicate="kesepian";break;case "worried":predicate="khawatir";break;case "afraid":case "scared":predicate="takut";break;case "upset":predicate="(?:kesal|sedih)";break;case "confused":predicate="bingung";break;default:predicate="(?:keliru|salah)";}
   result=Pattern.compile("(?iu)\\bharus(?:lah)?\\s+((?:(?:sedang|sangat|masih|sudah|benar-benar)\\s+)*"+predicate+")\\b").matcher(result).replaceAll("pasti $1");
  }
  if(APOLOGY_PREFIX.matcher(source).find()){
   result=Pattern.compile("(?iu)^\\s*permintaan\\s+maaf(?:\\s+(?:saya|aku|kami|kita))?\\s+(?:untuk|karena)\\b").matcher(result).replaceFirst("Maaf karena");
   result=Pattern.compile("(?iu)^\\s*permintaan\\s+maaf(?:\\s+(?:saya|aku|kami|kita))?\\s+atas\\b").matcher(result).replaceFirst("Maaf atas");
  }
  int reply=response(source,previous);if(reply!=0)result=Pattern.compile("(?iu)^\\s*(?:tidak\\s+sama\\s+sekali|sama\\s+sekali\\s+tidak)(?=\\s*(?:[,!.…;:]|$))").matcher(result).replaceFirst(reply==1?"Tidak apa-apa":"Sama-sama");
  Matcher arrival=ARRIVAL.matcher(source);while(arrival.find())if(emphatic(arrival)){
   Matcher own=Pattern.compile("(?iu)\\b(kami|kita|saya|aku|dia|mereka|kamu)\\s+(juga\\s+)?baru(?:\\s+saja)?\\s+(tiba|sampai)\\s+sendiri\\b").matcher(result);StringBuffer out=new StringBuffer();while(own.find()){String subject=own.group(1);if(reply==1&&arrival.group(1).equalsIgnoreCase("we")&&subject.equalsIgnoreCase("kita"))subject="kami";own.appendReplacement(out,Matcher.quoteReplacement(subject+" juga baru saja "+own.group(3)));}own.appendTail(out);result=out.toString();
   if(reply==1&&arrival.group(1).equalsIgnoreCase("we"))result=Pattern.compile("(?iu)\\bkita(?=\\s+(?:juga\\s+)?baru(?:\\s+saja)?\\s+(?:tiba|sampai)\\b)").matcher(result).replaceAll("kami");
  }
  if(RAMBLE.matcher(source).find()&&!WALKING.matcher(source).find())result=Pattern.compile("(?iu)\\b(aku|saya)\\s+(?:(?:telah|sudah)\\s+)?mengoceh\\s+terlalu\\s+lama\\b").matcher(result).replaceAll("$1 sudah terlalu banyak bicara");
  if(people(source)){
   result=Pattern.compile("(?iu)\\b(?:angka(?:-angka)?|figur(?:-figur)?)\\s+(?:kunci|penting|utama)\\b").matcher(result).replaceAll("tokoh-tokoh penting");
   result=Pattern.compile("(?iu)(\\btokoh(?:-tokoh)?\\s+penting\\s+(?:(?:sebagian\\s+besar|kebanyakan|sudah|telah)\\s+)*)dikumpulkan\\b").matcher(result).replaceAll("$1berkumpul");
  }
  if(source.trim().matches("(?isu)^just\\s+how\\s+much\\s+(?:blasphemy|damage|harm|pain|suffering|trouble)\\s+(?:is|are|was|were)\\b.*"))result=Pattern.compile("(?iu)^\\s*betapa\\s+banyak\\b").matcher(result).replaceFirst("Sebenarnya, seberapa besar");
  if(heretics(source))result=Pattern.compile("(?iu)\\bdi\\s+antara\\s+(?:para\\s+)?bidat\\b").matcher(result).replaceAll("di antara para penganut ajaran sesat");
  if(belief(source)){
   result=Pattern.compile("(?iu)\\b(?:memegang|menahan)\\b").matcher(result).replaceAll("menganut");
   if(Pattern.compile("(?iu)\\bdoctrine\\b").matcher(source).find()){
    result=Pattern.compile("(?iu)\\b(?:menganut|mengikuti)\\s+(?:(?:sebuah|suatu)\\s+)?((?:(?:sangat|amat)\\s+)?radikal)\\s+doktrin\\b").matcher(result).replaceAll("menganut ajaran yang $1");
    result=Pattern.compile("(?iu)\\b(?:menganut|mengikuti)\\s+(?:(?:sebuah|suatu)\\s+)?doktrin\\b").matcher(result).replaceAll("menganut ajaran");
   }
  }
  if(STREET_THUGS.matcher(source).find())result=Pattern.compile("(?iu)\\b(?:penjahat|preman|gangster)\\s+(?:back[- ]lorong|back[- ]alley|gang\\s+belakang)\\b").matcher(result).replaceAll("preman jalanan");
  if(REFERENTIAL_MEAN.matcher(source).find()){
   result=Pattern.compile("(?iu)\\bapakah\\s+kamu\\s+(?:(?:bisa|kebetulan)\\s+)?berarti\\b").matcher(result).replaceAll("apakah maksudmu");
   if(source.trim().matches("(?isu)^(?:\\.{2,}|…+)?\\s*by\\s+that\\s+(?:faction|group|word|term|name)\\s*,.*"))result=Pattern.compile("(?iu)\\boleh\\s+([^,.!?]{1,60})\\s+itu\\s*,").matcher(result).replaceFirst("dengan $1 itu,");
  }
  if(groupGrowth(source))result=Pattern.compile("(?iu)\\btumbuh\\s+(?:dengan\\s+)?cepat\\b").matcher(result).replaceAll("berkembang pesat");
  if(HEGEMON.matcher(source).find())result=Pattern.compile("(?iu)\\bbangsa\\s+hegemonik\\b").matcher(result).replaceAll("negara dominan");
  if(SHIELDING.matcher(source).find())result=Pattern.compile("(?iu)\\bmenegaskan(?=\\s+(?:(?:sebuah|suatu)\\s+)?(?:kelompok|faksi|anak|pengungsi)\\b)").matcher(result).replaceAll("melindungi");
  Matcher relative=OBJECT_RELATIVE.matcher(source);while(relative.find()){
   // A retained name marker anchors the target agent; avoid guessing with free text.
   Matcher named=Pattern.compile(MARKER,Pattern.CASE_INSENSITIVE).matcher(relative.group(1));if(!named.find())continue;String active,passive;switch(relative.group(2).toLowerCase(Locale.ROOT)){case "creating":active="menciptakan";passive="diciptakan";break;case "making":active="membuat";passive="dibuat";break;case "building":active="membangun";passive="dibangun";break;case "developing":active="mengembangkan";passive="dikembangkan";break;default:active="memproduksi";passive="diproduksi";}
   result=Pattern.compile("(?iu)\\byang\\s+"+active+"\\s+((?:(?:kerajaan|kekaisaran|kota|desa)\\s+)?"+Pattern.quote(named.group())+")\\b").matcher(result).replaceAll("yang sedang "+passive+" oleh $1");
  }
  Matcher cult=NAMED_CULT.matcher(source);while(cult.find())result=Pattern.compile("(?iu)\\b"+Pattern.quote(cult.group(1))+"\\s+(?:cult|kultus)\\b|\\b(?:cult|kultus)\\s+"+Pattern.quote(cult.group(1))+"\\b").matcher(result).replaceAll("sekte "+Matcher.quoteReplacement(cult.group(1)));
  if(PRECISE.matcher(source).find()){Matcher literal=Pattern.compile("(?isu)^(.+?),\\s*yaitu\\s*([.!]?)\\s*$").matcher(result);if(literal.matches())result="Tepatnya, "+literal.group(1)+literal.group(2);}
  if(GOOD_GRIEF.matcher(source).find())result=Pattern.compile("(?iu)^\\s*kesedihan\\s+(?:yang\\s+)?baik\\b").matcher(result).replaceFirst("Astaga");
  if(BOGGLING.matcher(source).find())result=Pattern.compile("(?iu)\\bbengalan\\b").matcher(result).replaceAll("sulit dipahami");
  if(GRAVE_MATTER.matcher(source).find())result=Pattern.compile("(?iu)\\b(hal|masalah|perkara)\\s+yang\\s+serius\\s+dan\\s+serius\\b").matcher(result).replaceAll("$1 yang sangat serius");
  if(Pattern.compile("(?iu)\\bdiscussions?\\s+regarding\\b").matcher(source).find()&&!Pattern.compile("(?iu)\\b(?:birth|born|baby|babies|pregnant)\\b").matcher(source).find())result=Pattern.compile("(?iu)\\bdiskusi(\\s+mendalam)?\\s+(?:yang\\s+)?melahirkan\\b").matcher(result).replaceAll("diskusi$1 mengenai");
  if(FATE_BALANCE.matcher(source).find())result=Pattern.compile("(?iu)\\bmenggantung(?:kan)?\\s+(nasib\\s+[^.!?;]{1,70}?)\\s+dalam\\s+keseimbangan\\b").matcher(result).replaceAll("mempertaruhkan $1");
  if(SLACKING.matcher(source).find()&&!ROPE.matcher(source).find())result=Pattern.compile("(?iu)\\b(?:ope\\s+malas|malas\\s+ope)\\b").matcher(result).replaceAll("bermalas-malasan");
  if(biological(source)){Matcher race=BIO_RACE.matcher(source);while(race.find())result=Pattern.compile("(?iu)\\b(?:lomba|perlombaan|ras)\\s+"+Pattern.quote(race.group(1))+"\\b").matcher(result).replaceAll("ras "+raceName(race.group(1)));}
  if(VOCABULARY.matcher(source).find())result=Pattern.compile("(?iu)\\bkosakata(mu|nya|ku)?(\\s+(?:kamu|anda|dia|saya|aku))?\\s+(?:secara\\s+)?mengejutkan\\s+canggih\\b").matcher(result).replaceAll("pilihan kata$1$2 ternyata cukup berbobot");
  if(FRIVOLOUS.matcher(source).find())result=Pattern.compile("(?iu)\\b(?:seseorang|orang)\\s+yang\\s+berperilaku\\s+(?:sangat|begitu)\\s+sembrono\\b").matcher(result).replaceAll("orang yang bersikap begitu main-main");
  if(SUGARCOAT.matcher(source).find())result=Pattern.compile("(?iu)\\bsugar(?:\\s+itu|nya)?\\b").matcher(result).replaceAll("memperhalus kenyataan");
  if(THIS_INSTANT.matcher(source).find())result=Pattern.compile("(?iu)\\binstan\\s+ini\\b").matcher(result).replaceAll("sekarang juga");
  Matcher subdued=SUBDUED_OBJECT.matcher(source);while(subdued.find())if(subdued.group(1).equalsIgnoreCase("i")&&subdued.group(3).matches("(?iu)him|her")&&subdued.group(4).matches("(?iu).*(?:almost|nearly).*"))result=Pattern.compile("(?iu)\\b(aku|saya)\\s+(?:(?:telah|sudah)\\s+)?(?:hampir|nyaris)\\s+(?:(?:benar-benar|sepenuhnya|sama\\s+sekali|total)\\s+)?tenang\\b").matcher(result).replaceAll("$1 hampir sepenuhnya menundukkannya");
  if(WRAP.matcher(source).find()&&!PACKAGING.matcher(source).find())result=Pattern.compile("(?iu)\\bmembungkus(nya)?\\b").matcher(result).replaceAll("menyelesaikan$1");
  if(Pattern.compile("(?iu)\\bwait\\s+for\\s+me\\b").matcher(source).find())result=Pattern.compile("(?iu)\\btunggu\\s+po\\s+the\\s+me\\b").matcher(result).replaceAll("tunggu aku");
  if(SHOW_RESTRAINT.matcher(source).find()){
   result=Pattern.compile("(?iu)\\b(?:tunjukkan|menunjukkan)\\s+(?:(?:beberapa|sedikit)\\s+)?(?:pengekangan|pengendalian)\\b").matcher(result).replaceAll("tahan diri");
   if(Pattern.compile("(?iu)\\bfor\\s+once\\b").matcher(source).find())result=Pattern.compile("(?iu)\\b(tahan\\s+diri)\\s+sekali(?=\\s*[!?.…]*\\s*$)").matcher(result).replaceAll("$1 sekali ini");
  }
  if(AWAY_FROM_POST.matcher(source).find()){
   Matcher longAway=LONG_AWAY_FROM_POST.matcher(result);StringBuffer posts=new StringBuffer();while(longAway.find())longAway.appendReplacement(posts,Matcher.quoteReplacement(longAway.group(1)+" sudah terlalu lama meninggalkan pos tugasku"));longAway.appendTail(posts);result=posts.toString();
   result=Pattern.compile("(?iu)\\bposting\\s+(?:aku|saya)\\b").matcher(result).replaceAll("pos tugasku");
  }
  if(STAY_ANY_LONGER.matcher(source).find()){
   result=Pattern.compile("(?iu)\\btinggal\\s+di\\s+sini\\s+lagi(?=\\s*[-—–])").matcher(result).replaceAll("tetap di sini lebih lama lagi");
   result=Pattern.compile("(?iu)\\btinggal\\s+di\\s+sini\\s+lebih\\s+lama\\b").matcher(result).replaceAll("tetap di sini lebih lama");
  }
  if(DALLY_WITH.matcher(source).find())result=Pattern.compile("(?iu)\\bdally\\s+sekitar\\s+dengan\\b").matcher(result).replaceAll("berlama-lama bersama");
  if(SLY_ELF.matcher(source).find())result=Pattern.compile("(?iu)\\b(?:rubah|serigala)\\s+licik\\s+dari\\s+(?:peri|elf)\\b").matcher(result).replaceAll("elf licik itu");
  if(GET_LOST.matcher(source).find())result=Pattern.compile("(?iu)\\b(?:hanya\\s+)?cepat\\s+dan\\s+tersesat\\b").matcher(result).replaceAll("cepat pergi sana");
  if(SEE_AROUND.matcher(source).find()){
   result=Pattern.compile("(?iu)\\bsampai\\s+jumpa\\s+di\\s+sekitar\\s+(?:kamu|anda|mu)\\b").matcher(result).replaceAll("sampai jumpa lagi");
   if(Pattern.compile("(?iu)\\bsee\\s+you\\s+around\\s*,\\s*then\\b").matcher(source).find())result=Pattern.compile("(?iu)(\\bsampai\\s+jumpa\\s+lagi)\\s*,\\s*(?:lalu|kemudian)(?=\\s*[!?.…]*\\s*$)").matcher(result).replaceAll("$1, kalau begitu");
  }
  if(CRUSH_BENEATH.matcher(source).find())result=Pattern.compile("(?iu)\\bmenghancurkan\\s+(mereka|dia|kalian)\\s+di\\s+bawah\\s+kaki\\s+aku\\b").matcher(result).replaceAll("meremukkan $1 di bawah kakiku");
  if(URGENT_MATTERS.matcher(source).find())result=Pattern.compile("(?iu)\\b(?:memiliki|punya)\\s+beberapa\\s+hal\\s+mendesak\\s+untuk\\s+diperhatikan\\b").matcher(result).replaceAll("harus mengurus beberapa urusan mendesak");
  if(OCEAN_GRACE.matcher(source).find())result=Pattern.compile("(?iu)\\brahmat\\s+lautan\\s+yang\\s+mulia\\b").matcher(result).replaceAll("kemurahan hati Yang Mulia yang seluas lautan");
  if(PRESERVE_MY_LIFE.matcher(source).find())result=Pattern.compile("(?iu)\\b(?:aku|saya)\\s+bisa\\s+melestarikanku\\b").matcher(result).replaceAll("nyawaku terselamatkan");
  return result;
 }
 private ConversationMeaning(){}
}
