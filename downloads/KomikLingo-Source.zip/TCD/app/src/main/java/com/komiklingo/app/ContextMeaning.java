package com.komiklingo.app;

import java.util.*;
import java.util.regex.*;

/** Small, explicit sense rules. This is not a general story-understanding model. */
public final class ContextMeaning {
 private static final String AUX="(?:(?:can(?:not)?|could|will|would|shall|should|must|may|might|do|does|did)(?:\\s+not)?|(?:ca|could|wo|would|sha|should|do|does|did)n['’]t)";
 private static final String COMPLEMENT="(?:be|have|do|go|come|sense|feel|see|hear|detect|perceive|notice|tell|find|believe|understand|remember|forget|move|run|walk|stop|leave|say|think|speak|breathe|stand|sleep|stay|fight|save|reach|accept|allow|trust|use|read|write|choose|change|make|take|give|get|know|help|lose|keep|control|hold|protect|not)";
 private static final Pattern PAUSED_AUX=Pattern.compile("(?iu)\\b("+AUX+")\\s*(?:\\.{2,}|…+)\\s*$");
 private static final Pattern LINKED_PAUSE=Pattern.compile("(?iu)\\b("+AUX+")\\s*(?:\\.{2,}|…+)\\s+(?="+COMPLEMENT+"\\b)");
 private static final Pattern SENSE_PRESENCE=Pattern.compile("(?iu)\\b(?:sense|sensed|sensing)\\s+(?:(?:her|his|their|your|my|our|its|the|a)\\s+)?presence\\b");
 private static final Pattern SADNESS=Pattern.compile("(?iu)\\b(?:sad|sadly|sadness|sorrow|sorrowful|unfortunately)\\b");
 private static final Pattern HUMAN_POWERHOUSE=Pattern.compile("(?iu)\\b(he|she|i|you|we|they)((?:['’](?:s|re|m))|(?:\\s+(?:am|is|are|was|were)))\\s+((?:(?:a|an|the)\\s+)?)(powerhouse|powerhouses)\\b");
 private static final Pattern POWER_SOURCE=Pattern.compile("(?iu)\\b(?:power\\s+(?:plant|station|generation)|electricity|electrical|hydroelectric|megawatts?|kilowatts?|turbines?|generator|generates?|supplies?)\\b");
 private static final Pattern PRICKLY_SIMILE=Pattern.compile("(?iu)\\blike\\s+(?:such\\s+)?(?:a\\s+)?prickly\\s+(?:cat|person|man|woman|boy|girl)\\b");
 private static final Pattern BEHAVIOUR=Pattern.compile("(?iu)\\b(?:glare|glaring|stare|staring|act|acting|behave|behaving)\\b");
 private static final Pattern LITERAL_SPINES=Pattern.compile("(?iu)\\b(?:thorns?|spines?|needles?|cactus|cacti|sculpture|statue|figurine)\\b");
 private static final Pattern NEGATIVE_INTENTION=Pattern.compile("(?iu)\\b(i|you|we|they|he|she|it|ZXQNAMEX*\\d+QXZ)\\s+(have|has|had)\\s+((?:(?:absolutely|certainly|definitely|really)\\s+)?)no\\s+intentions?(?:\\s+whatsoever)?\\s+of\\b");
 private static boolean pricklyBehaviour(String source){return PRICKLY_SIMILE.matcher(source).find()&&BEHAVIOUR.matcher(source).find()&&!LITERAL_SPINES.matcher(source).find();}
 public static boolean pausedAuxiliary(String source){return PAUSED_AUX.matcher(source.trim()).find();}
 public static boolean startsNamed(String source,List<String> names){for(String name:names)if(source.regionMatches(true,0,name,0,name.length())&&(source.length()==name.length()||!Character.isLetterOrDigit(source.charAt(name.length()))))return true;return false;}
 private static final Pattern BRAND=Pattern.compile("(?iu)\\b(brand|brands)\\s+of\\s+(fate|destiny|shame|disgrace|slavery|ownership)\\b");
 private static final Pattern COMMERCIAL=Pattern.compile("(?iu)\\b(?:product|products|company|companies|perfume|shampoo|shoes|clothing|cosmetics|logo|marketing|trademark|advertising)\\b");
 private static boolean commercial(String source,Matcher phrase){int left=Math.max(0,phrase.start()-70),right=Math.min(source.length(),phrase.end()+70);return COMMERCIAL.matcher(source.substring(left,right)).find();}
 public static String normalize(String source){
  source=PhrasalVerbs.normalize(source);
  source=LINKED_PAUSE.matcher(source).replaceAll("$1 ");
  Matcher intention=NEGATIVE_INTENTION.matcher(source);StringBuffer intentInput=new StringBuffer();while(intention.find()){String auxiliary=intention.group(2).equalsIgnoreCase("has")?"does":intention.group(2).equalsIgnoreCase("had")?"did":"do";intention.appendReplacement(intentInput,Matcher.quoteReplacement(intention.group(1)+" "+intention.group(3)+auxiliary+" not plan on"));}intention.appendTail(intentInput);source=intentInput.toString();
  if(pricklyBehaviour(source)){Matcher simile=PRICKLY_SIMILE.matcher(source);StringBuffer clarified=new StringBuffer();while(simile.find())simile.appendReplacement(clarified,Matcher.quoteReplacement(simile.group().replaceAll("(?iu)\\bprickly\\b","grumpy")));simile.appendTail(clarified);source=clarified.toString();}
  if(!POWER_SOURCE.matcher(source).find()){
   Matcher person=HUMAN_POWERHOUSE.matcher(source);StringBuffer expanded=new StringBuffer();
   while(person.find()){boolean plural=person.group(1).matches("(?iu)we|they")||person.group(4).equalsIgnoreCase("powerhouses");person.appendReplacement(expanded,Matcher.quoteReplacement(person.group(1)+person.group(2)+" "+person.group(3)+"very powerful "+(plural?"people":"person")));}
   person.appendTail(expanded);source=expanded.toString();
  }
  Matcher match=BRAND.matcher(source);StringBuffer output=new StringBuffer();while(match.find()){
   if(commercial(source,match))continue;String meaning=match.group(2).toLowerCase(Locale.ROOT);if(meaning.equals("fate"))meaning="destiny";
   match.appendReplacement(output,Matcher.quoteReplacement((match.group(1).equalsIgnoreCase("brands")?"marks":"mark")+" of "+meaning));
  }match.appendTail(output);return output.toString();
 }
 public static String polish(String source,String translated){
  if(translated==null)return "";String result=PhrasalVerbs.polish(source,translated);Matcher phrase=BRAND.matcher(source);while(phrase.find()){
   if(commercial(source,phrase))continue;String meaning=phrase.group(2).toLowerCase(Locale.ROOT);String noun,replacement;
   switch(meaning){case "fate":case "destiny":noun="(?:nasib|takdir)";replacement="tanda takdir";break;case "shame":case "disgrace":noun="(?:rasa malu|malu|aib|kehinaan)";replacement="cap aib";break;case "slavery":noun="perbudakan";replacement="tanda perbudakan";break;default:noun="kepemilikan";replacement="tanda kepemilikan";}
   if(phrase.group(1).equalsIgnoreCase("brands"))replacement=replacement.replaceFirst("^(tanda|cap)","$1-$1");
   result=Pattern.compile("(?iu)\\bmerek(?:-merek)?(?:\\s+dari)?\\s+"+noun+"\\b").matcher(result).replaceAll(Matcher.quoteReplacement(replacement));
  }
  // Called before protected names are restored: the source article is not a literal character A.
  boolean article=Pattern.compile("(?iu)\\b(?:am|is|are|was|were)\\s+(?:a|an)\\s+(?!(?:and|or|from|of|in|on|at|with|without|to)\\b)[a-z][a-z0-9_'-]+\\b").matcher(source).find();
  if(article)result=Pattern.compile("(?iu)\\b(adalah|merupakan|ada)\\s+a\\s+(?!(?:dan|atau|dari|yang|di)\\b)(?=[\\p{L}])").matcher(result).replaceAll("$1 ");
  if(SENSE_PRESENCE.matcher(source).find()&&!SADNESS.matcher(source).find())result=Pattern.compile("(?iu)\\b(?:sedihnya|kesedihannya|rasa sedih|sedih)\\s+((?:kehadiran|keberadaan)(?:nya|mu|ku)?)\\b").matcher(result).replaceAll("merasakan $1");
  if(HUMAN_POWERHOUSE.matcher(source).find()&&!POWER_SOURCE.matcher(source).find())result=Pattern.compile("(?iu)\\bpembangkit(?:\\s+tenaga)?\\s+listrik\\b").matcher(result).replaceAll("orang yang sangat kuat");
  if(pricklyBehaviour(source))result=Pattern.compile("(?iu)\\b(?:kucing\\s+(?:yang\\s+)?berduri|berduri\\s+kucing)\\b").matcher(result).replaceAll("kucing galak");
  if(NEGATIVE_INTENTION.matcher(source).find())result=Pattern.compile("(?iu)\\b(?:punya|memiliki|mempunyai)\\s+((?:sama sekali\\s+)?(?:tidak|tak)\\s+(?:berniat|bermaksud|berencana))\\b").matcher(result).replaceAll("$1");
  return result;
 }
 /** Strong unfinished grammar only; capitalisation alone is never a reason to join balloons. */
 public static boolean named(String source,List<String> names){for(String name:names)if(name.equalsIgnoreCase(source.trim()))return true;return false;}
 public static boolean openFragment(String source){return !source.trim().isEmpty()&&!source.trim().matches("(?s).*[.!?…:;][\\\"”’']*$");}
 public static boolean dangling(String source,List<String> names){return !named(source,names)&&dangling(source);}
 public static boolean dangling(String source){
  String text=source.trim();if(text.isEmpty()||text.matches("(?s).*[.!?…:;][\\\"”’']*$"))return false;
  return Pattern.compile("(?iu)(?:^|\\s)(?:a|an|the|of|from|with|into|onto|because|although|whether)$").matcher(text).find()||text.matches("(?iu)(?:am|is|are|was|were)");
 }
 public static boolean continues(String left,String right){
  if(right.trim().isEmpty())return false;if(pausedAuxiliary(left))return Pattern.compile("(?iu)^"+COMPLEMENT+"\\b").matcher(right.trim()).find();if(dangling(left))return true;
  if(left.trim().matches("(?s).*[.!?…:;][\\\"”’']*$"))return false;
  if(PhrasalVerbs.continues(left,right))return true;
  if(HUMAN_POWERHOUSE.matcher(left).find()&&right.trim().matches("(?iu)^on\\s+the\\s+level\\s+of\\b.*"))return true;
  return right.trim().matches("(?iu)^(?:and|or|but|of|from|with|without|for|by|into|onto|through|under)\\b.*");
 }
 private ContextMeaning(){}
}
