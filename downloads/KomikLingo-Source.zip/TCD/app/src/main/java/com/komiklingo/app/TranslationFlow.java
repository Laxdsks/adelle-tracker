package com.komiklingo.app;

import java.util.*;
import java.util.function.BooleanSupplier;

/** Bounded dialogue groups; retries preserve balloon order and protected names. */
public final class TranslationFlow {
 public interface Result {void done(List<String> translations,int failures);}
 private final List<ProtectedTerms.Plan> plans;private final NameTranslation.Engine engine;
 private final BooleanSupplier active;private final Result result;
 private final List<String> output;private int failures=0;
 private TranslationFlow(List<ProtectedTerms.Plan> plans,NameTranslation.Engine engine,BooleanSupplier active,Result result){this.plans=new ArrayList<>(plans);this.engine=engine;this.active=active;this.result=result;output=new ArrayList<>(Collections.nCopies(plans.size(),""));}
 public static void translate(List<ProtectedTerms.Plan> plans,NameTranslation.Engine engine,BooleanSupplier active,Result result){new TranslationFlow(plans,engine,active,result).group(0);}
 private void group(int start){
  if(!active.getAsBoolean())return;if(start>=plans.size()){result.done(output,failures);return;}
  int end=start,characters=0;List<String> source=new ArrayList<>();
  while(end<plans.size()&&end-start<8){String text=ReadingText.translationInput(plans.get(end).masked);if(end>start&&characters+text.length()+2>4000)break;source.add(text);characters+=text.length()+2;end++;}
  final int until=end;
  if(until-start<2){individual(start,until,()->group(until));return;}
  engine.translate(String.join("\n\n",source),(value,error)->{
   if(!active.getAsBoolean())return;
   List<String> parts=error==null?ReadingText.splitBatch(value,until-start):null;
   if(parts==null){individual(start,until,()->group(until));return;}
   // Each protected name belongs to its own balloon, even if a batch rearranges tokens.
   repair(start,until,parts,()->group(until));
  });
 }
 private void repair(int at,int until,List<String> parts,Runnable done){
  if(!active.getAsBoolean())return;if(at>=until){done.run();return;}
  int first=until-parts.size();ProtectedTerms.Plan plan=plans.get(at);String value=parts.get(at-first);
  if(plan.valid(value)){output.set(at,ContextMeaning.polish(plan.masked,value));repair(at+1,until,parts,done);return;}
  NameTranslation.translate(plan,normalizedEngine(),(translated,error)->{if(!active.getAsBoolean())return;if(error==null&&plan.valid(translated))output.set(at,ContextMeaning.polish(plan.masked,translated));else failures++;repair(at+1,until,parts,done);});
 }
 private NameTranslation.Engine normalizedEngine(){return (source,callback)->engine.translate(ReadingText.translationInput(source),callback);}
 private void individual(int at,int until,Runnable done){
  if(!active.getAsBoolean())return;if(at>=until){done.run();return;}
  ProtectedTerms.Plan plan=plans.get(at);
  NameTranslation.translate(plan,normalizedEngine(),(translated,error)->{if(!active.getAsBoolean())return;if(error==null&&plan.valid(translated))output.set(at,ContextMeaning.polish(plan.masked,translated));else failures++;individual(at+1,until,done);});
 }
}
