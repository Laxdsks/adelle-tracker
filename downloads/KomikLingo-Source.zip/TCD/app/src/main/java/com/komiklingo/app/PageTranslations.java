package com.komiklingo.app;
import android.graphics.RectF;
import java.util.*;

/** RAM-only results and scanned regions for one loaded document. */
public final class PageTranslations {
 public static final class Entry {
  public final long id;public final String source,target;public final RectF css;public final int background,ink;public final float font;public final boolean caps,left,italic;
  public boolean pending,updated;
  Entry(long id,String source,String target,RectF css,int background,int ink,float font,boolean caps,boolean left,boolean italic,boolean updated){this.id=id;this.source=source;this.target=target;this.css=css;this.background=background;this.ink=ink;this.font=font;this.caps=caps;this.left=left;this.italic=italic;this.updated=updated;}
 }
 private final List<Entry> entries=new ArrayList<>();private final List<RectF> scanned=new ArrayList<>();private long nextId=1;
 public void clear(){entries.clear();scanned.clear();}public int size(){return entries.size();}
 public Entry get(long id){for(Entry entry:entries)if(entry.id==id)return entry;return null;}
 public void remove(long id){entries.removeIf(entry->entry.id==id);}
 public List<Entry> entries(){List<Entry> ordered=new ArrayList<>(entries);ordered.sort(Comparator.comparingDouble(entry->entry.css.top));return ordered;}
 /** A nearby following paragraph in the same column, not a whole-page context dump. */
 public static float followingDistance(RectF area,RectF candidate,float maxGap){float shared=Math.min(area.right,candidate.right)-Math.max(area.left,candidate.left);float gap=candidate.top-area.bottom;if(candidate.centerY()<=area.centerY()||candidate.top<area.bottom-2||gap>maxGap||shared<Math.min(area.width(),candidate.width())*.3f)return Float.POSITIVE_INFINITY;return Math.max(0,gap);}
 public Entry following(RectF area,float maxGap){Entry best=null;float distance=Float.POSITIVE_INFINITY;for(Entry entry:entries){float gap=followingDistance(area,entry.css,maxGap);if(gap<distance){best=entry;distance=gap;}}return best;}
 public static RectF css(RectF viewport,float scale,int x,int y){return new RectF((viewport.left+x)/scale,(viewport.top+y)/scale,(viewport.right+x)/scale,(viewport.bottom+y)/scale);}
 public static float overlap(RectF first,RectF second){RectF shared=new RectF(first);if(!shared.intersect(second))return 0;return shared.width()*shared.height()/Math.max(1,Math.min(first.width()*first.height(),second.width()*second.height()));}
 public boolean contains(RectF box,float scale,int x,int y){RectF area=css(box,scale,x,y);for(Entry entry:entries){RectF shared=new RectF(area);if(shared.intersect(entry.css)&&shared.width()*shared.height()>=area.width()*area.height()*.86f)return true;}return false;}
 public boolean scanned(float scale,int x,int y,int width,int height){RectF visible=css(new RectF(0,0,width,height),scale,x,y);visible.inset(2,2);for(RectF area:scanned)if(area.contains(visible))return true;return false;}
 public void markScanned(float scale,int x,int y,int width,int height){RectF area=css(new RectF(0,0,width,height),scale,x,y);for(RectF old:scanned)if(old.contains(area))return;scanned.removeIf(area::contains);if(scanned.size()>=800)scanned.remove(0);scanned.add(area);}
 public Entry put(String source,String target,RectF viewport,int background,boolean caps,BubbleOverlay.Appearance appearance,float scale,int scrollX,int scrollY){return put(source,target,viewport,background,caps,appearance,scale,scrollX,scrollY,false);}
 public Entry put(String source,String target,RectF viewport,int background,boolean caps,BubbleOverlay.Appearance appearance,float scale,int scrollX,int scrollY,boolean updated){
  if(target==null||target.isEmpty()||scale<=0)return null;RectF area=css(viewport,scale,scrollX,scrollY);long id=0;
  for(Iterator<Entry> iterator=entries.iterator();iterator.hasNext();){Entry old=iterator.next();if(overlap(area,old.css)>.65f){if(id==0)id=old.id;updated|=old.updated;iterator.remove();}}
  if(entries.size()>=6000)return null;if(id==0)id=nextId++;
  Entry entry=new Entry(id,source,target,area,background,appearance==null?0xff18181c:appearance.ink,appearance==null?24:appearance.sourceSize/scale,caps,appearance!=null&&appearance.leftAligned,appearance!=null&&appearance.italic,updated);entries.add(entry);return entry;
 }
 public List<BubbleOverlay.Bubble> visible(float scale,int scrollX,int scrollY,int width,int height){
  List<BubbleOverlay.Bubble> result=new ArrayList<>();for(Entry entry:entries){RectF box=new RectF(entry.css.left*scale-scrollX,entry.css.top*scale-scrollY,entry.css.right*scale-scrollX,entry.css.bottom*scale-scrollY);if(box.right<=0||box.left>=width||box.bottom<=0||box.top>=height)continue;String text=entry.caps?entry.target.toUpperCase(new Locale("id")):entry.target;result.add(new BubbleOverlay.Bubble(box,text,entry.background,entry.caps,new BubbleOverlay.Appearance(entry.ink,entry.font*scale,entry.left,entry.italic),entry.id,entry.pending,entry.updated));}return result;
 }
}
