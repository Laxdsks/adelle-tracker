import com.komiklingo.app.OcrQuality;
import com.komiklingo.app.ReadingText;
import com.komiklingo.app.ProtectedTerms;
import java.util.*;
import java.nio.file.*;
public class OcrQualityTest {
 static void yes(boolean value){if(!value)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  OcrQuality.load(Files.newInputStream(Path.of("app/src/main/assets/english-ocr-words.txt")));
  yes(OcrQuality.knownRatio("LAUGH DIRECTLY AFFECTING THE SOUL")>OcrQuality.knownRatio("LAMGH PIRECTLY AFFECTING THE 50ML"));
  yes(OcrQuality.mixedGlyphs("50ML"));yes(!OcrQuality.mixedGlyphs("SOUL"));yes(OcrQuality.caps("DON'T MAKE ME LAUGH"));yes(!OcrQuality.caps("Don't make me laugh"));
  yes(OcrQuality.keepsNames("Ban and Eldoria","Ban in Eldoria",List.of("Ban","Eldoria")));yes(!OcrQuality.keepsNames("Ban and Eldoria","Ban and Elders",List.of("Eldoria")));
  yes(OcrQuality.ambiguousShort("60!"));yes(OcrQuality.ambiguousShort("DO OR PO?"));yes(!OcrQuality.ambiguousShort("600 dollars"));
  yes(OcrQuality.numeralWordConflict("60!", "GO!"));yes(OcrQuality.numeralWordConflict("I SAID 60", "I SAID GO"));yes(!OcrQuality.numeralWordConflict("60", "70"));yes(!OcrQuality.numeralWordConflict("GO", "NO"));
  yes(OcrQuality.suspiciousSyntax("NE PLAN TO HEAD TO THE KINGDOM"));yes(OcrQuality.suspiciousSyntax("GET READY TO MOE!"));yes(!OcrQuality.suspiciousSyntax("WE PLAN TO HEAD"));yes(!OcrQuality.suspiciousSyntax("Moe, come here."));
  yes(OcrQuality.score("WE PLAN TO HEAD",.9)>OcrQuality.score("NE PLAN TO HEAD",.99));
  yes(OcrQuality.keepsNames("MOE","MOE",List.of("Moe")));yes(!OcrQuality.keepsNames("MOE","MOVE",List.of("Moe")));
  yes(ProtectedTerms.cleanOcr("GET READY TO MOE!",List.of("Moe")).contains("Moe"));
  yes(OcrQuality.suspiciousSyntax("BANI DONT JUST $TAND THERE SULKING"));
  yes(!OcrQuality.suspiciousSyntax("BAN! DON'T JUST STAND THERE SULKING"));
  yes(ReadingText.garbledTranslation("DON'T JUST STAND THERE SULKING","Bani dont hanya $ tand di sana meregangkan"));
  yes(!ReadingText.garbledTranslation("DON'T JUST STAND THERE SULKING","Ban, jangan hanya berdiri di sana sambil merajuk."));
  yes(OcrQuality.better("TAKE A LOOK AT THAT MAJESTRCSTCUT",.92,"TAKE A LOOK AT THAT MAJESTIC SIGHT",.90,List.of()));
  yes(!OcrQuality.better("STAND THERE",.9,"STAND THERE QWERTYUIOPASDFGHJKL",.99,List.of()));
  yes(!OcrQuality.better("DON'T JUST STAND THERE SULKING",.9,"STAND THERE",.99,List.of()));
  yes(!OcrQuality.better("BAN WAIT HERE",.7,"MAN WAIT HERE",.99,List.of("Ban")));
  yes(ReadingText.garbledTranslation("TAKE A LOOK AT THAT MAJESTRCSTCUT", "Lihatlah MajestrcStcut itu!!"));
  yes(ReadingText.readerChrome("Ch. 56 Chronicle of Runes", "Ch. 56 - Chronicle of Runes | Kaynscans"));
  yes(!ReadingText.readerChrome("I am telling you to depart tomorrow", "Ch. 56 Chronicle of Runes"));
  yes(!ReadingText.readerChrome("Chronicle of Runes", null));
  yes(ReadingText.joinLines(List.of("IN THE ROEN KING-", "DOM'S MILITARY ACADEMY.")).equals("IN THE ROEN KINGDOM'S MILITARY ACADEMY."));
  yes(com.komiklingo.app.DialogueMeaning.normalize("HOW ON EARTH DID THINGS END UP LIKE THIS?", "").equals("HOW DID THINGS END UP LIKE THIS?"));
  yes(com.komiklingo.app.DialogueMeaning.normalize("LIFE ON EARTH IS PRECIOUS", "").equals("LIFE ON EARTH IS PRECIOUS"));
  yes(ProtectedTerms.discover(List.of("OUR 'HORA KINGDOM' AND THE 'SHIZEN KINGDOM'", "IDEA KINGDOM")).containsAll(List.of("HORA","SHIZEN","IDEA")));
  String politics=com.komiklingo.app.DialogueMeaning.normalize("OUR KINGDOM IS HEADING A COALITION IN THIS CLIMATE", "");
  yes(politics.contains("leading A COALITION"));yes(politics.contains("in this situation"));
  yes(com.komiklingo.app.DialogueMeaning.normalize("HE IS HEADING NORTH IN THIS CLIMATE", "").equals("HE IS HEADING NORTH IN THIS CLIMATE"));
  yes(com.komiklingo.app.DialogueMeaning.normalize("AND IN NONE OTHER THAN THE NEUTRAL ROEN KINGDOM", "").contains("specifically in THE NEUTRAL ROEN KINGDOM"));
  yes(com.komiklingo.app.DialogueMeaning.normalize("NONE OTHER THAN THE CAPTAIN CAN HELP", "").equals("NONE OTHER THAN THE CAPTAIN CAN HELP"));
  yes(!ReadingText.garbledTranslation("Watch it on YouTube tomorrow", "Tonton di YouTube besok"));
  yes(!ReadingText.garbledTranslation("Welcome to AzureDragonVillage", "Selamat datang di AzureDragonVillage"));
  System.out.println("OCR quality passed: dictionary evidence, mixed glyph warning, uppercase detection and known-name preservation; no dictionary replacement.");
 }
}
