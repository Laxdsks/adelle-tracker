import com.komiklingo.app.OcrQuality;
import java.util.*;
import java.nio.file.*;
public class OcrQualityTest {
 static void yes(boolean value){if(!value)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  OcrQuality.load(Files.newInputStream(Path.of("app/src/main/assets/english-ocr-words.txt")));
  yes(OcrQuality.knownRatio("LAUGH DIRECTLY AFFECTING THE SOUL")>OcrQuality.knownRatio("LAMGH PIRECTLY AFFECTING THE 50ML"));
  yes(OcrQuality.mixedGlyphs("50ML"));yes(!OcrQuality.mixedGlyphs("SOUL"));yes(OcrQuality.caps("DON'T MAKE ME LAUGH"));yes(!OcrQuality.caps("Don't make me laugh"));
  yes(OcrQuality.keepsNames("Ban and Eldoria","Ban in Eldoria",List.of("Ban","Eldoria")));yes(!OcrQuality.keepsNames("Ban and Eldoria","Ban and Elders",List.of("Eldoria")));
  System.out.println("OCR quality passed: dictionary evidence, mixed glyph warning, uppercase detection and known-name preservation; no dictionary replacement.");
 }
}
