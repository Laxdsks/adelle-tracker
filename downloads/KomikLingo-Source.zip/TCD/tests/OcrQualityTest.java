import com.komiklingo.app.OcrQuality;
import java.util.*;
import java.nio.file.*;
public class OcrQualityTest {
 static void yes(boolean value){if(!value)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  OcrQuality.load(Files.newInputStream(Path.of("app/src/main/assets/english-ocr-words.txt")));
  yes(OcrQuality.knownRatio("LAUGH DIRECTLY AFFECTING THE SOUL")>OcrQuality.knownRatio("LAMGH PIRECTLY AFFECTING THE 50ML"));
  yes(OcrQuality.mixedGlyphs("50ML"));yes(!OcrQuality.mixedGlyphs("SOUL"));yes(OcrQuality.caps("DON'T MAKE ME LAUGH"));yes(!OcrQuality.caps("Don't make me laugh"));
  yes(OcrQuality.keepsNames("Ban and Eldoria","Ban in Eldoria",List.of("Ban","Eldoria")));yes(!OcrQuality.keepsNames("Ban and Eldoria","Ban and Elders",List.of("Eldoria")));
  yes(OcrQuality.ambiguousShort("60!"));yes(OcrQuality.ambiguousShort("DO OR PO?"));yes(!OcrQuality.ambiguousShort("600 dollars"));
  yes(OcrQuality.numeralWordConflict("60!", "GO!"));yes(OcrQuality.numeralWordConflict("I SAID 60", "I SAID GO"));yes(!OcrQuality.numeralWordConflict("60", "70"));yes(!OcrQuality.numeralWordConflict("GO", "NO"));
  System.out.println("OCR quality passed: dictionary evidence, mixed glyph warning, uppercase detection and known-name preservation; no dictionary replacement.");
 }
}
