import com.komiklingo.app.*;
import java.util.*;
import java.util.concurrent.atomic.*;
public class TranslationFlowTest {
 static void same(Object actual,Object expected){if(!Objects.equals(actual,expected))throw new AssertionError(actual+" != "+expected);}
 static void yes(boolean value){if(!value)throw new AssertionError("Expected true");}
 public static void main(String[] args){
  same(ReadingText.joinLines(List.of("SUD-","DENLY, I UNDER-","STAND.")),"SUDDENLY, I UNDERSTAND.");
  same(ReadingText.joinLines(List.of("I-","I DON'T KNOW!")),"I- I DON'T KNOW!");
  same(ReadingText.joinLines(List.of("Some-","Thing"),List.of("Some-Thing")),"Some-Thing");
  same(ReadingText.joinLines(List.of("Ban-","DIT")),"Ban- DIT");
  same(ReadingText.translationInput("P-DON'T MAKE ME LAUGH!"),"DO NOT MAKE ME LAUGH!");
  same(ReadingText.emotion("D-DON'T MAKE ME LAUGH!","Jangan membuatku tertawa!"),"J-Jangan membuatku tertawa!");
  same(ReadingText.emotion("B-Ban!","Ban!"),"B-Ban!");same(ReadingText.emotion("I-I will go.","A-aku pergi."),"A-aku pergi.");
  same(ReadingText.translationInput("X-Ray technology"),"X-Ray technology");
  same(ReadingText.translationInput("I WON'T leave. You're safe. I'd gone home. Ban's sword."),"I WILL NOT leave. You are safe. I'd gone home. Ban's sword.");
  same(ReadingText.translationInput("I can't! We’re ready; he's waiting."),"I cannot! We are ready; he's waiting.");
  same(ReadingText.paragraphs("Aku,kamu;dia!Tunggu?Apa 3,14"),"Aku, kamu; dia! Tunggu? Apa 3,14");
  same(ReadingText.paragraphs("  Apa ? !\n Kamu   di sini .\n\n\n  Aku datang !  "),"Apa?! Kamu di sini.\n\nAku datang!");
  same(ReadingText.style("You stay.","Anda tetap di sini .\n\nSaya menyusul !","dialogue"),"Kamu tetap di sini.\n\nAku menyusul!");
  List<ProtectedTerms.Plan> plans=new ArrayList<>();for(int i=0;i<9;i++)plans.add(ProtectedTerms.prepare("Ban, stay "+i+".",List.of("Ban"),i*1000));
  AtomicInteger calls=new AtomicInteger(),done=new AtomicInteger();
  TranslationFlow.translate(plans,(source,result)->{calls.incrementAndGet();result.done(source.replace("stay","tetap"),null);},()->true,(values,failed)->{done.incrementAndGet();same(values.size(),9);same(failed,0);for(int i=0;i<9;i++)same(plans.get(i).restore(values.get(i)),"Ban, tetap "+i+".");});
  same(calls.get(),2);same(done.get(),1);
  var first=ProtectedTerms.prepare("Ban, stay.",List.of("Ban"),0);var second=ProtectedTerms.prepare("Linda, wait.",List.of("Linda"),1000);
  AtomicInteger repairs=new AtomicInteger();
  TranslationFlow.translate(List.of(first,second),(source,result)->{repairs.incrementAndGet();if(source.contains("\n\n"))result.done(second.masked+"\n\n"+first.masked,null);else result.done(source,null);},()->true,(values,failed)->{same(failed,0);same(first.restore(values.get(0)),"Ban, stay.");same(second.restore(values.get(1)),"Linda, wait.");});same(repairs.get(),3);
  var plain=List.of(ProtectedTerms.prepare("One",List.of()),ProtectedTerms.prepare("Two",List.of()));
  AtomicInteger fallback=new AtomicInteger();TranslationFlow.translate(plain,(source,result)->{fallback.incrementAndGet();result.done(source.contains("\n\n")?"Merged dialogue":source.equals("One")?"Satu":"Dua",null);},()->true,(values,failed)->{same(values,List.of("Satu","Dua"));same(failed,0);});same(fallback.get(),3);
  AtomicInteger completed=new AtomicInteger();AtomicBoolean active=new AtomicBoolean(true);TranslationFlow.translate(plain,(source,result)->{active.set(false);result.done("Satu\n\nDua",null);},active::get,(values,failed)->completed.incrementAndGet());same(completed.get(),0);
  TranslationFlow.translate(plain,(source,result)->{if(source.equals("Two"))result.done("Dua",null);else result.done(null,new Exception("offline"));},()->true,(values,failed)->{same(values,List.of("","Dua"));same(failed,1);});
  List<String> engineInput=new ArrayList<>();TranslationFlow.translate(List.of(first,second),(source,result)->{engineInput.add(source);result.done(source.replaceAll("ZXQNAME[0-9]+QXZ","Larangan"),null);},()->true,(values,failed)->{same(failed,0);same(first.restore(values.get(0)),"Ban, stay.");same(second.restore(values.get(1)),"Linda, wait.");});for(String input:engineInput)yes(!input.contains("Ban")&&!input.contains("Linda"));
  var question=ProtectedTerms.prepare("THEN AM I TO TAKE IT THAT YOU HAVE NO INTENTION OF EVER ANNOUNCING IT?",List.of());
  TranslationFlow.translate(List.of(question),(source,result)->{yes(source.toLowerCase(Locale.ROOT).contains("should i understand that"));result.done("Lalu ami untuk mengambilnya yang tidak kamu rencanakan untuk mengumumkannya?",null);},()->true,(values,failed)->{same(failed,0);same(values,List.of("Jadi, apakah aku harus menganggap bahwa kau sama sekali tidak berniat mengumumkannya?"));});
  var contextual=ProtectedTerms.prepare("Is he ready?",List.of());
  TranslationFlow.translate(List.of(contextual),List.of("The captain is waiting."),List.of("Yes, send him in."),(source,result)->{
   same(source,"The captain is waiting.\n\nIs he ready?\n\nYes, send him in.");
   result.done("Kapten sedang menunggu.\n\nApa dia sudah siap?\n\nYa, suruh dia masuk.",null);
  },()->true,(values,failed)->{same(values,List.of("Apa dia sudah siap?"));same(failed,0);});
  List<ProtectedTerms.Plan> windowPlans=new ArrayList<>();for(String line:List.of("One","Two","Three","Four"))windowPlans.add(ProtectedTerms.prepare(line,List.of()));
  TranslationFlow.translate(windowPlans,(source,result)->{
   String[] lines=source.split("\n\n");yes(lines.length>=2);
   if(lines.length==4)result.done("Merged",null);
   else result.done(source.replace("One","Satu").replace("Two","Dua").replace("Three","Tiga").replace("Four","Empat"),null);
  },()->true,(values,failed)->{same(values,List.of("Satu","Dua","Tiga","Empat"));same(failed,0);});
  var titled=ProtectedTerms.prepare("Are you thrilled, Mr. Falling?",List.of());
  yes(titled.masked.contains("ZXQNAME0QXZ"));same(titled.restore("Senangkah kamu, Tuan ZXQNAME0QXZ?"),"Senangkah kamu, Tuan Falling?");
  for(String name:List.of("White","Rose","Falling"))yes(ProtectedTerms.discover(List.of("Hello, Mr. "+name+"!")).contains(name));
  yes(ProtectedTerms.discover(List.of("Mr. President, welcome.")).isEmpty());
  yes(ReadingText.publisherNotice("READ THIS SERIES AT KAYNSCAN.COM TO SUPPORT US!"));
  yes(ReadingText.publisherNotice("EXAMPLE.NET"));
  yes(!ReadingText.publisherNotice("Can you support us in this battle?"));
  yes(!ReadingText.publisherNotice("Visit example.com to find my letter."));
  var garbled=ProtectedTerms.prepare("DON'T JUST STAND THERE SULKING",List.of());
  AtomicInteger qualityRetries=new AtomicInteger();TranslationFlow.translate(List.of(garbled),(source,result)->{
   if(qualityRetries.incrementAndGet()==1)result.done("Bani dont hanya $ tand di sana meregangkan",null);
   else result.done("Ban, jangan hanya berdiri di sana sambil merajuk",null);
  },()->true,(values,failed)->{same(failed,0);same(values,List.of("Ban, jangan hanya berdiri di sana sambil merajuk"));});same(qualityRetries.get(),2);
  var brokenWord=ProtectedTerms.prepare("TAKE A LOOK AT THAT MAJESTRCSTCUT",List.of());
  class InvalidCache implements NameTranslation.Engine {
   int calls=0;
   public boolean reusesTranslations(){return true;}
   public String cached(String key){return "Lihatlah MajestrcStcut itu!!";}
   public void translate(String source,NameTranslation.Result done){calls++;done.done("Lihatlah pemandangan megah itu!",null);}
  }
  var invalidCache=new InvalidCache();
  TranslationFlow.translate(List.of(brokenWord),invalidCache,()->true,(values,failed)->{same(failed,0);same(values,List.of("Lihatlah pemandangan megah itu!"));});same(invalidCache.calls,1);
  AtomicInteger alwaysBad=new AtomicInteger();TranslationFlow.translate(List.of(brokenWord),(source,result)->{alwaysBad.incrementAndGet();result.done("Lihatlah MajestrcStcut itu!!",null);},()->true,(values,failed)->{same(failed,1);same(values,List.of(""));});same(alwaysBad.get(),2);
  System.out.println("Translation flow passed: complete groups, contractions, punctuation/paragraphs, marker ownership, merged-batch retry, cancellation and partial errors.");
 }
}
