#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
reader_test_classes="$(mktemp -d)"
trap 'rm -rf -- "$reader_test_classes"' EXIT
javac -d "$reader_test_classes" app/src/main/java/com/komiklingo/app/ReadingText.java app/src/main/java/com/komiklingo/app/ContextMeaning.java app/src/main/java/com/komiklingo/app/DialogueMeaning.java app/src/main/java/com/komiklingo/app/ConversationMeaning.java tests/ConversationMeaningTest.java tests/DialogueMeaningTest.java app/src/main/java/com/komiklingo/app/PhrasalVerbs.java app/src/main/java/com/komiklingo/app/ReadingLink.java app/src/main/java/com/komiklingo/app/ProtectedTerms.java app/src/main/java/com/komiklingo/app/NameTranslation.java app/src/main/java/com/komiklingo/app/TranslationFlow.java tests/ReaderRulesTest.java tests/NameRulesTest.java app/src/main/java/com/komiklingo/app/OcrQuality.java tests/TranslationFlowTest.java tests/OcrQualityTest.java app/src/main/java/com/komiklingo/app/LiveDialogueGate.java tests/LiveDialogueGateTest.java tests/ContextMeaningTest.java tests/PhrasalVerbsTest.java app/src/main/java/com/komiklingo/app/BrowserRules.java tests/BrowserRulesTest.java
java -cp "$reader_test_classes" ReaderRulesTest
java -cp "$reader_test_classes" NameRulesTest

java -cp "$reader_test_classes" TranslationFlowTest

java -cp "$reader_test_classes" OcrQualityTest

java -cp "$reader_test_classes" ContextMeaningTest
java -cp "$reader_test_classes" PhrasalVerbsTest

java -cp "$reader_test_classes" BrowserRulesTest

java -cp "$reader_test_classes" DialogueMeaningTest

java -cp "$reader_test_classes" ConversationMeaningTest

java -cp "$reader_test_classes" LiveDialogueGateTest
