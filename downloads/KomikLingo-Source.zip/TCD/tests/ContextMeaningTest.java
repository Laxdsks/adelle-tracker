import com.komiklingo.app.*;
import java.util.*;
public class ContextMeaningTest {
 static void same(Object actual,Object expected){if(!Objects.equals(actual,expected))throw new AssertionError(actual+" != "+expected);}static void yes(boolean value){if(!value)throw new AssertionError();}
 public static void main(String[] args){
  same(ReadingText.translationInput("ARE A BRAND OF FATE, AND A CURSE FROM GOD."),"ARE A mark of destiny, AND A CURSE FROM GOD.");
  same(ContextMeaning.polish("ARE A BRAND OF FATE, AND A CURSE FROM GOD.","ADALAH A MEREK NASIB, DAN KUTUKAN DARI TUHAN."),"ADALAH tanda takdir, DAN KUTUKAN DARI TUHAN.");
  same(ContextMeaning.polish("BRANDS OF FATE", "MEREK-MEREK NASIB"),"tanda-tanda takdir");
  same(ContextMeaning.polish("This is a brand of shoes.","Ini adalah merek sepatu."),"Ini adalah merek sepatu.");same(ContextMeaning.normalize("A perfume product, a brand of Fate."),"A perfume product, a brand of Fate.");
  same(ContextMeaning.polish("It is a brand of shame.","Itu adalah merek rasa malu."),"Itu adalah cap aib.");same(ContextMeaning.normalize("His brand is famous."),"His brand is famous.");
  same(ContextMeaning.polish("THIS IS A BOOK.","INI ADALAH A BUKU."),"INI ADALAH BUKU.");same(ContextMeaning.polish("He is A from the village.","Dia adalah A dari desa."),"Dia adalah A dari desa.");
  var character=ProtectedTerms.prepare("He is A from the village.",List.of("A"));same(character.restore(ContextMeaning.polish(character.masked,character.masked)),"He is A from the village.");
  var named=ProtectedTerms.prepare("It is a Brand of Fate.",List.of("Brand of Fate"));same(ContextMeaning.normalize(named.masked),named.masked);same(named.restore(ContextMeaning.polish(named.masked,named.masked)),"It is a Brand of Fate.");
  yes(ContextMeaning.continues("ARE A","BRAND OF FATE."));yes(ContextMeaning.continues("THIS IS THE","PROMISE I MADE."));yes(ContextMeaning.continues("A MARK OF FATE,","AND A CURSE FROM GOD."));yes(ContextMeaning.continues("AND A CURSE","FROM GOD."));yes(!ContextMeaning.continues("WAIT HERE.","FOR ME IT IS DIFFERENT."));yes(!ContextMeaning.continues("I AM READY!","ARE YOU READY?"));yes(!ContextMeaning.dangling("A CURSE FROM GOD."));yes(ContextMeaning.dangling("I COULD NOT LIVE WITH"));
  var plan=ProtectedTerms.prepare("ARE A BRAND OF FATE, AND A CURSE FROM GOD.",List.of());TranslationFlow.translate(List.of(plan),(source,result)->{yes(source.contains("mark of destiny"));result.done("ADALAH A MEREK NASIB, DAN KUTUKAN DARI TUHAN.",null);},()->true,(values,failed)->{same(failed,0);same(values.get(0),"ADALAH tanda takdir, DAN KUTUKAN DARI TUHAN.");});
  same(ReadingText.translationInput("I COULDN'T... SENSE HER PRESENCE AT ALL!"),"I COULD NOT SENSE HER PRESENCE AT ALL!");
  same(ReadingText.translationInput("I CAN'T... FEEL ANYTHING!"),"I CANNOT FEEL ANYTHING!");same(ReadingText.translationInput("I WON'T... GIVE UP!"),"I WILL NOT GIVE UP!");
  yes(ContextMeaning.continues("I COULDN'T...","SENSE HER PRESENCE AT ALL!"));yes(ContextMeaning.continues("He didn't…","HEAR A THING."));yes(!ContextMeaning.continues("I couldn't...","WHY NOT?"));
  same(ContextMeaning.polish("I COULDN'T... SENSE HER PRESENCE AT ALL!","AKU TIDAK BISA.. SEDIHNYA KEHADIRANNYA SAMA SEKALI!"),"AKU TIDAK BISA.. merasakan KEHADIRANNYA SAMA SEKALI!");
  same(ContextMeaning.polish("Sadly, her presence was missed.","Sedihnya kehadirannya dirindukan."),"Sedihnya kehadirannya dirindukan.");
  same(ContextMeaning.polish("I sense her presence, and sadly her presence makes him cry.","Aku merasakan kehadirannya, sedihnya kehadirannya membuat dia menangis."),"Aku merasakan kehadirannya, sedihnya kehadirannya membuat dia menangis.");
  var namedSense=ProtectedTerms.prepare("Sense her presence",List.of("Sense"));same(ContextMeaning.polish(namedSense.masked,"sedihnya kehadirannya"),"sedihnya kehadirannya");
  var sensePlan=ProtectedTerms.prepare("I COULDN'T... SENSE HER PRESENCE AT ALL!",List.of());TranslationFlow.translate(List.of(sensePlan),(source,result)->{same(source,"I COULD NOT SENSE HER PRESENCE AT ALL!");result.done("AKU TIDAK BISA.. SEDIHNYA KEHADIRANNYA SAMA SEKALI!",null);},()->true,(values,failed)->{same(failed,0);same(values.get(0),"AKU TIDAK BISA.. merasakan KEHADIRANNYA SAMA SEKALI!");});
  same(ReadingText.translationInput("AS I THOUGHT... SHE'S A POWERHOUSE ON THE LEVEL OF ACRATOS."),"AS I THOUGHT... SHE'S A very powerful person ON THE LEVEL OF ACRATOS.");
  same(ContextMeaning.polish("SHE'S A POWERHOUSE ON THE LEVEL OF ACRATOS.","DIA ADALAH PEMBANGKIT TENAGA LISTRIK PADA TINGKAT ACRATOS."),"DIA ADALAH orang yang sangat kuat PADA TINGKAT ACRATOS.");
  same(ContextMeaning.normalize("They are powerhouses."),"They are very powerful people.");
  same(ContextMeaning.normalize("The powerhouse supplies electricity."),"The powerhouse supplies electricity.");
  same(ContextMeaning.polish("She is a powerhouse that generates electricity.","Dia pembangkit listrik."),"Dia pembangkit listrik.");
  same(ContextMeaning.normalize("It is a powerhouse."),"It is a powerhouse.");
  var namedPower=ProtectedTerms.prepare("She is a Powerhouse.",List.of("Powerhouse"));same(ContextMeaning.normalize(namedPower.masked),namedPower.masked);
  var namedFighter=ProtectedTerms.prepare("SHE'S A POWERHOUSE ON THE LEVEL OF ACRATOS.",List.of("Acratos"));TranslationFlow.translate(List.of(namedFighter),(source,result)->{yes(source.contains("very powerful person"));yes(!source.contains("ACRATOS"));result.done(source,null);},()->true,(values,failed)->{same(failed,0);yes(namedFighter.restore(values.get(0)).contains("Acratos"));});
  yes(ContextMeaning.continues("SHE'S A POWERHOUSE","ON THE LEVEL OF ACRATOS."));yes(!ContextMeaning.continues("SHE'S A POWERHOUSE.","ON THE LEVEL OF ACRATOS."));
  yes(ReadingLink.sharedAsUrl("https://example.com/page"));yes(ReadingLink.sharedAsUrl("example.com/path"));yes(!ReadingLink.sharedAsUrl("I will keep my promise."));yes(!ReadingLink.sharedAsUrl("javascript:alert(1)"));
  System.out.println("Context meaning passed: incomplete syntax, limited mark/brand senses, business exceptions and protected names; no full-panel replacement.");
 }
}
