# Data yang digunakan

OCR dan mode terjemahan dasar bekerja di perangkat. Unduhan model bahasa menggunakan layanan ML Kit/Google dan jaringan; situs yang dibuka menerima permintaan normal WebView serta cookie situs. Aplikasi tidak menambahkan analytics atau iklan sendiri. SDK ML Kit dapat mengirim data diagnostik/penggunaan sesuai ketentuan Google, terpisah dari pemrosesan OCR lokal.

Mode AI hanya saat alamat server diisi. Teks OCR bagian layar dikirim ke alamat itu, bersama ID dokumen acak; gambar dan cookie situs tidak ikut dikirim. Server contoh menyimpan konteks sementara di RAM dan mengirimnya ke Ollama lokal. Jangan memasukkan server yang tidak dipercaya. Token akses server tersimpan dalam ruang privat aplikasi dan cadangan Android dinonaktifkan. HTTPS wajib, kecuali localhost lewat USB. Kunci penyedia AI tidak dibutuhkan.

Izin jaringan: internet dan pemeriksaan koneksi. Ada izin penerima internal yang hanya boleh dipakai aplikasi sendiri. File dipilih sendiri melalui pemilih Android; aplikasi tidak meminta akses seluruh penyimpanan, kamera, mikrofon atau aksesibilitas. Gambar/file asli tidak diubah. APK pengembangan ini belum diaudit keamanannya dan belum dirilis di Play Store.

Cookie/cache situs dan pengaturan lokal dapat dihapus melalui Pengaturan Android → Aplikasi → KomikLingo → Penyimpanan → Hapus data.
