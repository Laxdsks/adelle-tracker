# Komponen

- Android SDK dan Android Gradle Plugin: ketentuan Android SDK dan lisensi komponen masing-masing.
- Google ML Kit Text Recognition dan Translation, Play Services dependensi: https://developers.google.com/ml-kit/terms . Tidak ada API berbayar yang diaktifkan oleh proyek ini; ketentuan produk tetap berlaku. Model terjemahan diunduh pada perangkat, OCR Latin dibundel dalam dependensi APK.
- Gradle wrapper: Apache License 2.0, https://gradle.org/ . Distribusi diverifikasi dengan checksum resmi.
- Server contoh: Python standard library. Ollama (MIT) dan Qwen2.5 7B (Apache 2.0) dipasang sendiri, bobot/model tidak masuk arsip aplikasi.
- Konten komik dan situs tetap milik pemegang hak masing-masing. Aplikasi pembaca tidak menyertakan atau menerbitkan salinan bab komik.
