# Pemeriksaan versi awal 0.1.0

- Android Gradle assembleDebug: berhasil, paket com.komiklingo.app, minSDK26/targetSDK35, ARM64 dan ARMv7.
- Android lintDebug: lulus tanpa error; peringatan JavaScript diperlukan situs dan string Indonesia hardcoded sudah ditinjau.
- APK signature v2: valid. Debug certificate SHA256 bb1ef448fb34777d2d03a49e7bfdb2bfb355ba7d57fe7b6a11f410d020e346a1. Keystore privat tetap di toolchain, tidak masuk Source ZIP.
- Tes integrasi server: lulus. Backend model tiruan; memeriksa 401, input terlalu besar, urutan/jumlah hasil, konteks antarpermintaan dan pemisahan dokumen.
- Tautan contoh Kayn Scans: HTTP200 dan judul bab ditemukan. Bukan uji Android WebView atau seluruh isi bab.
- Belum diuji: perangkat Android fisik, pemasangan/pengunduhan model, hasil OCR komik bergaya, letak overlay setelah scroll/zoom, kualitas/emosi keluaran model Ollama asli, performa/baterai dan kelancaran pada perangkat pengguna.

APK ini hasil build pengembangan; belum untuk rilis Play Store. Mode AI lokal belum dinyalakan pada perangkat pengguna. Nilai kualitas bahasa tidak dapat disimpulkan dari keberhasilan build atau tes server tiruan.
