#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
tcd_google_test="$(mktemp -d)"
trap 'rm -rf -- "$tcd_google_test"' EXIT
# Host JVM only; Android supplies org.json in the shipping app.
curl -fsSL --retry 2 -o "$tcd_google_test/json.jar" https://repo.maven.apache.org/maven2/org/json/json/20240303/json-20240303.jar
printf '%s  %s\n' 3cf6cd6892e32e2b4c1c39e0f52f5248a2f5b37646fdfbb79a66b46b618414ed "$tcd_google_test/json.jar" | sha256sum -c -
javac -cp "$tcd_google_test/json.jar" -d "$tcd_google_test" app/src/main/java/com/komiklingo/app/{ReadingText,ContextMeaning,DialogueMeaning,ConversationMeaning,PhrasalVerbs,ProtectedTerms,NameTranslation,TranslationFlow,OcrQuality,TranslationQuality,TranslationUnavailable,ContextBatch,GoogleTranslateHttp}.java tests/{GoogleTransportTest,GoogleOnlineTest}.java
java -cp "$tcd_google_test:$tcd_google_test/json.jar" GoogleTransportTest
if [[ "${1:-}" == '--live' ]]; then
 # For managed environments, use the inherited HTTPS proxy and system Java CA trust.
 tcd_java_network=()
 if [[ -n "${HTTPS_PROXY:-}" ]]; then
  read -r tcd_proxy_host tcd_proxy_port < <(python3 - <<'PY'
import os,urllib.parse
u=urllib.parse.urlparse(os.environ['HTTPS_PROXY']);print(u.hostname,u.port or 8080)
PY
)
  tcd_java_network=("-Dhttps.proxyHost=$tcd_proxy_host" "-Dhttps.proxyPort=$tcd_proxy_port")
  if [[ -f /etc/ssl/certs/java/cacerts ]]; then tcd_java_network+=("-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts"); fi
 fi
 java "${tcd_java_network[@]}" -cp "$tcd_google_test:$tcd_google_test/json.jar" GoogleOnlineTest
fi
