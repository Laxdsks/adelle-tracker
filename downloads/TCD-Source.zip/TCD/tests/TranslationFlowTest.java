import com.komiklingo.app.*;
import java.util.*;
import java.util.concurrent.atomic.*;
public class TranslationFlowTest {
 static void same(Object actual,Object expected){if(!Objects.equals(actual,expected))throw new AssertionError(actual+" != "+expected);}
 static void yes(boolean value){if(!value)throw new AssertionError("Expected true");}
 public static void main(String[] args){
  same(ReadingText.joinLines(List.of("SUD-","DENLY, I UNDER-","STAND.")),"SUDDENLY, I UNDERSTAND.");
  same(ReadingText.joinLines(List.of("I-","I DON'T KNOW!")),"I- I DON'T KNOW!");
  same(ReadingText.joinLines(List.of("Some-","Thing"),List.of("Some-Thing")),"Some-Thing");
  same(ReadingText.joinLines(List.of("Ban-","DIT")),"Ban- DIT");
  same(ReadingText.translationInput("P-DON'T MAKE ME LAUGH!"),"DO NOT MAKE ME LAUGH!");
  same(ReadingText.emotion("D-DON'T MAKE ME LAUGH!","Jangan membuatku tertawa!"),"J-Jangan membuatku tertawa!");
  same(ReadingText.emotion("B-Ban!","Ban!"),"B-Ban!");same(ReadingText.emotion("I-I will go.","A-aku pergi."),"A-aku pergi.");
  same(ReadingText.translationInput("X-Ray technology"),"X-Ray technology");
  same(ReadingText.translationInput("I WON'T leave. You're safe. I'd gone home. Ban's sword."),"I WILL NOT leave. You are safe. I'd gone home. Ban's sword.");
  same(ReadingText.translationInput("I can't! We’re ready; he's waiting."),"I cannot! We are ready; he's waiting.");
  same(ReadingText.paragraphs("Aku,kamu;dia!Tunggu?Apa 3,14"),"Aku, kamu; dia! Tunggu? Apa 3,14");
  same(ReadingText.paragraphs("  Apa ? !\n Kamu   di sini .\n\n\n  Aku datang !  "),"Apa?! Kamu di sini.\n\nAku datang!");
  same(ReadingText.style("You stay.","Anda tetap di sini .\n\nSaya menyusul !","dialogue"),"Kamu tetap di sini.\n\nAku menyusul!");
  List<ProtectedTerms.Plan> plans=new ArrayList<>();for(int i=0;i<9;i++)plans.add(ProtectedTerms.prepare("Ban, stay "+i+".",List.of("Ban"),i*1000));
  AtomicInteger calls=new AtomicInteger(),done=new AtomicInteger();
  TranslationFlow.translate(plans,(source,result)->{calls.incrementAndGet();result.done(source.replace("stay","tetap"),null);},()->true,(values,failed)->{done.incrementAndGet();same(values.size(),9);same(failed,0);for(int i=0;i<9;i++)same(plans.get(i).restore(values.get(i)),"Ban, tetap "+i+".");});
  same(calls.get(),2);same(done.get(),1);
  var first=ProtectedTerms.prepare("Ban, stay.",List.of("Ban"),0);var second=ProtectedTerms.prepare("Linda, wait.",List.of("Linda"),1000);
  AtomicInteger repairs=new AtomicInteger();
  TranslationFlow.translate(List.of(first,second),(source,result)->{repairs.incrementAndGet();if(source.contains("\n\n"))result.done(second.masked+"\n\n"+first.masked,null);else result.done(source,null);},()->true,(values,failed)->{same(failed,0);same(first.restore(values.get(0)),"Ban, stay.");same(second.restore(values.get(1)),"Linda, wait.");});same(repairs.get(),3);
  var plain=List.of(ProtectedTerms.prepare("One",List.of()),ProtectedTerms.prepare("Two",List.of()));
  AtomicInteger fallback=new AtomicInteger();TranslationFlow.translate(plain,(source,result)->{fallback.incrementAndGet();result.done(source.contains("\n\n")?"Merged dialogue":source.equals("One")?"Satu":"Dua",null);},()->true,(values,failed)->{same(values,List.of("Satu","Dua"));same(failed,0);});same(fallback.get(),3);
  AtomicInteger completed=new AtomicInteger();AtomicBoolean active=new AtomicBoolean(true);TranslationFlow.translate(plain,(source,result)->{active.set(false);result.done("Satu\n\nDua",null);},active::get,(values,failed)->completed.incrementAndGet());same(completed.get(),0);
  TranslationFlow.translate(plain,(source,result)->{if(source.equals("Two"))result.done("Dua",null);else result.done(null,new Exception("offline"));},()->true,(values,failed)->{same(values,List.of("","Dua"));same(failed,1);});
  List<String> engineInput=new ArrayList<>();TranslationFlow.translate(List.of(first,second),(source,result)->{engineInput.add(source);result.done(source.replaceAll("ZXQNAME[0-9]+QXZ","Larangan"),null);},()->true,(values,failed)->{same(failed,0);same(first.restore(values.get(0)),"Ban, stay.");same(second.restore(values.get(1)),"Linda, wait.");});for(String input:engineInput)yes(!input.contains("Ban")&&!input.contains("Linda"));
  System.out.println("Translation flow passed: complete groups, contractions, punctuation/paragraphs, marker ownership, merged-batch retry, cancellation and partial errors.");
 }
}
