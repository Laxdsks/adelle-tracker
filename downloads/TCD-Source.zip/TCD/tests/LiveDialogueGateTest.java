import com.komiklingo.app.LiveDialogueGate;
public class LiveDialogueGateTest {
 static void yes(boolean value){if(!value)throw new AssertionError();}
 public static void main(String[] args){
  var gate=new LiveDialogueGate();yes(!gate.observe("H"));yes(!gate.observe("He"));yes(!gate.observe("Hello"));yes(gate.observe("Hello"));yes(!gate.observe("Hello"));yes(!gate.changed("Hello"));yes(gate.changed("Next dialogue"));
  yes(!gate.observe("Next dialogue"));yes(gate.observe("Next  dialogue"));yes(!gate.observe("Next dialogue"));
  yes(!gate.observe(""));yes(!gate.observe("Next dialogue"));yes(gate.observe("Next dialogue"));
  gate.retry();yes(!gate.observe("Next dialogue"));yes(gate.observe("Next dialogue"));
  gate.reset();yes(!gate.observe("Next dialogue"));yes(gate.observe("Next dialogue"));
  yes(!gate.observe(null));yes(!gate.observe("   "));
  System.out.println("Live gate passed: typing stability, deduplication, changed dialogue, whitespace, empty screen, retry and session reset.");
 }
}
