import com.komiklingo.app.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
public class GoogleTransportTest {
 static void eq(Object a,Object b){if(!Objects.equals(a,b))throw new AssertionError(a+" != "+b);}
 static class Response extends HttpURLConnection {
  int status;String body,retry;
  Response(int status,String body)throws Exception{super(GoogleTranslateHttp.url("Don't stop! Next line?"));this.status=status;this.body=body;}
  public int getResponseCode(){return status;}public String getHeaderField(String key){return key.equals("Retry-After")?retry:null;}
  public InputStream getInputStream(){return new ByteArrayInputStream(body.getBytes(StandardCharsets.UTF_8));}
  public void connect(){}public void disconnect(){}public boolean usingProxy(){return false;}
 }
 public static void main(String[] args)throws Exception{
  var ok=new Response(200,"[[[\"Jangan berhenti! \",\"Don't stop! \"],[\"Baris berikutnya?\",\"Next line?\"]],null,\"en\"]");
  eq(GoogleTranslateHttp.read(ok),"Jangan berhenti! Baris berikutnya?");eq(ok.getConnectTimeout(),2500);eq(ok.getReadTimeout(),3500);eq(ok.getInstanceFollowRedirects(),false);eq(ok.getUseCaches(),false);
  eq(GoogleTranslateHttp.url("a & b\nDia? 漢").getHost(),"translate.googleapis.com");if(!GoogleTranslateHttp.url("a & b\nDia? 漢").getQuery().contains("a+%26+b%0ADia%3F+%E6%BC%A2"))throw new AssertionError("Query not encoded");
  for(String invalid:List.of("[]","{}","[[]]","[[[null,\"original\"]]]","[[[\"translated\"]]]","<html>not JSON</html>")){try{GoogleTranslateHttp.read(new Response(200,invalid));throw new AssertionError("Accepted malformed response");}catch(IOException expected){}}
  for(int status:List.of(302,401,403,429,500,503)){var response=new Response(status,"ignored");response.retry="600";try{GoogleTranslateHttp.read(response);throw new AssertionError("Status accepted");}catch(TranslationUnavailable expected){eq(expected.retryAfterMillis,600000L);}}
  eq(new TranslationUnavailable(429,Long.toString(Long.MAX_VALUE)).retryAfterMillis,Long.MAX_VALUE);
  String tomorrow=java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC).plusDays(1).format(java.time.format.DateTimeFormatter.RFC_1123_DATE_TIME);
  if(new TranslationUnavailable(429,tomorrow).retryAfterMillis<86000000)throw new AssertionError("HTTP date backoff ignored");
  try{GoogleTranslateHttp.read(new Response(200,"x".repeat(131073)));throw new AssertionError("Oversize accepted");}catch(IOException expected){}
  for(String input:List.of(""," ","x".repeat(4601))){try{GoogleTranslateHttp.url(input);throw new AssertionError("Bad source accepted");}catch(IOException expected){}}
  System.out.println("Google transport passed: URL encoding, multi-segment JSON, deadlines, redirect refusal, rate-limit backoff, malformed/empty/oversize responses. HTTP fixtures; no language quality claim.");
 }
}
