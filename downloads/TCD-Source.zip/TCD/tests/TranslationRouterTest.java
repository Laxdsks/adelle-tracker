import com.komiklingo.app.*;
import java.util.*;
import java.util.concurrent.atomic.*;
public class TranslationRouterTest {
 static void eq(Object a,Object b){if(!Objects.equals(a,b))throw new AssertionError(a+" != "+b);}
 public static void main(String[] args){
  AtomicBoolean online=new AtomicBoolean(true);AtomicLong clock=new AtomicLong(100000);AtomicInteger calls=new AtomicInteger(),fallbacks=new AtomicInteger();AtomicBoolean fail=new AtomicBoolean(false);
  TranslationRouter router=new TranslationRouter(online::get,(source,result)->{calls.incrementAndGet();if(fail.get())result.done(null,new Exception("timeout"));else result.done("G:"+source,null);},(source,result)->result.done("O:"+source,null),clock::get,fallbacks::incrementAndGet);
  var result=new AtomicReference<String>();NameTranslation.Result save=(value,error)->{eq(error,null);result.set(value);};
  router.translate("Hello",save);eq(result.get(),"G:Hello");router.translate("Hello",save);eq(calls.get(),1);
  online.set(false);router.translate("Hello",save);eq(result.get(),"O:Hello");eq(calls.get(),1);
  online.set(true);fail.set(true);router.translate("Next",save);eq(result.get(),"O:Next");eq(fallbacks.get(),1);
  router.translate("Again",save);eq(result.get(),"O:Again");eq(calls.get(),2);
  clock.addAndGet(30001);fail.set(false);router.translate("Next",save);eq(result.get(),"G:Next");eq(calls.get(),3);
  var callbacks=new ArrayList<NameTranslation.Result>();var completed=new AtomicInteger();
  var delayed=new TranslationRouter(()->true,(source,done)->callbacks.add(done),(source,done)->done.done("offline",null),clock::get,()->{});
  delayed.translate("First",(value,error)->completed.incrementAndGet());delayed.cancel();callbacks.remove(0).done("late",null);eq(completed.get(),0);
  delayed.translate("Second",(value,error)->completed.incrementAndGet());delayed.translate("Third",(value,error)->{eq(value,"new");completed.incrementAndGet();});callbacks.get(0).done("stale",null);callbacks.get(1).done("new",null);eq(completed.get(),1);
  AtomicInteger limitedCalls=new AtomicInteger();var limited=new TranslationRouter(()->true,(source,done)->{limitedCalls.incrementAndGet();done.done(null,new TranslationUnavailable(429,"600"));},(source,done)->done.done("offline",null),clock::get,()->{});
  limited.translate("A",save);clock.addAndGet(300001);limited.translate("B",save);eq(limitedCalls.get(),1);clock.addAndGet(300001);limited.translate("C",save);eq(limitedCalls.get(),2);
  AtomicInteger malformedCalls=new AtomicInteger();var malformed=new TranslationRouter(()->true,(source,done)->{malformedCalls.incrementAndGet();done.done("Nama hilang",null);},(source,done)->done.done("offline",null),clock::get,()->{});
  malformed.translate("ZXQNAME0QXZ is waiting.",save);malformed.translate("ZXQNAME0QXZ is waiting.",save);eq(malformedCalls.get(),2);
  System.out.println("Translation router passed: Google preference, cache, strict offline, timeout fallback, cooldown recovery and late-response cancellation.");
 }
}
