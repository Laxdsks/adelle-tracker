import com.komiklingo.app.*;
import java.util.*;
public class BrowserRulesTest {
 static void yes(boolean value){if(!value)throw new AssertionError();}
 static void same(Object a,Object b){if(!Objects.equals(a,b))throw new AssertionError(a+" != "+b);}
 public static void main(String[] args){
  yes(BrowserRules.blockResource("https://a.doubleclick.net/ad.js","https://reading.example/page"));
  yes(BrowserRules.tracker("https://ADS.DOUBLECLICK.NET./x"));yes(BrowserRules.tracker("https://popads.net/x"));
  yes(!BrowserRules.tracker("https://doubleclick.net.safe.example/x"));yes(!BrowserRules.tracker("https://notdoubleclick.net/x"));
  yes(!BrowserRules.blockResource("https://cdn.reading.example/panel.jpg","https://reading.example/page"));
  yes(!BrowserRules.blockResource("https://doubleclick.net/home","https://doubleclick.net/home"));
  same(BrowserRules.https("http://example.com/path?q=a#b"),"https://example.com/path?q=a#b");
  for(String invalid:List.of("javascript:alert(1)","file:///tmp/a","data:text/plain,hi","content://x","intent://x","https://user:pass@example.com/x","https://reader.invalid/a","https://example.com/ a")){
   boolean failed=false;try{BrowserRules.https(invalid);}catch(IllegalArgumentException expected){failed=true;}yes(failed);
  }
  class Cached implements NameTranslation.Engine {
   final Map<String,String> memory=new HashMap<>();int calls;
   public boolean reusesTranslations(){return true;}
   public String cached(String key){return memory.get(key);}
   public void remember(String key,String value){memory.put(key,value);}
   public void translate(String input,NameTranslation.Result result){calls++;result.done(input.replace("HELLO","HALO").replace("WORLD","DUNIA"),null);}
  }
  var engine=new Cached();var plans=List.of(ProtectedTerms.prepare("HELLO WORLD",List.of()),ProtectedTerms.prepare("SECOND WORLD",List.of()));
  TranslationFlow.translate(plans,engine,()->true,(values,failed)->{same(failed,0);same(values,List.of("HALO DUNIA","SECOND DUNIA"));});same(engine.calls,1);
  TranslationFlow.translate(plans,engine,()->true,(values,failed)->same(values,List.of("HALO DUNIA","SECOND DUNIA")));same(engine.calls,1);
  var changed=List.of(plans.get(0),ProtectedTerms.prepare("OTHER WORLD",List.of()));TranslationFlow.translate(changed,engine,()->true,(values,failed)->same(failed,0));yes(engine.calls>1); // changed neighbour must not reuse an old contextual result
  engine.memory.replaceAll((k,v)->"");int before=engine.calls;TranslationFlow.translate(plans,engine,()->true,(values,failed)->same(failed,0));yes(engine.calls>before);
  var named=List.of(ProtectedTerms.prepare("Ban, HELLO WORLD",List.of("Ban")));TranslationFlow.translate(named,engine,()->true,(values,failed)->{same(failed,0);same(named.get(0).restore(values.get(0)),"Ban, HALO DUNIA");});int done=engine.calls;TranslationFlow.translate(named,engine,()->true,(values,failed)->same(failed,0));same(engine.calls,done);
  engine.memory.clear();TranslationFlow.translate(named,engine,()->true,(values,failed)->same(failed,0));yes(engine.calls>done);
  System.out.println("Browser rules passed: strict HTTPS, host boundaries, image allowance, contextual translation reuse, invalid cached results, protected names and reset.");
 }
}
