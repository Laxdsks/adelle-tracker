import com.komiklingo.app.*;
import java.util.*;
import java.util.concurrent.atomic.*;
public class PhrasalVerbsTest {
 static void same(Object actual,Object expected){if(!Objects.equals(actual,expected))throw new AssertionError(actual+" != "+expected);}
 static void yes(boolean value){if(!value)throw new AssertionError();}
 public static void main(String[] args){
  String source="IT WAS A FAILURE. BY THE TIME I BURST IN–";
  same(ReadingText.translationInput(source),"IT WAS A FAILURE. BY THE TIME I entered abruptly–");
  same(PhrasalVerbs.normalize("He had not burst in."),"He had not entered abruptly.");
  same(PhrasalVerbs.normalize("She will burst into the room."),"She will enter abruptly into the room.");
  same(PhrasalVerbs.normalize("They were bursting in."),"They were entering abruptly.");
  same(PhrasalVerbs.normalize("You did not burst in."),"You did not enter abruptly.");
  same(PhrasalVerbs.normalize("He barged into our house."),"He entered without permission into our house.");
  same(PhrasalVerbs.normalize("I burst in every day."),"I burst in every day."); // ambiguous tense: unchanged
  same(PhrasalVerbs.normalize("I burst in."),"I burst in.");
  for(String literal:List.of("The bomb burst in the room.","She burst into tears.","He burst into flames.","They burst out laughing.","We burst in unison.","I burst in pain.","I burst in London.","I burst in on their meeting.","He burst in during the discussion."))same(PhrasalVerbs.normalize(literal),literal);
  same(ContextMeaning.polish(source,"Itu gagal. Pada saat aku meledak"),"Itu gagal. Pada saat aku menerobos masuk");
  same(PhrasalVerbs.polish("She will burst in.","Dia akan meledak!"),"Dia akan menerobos masuk!");
  same(PhrasalVerbs.polish("He had not burst in.","Dia belum meledak."),"Dia belum menerobos masuk.");
  same(PhrasalVerbs.polish("I burst in. The bomb exploded.","Aku masuk. Bom meledak."),"Aku masuk. Bom meledak.");
  same(PhrasalVerbs.polish("I burst in and I exploded.","Aku masuk dan aku meledak."),"Aku masuk dan aku meledak.");
  same(PhrasalVerbs.polish("I burst into tears.","Aku menangis."),"Aku menangis.");
  same(PhrasalVerbs.polish("The bomb burst in the room.","Bom meledak di kamar."),"Bom meledak di kamar.");
  var name=ProtectedTerms.prepare("It was too late. By the time Ban burst in-",List.of("Ban"));
  String normalized=ReadingText.translationInput(name.masked);yes(normalized.contains("entered abruptly"));yes(!normalized.contains("Ban"));same(name.restore(normalized),"It was too late. By the time Ban entered abruptly-");
  same(PhrasalVerbs.normalize("By the time I burst in tomorrow, it will be too late."),"By the time I burst in tomorrow, it will be too late.");
  var literalName=ProtectedTerms.prepare("By the time I Burst In-",List.of("Burst In"));same(PhrasalVerbs.normalize(literalName.masked),literalName.masked);
  yes(PhrasalVerbs.continues("BY THE TIME I BURST","IN-"));yes(PhrasalVerbs.continues("SHE WILL BURST","INTO THE ROOM."));
  yes(!PhrasalVerbs.continues("THE BOMB BURST","IN THE ROOM."));yes(!PhrasalVerbs.continues("SHE BURST","INTO TEARS."));
  yes(PhrasalVerbs.temporalEntry("BY THE TIME I BURST IN-"));yes(!PhrasalVerbs.temporalEntry("SHE BURST INTO TEARS."));yes(!PhrasalVerbs.temporalEntry("I AM READY."));
  same(PhrasalVerbs.withNextClause("By the time I entered abruptly-", "IT HAD ALL ALREADY VANISHED."),"By the time I entered abruptly,");
  same(PhrasalVerbs.withNextClause("I-I cannot-", "WHAT DID YOU SAY?"),"I-I cannot-");
  same(PhrasalVerbs.withNextClause("When I arrived-", "SOMEWHERE ELSE."),"When I arrived-");
  same(PhrasalVerbs.withNextClause("When I w-", "HE HAD A SWORD."),"When I w-");
  same(PhrasalVerbs.withNextClause("By the time I had not entered abruptly-", "IT HAD VANISHED."),"By the time I had not entered abruptly,");
  var left=ProtectedTerms.prepare(source,List.of());var right=ProtectedTerms.prepare("IT HAD ALL ALREADY VANISHED.",List.of());var done=new AtomicInteger();
  TranslationFlow.translate(List.of(left,right),(input,result)->{same(input,"IT WAS A FAILURE. BY THE TIME I entered abruptly,\n\nIT HAD ALL ALREADY VANISHED.");result.done("Itu gagal. Saat aku meledak,\n\nSemuanya sudah lenyap.",null);},()->true,(values,failed)->{same(failed,0);same(values,List.of("Itu gagal. Saat aku menerobos masuk,","Semuanya sudah lenyap."));done.incrementAndGet();});same(done.get(),1);
  var fallbackCalls=new AtomicInteger();TranslationFlow.translate(List.of(left,right),(input,result)->{fallbackCalls.incrementAndGet();if(input.contains("\n\n"))result.done("Unsplit",null);else{if(input.startsWith("IT WAS")){yes(input.endsWith(","));result.done("Itu gagal. Saat aku meledak,",null);}else result.done("Semuanya sudah lenyap.",null);}},()->true,(values,failed)->{same(failed,0);same(values.get(0),"Itu gagal. Saat aku menerobos masuk,");});same(fallbackCalls.get(),4);
  var unrelated=ProtectedTerms.prepare("WHO KNOWS?",List.of());TranslationFlow.translate(List.of(left,right,left,unrelated),(input,result)->{var parts=input.split("\n\n");yes(parts[0].endsWith(","));yes(parts[2].endsWith("–"));result.done(input,null);},()->true,(values,failed)->same(failed,0));
  same(ReadingText.translationInput("AAAH! MY HEADACHE IS FLARING UP AGAIN!"),"AAAH! MY HEADACHE IS getting worse AGAIN!");
  same(PhrasalVerbs.normalize("The flames are flaring up."),"The flames are flaring up.");
  var medicalName=ProtectedTerms.prepare("MY HEADACHE IS FLARING UP",List.of("Flaring Up"));same(PhrasalVerbs.normalize(medicalName.masked),medicalName.masked);
  System.out.println("Phrasal verbs passed: entry actors/particles, tense guards, literal/emotional exclusions, protected names, temporal continuation and batch fallback.");
 }
}
