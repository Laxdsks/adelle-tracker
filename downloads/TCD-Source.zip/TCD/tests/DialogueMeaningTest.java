import com.komiklingo.app.*;
import java.util.*;
import java.util.concurrent.atomic.*;

public class DialogueMeaningTest {
 static void same(Object actual,Object expected){if(!Objects.equals(actual,expected))throw new AssertionError(actual+" != "+expected);}
 static void yes(boolean value){if(!value)throw new AssertionError("Expected true");}
 static final String FIRST="THEY PLAN TO TRANSPORT THEM TO THE BAHAIN KINGDOM AS SOON AS THE COLLECTION OF THE BODIES IS FINISHED-";
 static final String NEXT="SO THAT THEIR FUNERALS CAN BE HELD IN THEIR HOMELAND.";
 static final String BAD="MEREKA BERENCANA UNTUK MENGANGKUTNYA KE ZXQNAME0QXZ KERAJAAN SEGERA SETELAH KOLEKSI TUBUH SELESAI-";
 public static void main(String[] args)throws Exception{
  var top=ProtectedTerms.prepare(FIRST,List.of("Bahain"));var bottom=ProtectedTerms.prepare(NEXT,List.of(),1);
  yes(DialogueMeaning.normalize(top.masked,NEXT).contains("gathering of the dead bodies"));
  same(top.restore(DialogueMeaning.polish(top.masked,NEXT,BAD)),"MEREKA BERENCANA UNTUK MENGANGKUTNYA KE KERAJAAN Bahain SEGERA SETELAH pengumpulan jenazah SELESAI-");
  same(DialogueMeaning.polish("The collection of bodies is finished so that their funerals can be held.","","Pengoleksian badan selesai."),"pengumpulan jenazah selesai.");
  same(DialogueMeaning.polish("Their bodies have been recovered for burial.","","Tubuh-tubuhnya telah ditemukan."),"jenazahnya telah ditemukan.");
  same(DialogueMeaning.polish("The dead bodies are ready for burial.","","Badan orang yang meninggal siap dimakamkan."),"jenazah siap dimakamkan.");
  same(DialogueMeaning.polish("They are retrieving bodies for burial.","","Tubuhnya sedang dikumpulkan."),"jenazahnya sedang dikumpulkan.");
  same(DialogueMeaning.normalize("The collection of the bodies is finished for the car exhibition before the funeral.",NEXT),"The collection of the bodies is finished for the car exhibition before the funeral.");
  same(DialogueMeaning.polish("The collection of the bodies is finished. My body hurts before the funeral.",NEXT,"Koleksi tubuh selesai. Tubuhku sakit."),"Koleksi tubuh selesai. Tubuhku sakit.");
  // A funeral elsewhere is insufficient; ambiguous, living and non-human senses stay unchanged.
  for(String source:List.of("The collection of bodies is finished.","The body of evidence is complete.","The collection of celestial bodies is finished for burial.","The collection of car bodies is finished for funerals.","They gathered injured bodies for the funeral.","He exercises his body before the funeral.","They collected bodies of water near the funeral.","My body is alive after the funeral.")){
   same(DialogueMeaning.normalize(source,"They discussed a funeral."),source);same(DialogueMeaning.polish(source,"They discussed a funeral.","Koleksi tubuh selesai."),"Koleksi tubuh selesai.");
  }
  same(DialogueMeaning.normalize("The collection of bodies is finished-","So that we can study astronomy."),"The collection of bodies is finished-");
  var protectedBody=ProtectedTerms.prepare("The collection of Bodies is finished-",List.of("Bodies"));same(DialogueMeaning.normalize(protectedBody.masked,NEXT),protectedBody.masked);
  // Both joined and separate paragraphs, batch retry and name-fragment retry use the same rules.
  AtomicInteger calls=new AtomicInteger();TranslationFlow.translate(List.of(top,bottom),(input,result)->{calls.incrementAndGet();yes(input.contains("gathering of the dead bodies"));result.done(BAD+"\n\nAgar pemakaman mereka dapat diadakan di tanah air mereka.",null);},()->true,(values,failed)->{same(failed,0);yes(top.restore(values.get(0)).contains("KERAJAAN Bahain"));yes(values.get(0).contains("pengumpulan jenazah"));same(values.size(),2);});same(calls.get(),1);
  AtomicInteger retries=new AtomicInteger();TranslationFlow.translate(List.of(top,bottom),(input,result)->{retries.incrementAndGet();if(input.contains("\n\n"))result.done("Merged",null);else if(input.contains("COLLECTION")||input.contains("gathering")){yes(input.contains("gathering of the dead bodies"));result.done(BAD,null);}else result.done("Agar mereka dimakamkan di tanah air mereka.",null);},()->true,(values,failed)->{same(failed,0);yes(values.get(0).contains("pengumpulan jenazah"));});same(retries.get(),4);
  TranslationFlow.translate(List.of(top),List.of(NEXT),(input,result)->result.done(BAD,null),()->true,(values,failed)->{same(failed,0);yes(values.get(0).contains("pengumpulan jenazah"));});
  var whole=ProtectedTerms.prepare(FIRST+" "+NEXT,List.of("Bahain"));TranslationFlow.translate(List.of(whole),(input,result)->{yes(input.contains("dead bodies"));result.done(BAD+" Agar mereka dimakamkan.",null);},()->true,(values,failed)->{same(failed,0);yes(values.get(0).contains("pengumpulan jenazah"));});
  TranslationFlow.translate(List.of(top,bottom),(input,result)->{if(input.contains("ZXQNAME"))result.done(input.replace("ZXQNAME0QXZ","Bad"),null);else result.done(input.replace("gathering of the dead bodies","pengumpulan jenazah"),null);},()->true,(values,failed)->{same(failed,0);yes(top.restore(values.get(0)).contains("Bahain"));yes(values.get(0).contains("pengumpulan jenazah"));});
  // Cache keys include separately supplied following context, including Reset of one paragraph.
  class Cached implements NameTranslation.Engine{int count=0;Map<String,String> values=new HashMap<>();public void translate(String input,NameTranslation.Result result){count++;result.done(input.contains("dead bodies")?BAD:BAD.replace("KOLEKSI TUBUH","tubuh"),null);}public boolean reusesTranslations(){return true;}public String cached(String key){return values.get(key);}public void remember(String key,String value){values.put(key,value);}}
  var engine=new Cached();TranslationFlow.translate(List.of(top),List.of(NEXT),engine,()->true,(v,f)->yes(v.get(0).contains("pengumpulan jenazah")));TranslationFlow.translate(List.of(top),List.of(NEXT),engine,()->true,(v,f)->yes(v.get(0).contains("pengumpulan jenazah")));same(engine.count,3);TranslationFlow.translate(List.of(top),List.of(""),engine,()->true,(v,f)->yes(!v.get(0).contains("jenazah")));same(engine.count,4);
  for(String[] pair:new String[][]{{"kingdom","kerajaan"},{"empire","kekaisaran"},{"city","kota"},{"village","desa"}}){var place=ProtectedTerms.prepare("We are going to the Bahain "+pair[0]+".",List.of("Bahain"));same(place.restore(DialogueMeaning.polish(place.masked,"","Ke ZXQNAME0QXZ "+pair[1]+".")),"Ke "+pair[1]+" Bahain.");same(place.restore(DialogueMeaning.polish(place.masked,"","Ke "+pair[1]+" ZXQNAME0QXZ.")),"Ke "+pair[1]+" Bahain.");}
  var wholeTitle=ProtectedTerms.prepare("Read Bahain Kingdom.",List.of("Bahain Kingdom"));same(DialogueMeaning.polish(wholeTitle.masked,"","ZXQNAME0QXZ kerajaan"),"ZXQNAME0QXZ kerajaan");
  OcrQuality.load(java.nio.file.Files.newInputStream(java.nio.file.Path.of("app/src/main/assets/english-ocr-words.txt")));same(ProtectedTerms.discover(List.of(FIRST)),List.of("BAHAIN"));
  System.out.println("Dialogue meaning passed: funeral purpose across paragraphs, conservative body senses, place-name order, joined/batch/fallback/single-reset paths, name protection and contextual cache invalidation.");
 }
}
