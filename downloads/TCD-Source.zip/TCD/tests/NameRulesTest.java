import com.komiklingo.app.*;
import java.util.*;
public class NameRulesTest {
 static void same(Object actual,Object expected){if(!Objects.equals(actual,expected))throw new AssertionError(actual+" != "+expected);}
 static void yes(boolean value){if(!value)throw new AssertionError("Expected true");}
 public static void main(String[] args)throws Exception{
  same(ProtectedTerms.defaults(ReadingLink.storyKey("https://kaynscans.com/series/comic/chronicle-of-runes/chapter/48")),List.of("Ban","Chronicle of Runes"));
  same(ProtectedTerms.defaults("other.example/book"),List.of());
  var terms=ProtectedTerms.parse("Ban\nban\nMoon Blade\nMoon\nEldoria\nSaya\nAnda\nO’Neil");
  same(terms.size(),7);
  var plan=ProtectedTerms.prepare("BAN, take the Moon Blade to Eldoria. Ban!",terms);
  yes(!plan.masked.contains("BAN"));same(plan.names().size(),4);
  same(plan.restore(plan.masked),"Ban, take the Moon Blade to Eldoria. Ban!");
  yes(plan.valid(plan.masked.toLowerCase(Locale.ROOT)));yes(!plan.valid(plan.masked.replace("ZXQNAME0QXZ","Larangan")));
  yes(!plan.valid(plan.masked+" ZXQNAME0QXZ"));yes(!plan.valid(plan.masked+" ZXQNAME999QXZ"));
  same(ProtectedTerms.prepare("urban banana BANNED banner ban",List.of("Ban")).restore(ProtectedTerms.prepare("urban banana BANNED banner ban",List.of("Ban")).masked),"urban banana BANNED banner Ban");
  same(ProtectedTerms.prepare("They ban weapons.",List.of()).masked,"They ban weapons.");
  var pronouns=ProtectedTerms.prepare("Saya, tell Anda.",terms);
  same(pronouns.restore(ReadingText.style(pronouns.source,pronouns.masked+" Saya melindungi Anda.","dialogue")),"Saya, tell Anda. Aku melindungi kamu.");
  same(ProtectedTerms.cleanOcr("FEVERYONE, AFTERI WENT.\nSuddenlyy!",List.of("FEVERYONE")),"FEVERYONE, AFTER I WENT. Suddenly!");
  same(ProtectedTerms.discover(List.of("BAN, IF ONE DAY... YOU WERE LEFT ALONE", "MY NAME IS LUNA AND THIS IS MY SWORD", "the sword is named Moon Blade.", "the city is called Eldoria.","HEY AKIRA!", "Thank you, Iris.")),List.of("BAN","LUNA","Moon Blade","Eldoria","AKIRA","Iris"));
  same(ProtectedTerms.cleanOcr("The Moon\nBlade is here.",List.of("Moon Blade")),"The Moon Blade is here.");
  same(ProtectedTerms.discover(List.of("YES, YOU CAN!","WAIT, WHERE ARE YOU?","CALL ME LATER.","I HAVE A REASON TO EXIST.","THEY BAN WEAPONS.")),List.of());
  List<String> inputs=new ArrayList<>();var fallback=ProtectedTerms.prepare("Ban, if one day you were alone in Eldoria?",terms);
  NameTranslation.Engine faulty=(source,result)->{inputs.add(source);result.done(source.replaceAll("ZXQNAME[0-9]+QXZ","Larangan"),null);};
  NameTranslation.translate(fallback,faulty,(value,error)->{same(error,null);same(fallback.restore(value),"Ban, if one day you were alone in Eldoria?");});
  yes(inputs.size()>1);for(String input:inputs)yes(!input.contains("Ban")&&!input.contains("Eldoria"));
  var collision=ProtectedTerms.prepare("ZXQNAME0QXZ said Ban",terms);yes(collision.valid(collision.masked));same(collision.restore(collision.masked),"ZXQNAME0QXZ said Ban");
  var unicode=ProtectedTerms.prepare("IRIS, help!",List.of("İris"));same(unicode.restore(unicode.masked),"İris, help!");
  var possessive=ProtectedTerms.prepare("Ban's blade and O’Neil",terms);same(possessive.restore(possessive.masked),"Ban's blade and O’Neil");
  NameTranslation.translate(fallback,(source,result)->result.done(null,new Exception("offline")),(value,error)->{yes(error!=null);same(value,null);});
  for(String bad:new String[]{"x".repeat(65),"Ban\n<unsafe>"}){try{ProtectedTerms.parse(bad);throw new AssertionError("accepted invalid term");}catch(IllegalArgumentException expected){}}
  same(ProtectedTerms.discover(List.of("My name is "+"A".repeat(26)+" "+"B".repeat(26)+" "+"C".repeat(26))),List.of());
  OcrQuality.load(java.nio.file.Files.newInputStream(java.nio.file.Path.of("app/src/main/assets/english-ocr-words.txt")));
  same(ProtectedTerms.discover(List.of("WE PLAN TO HEAD TO THE UHWANA KINGDOM IMMEDIATELY!","the northern kingdom","THE GREAT CITY")),List.of("UHWANA"));
  System.out.println("Name rules passed: confirmed story names, boundaries, multiword/repeated/Unicode terms, style/OCR protection, detection limits, invalid markers and fragment fallback.");
 }
}
