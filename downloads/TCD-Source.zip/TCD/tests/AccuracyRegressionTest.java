import com.komiklingo.app.*;
import java.util.*;
import java.util.concurrent.atomic.*;
public class AccuracyRegressionTest {
 static void eq(Object a,Object b){if(!Objects.equals(a,b))throw new AssertionError(a+" != "+b);}
 static void yes(boolean value){if(!value)throw new AssertionError("Expected true");}
 public static void main(String[] args)throws Exception{
  var batch=new ContextBatch(List.of("I'm sorry I'm late.","Not at all."));
  eq(batch.parse("ZXQUNIT0QXZ Maaf aku terlambat. ZXQUNIT1QXZ Tidak apa-apa."),List.of("Maaf aku terlambat.","Tidak apa-apa."));
  for(String malformed:List.of("Merged","ZXQUNIT1QXZ Balasan ZXQUNIT0QXZ Sumber","ZXQUNIT0QXZ A ZXQUNIT0QXZ B ZXQUNIT1QXZ C","ZXQUNIT0QXZ A","extra ZXQUNIT0QXZ A ZXQUNIT1QXZ B","ZXQUNIT0QXZ A ZXQUNIT1QXZ"))eq(batch.parse(malformed),null);
  var reply=ProtectedTerms.prepare("Not at all.",List.of());AtomicInteger requests=new AtomicInteger();
  TranslationFlow.translate(List.of(reply),List.of("Thank you for helping me."),List.of(""),(input,done)->{requests.incrementAndGet();if(input.startsWith("ZXQUNIT"))done.done("ZXQUNIT0QXZ Terima kasih sudah membantuku. ZXQUNIT1QXZ Sama-sama.",null);else done.done("Terima kasih sudah membantuku. Sama-sama.",null);},()->true,(values,failed)->{eq(values,List.of("Sama-sama."));eq(failed,0);});eq(requests.get(),2);
  var names=ProtectedTerms.prepare("Ban gave the map to Falling.",List.of("Ban","Falling"));List<String> queries=new ArrayList<>();
  NameTranslation.translate(names,(input,done)->{queries.add(input);if(input.contains("\"ZXQNAME"))done.done("\"ZXQNAME0QXZ\" memberikan peta kepada \"ZXQNAME1QXZ\".",null);else done.done("Larangan memberikan peta kepada jatuh.",null);},(value,error)->{eq(error,null);eq(names.restore(value),"Ban memberikan peta kepada Falling.");});eq(queries.size(),2);yes(queries.get(1).contains("gave the map to"));
  yes(TranslationQuality.suspicious("Take 3 tablets.","Ambil 2 tablet."));yes(!TranslationQuality.suspicious("Take 3 tablets.","Ambil tiga tablet."));
  yes(!TranslationQuality.suspicious("The 7th order has 250 soldiers.","Ordo ketujuh memiliki dua ratus lima puluh prajurit."));
  yes(!TranslationQuality.suspicious("ZXQNAME123QXZ is here.","ZXQNAME123QXZ ada di sini."));
  yes(!TranslationQuality.suspicious("It costs 1500000 coins.","Harganya satu juta lima ratus ribu koin."));
  yes(!TranslationQuality.suspicious("Wait for 1.5 hours.","Tunggu satu setengah jam."));
  yes(TranslationQuality.suspicious("You scan the room. Her desk sits opposite from the bed, papers neatly stacked. A jewelry box rests on the dresser, half-open.","Kamarnya rapi."));
  OcrQuality.load(java.nio.file.Files.newInputStream(java.nio.file.Path.of("app/src/main/assets/english-ocr-words.txt")));
  yes(OcrQuality.uncertainLine("Don't just stand there sulk1ng",.9f,List.of()));
  yes(!OcrQuality.uncertainLine("Falling and Ban are here",.95f,List.of("Falling","Ban")));
  yes(!OcrQuality.keepsMeaningAnchors("I will not leave 3 guards.","I will leave 3 guards."));
  System.out.println("Accuracy regressions passed: context boundary recovery, ordered replies, whole-sentence name repair, quantities, truncation and evidence-only OCR reread.");
 }
}
