import com.komiklingo.app.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.atomic.*;

/** Optional live integration test: actual HTTPS transport, JSON decoding and complete translation flow. */
public class GoogleOnlineTest {
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
 static String request(String text)throws Exception{HttpURLConnection connection=(HttpURLConnection)GoogleTranslateHttp.url(text).openConnection();try{return GoogleTranslateHttp.read(connection);}finally{connection.disconnect();}}
 public static void main(String[] args)throws Exception{
  check(GoogleTranslateHttp.decode("[[[\"Halo. \",\"Hello. \"],[\"Tunggu!\",\"Wait!\"]]]").equals("Halo. Tunggu!"),"all segments retained");
  for(String invalid:List.of("[]","{}","[[]]","[[[null,\"original\"]]]","[[[\"translated\"]]]")){try{GoogleTranslateHttp.decode(invalid);throw new AssertionError("Accepted malformed response");}catch(org.json.JSONException expected){}}
  String[] sources={
   "The door clicks shut behind you. Her room is quiet and tidy. Her scent lingers in the air.",
   "OF COURSE, MY LADY!! BAN! DON'T JUST STAND THERE SULKING— TAKE A LOOK AT THAT MAJESTIC SIGHT!! HAHAHA!!",
   "SIGH... HOW ON EARTH DID THINGS END UP LIKE THIS...",
   "BLOCK THEM!! WE MUST NEVER FALL BACK!!",
   "CHARGE!! DO NOT STOP!!",
   "AND ROOT OUT THE BHAIRAVA CULT'S SPIES!",
   "YOU'VE GROWN STRONG ENOUGH TO WIPE OUT THE BASILEUS KINGDOM'S 7TH ORDER STRIKE FORCE.",
   "I AM TELLING YOU TO DEPART FOR THE ROEN KINGDOM TOMORROW, AND ENROLL IN THE ROEN KINGDOM'S MILITARY ACADEMY.",
   "You scan the room. Her desk sits opposite from the bed, papers neatly stacked. A jewelry box rests on the dresser, half-open.",
   "I didn't say she stole the key. I said she might know where it is."
  };
  for(String source:sources){
   var plan=ProtectedTerms.prepare(source,List.of("Ban","Bhairava","Basileus","Roen"));AtomicReference<String> translated=new AtomicReference<>();long start=System.nanoTime();
   TranslationFlow.translate(List.of(plan),(input,done)->{try{done.done(request(input),null);}catch(Exception e){System.out.println("REQUEST ERROR: "+e);done.done(null,e);}},()->true,(values,failed)->{check(failed==0,"Translation failed: "+source);translated.set(plan.restore(ReadingText.style(plan.source,values.get(0),ReadingText.DIALOGUE)));});
   check(translated.get()!=null&&!translated.get().isBlank(),"missing result");
   String lower=translated.get().toLowerCase(Locale.ROOT);check(!lower.contains("zxq"),"leaked marker");check(!lower.contains("kekuatan pemogokan")&&!lower.contains("jatuh kembali")&&!lower.contains("pada bumi"),"known wrong meaning: "+lower);
   if(source.contains("BHAIRAVA"))check(lower.contains("bhairava")&&lower.contains("mata-mata"),"spies ownership");
   if(source.contains("7TH"))check(lower.contains("7")||lower.contains("ketujuh"),"ordinal lost");
   if(source.contains("scent"))check(lower.contains("aroma")||lower.contains("wangi")||lower.contains("bau"),"scent lost");
   System.out.printf(Locale.ROOT,"SOURCE: %s%nRESULT: %s%nSECONDS: %.2f%n%n",source,translated.get(),(System.nanoTime()-start)/1e9);
  }
  var reply=ProtectedTerms.prepare("Not at all. I'm happy to help.",List.of());
  TranslationFlow.translate(List.of(reply),List.of("Thank you for saving me."),List.of(""),(input,done)->{try{done.done(request(input),null);}catch(Exception e){System.out.println("REQUEST ERROR: "+e);done.done(null,e);}},()->true,(values,failed)->{check(failed==0,"reply failed");System.out.println("CONTEXTUAL REPLY: "+values.get(0));check(values.get(0).toLowerCase(Locale.ROOT).contains("sama-sama"),"thanks response context");check(!values.get(0).toLowerCase(Locale.ROOT).contains("menyelamatkan"),"previous line leaked");});
  System.out.println("Google live integration passed: 10 source examples, contextual reply, actual HTTP parser and protected names. Not a universal accuracy score.");
 }
}
