# Data yang digunakan

OCR dan mode terjemahan dasar bekerja di perangkat. Unduhan model bahasa menggunakan layanan ML Kit/Google dan jaringan; situs yang dibuka menerima permintaan normal WebView serta cookie situs. Aplikasi tidak menambahkan analytics atau iklan sendiri. SDK ML Kit dapat mengirim data diagnostik/penggunaan sesuai ketentuan Google, terpisah dari pemrosesan OCR lokal.

Dalam pembaca internal, mode AI hanya saat alamat server diisi. Teks OCR bagian layar dikirim ke alamat itu, bersama ID dokumen acak; gambar dan cookie situs tidak ikut dikirim. Server contoh menyimpan konteks sementara di RAM dan mengirimnya ke Ollama lokal. Jangan memasukkan server yang tidak dipercaya. Token akses server tersimpan dalam ruang privat aplikasi dan cadangan Android dinonaktifkan. HTTPS wajib, kecuali localhost lewat USB. Kunci penyedia AI tidak dibutuhkan.

Izin jaringan: internet dan izin koneksi yang dibawa SDK. Ada izin penerima internal yang hanya boleh dipakai aplikasi sendiri. File dipilih sendiri melalui pemilih Android; aplikasi tidak meminta akses seluruh penyimpanan, kamera, mikrofon atau aksesibilitas. Gambar/file asli tidak diubah. APK pengembangan ini belum diaudit keamanannya dan belum dirilis di Play Store.

Cookie/cache situs dan pengaturan lokal dapat dihapus melalui Pengaturan Android → Aplikasi → TCD → Penyimpanan → Hapus data.

Pilihan gaya bahasa disimpan lokal per kunci situs/cerita. Jika mode AI dipakai, gaya dan Catatan cerita opsional ikut dikirim ke server yang dipilih dan menjadi bagian konteks sementara. URL situs tidak ikut dikirim sebagai ID dokumen; aplikasi memakai ID acak.

Jika kolom atas diisi kata kunci, aplikasi membuka situs DuckDuckGo dan mengirim pencarian itu melalui URL HTTPS. DuckDuckGo dan situs hasil yang dipilih mengikuti kebijakan/cookie mereka. Tidak ada API pencarian atau log pencarian milik pembuat aplikasi; URL terakhir tersimpan lokal seperti riwayat pembaca sebelumnya.

Daftar nama/istilah tetap, pilihan pengenalan otomatis dan nama yang diabaikan disimpan lokal per cerita. Identitas file lokal memakai ID turunan URI file, bukan isi file; tidak dikirim ke server AI. Dalam mode AI, teks memakai penanda nama beserta pemetaan ejaan istilah yang cocok. Nama juga menjadi bagian konteks sementara server pilihan pengguna. Tidak ada pencarian nama ke layanan lain pada mode dasar.

Percobaan ulang OCR dengan kontras dan penilaian warna/ukuran huruf dilakukan di perangkat. Gambar hasil kontras hanya sementara di memori, tidak diunggah oleh fitur ini. Pengelompokan terjemahan dasar dan koreksi pemenggalan baris tetap lokal. Server AI opsional menerima teks seperti sebelumnya; gambar/warna dan cookie situs tidak dikirim.

Beranda menyimpan riwayat maksimal 30 halaman web secara lokal: judul, URL, waktu kunjungan dan posisi gulir. Pencarian DuckDuckGo tidak masuk daftar bab ini. Daftar kosakata OCR dibundel di APK dan tidak mengirim kata ke layanan pemeriksa ejaan. Potongan untuk normalisasi/pelurusan huruf hanya sementara di memori. Riwayat dan pengaturan dapat dihapus lewat pengaturan penyimpanan aplikasi Android.

OCR cadangan Tesseract LSTM dijalankan di HP untuk maksimal dua baris yang belum jelas. Model English sekitar 4 MB dibundel di APK dan disalin ke folder privat aplikasi. Gambar baris hanya di memori selama pembacaan; model ini tidak mengirim teks/gambar ke server. Model dan lisensi ikut dalam paket.


Fitur opsional Balon TCD meminta SYSTEM_ALERT_WINDOW dan izin tangkap layar MediaProjection Android. FOREGROUND_SERVICE / FOREGROUND_SERVICE_MEDIA_PROJECTION menjaga sesi yang pengguna mulai; POST_NOTIFICATIONS ditawarkan untuk notifikasi dengan tombol Hentikan (Android 13+). Komponen service dan halaman izin tidak diekspor. Tidak ada izin aksesibilitas, mikrofon, kamera, boot receiver atau perekaman suara. Android menampilkan persetujuan layar; pembatalan tidak memulai sesi. Sesi tidak dipulihkan otomatis setelah aplikasi dihentikan dan berhenti saat layar dikunci.

Saat tidak diketuk, permukaan penangkap dilepas. Ketukan balon mengambil satu cuplikan untuk OCR dan terjemahan lokal saja, tanpa server AI. Cuplikan berada di RAM, dilepas setelah hasil ditutup/sesi berhenti. Teks hasil terakhir berada di RAM sampai sesi berhenti. Tidak ada log isi layar, penyimpanan cuplikan atau unggahan layar oleh fitur ini. Nama manual dan pilihan gaya balon disimpan lokal; nama hasil deteksi otomatis hanya untuk cuplikan yang sedang diproses, bukan daftar lintas aplikasi. Android dapat melindungi isi layar tertentu; fitur tidak melewati perlindungan itu.

Mode 1 halaman menyimpan hasil/posisi terjemahan di RAM hanya untuk dokumen aktif. Refresh dan navigasi next/back menghapus cache itu. Tidak ada cache terjemahan halaman di disk; riwayat bacaan/konfigurasi nama tetap terpisah seperti dijelaskan di atas. Jika pengguna mengaktifkan server AI untuk pembaca internal, pemindaian 1 halaman mengirim teks per viewport kepada server pilihan itu; balon aplikasi lain tetap memakai terjemahan lokal.


Mulai 0.1.8, penyimpanan hasil dokumen aktif juga berlaku untuk terjemahan biasa/otomatis, bukan hanya pemindaian 1 halaman. Sumber OCR, terjemahan, posisi dan wilayah viewport yang sudah dibaca disimpan di RAM. Refresh/next/back/dokumen baru menghapus hasil itu; tidak ditulis ke riwayat atau arsip disk. Reset hanya memproses ulang crop bagian yang pengguna pilih. Pada mode dasar tetap di HP; jika server AI pembaca internal diaktifkan, teks bagian terpilih dikirim ke server itu seperti terjemahan internal lainnya. Fitur balon aplikasi lain tetap memakai pemrosesan lokal dan tidak memakai server AI tersebut.


Pada 0.1.9, penyatuan potongan kalimat, pemeriksaan sambungan dan penyesuaian arti frasa terbatas dilakukan di perangkat. Tidak ditambahkan penyedia terjemahan, akun, izin atau unggahan baru. Kalimat OCR yang disatukan menjadi satu unit pada mode dasar, dan menjadi teks masukan biasa pada server AI jika pengguna sudah mengaktifkannya. Nama yang dilindungi tetap dimask sebelum terjemahan dan dipulihkan setelah pemeriksaan keluaran.


Tampilan 0.2.0 tidak menambahkan izin atau penyedia jaringan baru. Masukan teks langsung diproses oleh penerjemah di HP, tidak melewati OCR atau server AI pembaca. Teks dan hasil hanya berada di memori selama layar itu aktif; pilihan gaya/istilah disimpan lokal. Menekan Salin menulis hasil ke clipboard Android sesuai tindakan pengguna. Berbagi URL membuka situs; berbagi teks biasa membuka masukan teks lokal. Pilihan menyembunyikan bilah alat disimpan sebagai preferensi lokal dan tidak mengubah cache isi dokumen.


Pada 0.3.0, tab (maksimal 16) dan bookmark (maksimal 200) menyimpan URL, judul, ID/tab terpilih dan posisi gulir secara lokal di preferensi privat aplikasi. Tab tidak memuat semua halaman di latar saat aplikasi dibuka. Bookmark bukan arsip HTML offline. Browser WebView tetap dapat menyimpan cache/cookie/data situs menurut provider Android; fitur ini tidak mengklaim mode penyamaran. Tidak ada akun browser atau sinkronisasi cloud. Penghapusan data aplikasi Android menghapus data ini.

Filter iklan/pelacak memakai daftar domain kecil yang dibundel; tidak ada unduhan filter atau proxy/TLS intersepsi baru. Permintaan yang diblokir tidak diteruskan oleh filter. Situs yang diizinkan tetap menerima koneksi/cookie sesuai pengaturannya. Daftar pengecualian host disimpan lokal. Cookie pihak ketiga dibatasi secara default dan diizinkan pada pengecualian situs; popup skrip tetap ditolak. Sertifikat situs yang bermasalah tidak dilewati, dan Safe Browsing mengikuti layanan/kebijakan provider WebView Android bila tersedia. Situs tidak diberi akses kamera/mikrofon oleh aplikasi.

Cache unit terjemahan dasar menyimpan sumber/hasil di RAM, dengan kunci hash konteks. Batas 400 entri dibagi dengan cache yang sudah ada. Tidak ditulis ke bookmark/riwayat/disk atau dikirim ke layanan baru. Pengecekan pola OCR dan nama tempat tetap di perangkat, dalam batas pembacaan ulang sebelumnya. Tombol Terjemahan lengkap hanya membuka hasil lokal; Salin menulis clipboard setelah ditekan pengguna. Server AI opsional yang sudah dikonfigurasi pengguna tetap mengikuti perilaku sebelumnya.
