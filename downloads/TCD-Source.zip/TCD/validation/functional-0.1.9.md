# Pemeriksaan TCD 0.1.9

## Build

`:app:assembleDebug :app:lintDebug` lulus. APK pengguna: TCD, `com.komiklingo.app`, versionCode10/versionName0.1.9, minSDK26/targetSDK35, ARM64/ARMv7. `apksigner verify` berhasil dan sertifikat tetap `bb1ef448fb34777d2d03a49e7bfdb2bfb355ba7d57fe7b6a11f410d020e346a1` agar dapat memperbarui APK sebelumnya. Pemeriksaan APK/DEX memastikan ContextMeaning/readingParagraphs tersedia, sedangkan fixture, ABI x86 dan resource CA pengujian tidak masuk APK produksi.

## Aturan teks dan arti terbatas

Lima suite JVM lulus: ReaderRules, NameRules, TranslationFlow, OcrQuality dan ContextMeaning. Mencakup:

- Sambungan tata bahasa yang jelas, artikel/preposisi di akhir potongan dan lanjutan `and/or/from/of/...`; akhir kalimat bertanda baca tidak dianggap sambungan.
- Frasa `brand of fate/destiny` diberi arti tanda takdir, `brand of shame/disgrace` cap aib serta tanda kepemilikan/perbudakan. Bentuk plural, konteks produk/perusahaan dan nama `Brand of Fate` yang dilindungi diperiksa. Tidak ada penggantian brand/nasib secara global atau penggantian seluruh kalimat panel.
- Artikel A yang tertinggal setelah adalah/merupakan/ada dibersihkan hanya jika sumber bermakna artikel. A yang merupakan nama dan sumber `He is A from the village` tidak dihapus. Pemeriksaan terjadi sebelum nama dipulihkan.
- Jalur TranslationFlow meneruskan masukan yang diperjelas ke engine dan memeriksa kembali keluaran sesuai sumber, sambil menjaga penanda nama dan urutan paragraf.

## Android/OCR: 6 tes lulus

`validation/context-final-android-0.1.9.log` mencatat enam tes lulus pada emulator Android11/API30 x86_64 dengan rendering perangkat lunak:

1. Potongan `ARE A` dan kelanjutan yang dekat/diselaraskan disatukan. Kalimat yang sudah lengkap dan nama utuh yang dilindungi tidak dipaksa bergabung.
2. Garis tepi balon dan kolom berbeda menghalangi penyatuan.
3. OCR ML Kit nyata pada gambar balon buatan membaca kalimat `ARE A BRAND OF FATE, AND A CURSE FROM GOD.` dan menghasilkan satu unit kalimat melalui penyatuan paragraf. Ini menguji pengenalan/penyatuan pada font uji, bukan bukti semua tulisan komik sudah terbaca sempurna.
4. Terjemahan biasa tetap disimpan saat digulir; Reset hanya membaca ulang bagian terpilih; hasil lain dan hasil lama saat percobaan gagal tetap tersedia. Refresh/next/back membersihkan hasil.
5. Koreksi yang kotaknya tumpang tindih tidak ditumpuk dan coverage dibersihkan saat dokumen direset.
6. Drag dari tombol Reset tetap menggulir; area selain tombol tidak menangkap gesture pembaca.

Fixture pengujian cache/Reset memakai engine terjemahan deterministik, sedangkan OCR, koordinat, cache dan View memakai implementasi nyata. Pada percobaan awal uji OCR belum menyatukan `FROM GOD.` dengan klausa sebelumnya; log awal disimpan. Aturan sambungan preposisi ditambahkan lalu keenam tes diulang dan lulus. Tambahan aturan artikel generik/nama dan plural diverifikasi dengan suite JVM; keluaran bukan hasil penilaian bahasa oleh pembaca manusia.

## Percobaan model terjemahan nyata: tidak mencapai inferensi

RealTranslationTest mencoba mengunduh model Inggris–Indonesia melalui SDK ML Kit sebelum menerjemahkan kalimat contoh dan contoh komersial. Task unduhan tidak selesai dalam batas **180 detik**, sehingga tes gagal dengan TimeoutException sebelum inferensi. Log lengkap: `real-model-attempt-0.1.9.log`. Ini bukan hasil lulus dan tidak dianggap bukti kualitas bahasa model asli. Hasil akhir model di HP fisik pengguna belum diverifikasi.

Percobaan emulator memakai proxy sesi serta resource trust CA khusus uji agar pemeriksaan TLS tetap aktif; resource tersebut berada di luar proyek, hanya dimasukkan bila `captureTest` dan property `modelTestResources` diberikan. APK pengguna diperiksa tidak memuat resource CA uji atau konfigurasi trust tambahan. TLS produksi dan penyedia/model terjemahan tidak diganti.

## Perilaku dan batas

Satu kalimat yang berhasil disatukan memiliki satu hasil dan satu Reset; tidak lagi diterjemahkan sebagai prefiks “ARE A” yang berdiri sendiri. Pemeriksaan jarak, ukuran, warna, border dan area penghalang mencegah penggabungan sembarang balon. Potongan yang belum utuh ditunda, bukan ditebak subjek atau bagian yang hilang. Gaya campuran dapat memakai satu gaya dominan setelah digabung. Tidak ada klaim pendeteksian sempurna seluruh balon, panel atau pembicara.

Model dasar tetap ML Kit gratis yang sama, dengan masukan kalimat lebih utuh dan aturan arti lokal terbatas. Ini bukan AI pemahaman seluruh cerita, tidak menjamin emosi/idiom/rujukan selalu tepat dan tidak menggantikan penerjemah manusia. Koreksi aturan dapat tidak berlaku pada frasa di luar cakupannya; pengguna masih dapat membandingkan sumber melalui Lihat asli/Hasil. AI lokal opsional tetap membutuhkan komputer/server pengguna sendiri.

Tidak ada izin, akun, biaya API atau penyedia jaringan baru pada aplikasi. Backend server tidak berubah dan uji server tidak diulang. Service balon tidak diuji ulang pada sesi ini; perubahannya memakai helper paragraf/aturan arti yang sama, sedangkan batas pengujian balon 0.1.8 tetap tercatat pada validasi historis. Android14/15 dan HP fisik pengguna belum diuji. APK masih bertanda tangan pengembangan, bukan rilis Play Store.

Artefak APK, checksum, panduan dan sumber TCD diperbarui beserta alias KomikLingo pada branch unduhan yang sama. Tidak ada perubahan main atau kode Dualworld. Sumber tidak menyertakan keystore, local.properties, cache build, resource CA sesi atau gambar komik pengguna; gambar pengujian dibangkitkan dari teks contoh.
