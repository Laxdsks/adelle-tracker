# Komponen

- Android SDK dan Android Gradle Plugin: ketentuan Android SDK dan lisensi komponen masing-masing.
- Google ML Kit Text Recognition dan Translation, Play Services dependensi: https://developers.google.com/ml-kit/terms . Tidak ada API berbayar yang diaktifkan oleh proyek ini; ketentuan produk tetap berlaku. Model terjemahan diunduh pada perangkat, OCR Latin dibundel dalam dependensi APK.
- Gradle wrapper: Apache License 2.0, https://gradle.org/ . Distribusi diverifikasi dengan checksum resmi.
- Server contoh: Python standard library. Ollama (MIT) dan Qwen2.5 7B (Apache 2.0) dipasang sendiri, bobot/model tidak masuk arsip aplikasi.
- Konten komik dan situs tetap milik pemegang hak masing-masing. Aplikasi pembaca tidak menyertakan atau menerbitkan salinan bab komik.

- Kosakata pembanding OCR diturunkan dari CMUdict (Carnegie Mellon University), https://github.com/cmusphinx/cmudict . Ketentuan lengkap dan hak cipta disertakan di `app/src/main/assets/CMUdict-LICENSE.txt` pada sumber serta APK. Daftar kata dipakai untuk menilai hasil pengenalan, bukan untuk mengganti kata/nama secara otomatis.

- OCR cadangan: Tesseract4Android 4.9.0, Tesseract OCR dan model English `tessdata_fast` (Apache 2.0), serta Leptonica (lisensi BSD yang disertakan). Copyright/atribusi dan lisensi penuh berada di `app/src/main/assets/Tesseract4Android-NOTICE.txt`, `Tesseract-LICENSE.txt` dan `Leptonica-LICENSE.txt`, ikut dalam APK. Model English dipaketkan, tidak membutuhkan API key.
