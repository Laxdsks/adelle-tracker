# TCD 0.3.0

Browser ringan dengan terjemahan Inggris → Indonesia untuk teks, gambar, dokumen, situs dan layar aplikasi lain. Tampilan memakai komponen Android native, tanpa menambahkan iklan, animasi berat atau pustaka UI baru.

## Mulai

Pasang `TCD-Android.apk` pada Android 8+ ARM64/ARMv7 sebagai pembaruan aplikasi sebelumnya. Model Inggris–Indonesia perlu diunduh sekali; setelah siap, mode dasar memproses teks/file di HP. Membuka situs tetap membutuhkan internet.

Beranda menampilkan **Teks**, **Gambar & file**, kolom alamat/pencarian dan **Terjemahan layar**. **Lanjutkan** membuka sumber web terakhir; daftar lain ada di **Riwayat**.

- **Teks:** ketik/tempel teks, tekan Terjemahkan, lalu Salin. Teks langsung diteruskan ke penerjemah lokal tanpa OCR. Paragraf tetap diproses sebagai satu kesatuan; maksimal 16.000 karakter per proses, dan input yang melebihi batas ditolak tanpa dipotong diam-diam. Gaya dan istilah ada di menu Pilihan. Berbagi teks biasa ke TCD membuka masukan ini; berbagi URL membuka situs.
- **Gambar & file:** pilih JPG, PNG, WebP, PDF tanpa kata sandi atau TXT UTF-8 melalui pemilih Android. File sumber tidak ditulis ulang. EPUB/DOCX/CBZ dan PDF terenkripsi belum didukung.
- **Situs:** masukkan URL atau kata kunci. Pencarian memakai DuckDuckGo. Aturan login, pembatasan WebView dan akses situs tetap berlaku; aplikasi tidak melewatinya.
- **Terjemahan layar:** aktifkan balon dengan izin Android, buka aplikasi lain, lalu ketuk balon. Tutup hasil untuk kembali menggulir. Tahan balon untuk menu atau hentikan lewat notifikasi. Sesi berhenti saat layar dikunci. Layar yang dilindungi tidak bisa dibaca. Pengaturan tambahan tidak perlu diisi untuk mulai.

## Tab, bookmark dan perlindungan situs

Angka di samping kolom alamat membuka daftar **Tab**. Tekan **+ Tab baru** untuk halaman baru; pilih judul untuk berpindah dan × untuk menutup tab. Maksimal 16 tab. URL, judul, tab terpilih dan posisi gulir disimpan lokal setelah aplikasi ditutup. Saat mulai, beranda tetap muncul dan tab tersimpan tidak diunduh bersamaan. Satu WebView memuat tab yang dipilih agar hemat RAM; berpindah tab memuat ulang URL/posisinya. Riwayat mundur/maju WebView direset ketika berganti tab agar halaman tab lain tidak terbuka lewat Back. Riwayat global tetap tersedia lewat Menu → Riwayat di beranda.

Pada halaman web, buka Menu → **☆ Simpan bookmark**. Daftar **★ Bookmark** tersedia di menu dan ikon bintang beranda. Buka dengan mengetuk judul atau hapus dengan ×; maksimal 200 alamat. Bookmark menyimpan alamat, bukan salinan halaman offline. Tekan lama tautan untuk membuka tab baru atau menyimpannya. File lokal tetap dibuka melalui Gambar & file dan tidak ditulis menjadi bookmark web.

Penyaring domain iklan/pelacak, cookie pihak ketiga yang dibatasi dan penolakan popup skrip aktif sejak awal. Daftar domain dibundel, tanpa mengunduh filter eksternal. CSS menyembunyikan beberapa slot iklan umum; gambar halaman tetap dimuat. Ini dapat mengurangi transfer iklan, tetapi iklan pihak pertama, domain baru atau iklan yang menjadi bagian gambar masih bisa tampil. Menu → **Perlindungan situs** menyediakan pengecualian domain bila sumber terganggu; memuat ulang menghapus hasil terjemahan dokumen aktif. Popup skrip tetap diblokir; tautan nyata dapat dibuka ke tab baru. Akses kamera/mikrofon dari situs tidak diberikan.

Koneksi situs memakai HTTPS, sertifikat bermasalah dibatalkan dan Safe Browsing WebView diaktifkan bila tersedia dari provider Android. Ini tidak menjamin semua situs aman. DuckDuckGo ialah mesin pencari, bukan VPN: aplikasi ini tidak memintas blokir ISP/DNS, CAPTCHA, pembatasan akun/wilayah atau sertifikat situs. Hasil pencarian mengikuti pengaturan DuckDuckGo dan aturan situs. Tidak ada VPN/proxy, akun browser, sinkronisasi cloud atau API pencarian baru.

Menu halaman juga menyediakan Muat ulang, Maju, Buka file, Pengaturan dan submenu Terjemahan. **Terjemahkan 1 halaman**, Otomatis, Teks dan Terjemahan layar ada di submenu Terjemahan; kemampuan sebelumnya tetap tersedia.

## Area baca yang lebih luas

Bilah atas dipadatkan menjadi satu baris. Bilah bawah berisi Terjemahkan, Lihat asli dan Hasil. Ketuk ikon sudut layar untuk menyembunyikan alat: bilah atas/bawah, bilah sistem Android dan tombol Reset per bagian ikut tersembunyi. Ikon kecil tetap ada untuk menampilkan alat kembali; ikon dapat digeser jika menutupi isi. Android juga dapat menampilkan bilah sistem sementara lewat sapuan tepi layar.

Status pemrosesan hanya muncul sementara, bukan panel tetap. Menu → Terjemahan menyimpan Otomatis dan pemindaian 1 halaman; pengaturan tambahan ada di Menu → Pengaturan. Tampilan penuh tidak menghapus terjemahan.

## Hasil tersimpan dan Reset

Mode biasa/otomatis menyimpan hasil dalam RAM pada dokumen aktif. Bagian yang sudah selesai tidak perlu diterjemahkan ulang saat kembali ke viewport yang sama. Bagian baru dibaca bertahap saat terlihat. **Reset** di bawah hasil membaca ulang satu bagian; jika ruang tidak cukup, gunakan Hasil → Reset bagian ini. Bagian lain tetap tersedia dan percobaan gagal mempertahankan hasil sebelumnya. Dalam mode bersih, tampilkan alat dahulu untuk mengakses Reset/Hasil.

Refresh, next/back, sumber baru dan penghentian proses menghapus cache dokumen. Riwayat URL/posisi tetap disimpan terpisah. Mengubah gaya/nama/server membersihkan hasil lama agar konfigurasi baru berlaku. Hasil bukan arsip permanen lintas navigasi.

**Terjemahkan 1 halaman** tetap tersedia lewat Menu dan hanya memindai dokumen aktif dari atas sampai bawah, tanpa membuka tautan berikutnya. Gunakan mode biasa untuk membaca bertahap. Batas pemindaian 400 viewport atau 6.000 bagian; halaman tanpa akhir, scroll-container khusus, canvas/iframe atau pergeseran layout masih dapat membatasi hasil.

## Bahasa dan tampilan hasil

Perbaikan penyatuan kalimat dan pemilihan arti termasuk dalam versi ini. Potongan OCR dengan sambungan tata bahasa yang jelas dicoba disatukan berdasarkan posisi, warna dan piksel pembatas. Potongan yang belum utuh ditunda, bukan ditebak. Mulai 0.2.1, potongan tanpa tanda akhir juga bisa digabung bila berdekatan, selaras dan terbukti berada di area polos tertutup yang sama. Ini membantu kata sifat dan kata benda yang terpisah blok OCR, tanpa membutuhkan daftar semua kata sifat. Halaman putih terbuka, balon terpotong, border pemisah, kolom berbeda dan akhir kalimat tetap membatasi penggabungan. Penyesuaian arti lokal yang terbatas membedakan frasa seperti brand of fate (tanda takdir) dari konteks produk (merek). Nama yang telah dilindungi dipertahankan; daftar manual tersedia di pengaturan sumber. Jeda sesudah kata bantu seperti “I couldn’t…” dicoba disambungkan dengan kata kerja berikutnya. Frasa “sense her presence” mendapat pemeriksaan arti terbatas agar keluaran salah “sedihnya kehadirannya” dapat diperbaiki; sumber yang menyebut kesedihan sungguhan tidak ditimpa. “She’s a powerhouse” diperjelas sebagai orang yang sangat kuat, dengan pengecualian konteks listrik dan istilah yang dilindungi. Kiasan perilaku seperti “glare … like a prickly cat” diperjelas sebagai kucing pemarah/galak, dengan pengecualian konteks duri/benda dan nama yang dilindungi. Pola “I have absolutely no intention of…” diperjelas menjadi struktur penolakan yang utuh; kata punya yang salah tersisa sebelum “tidak berniat” dibersihkan hanya bila sumber mendukungnya. Ini aturan lokal yang terikat sumber, bukan pemahaman otomatis semua cerita. Model dasar tetap ML Kit, bukan AI pemahaman seluruh konteks.

Penutup sumber digambar sebelum semua teks hasil agar penutup tetangga tidak memotong baris. Warna, ukuran dan kemiringan diperkirakan; font asli tidak disalin persis dan gambar di balik huruf tidak dipulihkan. Jika teks tidak muat pada ukuran terbaca, teks asli tidak ditutupi sebagian. Tombol kecil Terjemahan ↗ di luar area teks membuka hasil lengkap yang dapat dipilih/disalin, beserta Reset. Jika tidak ada ruang untuk tombol, gunakan Hasil. Tampilkan alat dahulu jika sedang memakai mode bersih. Tulisan dekoratif, gambar pecah, latar ramai, nama ambigu dan kalimat yang terpotong masih bisa salah. Bandingkan Lihat asli/Hasil.

## Kecepatan, OCR dan kata kerja berpasangan

Cache 0.3.0 memakai kembali terjemahan unit yang telah berhasil dengan sumber dan konteks tetangga yang sama, termasuk keluaran batch. Kunci konteks dipadatkan dengan SHA-256; data terjemahan tetap hanya di RAM dalam batas cache 400 entri yang sama. Perubahan konteks, hasil tidak valid atau Reset tidak memakai hasil unit lama. Ini mengurangi pekerjaan berulang; tidak mengunduh model/menambah kuota pada tiap kalimat. Kecepatan tergantung HP dan hasil OCR, bukan jaminan waktu tertentu. Situs/gambar masih memakai internet dan unduhan model awal tetap diperlukan.

Pola OCR mencurigakan seperti NE PLAN atau READY TO MOE memicu pembacaan ulang dari piksel dalam batas percobaan yang sudah ada. Tidak ada penggantian NE menjadi WE atau nama Moe menjadi MOVE tanpa kandidat OCR baru; nama yang dilindungi tetap dijaga. Nama tempat baru sebelum Kingdom/Empire/City/Village bisa dikenali bila kapitalisasi dan kosakata mendukung. Ejaan yang sudah salah di sumber OCR masih bisa salah.

Frasa sakit seperti headache is flaring up diperjelas sebagai getting worse; api/flames dan nama yang dilindungi tidak diganti. Versi ini juga membaca `burst in/into` dan `barge in/into` bersama pelaku dan pelengkapnya. Arti masuk mendadak dibedakan dari bom, tangisan, api dan kata yang menjadi nama. Bentuk waktu yang jelas dipertahankan; ejaan burst tanpa bukti waktu tidak dipaksa menjadi lampau. Koreksi “aku meledak” menjadi “aku menerobos masuk” hanya berlaku ketika sumber mendukung arti masuk.

Kalimat pembuka dan klausa waktu yang dekat bisa disatukan jika berada pada area tertutup yang sama. Klausa lengkap yang jelas berlanjut dengan tanda pisah dapat memakai koma pada masukan penerjemah ketika bagian berikutnya berupa klausa utama. Hasil pada balon yang berjauhan tetap memakai kotaknya masing-masing. Ini membantu struktur kalimat, bukan memahami seluruh percakapan secara otomatis.

## AI lokal opsional

Pembaca situs/file dapat memakai server pengguna sendiri untuk konteks yang lebih luas. Masukan teks langsung dan balon layar tetap memakai model di HP. Tidak ada server AI publik yang otomatis aktif atau API berbayar tersembunyi. Model lokal membutuhkan komputer, RAM, unduhan model dan listrik; hasil tetap dapat keliru.

1. Di komputer, pasang Ollama dan unduh model: `ollama pull qwen2.5:7b`.
2. Jalankan `python3 server/reader_server.py`. Simpan kode akses yang ditampilkan.
3. Hubungkan HP dengan USB debugging, izinkan komputer, lalu jalankan `adb reverse tcp:8765 tcp:8765`.
4. Pada pembaca TCD: Menu → Pengaturan → AI opsional. Alamat `http://127.0.0.1:8765/translate` dan kode akses dari server.
5. Kosongkan alamat untuk kembali ke mode dasar. Server jaringan lain wajib HTTPS serta kontrol akses yang disiapkan pemiliknya.

Server contoh mendengar 127.0.0.1, memeriksa kode akses/ukuran/antrean dan memisahkan konteks dokumen di RAM. Konteks kedaluwarsa 30 menit dengan batas 32 dokumen. Ini untuk penggunaan pribadi dan membutuhkan penguatan sebelum dijadikan layanan publik.

## Build dan batas pengujian

AGP8.7.3, Gradle8.9, JDK17, compile/targetSDK35. Buka di Android Studio atau jalankan Gradle setelah menentukan SDK. `scripts/build.sh` khusus workspace cloud dan menjaga proxy/CA sesi. Keystore privat tidak masuk sumber. Identitas paket/sertifikat dipertahankan agar pembaruan tetap memakai data aplikasi yang sama; APK masih bertanda tangan pengembangan dan belum dirilis di Play Store.

Pengujian Android memakai `-PcaptureTest` sehingga fixture/x86 hanya masuk APK uji. Property `modelTestResources` bersifat khusus pengujian; resource CA sesi tidak masuk APK pengguna/sumber. Percobaan model ML Kit asli belum mencapai inferensi karena unduhan model emulator melewati batas 180 detik. Uji UI/OCR/aturan serta engine simulasi dicatat terpisah dalam Pemeriksaan dan tidak dianggap jaminan kualitas seluruh bahasa. Belum diperiksa pada HP fisik pengguna atau runtime Android14/15.

APK utama dan sumber: `TCD-Android.apk` / `TCD-Source.zip`. Artefak lama tetap dipertahankan sebagai alias untuk kompatibilitas tautan.
