package com.komiklingo.app;
import android.content.*;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
public final class AppUi {
 public static final int BACKGROUND=0xff0f172a,PANEL=0xff1e293b,TEXT=0xffe2e8f0,MUTED=0xff94a3b8,ACCENT=0xffd9f99d;
 public static int dp(Context context,int value){return Math.round(value*context.getResources().getDisplayMetrics().density);}
 public static GradientDrawable panel(Context context,int color,int radius){var shape=new GradientDrawable();shape.setColor(color);shape.setCornerRadius(dp(context,radius));return shape;}
 public static TextView label(Context context,String text,int size){var view=new TextView(context);view.setText(text);view.setTextColor(TEXT);view.setTextSize(size);view.setGravity(Gravity.CENTER_VERTICAL);return view;}
 public static Button button(Context context,String text,View.OnClickListener click){var view=new Button(context);view.setText(text);view.setAllCaps(false);view.setTextSize(13);view.setTextColor(ACCENT);view.setBackgroundTintList(android.content.res.ColorStateList.valueOf(PANEL));view.setOnClickListener(click);return view;}
 public static ImageButton icon(Context context,int resource,String description,View.OnClickListener click){var view=new ImageButton(context);view.setImageResource(resource);view.setColorFilter(ACCENT);view.setBackground(panel(context,PANEL,12));view.setPadding(dp(context,10),dp(context,10),dp(context,10),dp(context,10));view.setContentDescription(description);view.setTooltipText(description);view.setOnClickListener(click);return view;}
 public static void insetRoot(View root){root.setOnApplyWindowInsetsListener((view,insets)->{view.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});}
 private AppUi(){}
}
