package com.komiklingo.app;

import java.util.*;
import java.util.regex.*;

/** Explicit paragraph boundaries for engines that collapse blank lines. Never infer alignment. */
public final class ContextBatch {
 private final String prefix;private final int count;public final String input;
 public ContextBatch(List<String> paragraphs){
  String all=String.join("\n\n",paragraphs),key="ZXQUNIT";while(all.toUpperCase(Locale.ROOT).contains(key))key+="X";
  prefix=key;count=paragraphs.size();StringBuilder out=new StringBuilder();
  for(int i=0;i<count;i++){if(i>0)out.append("\n\n");out.append(marker(i)).append('\n').append(paragraphs.get(i));}input=out.toString();
 }
 private String marker(int index){return prefix+index+"QXZ";}
 public List<String> parse(String translated){
  if(translated==null)return null;Matcher tags=Pattern.compile(Pattern.quote(prefix)+"(\\d+)QXZ",Pattern.CASE_INSENSITIVE).matcher(translated);
  List<String> result=new ArrayList<>();int end=0,expected=0;
  while(tags.find()){
   if(expected>=count||!tags.group(1).equals(Integer.toString(expected)))return null;
   String part=translated.substring(end,tags.start()).trim();
   if(expected==0){if(!part.isEmpty())return null;}else{if(part.isEmpty())return null;result.add(part);}
   expected++;end=tags.end();
  }
  String last=translated.substring(end).trim();if(expected!=count||last.isEmpty())return null;result.add(last);
  for(String part:result)if(part.toUpperCase(Locale.ROOT).contains(prefix))return null;
  return result;
 }
 private ContextBatch(){prefix="";count=0;input="";}
}
