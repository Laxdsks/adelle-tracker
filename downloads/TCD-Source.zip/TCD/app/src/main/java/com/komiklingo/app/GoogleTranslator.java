package com.komiklingo.app;

import android.content.*;
import android.os.*;
import java.net.*;
import java.util.concurrent.*;

/** Lifecycle-owned transport. Callbacks and routing run on the main thread. */
public final class GoogleTranslator implements AutoCloseable {
 public static final String PREFERENCE="translation-provider";
 private final Handler main=new Handler(Looper.getMainLooper());
 private final ExecutorService worker=Executors.newSingleThreadExecutor();
 private final TranslationRouter router;private volatile boolean closed;private volatile HttpURLConnection connection;private Future<?> task;
 public static boolean enabled(Context context){return !context.getSharedPreferences("reader",Context.MODE_PRIVATE).getString(PREFERENCE,"google").equals("offline");}
 public GoogleTranslator(Context context,NameTranslation.Engine offline,Runnable fallback){
  Context app=context.getApplicationContext();router=new TranslationRouter(()->enabled(app),this::online,offline,SystemClock::elapsedRealtime,fallback);
 }
 public boolean onlineResult(){return router.onlineResult();}
 public void translate(String source,NameTranslation.Result result){if(!closed)router.translate(source,result);}
 private void online(String source,NameTranslation.Result result){
  task=worker.submit(()->{String text=null;Exception failure=null;HttpURLConnection current=null;
   try{if(closed||Thread.currentThread().isInterrupted())return;current=(HttpURLConnection)GoogleTranslateHttp.url(source).openConnection();connection=current;text=GoogleTranslateHttp.read(current);}catch(Exception error){failure=error;}finally{if(current!=null)current.disconnect();if(connection==current)connection=null;}
   String value=text;Exception error=failure;main.post(()->{if(!closed)result.done(value,error);});
  });
 }
 public void cancel(){router.cancel();if(task!=null)task.cancel(true);HttpURLConnection current=connection;if(current!=null)current.disconnect();}
 @Override public void close(){closed=true;cancel();router.clear();worker.shutdownNow();main.removeCallbacksAndMessages(null);}
}
