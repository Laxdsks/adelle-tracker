package com.komiklingo.app;

import android.app.*;
import android.content.*;

/** Shared preference for reader, direct text and floating translation. */
public final class TranslationSettings {
 public static void show(Activity activity,Runnable changed){
  new AlertDialog.Builder(activity).setTitle("Mesin terjemahan · semua mode")
   .setSingleChoiceItems(new String[]{"Google online · teks dikirim ke Google","Offline · teks diproses di HP"},GoogleTranslator.enabled(activity)?0:1,(dialog,which)->{
    activity.getSharedPreferences("reader",Context.MODE_PRIVATE).edit().putString(GoogleTranslator.PREFERENCE,which==0?"google":"offline").apply();dialog.dismiss();changed.run();
   }).setNeutralButton("Tentang data",(dialog,which)->new AlertDialog.Builder(activity).setTitle("Google Translate online")
    .setMessage("Mode online mengirim teks Inggris dan konteks dialog ke Google melalui HTTPS. Gambar layar, URL halaman, dan cookie situs tidak dikirim. Hasil sementara disimpan di RAM. Jika layanan gagal, TCD mencoba model offline yang sudah terunduh. Layanan web Google dapat membatasi permintaan; hasil tetap perlu dibaca ulang.")
    .setPositiveButton("Mengerti",null).show()).setNegativeButton("Tutup",null).show();
 }
 private TranslationSettings(){}
}
