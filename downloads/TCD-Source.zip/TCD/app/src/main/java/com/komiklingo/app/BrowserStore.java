package com.komiklingo.app;
import android.content.SharedPreferences;
import org.json.*;
import java.util.*;

/** Bounded local metadata, never HTML, passwords or page translation archives. */
public final class BrowserStore {
 public static final int MAX_TABS=16,MAX_BOOKMARKS=200;
 public static final class Page {
  public final String id,url,title;public final float scroll;
  Page(String id,String url,String title,float scroll){this.id=id;this.url=url;this.title=title;this.scroll=scroll;}
 }
 private final SharedPreferences prefs;private final List<Page> tabs=new ArrayList<>();private String active;
 public BrowserStore(SharedPreferences prefs){this.prefs=prefs;try{JSONArray json=new JSONArray(prefs.getString("browser-tabs-v1","[]"));for(int i=0;i<json.length()&&tabs.size()<MAX_TABS;i++){try{JSONObject p=json.getJSONObject(i);String url=p.optString("url","");if(!url.isEmpty())url=BrowserRules.https(url);String id=p.getString("id");if(id.length()>80||tabs.stream().anyMatch(t->t.id.equals(id)))continue;tabs.add(new Page(id,url,title(p.optString("title",""),url),position(p.optDouble("scroll",0))));}catch(Exception ignored){}}}catch(Exception ignored){}
  active=prefs.getString("browser-active","");if(tabs.stream().noneMatch(p->p.id.equals(active)))active=tabs.isEmpty()?"":tabs.get(0).id;if(tabs.isEmpty())newTab();else persist();
 }
 public List<Page> tabs(){return new ArrayList<>(tabs);}public String activeId(){return active;}
 public Page current(){for(Page p:tabs)if(p.id.equals(active))return p;return null;}
 public Page newTab(){if(tabs.size()>=MAX_TABS)return null;Page p=new Page(UUID.randomUUID().toString(),"","Tab baru",0);tabs.add(p);active=p.id;persist();return p;}
 public void select(String id){for(Page p:tabs)if(p.id.equals(id)){active=id;persist();return;}}
 public void close(String id){int at=-1;for(int i=0;i<tabs.size();i++)if(tabs.get(i).id.equals(id))at=i;if(at<0)return;boolean selected=id.equals(active);tabs.remove(at);if(tabs.isEmpty()){newTab();return;}if(selected)active=tabs.get(Math.min(at,tabs.size()-1)).id;persist();}
 public void update(String id,String url,String title,float scroll){try{url=BrowserRules.https(url);}catch(Exception ignored){return;}for(int i=0;i<tabs.size();i++){Page old=tabs.get(i);if(old.id.equals(id)){String value=title==null||title.trim().isEmpty()?(old.url.equals(url)?old.title:url):title;tabs.set(i,new Page(id,url,title(value,url),position(scroll)));persist();return;}}}
 public List<Page> bookmarks(){List<Page> result=new ArrayList<>();try{JSONArray json=new JSONArray(prefs.getString("browser-bookmarks-v1","[]"));for(int i=0;i<json.length()&&result.size()<MAX_BOOKMARKS;i++){try{JSONObject p=json.getJSONObject(i);String url=BrowserRules.https(p.getString("url"));if(result.stream().noneMatch(v->v.url.equals(url)))result.add(new Page(url,url,title(p.optString("title",""),url),0));}catch(Exception ignored){}}}catch(Exception ignored){}return result;}
 public boolean starred(String url){try{String clean=BrowserRules.https(url);return bookmarks().stream().anyMatch(p->p.url.equals(clean));}catch(Exception ignored){return false;}}
 public boolean toggleBookmark(String url,String title){url=BrowserRules.https(url);List<Page> all=bookmarks();final String target=url;boolean removed=all.removeIf(p->p.url.equals(target));if(!removed){if(all.size()>=MAX_BOOKMARKS)throw new IllegalStateException("Bookmark penuh");all.add(0,new Page(url,url,title(title,url),0));}JSONArray json=new JSONArray();for(Page p:all)json.put(json(p));prefs.edit().putString("browser-bookmarks-v1",json.toString()).apply();return !removed;}
 public boolean protectedSite(String url){String host=BrowserRules.host(url);return !host.isEmpty()&&!prefs.getStringSet("browser-unprotected",Collections.emptySet()).contains(host);}
 public void setProtected(String url,boolean enabled){String host=BrowserRules.host(url);if(host.isEmpty())return;Set<String> all=new HashSet<>(prefs.getStringSet("browser-unprotected",Collections.emptySet()));if(enabled)all.remove(host);else if(all.size()<200)all.add(host);prefs.edit().putStringSet("browser-unprotected",all).apply();}
 private static float position(double value){return Double.isFinite(value)?(float)Math.max(0,Math.min(value,10000000)):0;}
 private static String title(String value,String url){String text=value==null?"":value.trim();if(text.isEmpty())text=url.isEmpty()?"Tab baru":url;return text.substring(0,Math.min(180,text.length()));}
 private JSONObject json(Page p){JSONObject json=new JSONObject();try{json.put("id",p.id).put("url",p.url).put("title",p.title).put("scroll",p.scroll);}catch(JSONException ignored){}return json;}
 private void persist(){JSONArray json=new JSONArray();for(Page p:tabs)json.put(json(p));prefs.edit().putString("browser-tabs-v1",json.toString()).putString("browser-active",active).apply();}
}
