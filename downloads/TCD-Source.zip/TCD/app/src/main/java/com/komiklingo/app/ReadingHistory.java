package com.komiklingo.app;
import android.content.SharedPreferences;
import org.json.*;
import java.util.*;

/** Bounded chapter history. Saving an old page's scroll position never makes it the newest chapter. */
public final class ReadingHistory {
 public static final class Entry {
  public final String url,title;public final float scroll;public final long visit;
  Entry(String url,String title,float scroll,long visit){this.url=url;this.title=title;this.scroll=scroll;this.visit=visit;}
 }
 private final SharedPreferences prefs;
 public ReadingHistory(SharedPreferences prefs){this.prefs=prefs;}
 public List<Entry> entries(){
  List<Entry> result=new ArrayList<>();try{JSONArray all=new JSONArray(prefs.getString("reading-history","[]"));for(int i=0;i<all.length()&&i<30;i++){JSONObject item=all.getJSONObject(i);String url=ReadingLink.normalize(item.getString("url"));if(!ReadingLink.isSearchPage(url))result.add(new Entry(url,item.optString("title",url),(float)item.optDouble("scroll",0),item.optLong("visit",0)));}}catch(Exception ignored){}
  result.sort((a,b)->Long.compare(b.visit,a.visit));return result;
 }
 public void record(String input,String title,float scroll,long visit){
  String url;try{url=ReadingLink.normalize(input);if(ReadingLink.isSearchPage(url))return;}catch(Exception error){return;}
  if(!Float.isFinite(scroll)||scroll<0)scroll=0;scroll=Math.min(scroll,10000000);if(title==null||title.trim().isEmpty())title=url;if(title.length()>180)title=title.substring(0,180);
  List<Entry> entries=entries();for(Iterator<Entry> iterator=entries.iterator();iterator.hasNext();){Entry old=iterator.next();if(old.url.equals(url)){if(old.visit>visit)return;if(title.equals(url))title=old.title;iterator.remove();}}
  entries.add(new Entry(url,title,scroll,visit));entries.sort((a,b)->Long.compare(b.visit,a.visit));JSONArray json=new JSONArray();for(int i=0;i<Math.min(30,entries.size());i++){Entry item=entries.get(i);try{json.put(new JSONObject().put("url",item.url).put("title",item.title).put("scroll",item.scroll).put("visit",item.visit));}catch(JSONException ignored){}}
  prefs.edit().putString("reading-history",json.toString()).apply();
 }
}
