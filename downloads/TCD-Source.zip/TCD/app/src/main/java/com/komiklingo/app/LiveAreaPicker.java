package com.komiklingo.app;
import android.content.Context;
import android.graphics.*;
import android.view.*;

/** Temporary touch surface; removed before monitoring or resuming the game. */
public final class LiveAreaPicker extends View {
 private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);private final RectF area=new RectF();private float startX,startY;private boolean initialized;private int mode;private final RectF original=new RectF();
 public LiveAreaPicker(Context context){super(context);setContentDescription("Seret untuk memilih kotak dialog game");}
 @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){if(!initialized){area.set(w*.06f,h*.65f,w*.94f,h*.88f);initialized=true;}}
 @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);paint.setColor(0x99000000);canvas.drawRect(0,0,getWidth(),area.top,paint);canvas.drawRect(0,area.bottom,getWidth(),getHeight(),paint);canvas.drawRect(0,area.top,area.left,area.bottom,paint);canvas.drawRect(area.right,area.top,getWidth(),area.bottom,paint);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(4);paint.setColor(0xffd9f99d);canvas.drawRect(area,paint);paint.setStyle(Paint.Style.FILL);for(float x:new float[]{area.left,area.right})for(float y:new float[]{area.top,area.bottom})canvas.drawCircle(x,y,8,paint);}
 @Override public boolean onTouchEvent(MotionEvent event){float x=event.getX(),y=event.getY();switch(event.getActionMasked()){
  case MotionEvent.ACTION_DOWN:startX=x;startY=y;original.set(area);float hit=28*getResources().getDisplayMetrics().density;mode=0;if(Math.abs(x-area.left)<hit&&Math.abs(y-area.top)<hit)mode=1;else if(Math.abs(x-area.right)<hit&&Math.abs(y-area.top)<hit)mode=2;else if(Math.abs(x-area.left)<hit&&Math.abs(y-area.bottom)<hit)mode=3;else if(Math.abs(x-area.right)<hit&&Math.abs(y-area.bottom)<hit)mode=4;else if(area.contains(x,y))mode=5;return true;
  case MotionEvent.ACTION_MOVE:case MotionEvent.ACTION_UP:
   if(mode==5){float dx=Math.max(-original.left,Math.min(getWidth()-original.right,x-startX)),dy=Math.max(-original.top,Math.min(getHeight()-original.bottom,y-startY));area.set(original);area.offset(dx,dy);}
   else if(mode>0){area.set(original);float min=24*getResources().getDisplayMetrics().density;if(mode==1||mode==3)area.left=Math.max(0,Math.min(x,original.right-min));else area.right=Math.min(getWidth(),Math.max(x,original.left+min));if(mode==1||mode==2)area.top=Math.max(0,Math.min(y,original.bottom-min));else area.bottom=Math.min(getHeight(),Math.max(y,original.top+min));}
   else area.set(Math.max(0,Math.min(startX,x)),Math.max(0,Math.min(startY,y)),Math.min(getWidth(),Math.max(startX,x)),Math.min(getHeight(),Math.max(startY,y)));
   invalidate();return true;default:return true;
  }}
 public RectF screenArea(){int[] location=new int[2];getLocationOnScreen(location);RectF result=new RectF(area);result.offset(location[0],location[1]);return result;}
}
