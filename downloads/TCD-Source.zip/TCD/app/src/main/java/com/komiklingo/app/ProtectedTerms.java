package com.komiklingo.app;

import java.util.*;
import java.util.regex.*;

/** Per-story literal terms. The translation engine never owns their spelling. */
public final class ProtectedTerms {
 public static List<String> parse(String input){
  LinkedHashMap<String,String> result=new LinkedHashMap<>();
  for(String line:input.split("[\\r\\n]+")){
   String term=line.trim().replaceAll("\\s+"," ");if(term.isEmpty())continue;
   if(term.length()>64||!term.matches("[\\p{L}\\p{N}][\\p{L}\\p{N} .’'\\-]*"))throw new IllegalArgumentException("Nama maksimal 64 karakter: huruf, angka, spasi, titik, apostrof atau tanda hubung.");
   result.putIfAbsent(term.toLowerCase(Locale.ROOT),term);
   if(result.size()>80)throw new IllegalArgumentException("Maksimal 80 nama/istilah per sumber.");
  }
  return new ArrayList<>(result.values());
 }
 public static List<String> defaults(String story){
  if(story.equals("kaynscans.com/series/comic/chronicle-of-runes")||story.equals("www.kaynscans.com/series/comic/chronicle-of-runes"))return Arrays.asList("Ban","Chronicle of Runes");
  return Collections.emptyList();
 }
 public static final class Piece {
  public final String value;public final boolean protectedName;
  Piece(String value,boolean name){this.value=value;this.protectedName=name;}
 }
 public static final class Plan {
  public final String source,masked;
  public final List<Piece> pieces;
  private final LinkedHashMap<String,String> names;
  private final String prefix;
  private Plan(String source,String masked,List<Piece> pieces,LinkedHashMap<String,String> names,String prefix){this.source=source;this.masked=masked;this.pieces=Collections.unmodifiableList(pieces);this.names=names;this.prefix=prefix;}
  public Map<String,String> names(){return Collections.unmodifiableMap(names);}
  public boolean valid(String translated){
   if(translated==null||translated.trim().isEmpty())return false;
   String remaining=translated;
   for(String marker:names.keySet()){
    Matcher m=Pattern.compile(Pattern.quote(marker),Pattern.CASE_INSENSITIVE).matcher(remaining);int count=0;while(m.find())count++;if(count!=1)return false;
    remaining=remaining.replaceAll("(?i)"+Pattern.quote(marker),"");
   }
   return !remaining.toUpperCase(Locale.ROOT).contains(prefix);
  }
  public String restore(String translated){
   if(!valid(translated))throw new IllegalArgumentException("Nama tidak terjaga oleh mesin terjemahan.");
   String out=translated;
   for(Map.Entry<String,String> item:names.entrySet())out=out.replaceAll("(?i)"+Pattern.quote(item.getKey()),Matcher.quoteReplacement(item.getValue()));
   return out;
  }
 }
 public static Plan prepare(String source,List<String> terms){return prepare(source,terms,0);}
 public static Plan prepare(String source,List<String> terms,int startIndex){
  String prefix="ZXQNAME";while(source.toUpperCase(Locale.ROOT).contains(prefix))prefix+="X";
  List<String> sorted=new ArrayList<>(terms);for(String name:honorificNames(source))if(sorted.stream().noneMatch(t->t.equalsIgnoreCase(name)))sorted.add(name);sorted.sort((a,b)->Integer.compare(b.length(),a.length()));
  List<Piece> pieces=new ArrayList<>();LinkedHashMap<String,String> names=new LinkedHashMap<>();StringBuilder masked=new StringBuilder();
  if(sorted.isEmpty()){pieces.add(new Piece(source,false));return new Plan(source,source,pieces,names,prefix);}
  StringBuilder alternatives=new StringBuilder();
  for(String term:sorted){if(alternatives.length()>0)alternatives.append('|');alternatives.append(Pattern.quote(term));}
  Matcher matcher=Pattern.compile("(?iu)(?<![\\p{L}\\p{N}_])(?:"+alternatives+")(?![\\p{L}\\p{N}_])").matcher(source);
  int offset=0,index=startIndex;
  while(matcher.find()){
   String before=source.substring(offset,matcher.start());if(!before.isEmpty()){pieces.add(new Piece(before,false));masked.append(before);}
   String canonical=matcher.group();for(String term:sorted)if(term.equalsIgnoreCase(canonical)){canonical=term;break;}
   String token=prefix+(index++)+"QXZ";names.put(token,canonical);pieces.add(new Piece(token,true));masked.append(token);offset=matcher.end();
  }
  String tail=source.substring(offset);if(!tail.isEmpty()){pieces.add(new Piece(tail,false));masked.append(tail);}
  return new Plan(source,masked.toString(),pieces,names,prefix);
 }
 public static String cleanOcr(String source,List<String> terms){
  Plan plan=prepare(source.replaceAll("\\s+"," ").trim(),terms);StringBuilder result=new StringBuilder();
  for(Piece part:plan.pieces)result.append(part.protectedName?part.value:cleanFragment(part.value));
  return plan.restore(result.toString()).replaceAll("\\s+"," ").trim();
 }
 private static String cleanFragment(String value){
  String lead=value.replaceFirst("(?s)\\S.*$","");String tail=value.replaceFirst("(?s)^.*\\S","");
  if(value.trim().isEmpty())return value;
  return lead+ReadingText.cleanOcr(value)+tail;
 }
 private static final Set<String> COMMON=new HashSet<>(Arrays.asList("yes","no","well","hey","oh","okay","ok","look","wait","listen","please","sorry","really","seriously","so","but","now","then","suddenly","however","run","stop","help","thanks","hello","goodbye","what","why","how","who","where","when","if","i","you","we","they","he","she","it","everyone","someone","anyone","anything","something","everything","nothing","crazy","stupid","sir","madam","father","mother","mom","dad","dear","later","by","nice","glad","back","again","tomorrow","today","here","there","soon","sometime","maybe","only","first","last","dead","alive","ready","happy","home"));
 private static List<String> honorificNames(String text){
  List<String> names=new ArrayList<>();
  Matcher m=Pattern.compile("(?iu)\\b(?:mr|mrs|ms|dr)\\.\\s+([\\p{Lu}][\\p{L}’'\\-]{1,30})(?=[,!? .]|$)").matcher(text);
  while(m.find()){String name=m.group(1);if(Character.isUpperCase(name.codePointAt(0))&&!Arrays.asList("president","king","queen","doctor","sir","the","and").contains(name.toLowerCase(Locale.ROOT)))names.add(name);}
  return names;
 }
 public static List<String> discover(List<String> texts){
  LinkedHashSet<String> found=new LinkedHashSet<>();
  for(String raw:texts){
   found.addAll(honorificNames(raw));
   String text=raw.replaceAll("\\s+"," ").trim();
   // Strong, bounded introductions and vocatives only; ALL CAPS alone is not evidence.
   Matcher introduced=Pattern.compile("(?iu)\\b(?:my name is|i am called|(?:sword|weapon|relic|artifact|city|village|kingdom|item) (?:is )?(?:called|named))\\s+[\"“]?([\\p{L}][\\p{L}’'\\-]{1,25}(?: [\\p{L}][\\p{L}’'\\-]{1,25}){0,2})").matcher(text);
   while(introduced.find()){StringBuilder term=new StringBuilder();for(String word:introduced.group(1).split(" ")){if(COMMON.contains(word.toLowerCase(Locale.ROOT))||Arrays.asList("and","the","is","was","from","but","a","an","of","in","on","at","for","to","with","because").contains(word.toLowerCase(Locale.ROOT)))break;if(term.length()>0)term.append(' ');term.append(word);}if(term.length()>1)found.add(term.toString());}
   Matcher addressed=Pattern.compile("(?iu)^([\\p{L}][\\p{L}’'\\-]{1,25}),\\s+(?:you|if you|if one|are you|do you|did you|can you|will you|where|why|what|how)\\b").matcher(text.trim());
   if(addressed.find()&&!COMMON.contains(addressed.group(1).toLowerCase(Locale.ROOT)))found.add(addressed.group(1));
   Matcher greeting=Pattern.compile("(?iu)\\b(?:hey|hello|thanks|thank you|goodbye)[,!]?\\s+([\\p{L}][\\p{L}’'\\-]{1,25})[,.!?](?:\\s|$)").matcher(text);
   while(greeting.find())if(!COMMON.contains(greeting.group(1).toLowerCase(Locale.ROOT)))found.add(greeting.group(1));
   if(OcrQuality.dictionaryReady()){Matcher place=Pattern.compile("(?iu)\\bthe\\s+([\\p{L}][\\p{L}’'\\-]{1,30})\\s+(?:kingdom|empire|city|village|cult|sect|clan|guild)\\b").matcher(text);while(place.find()){String word=place.group(1);if(Character.isUpperCase(word.codePointAt(0))&&!OcrQuality.knownWord(word)&&!COMMON.contains(word.toLowerCase(Locale.ROOT)))found.add(word);}}
   Matcher quotedName=Pattern.compile("(?iu)[\"‘“']([\\p{L}][\\p{L}’'\\-]{1,30})[\"’”']\\s*(?:\\.{2,}|…+)[?7]?\\s*(?:could|can)\\s+it\\s+be\\b").matcher(text);while(quotedName.find()){String word=quotedName.group(1);if(Character.isUpperCase(word.codePointAt(0))&&!COMMON.contains(word.toLowerCase(Locale.ROOT)))found.add(word);}
   Matcher ofPlace=Pattern.compile("(?iu)\\b(?:kingdom|empire|city|village)\\s+of\\s+([\\p{L}][\\p{L}’'\\-]{1,30})\\b").matcher(text);while(ofPlace.find()){String word=ofPlace.group(1);if(Character.isUpperCase(word.codePointAt(0))&&!COMMON.contains(word.toLowerCase(Locale.ROOT))&&!Arrays.asList("the","a","an","people","survivors","citizens","children").contains(word.toLowerCase(Locale.ROOT)))found.add(word);}
   // A quoted label used as the noun of a relative clause is a literal term,
   // unlike an arbitrary quoted sentence. Do not treat apostrophes as quotes.
   Matcher label=Pattern.compile("(?iu)\\bthe\\s+['\"‘“]([\\p{L}][\\p{L} ’'\\-]{1,62})['\"’”]\\s+(?:that|which)\\b").matcher(text);while(label.find())if(label.group(1).trim().split("\\s+").length<=5)found.add(label.group(1).trim());
  }
  found.removeIf(term->term.length()>64);
  return new ArrayList<>(found);
 }
}
