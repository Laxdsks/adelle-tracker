package com.komiklingo.app;

import java.util.*;
import java.util.function.*;

/** One provider decision per request; online failures never poison the Google cache. */
public final class TranslationRouter implements NameTranslation.Engine {
 private final BooleanSupplier online;private final NameTranslation.Engine google,offline;private final LongSupplier clock;private final Runnable fallback;
 private final LinkedHashMap<String,String> cache=new LinkedHashMap<>(128,.75f,true);
 private long blockedUntil=0,generation=0;private boolean onlineResult;
 public boolean onlineResult(){return onlineResult;}
 public TranslationRouter(BooleanSupplier online,NameTranslation.Engine google,NameTranslation.Engine offline,LongSupplier clock,Runnable fallback){this.online=online;this.google=google;this.offline=offline;this.clock=clock;this.fallback=fallback;}
 private static boolean cacheable(String source,String target){
  if(ReadingText.garbledTranslation(source,target)||TranslationQuality.suspicious(source,target))return false;
  var pattern=java.util.regex.Pattern.compile("(?i)ZXQ(?:NAMEX*|UNITX*)\\d+QXZ");var found=pattern.matcher(source);Map<String,Integer> a=new HashMap<>(),b=new HashMap<>();
  while(found.find())a.merge(found.group().toUpperCase(Locale.ROOT),1,Integer::sum);found=pattern.matcher(target);while(found.find())b.merge(found.group().toUpperCase(Locale.ROOT),1,Integer::sum);return a.equals(b);
 }
 public void cancel(){generation++;}
 public void clear(){cancel();cache.clear();}
 @Override public void translate(String source,NameTranslation.Result result){
  long token=++generation;
  NameTranslation.Result guarded=(value,error)->{if(token==generation)result.done(value,error);};
  if(!online.getAsBoolean()){onlineResult=false;offline.translate(source,guarded);return;}
  String saved=cache.get(source);if(saved!=null){onlineResult=true;guarded.done(saved,null);return;}
  if(clock.getAsLong()<blockedUntil){onlineResult=false;offline.translate(source,guarded);return;}
  google.translate(source,(value,error)->{
   if(token!=generation)return;
   if(error==null&&value!=null&&!value.trim().isEmpty()){
    onlineResult=true;if(cacheable(source,value))cache.put(source,value);if(cache.size()>128)cache.remove(cache.keySet().iterator().next());guarded.done(value,null);
   }else{onlineResult=false;long now=clock.getAsLong(),delay=error instanceof TranslationUnavailable?((TranslationUnavailable)error).retryAfterMillis:30000;blockedUntil=delay>Long.MAX_VALUE-now?Long.MAX_VALUE:now+delay;fallback.run();offline.translate(source,guarded);}
  });
 }
}
