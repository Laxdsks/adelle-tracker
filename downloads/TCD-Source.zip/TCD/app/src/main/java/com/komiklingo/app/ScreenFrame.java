package com.komiklingo.app;

import android.graphics.Bitmap;
import android.media.Image;
import java.nio.ByteBuffer;

/** Handles padded RGBA image rows; the caller owns and closes the Image. */
public final class ScreenFrame {
 public static Bitmap decode(Image image){
  if(image.getPlanes().length==0)throw new IllegalArgumentException("Frame kosong");
  Image.Plane plane=image.getPlanes()[0];int width=image.getWidth(),height=image.getHeight(),pixel=plane.getPixelStride(),row=plane.getRowStride();
  if(width<1||height<1||pixel!=4||row<width*4)throw new IllegalArgumentException("Format frame tidak didukung");
  Bitmap result=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);ByteBuffer input=plane.getBuffer().duplicate();
  try{
  // The final row need not include padding. Copy only visible bytes row by row.
  ByteBuffer packed=ByteBuffer.allocateDirect(width*height*4);
  int origin=input.position();for(int y=0;y<height;y++){int start=origin+y*row;if(start+width*4>input.limit()){throw new IllegalArgumentException("Frame belum lengkap");}input.position(start);input.limit(start+width*4);packed.put(input);input.limit(plane.getBuffer().limit());}
  packed.flip();result.copyPixelsFromBuffer(packed);return result;
  }catch(RuntimeException|OutOfMemoryError error){result.recycle();throw error;}
 }
}
