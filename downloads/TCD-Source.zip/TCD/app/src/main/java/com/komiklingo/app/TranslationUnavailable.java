package com.komiklingo.app;
import java.io.IOException;
/** Provider-requested backoff, bounded to avoid hot retry loops. */
public final class TranslationUnavailable extends IOException {
 public final long retryAfterMillis;
 public TranslationUnavailable(int status,String retryAfter){
  super("Google Translate HTTP "+status);long delay=status==429||status==302?300000:30000;
  if(retryAfter!=null)try{long seconds=Long.parseLong(retryAfter.trim());if(seconds>=0)delay=Math.max(delay,seconds>Long.MAX_VALUE/1000?Long.MAX_VALUE:seconds*1000);}catch(NumberFormatException ignored){
   try{long until=java.time.ZonedDateTime.parse(retryAfter,java.time.format.DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli();delay=Math.max(delay,until-System.currentTimeMillis());}catch(java.time.DateTimeException invalid){}
  }
  retryAfterMillis=delay;
 }
}
