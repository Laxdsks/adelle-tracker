package com.komiklingo.app;

import java.util.*;
import java.util.regex.*;

/** Source-supported word senses, before protected names are restored. No sentence invention. */
public final class DialogueMeaning {
 private static final Pattern BODY=Pattern.compile("(?iu)\\b(?:body|bodies)\\b");
 private static final Pattern COLLECTION=Pattern.compile("(?iu)\\b(collection|gathering|retrieval|recovery)\\s+of\\s+(the\\s+)?bodies\\b");
 private static final Pattern BODY_HANDLING=Pattern.compile("(?iu)\\b(?:(?:collect|gather|recover)(?:ed|ing)?|retriev(?:e|ed|ing))\\s+(?:(?:the|their|his|her)\\s+)?bodies\\b|\\bbodies\\s+(?:(?:have|had|been|are|were|being|all)\\s+){0,4}(?:collected|gathered|recovered|retrieved)\\b|\\bdead\\s+(?:body|bodies)\\b");
 private static final Pattern FUNERAL=Pattern.compile("(?iu)\\b(?:funerals?|burials?|cremations?|corpses?|cadavers?|deceased|dead\\s+(?:body|bodies|people|soldiers?|victims?))\\b");
 private static final Pattern OTHER_BODY=Pattern.compile("(?iu)\\b(?:alive|living|live|unconscious|injured|survivors?|swimming|fitness|bodybuilding|celestial|planetary|astronomical|geometric|car|vehicle|robot|doll|mannequin|insect|animal|metal|governing|legislative|regulatory)\\b|\\b(?:body|bodies)\\s+of\\s+(?:water|work|evidence|knowledge|law|text)\\b");
 private static final Pattern PURPOSE=Pattern.compile("(?iu)^\\s*(?:so\\s+that|in\\s+order\\s+that|in\\s+order\\s+to)\\b");
 private static final Pattern PLACE=Pattern.compile("(?iu)\\b(ZXQNAMEX*\\d+QXZ)\\s+(kingdom|empire|city|village)\\b");
 private static String bounded(String text){return text==null?"":text.substring(0,Math.min(700,text.length()));}
 private static boolean mortuary(String source,String next){
  Matcher body=BODY.matcher(source);if(!body.find()||body.find()||OTHER_BODY.matcher(source).find())return false;
  if(!COLLECTION.matcher(source).find()&&!BODY_HANDLING.matcher(source).find())return false;
  if(FUNERAL.matcher(source).find())return true;
  // An adjacent purpose clause can disambiguate collection of bodies. An unrelated
  // funeral elsewhere on the page must not turn an ordinary body into a corpse.
  String following=bounded(next);return PURPOSE.matcher(following).find()&&FUNERAL.matcher(following).find();
 }
 public static String normalize(String source,String next){
  return normalize(source,"",next);
 }
 public static String normalize(String source,String previous,String next){
  source=source.replaceAll("(?iu)\\bthe\\s+(ZXQNAMEX*\\d+QXZ)\\s+cult['’]s\\s+spies\\b", "the spies of the $1 cult");
  if(Pattern.compile("(?iu)\\b(?:spies|infiltrators|agents)\\b").matcher(source).find()){
   source=source.replaceAll("(?iu)\\broot\\s+out\\b", "find and eliminate");
   source=source.replaceAll("(?iu)\\brooted\\s+out\\b", "found and eliminated");
  }
  if(Pattern.compile("(?iu)\\b(?:army|troops|soldiers|strike force|assault unit|battalion)\\b").matcher(source).find())source=source.replaceAll("(?iu)\\bwipe\\s+out\\b", "defeat completely");
  source=source.replaceAll("(?iu)\\bstrike\\s+force\\b", "assault unit");
  source=ConversationMeaning.normalize(source,previous);
  source=source.replaceAll("(?iu)\\bin\\s+none\\s+other\\s+than\\b", "specifically in");
  source=source.replaceAll("(?iu)\\bheading\\s+(a|the)\\s+(coalition|alliance|delegation|committee)\\b", "leading $1 $2");
  if(Pattern.compile("(?iu)\\b(?:coalition|alliance|diplomacy|political|negotiations)\\b").matcher(source).find()&&!Pattern.compile("(?iu)\\b(?:weather|rain|temperature|tropical|arctic)\\b").matcher(source).find())source=source.replaceAll("(?iu)\\bin\\s+this\\s+climate\\b", "in this situation");
  // Exclamatory question intensifier; literal locations such as "life on Earth" stay intact.
  source=source.replaceAll("(?iu)\\b(how|why|what|who|where|when)\\s+on\\s+earth\\b", "$1");
  if(!mortuary(source,next))return source;
  Matcher collection=COLLECTION.matcher(source);StringBuffer out=new StringBuffer();
  while(collection.find())collection.appendReplacement(out,Matcher.quoteReplacement("gathering of "+(collection.group(2)==null?"":"the ")+"dead bodies"));
  collection.appendTail(out);return out.toString();
 }
 public static String polish(String source,String next,String target){
  return polish(source,"",next,target);
 }
 public static String polish(String source,String previous,String next,String target){
  if(target==null)return "";String result=ConversationMeaning.polish(source,previous,target);
  if(mortuary(source,next)){
   if(COLLECTION.matcher(source).find())result=Pattern.compile("(?iu)\\b(?:koleksi|pengoleksian)(?:\\s+dari)?\\s+(?:tubuh|badan|jenazah)(?:-(?:tubuh|badan|jenazah))?(nya)?\\b").matcher(result).replaceAll("pengumpulan jenazah$1");
   result=Pattern.compile("(?iu)\\b(?:tubuh|badan)(?:-(?:tubuh|badan))?(?:\\s+(?:orang\\s+)?(?:yang\\s+)?(?:mati|meninggal))?(nya)?\\b").matcher(result).replaceAll("jenazah$1");
  }
  if(Pattern.compile("(?iu)\\bstrike\\s+force\\b").matcher(source).find())result=result.replaceAll("(?iu)\\b(?:kekuatan|pasukan)\\s+pemogokan\\b", "pasukan penyerbu");
  Matcher order=Pattern.compile("(?iu)\\b(\\d+)(?:st|nd|rd|th)\\s+order\\s+strike\\s+force\\b").matcher(source);
  while(order.find())result=result.replaceAll("(?iu)\\b(?:urutan|perintah)\\s+ke[- ]?"+order.group(1)+"\\b", "Ordo ke-"+order.group(1));
  // Reorder only a known name marker attached to this place type in this source.
  // A whole protected title, an ordinary noun or a different name is untouched.
  Matcher place=PLACE.matcher(source);
  while(place.find()){
   String noun;switch(place.group(2).toLowerCase(Locale.ROOT)){case "kingdom":noun="kerajaan";break;case "empire":noun="kekaisaran";break;case "city":noun="kota";break;default:noun="desa";}
   result=Pattern.compile("(?iu)\\b"+Pattern.quote(place.group(1))+"\\s+("+noun+")\\b").matcher(result).replaceAll("$1 "+Matcher.quoteReplacement(place.group(1)));
  }
  return result;
 }
 private DialogueMeaning(){}
}
