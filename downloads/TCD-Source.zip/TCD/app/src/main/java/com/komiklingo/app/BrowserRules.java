package com.komiklingo.app;
import java.net.*;
import java.util.*;

/** Small built-in network list. No remote list fetches or TLS interception. */
public final class BrowserRules {
 private static final Set<String> BLOCKED=new HashSet<>(Arrays.asList(
  "doubleclick.net","googlesyndication.com","googleadservices.com","adservice.google.com","google-analytics.com","googletagmanager.com",
  "adnxs.com","adsrvr.org","criteo.com","criteo.net","taboola.com","outbrain.com","scorecardresearch.com","quantserve.com",
  "hotjar.com","hotjar.io","clarity.ms","popads.net","popcash.net","propellerads.com","monetag.com","adsterra.com",
  "exoclick.com","exosrv.com","trafficjunky.net","trafficstars.com","juicyads.com","adskeeper.com","mgid.com","revcontent.com"));
 public static String https(String input){
  if(input==null||input.length()>2000||!input.equals(input.trim())||input.matches("(?s).*\\s.*"))throw new IllegalArgumentException();
  try{URI u=new URI(input);String scheme=u.getScheme(),host=u.getHost();if(host==null||host.isEmpty()||u.getUserInfo()!=null||(!"https".equalsIgnoreCase(scheme)&&!"http".equalsIgnoreCase(scheme))||host.equalsIgnoreCase("reader.invalid"))throw new IllegalArgumentException();
   return ("http".equalsIgnoreCase(scheme)?"https"+input.substring(input.indexOf(':')):input).replaceFirst("(?i)^https:","https:");
  }catch(URISyntaxException error){throw new IllegalArgumentException();}
 }
 public static String host(String input){try{String host=new URI(https(input)).getHost().toLowerCase(Locale.ROOT);while(host.endsWith("."))host=host.substring(0,host.length()-1);return host;}catch(Exception error){return "";}}
 public static boolean tracker(String input){String host=host(input);if(host.isEmpty())return false;for(String blocked:BLOCKED)if(host.equals(blocked)||host.endsWith("."+blocked))return true;return false;}
 public static boolean blockResource(String target,String page){return !host(target).equals(host(page))&&tracker(target);}
 public static final String COSMETIC_SCRIPT="(()=>{if(document.getElementById('tcd-ad-style'))return;const s=document.createElement('style');s.id='tcd-ad-style';s.textContent='ins.adsbygoogle,.adsbygoogle,[id^=\"google_ads_iframe\"],[id^=\"div-gpt-ad\"]{display:none!important}';(document.head||document.documentElement).appendChild(s)})()";
 private BrowserRules(){}
}
