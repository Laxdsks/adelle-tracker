package com.komiklingo.app;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import org.json.*;

/** Public Google Translate web endpoint. No API key, image, URL, cookie or device ID is sent. */
public final class GoogleTranslateHttp {
 public static URL url(String source)throws IOException{
  if(source==null||source.trim().isEmpty()||source.length()>4600)throw new IOException("Ukuran teks tidak didukung");
  return new URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=id&dt=t&q="+URLEncoder.encode(source,StandardCharsets.UTF_8.name()));
 }
 public static String read(HttpURLConnection connection)throws IOException{
  connection.setConnectTimeout(2500);connection.setReadTimeout(3500);connection.setUseCaches(false);connection.setInstanceFollowRedirects(false);
  connection.setRequestProperty("Accept","application/json");connection.setRequestProperty("User-Agent","TCD/0.5.0 (Android)");
  int status=connection.getResponseCode();if(status!=200)throw new TranslationUnavailable(status,connection.getHeaderField("Retry-After"));
  ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream input=connection.getInputStream()){
   byte[] buffer=new byte[4096];int n;while((n=input.read(buffer))!=-1){if(bytes.size()+n>131072)throw new IOException("Respons terlalu besar");bytes.write(buffer,0,n);}
  }
  try{return decode(bytes.toString(StandardCharsets.UTF_8.name()));}catch(JSONException error){throw new IOException("Respons terjemahan tidak dikenali",error);}
 }
 public static String decode(String json)throws JSONException{
  JSONArray segments=new JSONArray(json).getJSONArray(0);StringBuilder text=new StringBuilder();
  for(int i=0;i<segments.length();i++){JSONArray segment=segments.getJSONArray(i);if(segment.length()<2||!(segment.opt(0) instanceof String)||!(segment.opt(1) instanceof String))throw new JSONException("Missing translation segment");text.append(segment.getString(0));}
  if(text.toString().trim().isEmpty())throw new JSONException("Empty translation");return text.toString();
 }
 private GoogleTranslateHttp(){}
}
