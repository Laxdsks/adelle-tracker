package com.komiklingo.app;

import java.util.*;
import java.util.regex.*;

/** Source-gated entry verbs. Particles are interpreted with their actor and complement. */
public final class PhrasalVerbs {
 private static final String ACTOR="(?:i|you|he|she|we|they|ZXQNAMEX*\\d+QXZ)";
 private static final String AUX="(?:do|does|did|have|has|had|am|is|are|was|were|will|would|can|could|may|might|must|should|shall|not|never|just|already|suddenly|abruptly|finally|always|often)";
 private static final Pattern ENTRY=Pattern.compile("(?iu)\\b("+ACTOR+")\\s+((?:"+AUX+"\\s+){0,4})(burst|bursts|bursting|barge|barges|barged|barging)\\s+(in|into)\\b");
 private static final Pattern ROOM=Pattern.compile("(?iu)^\\s+(?:(?:the|a|an|my|your|his|her|our|their)\\s+)?(?:room|house|home|office|hall|hallway|building|chamber|castle|shop|inn|tavern|tent|cabin|store|classroom|church|temple|palace|prison|cell|laboratory)\\b");
 private static final Pattern OTHER_IN=Pattern.compile("(?iu)^\\s+(?:(?:a|an|the)\\s+)?(?:tears|flames|flame|fire|laughter|laughing|song|singing|anger|rage|half|two|pieces|unison|sync|sequence|explosion)\\b");
 private static final Pattern SPEECH=Pattern.compile("(?iu)\\b(?:conversation|discussion|interrupted|interrupting)\\b");
 private static final Pattern LITERAL_EXPLOSION=Pattern.compile("(?iu)\\b(?:explode|explodes|exploded|exploding|detonate|detonates|detonated|detonating)\\b");
 private static final Pattern BARE_IN=Pattern.compile("(?iu)^(?:\\s*$|\\s*[-–—,.!?;:…\"”’']|\\s+(?:now|then|here|there|today|yesterday|tomorrow|soon|earlier|later|and|but|while|when|before|after)\\b)");
 private static final Pattern TEMPORAL=Pattern.compile("(?iu)\\b(?:by\\s+the\\s+time|when|as\\s+soon\\s+as|once)\\b[^.!?;…]*[-–—]\\s*$");
 private static final Pattern NEXT_CLAUSE=Pattern.compile("(?iu)^\\s*(?:it|i|you|he|she|we|they|this|that|ZXQNAMEX*\\d+QXZ)\\s+(?:had|has|have|was|were|is|are|did|do|does|will|would|can|could|must|may|might)\\b");
 private static final Pattern EXPANDED_ENTRY=Pattern.compile("(?iu)\\b"+ACTOR+"\\s+(?:"+AUX+"\\s+){0,4}(?:enter|enters|entered|entering)\\s+(?:abruptly|without permission)\\b");
 private static boolean entry(String source,Matcher match){
  String tail=source.substring(match.end());if(match.group(4).equalsIgnoreCase("into"))return ROOM.matcher(tail).find();
  return !OTHER_IN.matcher(tail).find()&&!SPEECH.matcher(source).find()&&(BARE_IN.matcher(tail).find()||ROOM.matcher(tail).find());
 }
 private static String expansion(String source,Matcher match){
  String verb=match.group(3).toLowerCase(Locale.ROOT),aux=match.group(2).toLowerCase(Locale.ROOT);String form;
  if(verb.endsWith("ing"))form="entering";
  else if(verb.equals("bursts")||verb.equals("barges"))form="enters";
  else if(verb.equals("barged")||aux.matches("(?s).*\\b(?:have|has|had)\\b.*"))form="entered";
  else if(aux.matches("(?s).*\\b(?:do|does|did|will|would|can|could|may|might|must|should|shall)\\b.*"))form="enter";
  else if(verb.equals("barge"))form="enter";
  else{
   // Bare burst has identical present/past spelling; do not guess its tense.
   String before=source.substring(Math.max(0,match.start()-120),match.start());
   if(Pattern.compile("(?iu)\\bby\\s+the\\s+time\\s*$").matcher(before).find()&&Pattern.compile("(?iu)\\b(?:was|were|had|did|yesterday)\\b").matcher(before).find()&&!Pattern.compile("(?iu)\\b(?:tomorrow|will|shall|always|often)\\b").matcher(source).find())form="entered";else return null;
  }
  String manner=verb.startsWith("barg")?"without permission":"abruptly";
  return match.group(1)+" "+match.group(2)+form+" "+manner+(match.group(4).equalsIgnoreCase("into")||ROOM.matcher(source.substring(match.end())).find()?" into":"");
 }
 public static String normalize(String source){
  Matcher match=ENTRY.matcher(source);StringBuffer result=new StringBuffer();
  while(match.find()){if(!entry(source,match))continue;String expanded=expansion(source,match);if(expanded!=null)match.appendReplacement(result,Matcher.quoteReplacement(expanded));}
  match.appendTail(result);return result.toString();
 }
 public static boolean continues(String left,String right){
  Matcher phrase=ENTRY.matcher(left+" "+right);while(phrase.find())if(phrase.start()<left.length()&&phrase.end()>left.length()&&entry(left+" "+right,phrase))return true;return false;
 }
 public static boolean temporalEntry(String source){
  if(!Pattern.compile("(?iu)^\\s*(?:by\\s+the\\s+time|when|as\\s+soon\\s+as|once)\\b").matcher(source).find())return false;
  Matcher phrase=ENTRY.matcher(source);while(phrase.find())if(entry(source,phrase))return true;return false;
 }
 /** Keep a clearly signalled temporal clause connected, without merging display boxes. */
 public static String withNextClause(String input,String next){
  boolean complete=EXPANDED_ENTRY.matcher(input).find();Matcher phrase=ENTRY.matcher(input);while(!complete&&phrase.find())complete=entry(input,phrase);
  return complete&&TEMPORAL.matcher(input).find()&&NEXT_CLAUSE.matcher(next).find()?input.replaceFirst("[-–—]\\s*$",","):input;
 }
 private static String actor(String source){
  switch(source.toLowerCase(Locale.ROOT)){case "i":return "(?:aku|saya)";case "you":return "(?:kamu|anda|kau|engkau)";case "he":case "she":return "(?:dia|ia)";case "we":return "(?:kami|kita)";case "they":return "mereka";default:return Pattern.quote(source);}
 }
 public static String polish(String source,String translated){
  if(LITERAL_EXPLOSION.matcher(source).find())return translated;String result=translated;Matcher phrase=ENTRY.matcher(source);
  while(phrase.find()){
   if(!entry(source,phrase))continue;
   Pattern wrong=Pattern.compile("(?iu)\\b("+actor(phrase.group(1))+"\\s+(?:(?:sudah|telah|akan|belum|tidak|tak|baru|saja|tiba-tiba)\\s+){0,4})(?:meledak|meletus)\\b");
   result=wrong.matcher(result).replaceAll("$1menerobos masuk");
  }return result;
 }
 private PhrasalVerbs(){}
}
