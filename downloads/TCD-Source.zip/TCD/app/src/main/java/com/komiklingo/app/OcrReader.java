package com.komiklingo.app;

import android.graphics.*;
import android.os.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.*;
import java.util.*;
import java.util.concurrent.Executor;
import java.util.function.BooleanSupplier;

/** Bounded contrast and normalized crop passes; all geometry returns to original screenshot space. */
public final class OcrReader {
 public interface Result {void success(Text text);void failure(Exception error);}
 private static float confidence(Text.TextBlock block){float sum=0,total=0;for(Text.Line line:block.getLines()){int length=line.getText().length();sum+=(line.getConfidence()>0?line.getConfidence():.8f)*length;total+=length;}return total==0?0:sum/total;}
 private static float lineSize(Text.TextBlock block){List<Integer> sizes=new ArrayList<>();for(Text.Line line:block.getLines())if(line.getBoundingBox()!=null)sizes.add(line.getBoundingBox().height());if(sizes.isEmpty())return 0;Collections.sort(sizes);return sizes.get(sizes.size()/2);}
 private static boolean difficult(Text.TextBlock block){return confidence(block)<.68||OcrQuality.suspiciousSyntax(block.getText())||OcrQuality.ambiguousShort(block.getText())||OcrQuality.mixedGlyphs(block.getText())||(OcrQuality.caps(block.getText())&&(lineSize(block)>65||OcrQuality.knownRatio(block.getText())<.84));}
 public static boolean weak(Text text){if(text.getText().replaceAll("[^A-Za-z]","").length()<5)return true;for(Text.TextBlock block:text.getTextBlocks())if(difficult(block))return true;return false;}
 public static void read(TextRecognizer recognizer,Bitmap original,Executor worker,BooleanSupplier active,Result callback){read(recognizer,original,worker,active,Collections.emptyList(),callback);}
 public static void read(TextRecognizer recognizer,Bitmap original,Executor worker,BooleanSupplier active,List<String> names,Result callback){
  recognizer.process(InputImage.fromBitmap(original,0)).addOnSuccessListener(first->{
   if(!active.getAsBoolean()||!weak(first)){callback.success(first);return;}
   List<Text.TextBlock> difficult=new ArrayList<>();for(Text.TextBlock block:first.getTextBlocks())if(block.getBoundingBox()!=null&&difficult(block))difficult.add(block);
   difficult.sort(Comparator.comparingDouble(block->OcrQuality.score(block.getText(),confidence(block))));if(difficult.size()>4)difficult=new ArrayList<>(difficult.subList(0,4));
   if(difficult.isEmpty()){contrastRead(recognizer,original,worker,active,first,callback);return;}
   retryRegion(recognizer,original,worker,active,names,first,difficult,0,0,callback);
  }).addOnFailureListener(callback::failure);
 }
 /** Live mode only refines stable dialogue, with at most three uncertain lines. */
 public static void refineLive(TextRecognizer recognizer,Bitmap original,Text first,Executor worker,BooleanSupplier active,List<String> names,Result callback){
  List<Text.Line> uncertain=new ArrayList<>();
  for(Text.TextBlock block:first.getTextBlocks())for(Text.Line line:block.getLines())
   if(line.getBoundingBox()!=null&&OcrQuality.uncertainLine(line.getText(),line.getConfidence(),names))uncertain.add(line);
  uncertain.sort(Comparator.comparingDouble(line->OcrQuality.score(line.getText(),line.getConfidence()>0?line.getConfidence():.8)));
  if(uncertain.size()>3)uncertain=new ArrayList<>(uncertain.subList(0,3));
  retryLines(recognizer,original,worker,active,names,first,uncertain,0,0,callback);
 }
 private static void retryRegion(TextRecognizer recognizer,Bitmap original,Executor worker,BooleanSupplier active,List<String> names,Text current,List<Text.TextBlock> regions,int region,int pass,Result callback){
  if(!active.getAsBoolean()){callback.success(current);return;}
  if(region>=regions.size()){
   List<Text.Line> uncertain=new ArrayList<>();for(Text.TextBlock block:current.getTextBlocks())for(Text.Line line:block.getLines())if(line.getBoundingBox()!=null&&(OcrQuality.suspiciousSyntax(line.getText())||OcrQuality.knownRatio(line.getText())<.84||OcrQuality.mixedGlyphs(line.getText())||OcrQuality.ambiguousShort(line.getText())))uncertain.add(line);
   uncertain.sort(Comparator.comparingDouble(line->OcrQuality.score(line.getText(),line.getConfidence()>0?line.getConfidence():.8)));if(uncertain.size()>6)uncertain=new ArrayList<>(uncertain.subList(0,6));
   retryLines(recognizer,original,worker,active,names,current,uncertain,0,0,callback);return;
  }
  worker.execute(()->{
   Crop prepared;try{prepared=normalized(original,regions.get(region),pass==0?0:pass==1?.30f:-.30f);if(pass>0)prepared=rescale(prepared,1.4f);}catch(OutOfMemoryError|RuntimeException error){new Handler(Looper.getMainLooper()).post(()->retryRegion(recognizer,original,worker,active,names,current,regions,region+1,0,callback));return;}
   final Crop crop=prepared;new Handler(Looper.getMainLooper()).post(()->{
    if(!active.getAsBoolean()){crop.bitmap.recycle();callback.success(current);return;}
    recognizer.process(InputImage.fromBitmap(crop.bitmap,0)).addOnSuccessListener(result->{crop.bitmap.recycle();Text mapped=map(result,crop.inverse);Text merged=merge(current,mapped,names,false);retryRegion(recognizer,original,worker,active,names,merged,regions,pass<2?region:region+1,pass<2?pass+1:0,callback);}).addOnFailureListener(error->{crop.bitmap.recycle();retryRegion(recognizer,original,worker,active,names,current,regions,region+1,0,callback);});
   });
  });
 }
 private static Text.TextBlock single(Text.Line line){return new Text.TextBlock(line.getText(),line.getBoundingBox(),Collections.emptyList(),line.getRecognizedLanguage(),new Matrix(),Collections.singletonList(line));}
 private static void retryLines(TextRecognizer recognizer,Bitmap original,Executor worker,BooleanSupplier active,List<String> names,Text current,List<Text.Line> lines,int at,int pass,Result callback){
  if(!active.getAsBoolean()||at>=lines.size()){callback.success(current);return;}
  worker.execute(()->{TessFallback.Read read=null;try{read=TessFallback.read(original,lines.get(at).getBoundingBox());}catch(RuntimeException|LinkageError|OutOfMemoryError ignored){}Text improved=current;
   if(read!=null){Text.Line source=lines.get(at);Text.Line candidate=new Text.Line(read.text,source.getBoundingBox(),points(source.getCornerPoints(),new Matrix()),source.getRecognizedLanguage(),new Matrix(),source.getElements(),read.confidence,source.getAngle());improved=replaceLine(current,new Text(read.text,Collections.singletonList(single(candidate))),source,names);}
   final Text result=improved;new Handler(Looper.getMainLooper()).post(()->retryLines(recognizer,original,worker,active,names,result,lines,at+1,0,callback));
  });
 }
 private static Text replaceLine(Text current,Text recognized,Text.Line target,List<String> names){
  List<Text.Line> candidates=new ArrayList<>();for(Text.TextBlock block:recognized.getTextBlocks())for(Text.Line line:block.getLines())if(overlaps(line.getBoundingBox(),target.getBoundingBox()))candidates.add(line);
  if(candidates.isEmpty())return current;candidates.sort(Comparator.comparingInt(line->line.getBoundingBox().left));StringBuilder words=new StringBuilder();Rect rect=new Rect(candidates.get(0).getBoundingBox());List<Text.Element> elements=new ArrayList<>();float confidence=0;
  for(Text.Line line:candidates){if(words.length()>0)words.append(' ');words.append(line.getText());rect.union(line.getBoundingBox());elements.addAll(line.getElements());confidence+=line.getConfidence();}
  Text.Line candidate=new Text.Line(words.toString(),rect,Collections.emptyList(),"en",new Matrix(),elements,confidence/candidates.size(),0);List<Text.TextBlock> blocks=new ArrayList<>();
  for(Text.TextBlock block:current.getTextBlocks()){
   List<Text.Line> updated=new ArrayList<>();boolean changed=false;for(Text.Line line:block.getLines()){
    if(overlaps(line.getBoundingBox(),target.getBoundingBox())&&OcrQuality.better(line.getText(),confidence(single(line)),candidate.getText(),confidence(single(candidate)),names)){updated.add(candidate);changed=true;}else updated.add(line);
   }
   if(!changed){blocks.add(block);continue;}StringBuilder content=new StringBuilder();Rect bounds=new Rect(updated.get(0).getBoundingBox());for(Text.Line line:updated){if(content.length()>0)content.append('\n');content.append(line.getText());bounds.union(line.getBoundingBox());}blocks.add(new Text.TextBlock(content.toString(),bounds,Collections.emptyList(),block.getRecognizedLanguage(),new Matrix(),updated));
  }
  StringBuilder text=new StringBuilder();for(Text.TextBlock block:blocks){if(text.length()>0)text.append('\n');text.append(block.getText());}return new Text(text.toString(),blocks);
 }
 private static void contrastRead(TextRecognizer recognizer,Bitmap original,Executor worker,BooleanSupplier active,Text first,Result callback){
  worker.execute(()->{Bitmap enhanced;try{enhanced=contrast(original);}catch(OutOfMemoryError|RuntimeException error){new Handler(Looper.getMainLooper()).post(()->callback.success(first));return;}
   new Handler(Looper.getMainLooper()).post(()->{if(!active.getAsBoolean()){enhanced.recycle();callback.success(first);return;}recognizer.process(InputImage.fromBitmap(enhanced,0)).addOnSuccessListener(second->{enhanced.recycle();callback.success(merge(first,second));}).addOnFailureListener(error->{enhanced.recycle();callback.success(first);});});
  });
 }
 static final class Crop {final Bitmap bitmap;final Matrix inverse;Crop(Bitmap bitmap,Matrix inverse){this.bitmap=bitmap;this.inverse=inverse;}}
 static Crop normalized(Bitmap original,Text.TextBlock block,float shear){return normalized(original,block,shear,48);}
 static Crop normalized(Bitmap original,Text.TextBlock block,float shear,float targetHeight){
  Rect roi=new Rect(block.getBoundingBox());int pad=Math.round(Math.max(12,lineSize(block)*.4f));roi.inset(-pad,-pad);roi.intersect(0,0,original.getWidth(),original.getHeight());
  float scale=Math.min(3f,Math.max(.25f,targetHeight/Math.max(8,lineSize(block))));scale=Math.min(scale,1400f/(roi.width()+Math.abs(shear)*roi.height()));scale=Math.min(scale,(float)Math.sqrt(1800000.0/(roi.width()*(double)roi.height())));
  Matrix transform=new Matrix();transform.setValues(new float[]{scale,shear*scale,-scale*(roi.left+shear*roi.top+Math.min(0,shear*roi.height()))+16,0,scale,-scale*roi.top+16,0,0,1});
  int width=Math.max(1,(int)Math.ceil(scale*(roi.width()+Math.abs(shear)*roi.height()))+32),height=Math.max(1,(int)Math.ceil(scale*roi.height())+32);Bitmap target=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(target);
  int background=OcrAppearance.background(original,block.getBoundingBox());canvas.drawColor(background);Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);canvas.save();canvas.concat(transform);canvas.clipRect(roi);canvas.drawBitmap(original,0,0,paint);canvas.restore();Matrix inverse=new Matrix();if(!transform.invert(inverse))throw new IllegalArgumentException("Singular OCR crop");return new Crop(target,inverse);
 }
 private static Crop rescale(Crop crop,float factor){Bitmap resized=Bitmap.createScaledBitmap(crop.bitmap,Math.round(crop.bitmap.getWidth()*factor),Math.round(crop.bitmap.getHeight()*factor),true);Matrix inverse=new Matrix();inverse.setScale(1/factor,1/factor);inverse.postConcat(crop.inverse);if(resized!=crop.bitmap)crop.bitmap.recycle();return new Crop(resized,inverse);}
 private static Rect bounds(Rect rect,Matrix transform){RectF mapped=new RectF(rect);transform.mapRect(mapped);Rect result=new Rect();mapped.roundOut(result);return result;}
 private static List<Point> points(Point[] corners,Matrix transform){List<Point> result=new ArrayList<>();if(corners!=null)for(Point point:corners){float[] xy={point.x,point.y};transform.mapPoints(xy);result.add(new Point(Math.round(xy[0]),Math.round(xy[1])));}return result;}
 public static Text offset(Text source,int x,int y){Matrix transform=new Matrix();transform.setTranslate(x,y);return map(source,transform);}
 private static Text map(Text source,Matrix inverse){
  List<Text.TextBlock> blocks=new ArrayList<>();for(Text.TextBlock block:source.getTextBlocks()){
   if(block.getBoundingBox()==null)continue;List<Text.Line> lines=new ArrayList<>();for(Text.Line line:block.getLines()){
    if(line.getBoundingBox()==null)continue;List<Text.Element> elements=new ArrayList<>();for(Text.Element element:line.getElements())if(element.getBoundingBox()!=null)elements.add(new Text.Element(element.getText(),bounds(element.getBoundingBox(),inverse),points(element.getCornerPoints(),inverse),element.getRecognizedLanguage(),new Matrix(),element.getConfidence(),0,Collections.emptyList()));
    lines.add(new Text.Line(line.getText(),bounds(line.getBoundingBox(),inverse),points(line.getCornerPoints(),inverse),line.getRecognizedLanguage(),new Matrix(),elements,line.getConfidence(),0));
   }
   blocks.add(new Text.TextBlock(block.getText(),bounds(block.getBoundingBox(),inverse),points(block.getCornerPoints(),inverse),block.getRecognizedLanguage(),new Matrix(),lines));
  }return new Text(source.getText(),blocks);
 }
 public static Bitmap contrast(Bitmap source){Bitmap target=Bitmap.createBitmap(source.getWidth(),source.getHeight(),Bitmap.Config.ARGB_8888);ColorMatrix gray=new ColorMatrix();gray.setSaturation(0);ColorMatrix boost=new ColorMatrix(new float[]{1.65f,0,0,0,-55,0,1.65f,0,0,-55,0,0,1.65f,0,-55,0,0,0,1,0});gray.postConcat(boost);Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setColorFilter(new ColorMatrixColorFilter(gray));new Canvas(target).drawBitmap(source,0,0,paint);return target;}
 private static double quality(Text.TextBlock block){return OcrQuality.score(block.getText(),confidence(block))*Math.sqrt(block.getText().replaceAll("[^\\p{L}\\p{N}]","").length());}
 private static boolean overlaps(Rect a,Rect b){if(a==null||b==null)return false;Rect intersection=new Rect(a);return intersection.intersect(b)&&((long)intersection.width()*intersection.height())>.55*Math.min((long)a.width()*a.height(),(long)b.width()*b.height());}
 public static Text merge(Text first,Text second){return merge(first,second,Collections.emptyList());}
 private static Text merge(Text first,Text second,List<String> names){return merge(first,second,names,true);}
 private static Text merge(Text first,Text second,List<String> names,boolean allowNew){List<Text.TextBlock> blocks=new ArrayList<>(first.getTextBlocks());for(Text.TextBlock candidate:second.getTextBlocks()){
   List<Text.TextBlock> matches=new ArrayList<>();double previous=0,weight=0;StringBuilder old=new StringBuilder();for(Text.TextBlock block:blocks)if(overlaps(candidate.getBoundingBox(),block.getBoundingBox())){matches.add(block);int n=block.getText().length();previous+=confidence(block)*n;weight+=n;old.append(block.getText()).append(' ');}
   if(matches.isEmpty()?allowNew:OcrQuality.better(old.toString().trim(),previous/Math.max(1,weight),candidate.getText(),confidence(candidate),names)){blocks.removeAll(matches);blocks.add(candidate);}
  }blocks.sort(Comparator.comparingInt(block->block.getBoundingBox()==null?Integer.MAX_VALUE:block.getBoundingBox().top));StringBuilder content=new StringBuilder();for(Text.TextBlock block:blocks){if(content.length()>0)content.append('\n');content.append(block.getText());}return new Text(content.toString(),blocks);}
}
