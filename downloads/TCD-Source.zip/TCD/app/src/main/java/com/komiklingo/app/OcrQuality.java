package com.komiklingo.app;
import java.util.*;
import java.util.regex.*;
import java.io.*;

/** Recognition evidence only. Never replaces a word with a dictionary guess. */
public final class OcrQuality {
 private static final Set<String> CORE=new HashSet<>(Arrays.asList("do","did","does","don't","be","is","are","am","was","were","go","no","so","if","to","in","at","on","of","my","me","he","she","we","it","you","the","a","an","and","not","can","will","have","has","had"));
 private static volatile Set<String> words=Collections.emptySet();
 public static boolean dictionaryReady(){return !words.isEmpty();}
 public static boolean knownWord(String value){String word=value.toLowerCase(Locale.ROOT);return CORE.contains(word)||words.contains(word);}
 /** A reason to reread pixels, never permission to substitute a word. */
 public static boolean suspiciousSyntax(String text){return Pattern.compile("(?iu)\\bne\\s+(?:plan|want|need|will|can|must|have)\\b|\\b(?:ready|prepared)\\s+to\\s+moe\\b|['’][. …]{2,}\\s*7\\s+(?:could|can|is|are)\\b|(?:\\.{2,}|…+)\\s*p\\s*!\\s*$|\\b(?:nation|country)\\s+op\\s+the\\s+continent\\b|\\b(?:pate|fate)\\s+op\\s+the\\s+(?:continent|world|kingdom)\\b|\\bslacking\\s+ope\\b|\\bwait\\s+(?:po\\s+(?:the\\s+)?me|po\\s+theme)\\b|\\bthen\\s+ami\\s+to\\s+take\\s+it\\b").matcher(text).find();}
 public static synchronized void load(InputStream input)throws IOException{try(BufferedReader reader=new BufferedReader(new InputStreamReader(input,java.nio.charset.StandardCharsets.UTF_8))){if(!words.isEmpty())return;Set<String> loaded=new HashSet<>();String line;while((line=reader.readLine())!=null)loaded.add(line.trim());words=Collections.unmodifiableSet(loaded);}}
 public static double knownRatio(String text){
  Matcher tokens=Pattern.compile("[A-Za-z0-9]+(?:['’][A-Za-z]+)?").matcher(text);double known=0,total=0;
  while(tokens.find()){String word=tokens.group().toLowerCase(Locale.ROOT).replace('’','\'');if(word.matches("[0-9]+")){total++;known+=.85;continue;}total++;if(words.isEmpty()||CORE.contains(word))known++;else if(words.contains(word))known+=.85;}
  return total==0?0:known/total;
 }
 public static boolean mixedGlyphs(String text){return Pattern.compile("(?i)(?:[a-z]+[0-9]+[a-z0-9]*|[0-9]+[a-z]+)").matcher(text).find();}
 public static boolean ambiguousShort(String text){return Pattern.compile("\\b(?:PO|P0|D0|60|6O|G0|PON[’\']T)\\b").matcher(text).find();}
 /** A numeric/word switch needs the independent OCR pass, never just a spelling guess. */
 public static boolean numeralWordConflict(String first,String second){
  String[] a=first.toUpperCase(Locale.ROOT).split("[^A-Z0-9]+"),b=second.toUpperCase(Locale.ROOT).split("[^A-Z0-9]+");
  if(a.length!=b.length)return false;for(int i=0;i<a.length;i++)if(!a[i].equals(b[i])&&(a[i].matches("[0-9]+")&&b[i].matches("[A-Z]+")||b[i].matches("[0-9]+")&&a[i].matches("[A-Z]+"))&&glyphKey(a[i]).equals(glyphKey(b[i])))return true;return false;
 }
 private static String glyphKey(String text){return text.replace('0','O').replace('6','G').replace('5','S').replace('1','I').replace('8','B').replace('2','Z');}
 public static boolean caps(String text){String letters=text.replaceAll("[^A-Za-z]","");return letters.length()>5&&letters.equals(letters.toUpperCase(Locale.ROOT));}
 public static double score(String text,double confidence){return confidence*.60+knownRatio(text)*.40-(suspiciousSyntax(text)?.12:0);}
 public static boolean keepsNames(String original,String candidate,List<String> names){for(String name:names){Pattern match=Pattern.compile("(?iu)(?<![\\p{L}\\p{N}])"+Pattern.quote(name)+"(?![\\p{L}\\p{N}])");if(match.matcher(original).find()&&!match.matcher(candidate).find())return false;}return true;}
}
