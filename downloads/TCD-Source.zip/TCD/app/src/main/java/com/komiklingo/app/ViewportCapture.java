package com.komiklingo.app;

import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.PixelCopy;
import android.view.View;
import android.view.Window;
import android.webkit.WebView;
import java.util.concurrent.atomic.AtomicBoolean;

/** Copies the composited pixels the reader actually displays, including GPU WebView images. */
public final class ViewportCapture {
 public static final int NOT_VISIBLE=-1, NO_MEMORY=-2;
 public interface Callback { void success(Bitmap image,float scale); void failure(int reason); }
 public static void capture(Window window,View content,Callback callback){
  if(!content.isAttachedToWindow()||!content.isShown()){callback.failure(NOT_VISIBLE);return;}
  Handler handler=new Handler(Looper.getMainLooper());AtomicBoolean completed=new AtomicBoolean(false);
  Runnable timeout=()->{if(completed.compareAndSet(false,true))callback.failure(PixelCopy.ERROR_TIMEOUT);};
  handler.postDelayed(timeout,8000);
  Callback once=new Callback(){
   @Override public void success(Bitmap image,float scale){if(completed.compareAndSet(false,true)){handler.removeCallbacks(timeout);callback.success(image,scale);}else image.recycle();}
   @Override public void failure(int reason){if(completed.compareAndSet(false,true)){handler.removeCallbacks(timeout);callback.failure(reason);}}
  };
  Runnable frames=()->content.postOnAnimation(()->content.postOnAnimation(()->{if(!completed.get())copy(window,content,once,0);}));
  // WebView paints in another process. View animation callbacks alone do not
  // guarantee its new scroll tiles have reached the compositor.
  if(content instanceof WebView)((WebView)content).postVisualStateCallback(android.os.SystemClock.uptimeMillis(),new WebView.VisualStateCallback(){
   @Override public void onComplete(long requestId){if(!completed.get())frames.run();}
  });else frames.run();
 }
 private static void copy(Window window,View content,Callback callback,int attempt){
  int width=content.getWidth(),height=content.getHeight();
  if(!content.isAttachedToWindow()||!content.isShown()||width<1||height<1){callback.failure(NOT_VISIBLE);return;}
  float scale=(float)Math.min(Math.min(1.5f,2048f/width),Math.sqrt(8000000.0/((double)width*height)));
  Bitmap image;
  try{image=Bitmap.createBitmap(Math.max(1,Math.round(width*scale)),Math.max(1,Math.round(height*scale)),Bitmap.Config.ARGB_8888);}
  catch(OutOfMemoryError e){callback.failure(NO_MEMORY);return;}
  int[] offset=new int[2];content.getLocationInWindow(offset);
  Rect area=new Rect(offset[0],offset[1],offset[0]+width,offset[1]+height);
  try{
   PixelCopy.request(window,area,image,result->{
    if(result==PixelCopy.SUCCESS){callback.success(image,scale);return;}
    image.recycle();
    if(result==PixelCopy.ERROR_SOURCE_NO_DATA&&attempt==0)content.postDelayed(()->copy(window,content,callback,1),160);
    else callback.failure(result);
   },new Handler(Looper.getMainLooper()));
  }catch(IllegalArgumentException e){image.recycle();callback.failure(NOT_VISIBLE);}
 }
}
