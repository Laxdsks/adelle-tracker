package com.komiklingo.app;

/** Validate marker preservation; if an engine drops one, translate only non-name fragments. */
public final class NameTranslation {
 public interface Result { void done(String text,Exception error); }
 public interface Engine {
  void translate(String source,Result result);
  default boolean reusesTranslations(){return false;}
  default String cached(String key){return null;}
  default void remember(String key,String value){}
 }
 public static void translate(ProtectedTerms.Plan plan,Engine engine,Result result){
  engine.translate(plan.masked,(text,error)->{if(error==null&&plan.valid(text))result.done(text,null);else if(plan.names().isEmpty())result.done(null,error==null?new IllegalArgumentException("Hasil kosong"):error);else wholeSentenceRetry(plan,engine,result);});
 }
 public static void repair(ProtectedTerms.Plan plan,String raw,Engine engine,Result result){
  if(plan.valid(raw))result.done(raw,null);else if(plan.names().isEmpty())result.done(null,new IllegalArgumentException("Hasil kosong"));else wholeSentenceRetry(plan,engine,result);
 }
 /** Keep the full grammar on a second pass before resorting to isolated fragments. */
 private static void wholeSentenceRetry(ProtectedTerms.Plan plan,Engine engine,Result result){
  String quoted=plan.masked;for(String marker:plan.names().keySet())quoted=quoted.replace(marker,"\""+marker+"\"");
  engine.translate(quoted,(text,error)->{
   if(error==null&&plan.valid(text)){
    for(String marker:plan.names().keySet())text=text.replaceAll("(?i)[\"“]\\s*("+java.util.regex.Pattern.quote(marker)+")\\s*[\"”]", "$1");
    result.done(text,null);
   }else fragments(plan,engine,result,0,new StringBuilder());
  });
 }
 private static void fragments(ProtectedTerms.Plan plan,Engine engine,Result result,int index,StringBuilder output){
  if(index>=plan.pieces.size()){String value=output.toString();if(plan.valid(value))result.done(value,null);else result.done(null,new IllegalArgumentException("Nama gagal dipertahankan"));return;}
  ProtectedTerms.Piece part=plan.pieces.get(index);
  if(part.protectedName||!part.value.matches("(?s).*[\\p{L}].*")){output.append(part.value);fragments(plan,engine,result,index+1,output);return;}
  String lead=part.value.replaceFirst("(?s)\\S.*$","");String tail=part.value.replaceFirst("(?s)^.*\\S","");
  engine.translate(part.value.trim(),(translated,error)->{if(error!=null||translated==null||translated.trim().isEmpty()){result.done(null,error==null?new IllegalArgumentException("Hasil kosong"):error);return;}output.append(lead).append(translated.trim()).append(tail);fragments(plan,engine,result,index+1,output);});
 }
}
