package com.komiklingo.app;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.*;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.*;
import android.os.*;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import com.google.mlkit.nl.translate.*;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.*;
import java.util.concurrent.*;

/** Explicit projection session; only a user tap schedules OCR. Never stores screen images. */
public class FloatingTranslateService extends Service {
 public static final String STOP="com.komiklingo.app.STOP_FLOATING",GRANT="projection-grant",RESULT="projection-result";
 private static final String CHANNEL="tcd-screen-translation";private static final int NOTIFICATION=1707;
 private static volatile boolean running=false;
 public static boolean isRunning(){return running;}
 private final Handler main=new Handler(Looper.getMainLooper());private final ExecutorService worker=Executors.newSingleThreadExecutor();
 private HandlerThread captureThread;private Handler captureHandler;private WindowManager windows;private MediaProjection projection;private VirtualDisplay display;private volatile ImageReader reader;
 private TextRecognizer ocr;private Translator translator;private View bubble,menu,resultView;private WindowManager.LayoutParams bubblePosition;
 private ImageView bubbleImage;private ProgressBar bubbleProgress;private Bitmap snapshot;private List<OcrAppearance.Paragraph> paragraphs=Collections.emptyList();
 private List<String> sources=new ArrayList<>(),translations=new ArrayList<>();private volatile boolean destroyed=false;private boolean busy=false,ready=false;private volatile long generation=0,frameTicket=0;private volatile boolean waitingFrame=false;
 private int captureWidth=0,captureHeight=0,density=0;private BroadcastReceiver screenOff;
 // Used by isolated test subclasses; production always uses on-device ML Kit.
 protected void prepareLanguage(Runnable success,Runnable failure){translator.downloadModelIfNeeded().addOnSuccessListener(v->success.run()).addOnFailureListener(e->failure.run());}
 protected void translateSource(String text,NameTranslation.Result result){translator.translate(text).addOnSuccessListener(value->result.done(value,null)).addOnFailureListener(error->result.done(null,error));}
 protected void outcome(String value){} // Test subclasses observe outcomes, without production logging of screen text.
 @Override public void onCreate(){super.onCreate();windows=(WindowManager)getSystemService(WINDOW_SERVICE);captureThread=new HandlerThread("tcd-screen-frame");captureThread.start();captureHandler=new Handler(captureThread.getLooper());}
 @Override public int onStartCommand(Intent intent,int flags,int id){
  if(intent==null||STOP.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
  if(projection!=null)return START_NOT_STICKY;
  Intent grant=Build.VERSION.SDK_INT>=33?intent.getParcelableExtra(GRANT,Intent.class):intent.getParcelableExtra(GRANT);int result=intent.getIntExtra(RESULT,Activity.RESULT_CANCELED);
  if(result!=Activity.RESULT_OK||grant==null||!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY;}
  try{
   NotificationManager manager=getSystemService(NotificationManager.class);manager.createNotificationChannel(new NotificationChannel(CHANNEL,"Balon terjemahan TCD",NotificationManager.IMPORTANCE_LOW));
   Notification notification=notification("Menyiapkan balon. Ketuk untuk membuka TCD.");if(Build.VERSION.SDK_INT>=29)startForeground(NOTIFICATION,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);else startForeground(NOTIFICATION,notification);
   projection=((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).getMediaProjection(result,grant);
   if(projection==null)throw new SecurityException("No projection");
   projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){stopSelf();}@Override public void onCapturedContentResize(int width,int height){if(Build.VERSION.SDK_INT>=34)resizeCapture(width,height);}},main);
   setupCapture();running=true;showBubble();
   screenOff=new BroadcastReceiver(){@Override public void onReceive(Context context,Intent event){stopSelf();}};if(Build.VERSION.SDK_INT>=33)registerReceiver(screenOff,new IntentFilter(Intent.ACTION_SCREEN_OFF),Context.RECEIVER_NOT_EXPORTED);else registerReceiver(screenOff,new IntentFilter(Intent.ACTION_SCREEN_OFF));
   ocr=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);translator=Translation.getClient(new TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.INDONESIAN).build());
   worker.execute(()->{try{OcrQuality.load(getAssets().open("english-ocr-words.txt"));TessFallback.prepare(this);}catch(java.io.IOException ignored){}main.post(()->{if(destroyed)return;prepareLanguage(()->{if(destroyed)return;ready=true;refreshBubble();notifyStatus("Ketuk balon untuk menerjemahkan layar. Tahan untuk menu.");outcome("READY");},()->{if(!destroyed){toast("Model belum siap. Periksa internet dan aktifkan ulang balon.");stopSelf();}});});});
   toast("Buka aplikasi lain, lalu ketuk balon TCD. Tahan balon untuk menu.");
  }catch(RuntimeException error){toast("Balon belum bisa aktif. Periksa izin lalu mulai lagi dari TCD.");stopSelf();}
  return START_NOT_STICKY;
 }
 private Notification notification(String message){
  PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,FloatingSetupActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,getClass()).setAction(STOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  return new Notification.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_translation_status).setContentTitle("TCD · Balon terjemahan aktif").setContentText(message).setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true).addAction(new Notification.Action.Builder(null,"Hentikan",stop).build()).build();
 }
 private void notifyStatus(String message){if(!destroyed)getSystemService(NotificationManager.class).notify(NOTIFICATION,notification(message));}
 @SuppressWarnings("deprecation") private DisplayMetrics realMetrics(){DisplayMetrics metrics=new DisplayMetrics();windows.getDefaultDisplay().getRealMetrics(metrics);return metrics;}
 private void setupCapture(){DisplayMetrics metrics=realMetrics();density=metrics.densityDpi;setReader(metrics.widthPixels,metrics.heightPixels);display=projection.createVirtualDisplay("TCD translation",captureWidth,captureHeight,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,captureHandler);pauseCapture();}
 private void pauseCapture(){try{if(display!=null)display.setSurface(null);}catch(RuntimeException ignored){}}
 private void setReader(int width,int height){
  double scale=Math.min(1,Math.min(1440.0/Math.max(1,width),Math.sqrt(4000000.0/Math.max(1,(double)width*height))));captureWidth=Math.max(1,(int)Math.round(width*scale));captureHeight=Math.max(1,(int)Math.round(height*scale));
  reader=ImageReader.newInstance(captureWidth,captureHeight,PixelFormat.RGBA_8888,2);ImageReader current=reader;
  reader.setOnImageAvailableListener(available->{Image image=null;try{image=available.acquireLatestImage();if(image==null)return;if(!waitingFrame||destroyed||available!=reader)return;long ticket=frameTicket;waitingFrame=false;Bitmap bitmap=ScreenFrame.decode(image);main.post(()->{if(destroyed||current!=reader||ticket!=generation){bitmap.recycle();return;}pauseCapture();showBubble();recognize(bitmap,ticket);});}catch(RuntimeException|OutOfMemoryError error){waitingFrame=false;main.post(()->captureFailed("Cuplikan belum bisa dibaca. Coba lagi."));}finally{if(image!=null)image.close();}},captureHandler);
 }
 private void resizeCapture(int width,int height){
  if(destroyed||display==null||width<1||height<1)return;double scale=Math.min(1,Math.min(1440.0/width,Math.sqrt(4000000.0/((double)width*height))));if(captureWidth==Math.round(width*scale)&&captureHeight==Math.round(height*scale))return;
  generation++;main.removeCallbacks(frameTimeout);waitingFrame=false;busy=false;dismissResult();hideBubble();pauseCapture();if(reader!=null)reader.close();setReader(width,height);display.resize(captureWidth,captureHeight,density);showBubble();refreshBubble();outcome("RESIZED");
 }
 @Override public void onConfigurationChanged(Configuration configuration){super.onConfigurationChanged(configuration);if(projection!=null){DisplayMetrics metrics=realMetrics();resizeCapture(metrics.widthPixels,metrics.heightPixels);}}
 private WindowManager.LayoutParams params(int width,int height,int flags){WindowManager.LayoutParams layout=new WindowManager.LayoutParams(width,height,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,flags,PixelFormat.TRANSLUCENT);layout.gravity=Gravity.TOP|Gravity.LEFT;return layout;}
 private void showBubble(){if(destroyed||bubble!=null)return;try{
  FrameLayout tile=new FrameLayout(this);GradientDrawable background=new GradientDrawable();background.setColor(0xff0f172a);background.setCornerRadius(dp(28));background.setStroke(dp(1),0xffa3e635);tile.setBackground(background);
  bubbleImage=new ImageView(this);bubbleImage.setImageResource(R.drawable.tcd_balloon);bubbleImage.setContentDescription("TCD. Ketuk untuk terjemahkan layar. Tahan untuk menu.");tile.addView(bubbleImage,new FrameLayout.LayoutParams(-1,-1));bubbleProgress=new ProgressBar(this);FrameLayout.LayoutParams progress=new FrameLayout.LayoutParams(dp(18),dp(18),Gravity.BOTTOM|Gravity.RIGHT);tile.addView(bubbleProgress,progress);
  if(bubblePosition==null){bubblePosition=params(dp(58),dp(58),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);DisplayMetrics screen=realMetrics();bubblePosition.x=Math.max(0,screen.widthPixels-dp(70));bubblePosition.y=screen.heightPixels/3;}
  DisplayMetrics screenBounds=realMetrics();bubblePosition.x=Math.max(0,Math.min(screenBounds.widthPixels-dp(58),bubblePosition.x));bubblePosition.y=Math.max(dp(24),Math.min(screenBounds.heightPixels-dp(84),bubblePosition.y));
  bubble=tile;tile.setOnTouchListener(new View.OnTouchListener(){float x,y;int originalX,originalY;boolean moved,longPress;final Runnable hold=()->{longPress=true;showMenu();};@Override public boolean onTouch(View view,android.view.MotionEvent event){switch(event.getActionMasked()){
   case android.view.MotionEvent.ACTION_DOWN:x=event.getRawX();y=event.getRawY();originalX=bubblePosition.x;originalY=bubblePosition.y;moved=false;longPress=false;main.postDelayed(hold,550);return true;
   case android.view.MotionEvent.ACTION_MOVE:float dx=event.getRawX()-x,dy=event.getRawY()-y;if(Math.hypot(dx,dy)>dp(7)){moved=true;main.removeCallbacks(hold);}if(moved){DisplayMetrics screen=realMetrics();bubblePosition.x=Math.max(0,Math.min(screen.widthPixels-dp(58),originalX+Math.round(dx)));bubblePosition.y=Math.max(dp(24),Math.min(screen.heightPixels-dp(84),originalY+Math.round(dy)));try{windows.updateViewLayout(tile,bubblePosition);}catch(RuntimeException ignored){}}return true;
   case android.view.MotionEvent.ACTION_UP:main.removeCallbacks(hold);if(!moved&&!longPress)requestCapture();return true;
   case android.view.MotionEvent.ACTION_CANCEL:main.removeCallbacks(hold);return true;default:return true;}}});
  windows.addView(tile,bubblePosition);refreshBubble();
 }catch(RuntimeException error){bubble=null;stopSelf();}}
 private void refreshBubble(){if(bubbleProgress!=null)bubbleProgress.setVisibility(busy||!ready?View.VISIBLE:View.GONE);if(bubbleImage!=null)bubbleImage.setAlpha(busy?.5f:1f);}
 private void remove(View view){if(view!=null)try{windows.removeViewImmediate(view);}catch(RuntimeException ignored){}}
 private void hideBubble(){remove(bubble);bubble=null;bubbleProgress=null;bubbleImage=null;}
 private void showMenu(){if(menu!=null||destroyed)return;LinearLayout items=column();items.addView(label("TCD · Inggris → Indonesia",16));items.addView(button("Terjemahkan layar",v->{dismissMenu();requestCapture();}));items.addView(button("Lihat teks terakhir",v->{dismissMenu();showText();}));items.addView(button("Hentikan balon",v->stopSelf()));items.addView(button("Tutup menu",v->dismissMenu()));menu=items;var layout=params(dp(260),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);DisplayMetrics screen=realMetrics();layout.x=Math.max(dp(8),Math.min(screen.widthPixels-dp(268),bubblePosition.x-dp(200)));layout.y=Math.max(dp(24),Math.min(screen.heightPixels-dp(320),bubblePosition.y));try{windows.addView(menu,layout);}catch(RuntimeException error){menu=null;stopSelf();}}
 private void dismissMenu(){remove(menu);menu=null;}
 private final Runnable frameTimeout=()->{if(waitingFrame){waitingFrame=false;pauseCapture();captureFailed("Layar belum bisa ditangkap. Buka aplikasinya lalu coba lagi.");}};
 protected void requestCapture(){
  if(destroyed)return;if(!ready){toast("Model sedang disiapkan. Tunggu sebentar.");return;}if(busy){toast("Layar sedang diproses. Tahan balon jika ingin menghentikan.");return;}
  if(projection==null||display==null){stopSelf();return;}final long ticket=++generation;busy=true;dismissMenu();dismissResult();hideBubble();outcome("CAPTURING");
  main.postDelayed(()->{if(destroyed||!busy||ticket!=generation)return;try{Image stale=reader.acquireLatestImage();if(stale!=null)stale.close();frameTicket=ticket;waitingFrame=true;display.setSurface(reader.getSurface());main.postDelayed(frameTimeout,7000);}catch(RuntimeException error){captureFailed("Izin tangkap layar berakhir. Aktifkan lagi dari TCD.");stopSelf();}},250);
 }
 private void captureFailed(String message){if(destroyed)return;pauseCapture();busy=false;waitingFrame=false;main.removeCallbacks(frameTimeout);showBubble();refreshBubble();toast(message);outcome("FAILED");}
 private List<String> terms(){try{return ProtectedTerms.parse(getSharedPreferences("reader",MODE_PRIVATE).getString("floating-terms",""));}catch(IllegalArgumentException error){return new ArrayList<>();}}
 private void recognize(Bitmap bitmap,long ticket){
  main.removeCallbacks(frameTimeout);if(destroyed||ticket!=generation){bitmap.recycle();return;}
  notifyStatus("Membaca layar di HP…");List<String> names=terms();
  OcrReader.read(ocr,bitmap,worker,()->!destroyed&&ticket==generation,names,new OcrReader.Result(){@Override public void success(Text result){
   if(destroyed||ticket!=generation){bitmap.recycle();return;}worker.execute(()->{List<OcrAppearance.Paragraph> found=new ArrayList<>();
   for(OcrAppearance.Paragraph paragraph:OcrAppearance.readingParagraphs(bitmap,result,names,false)){if(!ContextMeaning.dangling(paragraph.source,names)&&paragraph.source.length()>=2&&paragraph.source.matches("(?s).*[A-Za-z].*")&&paragraph.bounds.width()>8&&paragraph.bounds.height()>7)found.add(paragraph);if(found.size()>=40)break;}
   if(found.size()>40)found=new ArrayList<>(found.subList(0,40));final List<OcrAppearance.Paragraph> appearance=found;main.post(()->{if(destroyed||ticket!=generation){bitmap.recycle();return;}if(appearance.isEmpty()){bitmap.recycle();busy=false;refreshBubble();toast("Tidak ada teks terbaca. Beberapa aplikasi melindungi layarnya.");notifyStatus("Ketuk balon untuk mencoba layar lain.");outcome("NO_TEXT");return;}
   List<String> raw=new ArrayList<>();for(var paragraph:appearance)raw.add(paragraph.source);List<String> known=new ArrayList<>(names);for(String name:ProtectedTerms.discover(raw))if(known.size()<80&&!contains(known,name))known.add(name);
   List<ProtectedTerms.Plan> plans=new ArrayList<>();int index=0;for(String source:raw){var plan=ProtectedTerms.prepare(ProtectedTerms.cleanOcr(source,known),known,index);plans.add(plan);index+=plan.names().size()+1;}
   TranslationFlow.translate(plans,FloatingTranslateService.this::translateSource,()->{if(destroyed||ticket!=generation){if(!bitmap.isRecycled())bitmap.recycle();return false;}return true;},(values,failures)->{
    sources=new ArrayList<>();translations=new ArrayList<>();String style=getSharedPreferences("reader",MODE_PRIVATE).getString("floating-style",ReadingText.DIALOGUE);
    for(int i=0;i<plans.size();i++){var plan=plans.get(i);sources.add(plan.source);String value=values.get(i);String translated="";if(plan.valid(value)){String adjusted=ReadingText.style(plan.source,value,style);if(plan.valid(adjusted))translated=ReadingText.emotion(plan.source,plan.restore(adjusted));}translations.add(translated);}
    busy=false;refreshBubble();snapshot=bitmap;paragraphs=appearance;notifyStatus("Hasil siap. Tutup hasil untuk kembali ke aplikasi.");showPicture();outcome("RESULT");
   });});});
  }@Override public void failure(Exception error){bitmap.recycle();if(destroyed||ticket!=generation)return;captureFailed("Teks belum bisa dibaca. Coba perbesar huruf di aplikasi asal.");}});
 }
 private static boolean contains(List<String> names,String name){for(String value:names)if(value.equalsIgnoreCase(name))return true;return false;}
 private void addResult(View view){dismissMenu();hideBubble();remove(resultView);resultView=view;WindowManager.LayoutParams layout=params(-1,-1,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);layout.softInputMode=WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING;view.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});view.setFocusableInTouchMode(true);view.setOnKeyListener((v,key,event)->{if(key==KeyEvent.KEYCODE_BACK&&event.getAction()==KeyEvent.ACTION_UP){closeResult();return true;}return false;});try{windows.addView(view,layout);view.requestFocus();}catch(RuntimeException error){closeResult();stopSelf();}}
 private void showPicture(){
  if(snapshot==null||snapshot.isRecycled()){showText();return;}LinearLayout page=column();page.setPadding(0,0,0,0);page.addView(label("TCD · Hasil layar. Tutup untuk menggulir aplikasi.",13));LinearLayout actions=row();BubbleOverlay translated=new BubbleOverlay(this);Button original=button("Asli",v->{boolean visible=translated.getVisibility()==View.VISIBLE;translated.setVisibility(visible?View.INVISIBLE:View.VISIBLE);((Button)v).setText(visible?"Indonesia":"Asli");});actions.addView(original,new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(button("Teks",v->showText()),new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(button("Ulang",v->{closeResult();requestCapture();}),new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(button("Tutup",v->closeResult()),new LinearLayout.LayoutParams(0,dp(48),1));page.addView(actions);
  FrameLayout picture=new FrameLayout(this);ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_CENTER);image.setImageBitmap(snapshot);picture.addView(image,new FrameLayout.LayoutParams(-1,-1));picture.addView(translated,new FrameLayout.LayoutParams(-1,-1));page.addView(picture,new LinearLayout.LayoutParams(-1,0,1));
  picture.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{if(snapshot==null||snapshot.isRecycled())return;float scale=Math.min(picture.getWidth()/(float)snapshot.getWidth(),picture.getHeight()/(float)snapshot.getHeight());float x=(picture.getWidth()-snapshot.getWidth()*scale)/2,y=(picture.getHeight()-snapshot.getHeight()*scale)/2;List<BubbleOverlay.Bubble> bubbles=new ArrayList<>();for(int i=0;i<paragraphs.size()&&i<translations.size();i++){String value=translations.get(i);if(value.isEmpty())continue;var source=paragraphs.get(i);RectF box=new RectF(source.bounds);box.inset(-4,-3);box.left=box.left*scale+x;box.right=box.right*scale+x;box.top=box.top*scale+y;box.bottom=box.bottom*scale+y;boolean caps=source.source.equals(source.source.toUpperCase(Locale.ROOT));bubbles.add(new BubbleOverlay.Bubble(box,caps?value.toUpperCase(new Locale("id")):value,source.background,caps,new BubbleOverlay.Appearance(source.ink,source.sourceSize*scale,source.leftAligned,source.italic)));}translated.show(bubbles);});addResult(page);
 }
 private void showText(){LinearLayout page=column();page.addView(label("TCD · Teks layar terakhir",18));LinearLayout actions=row();if(snapshot!=null)actions.addView(button("Gambar",v->showPicture()),new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(button("Tutup",v->closeResult()),new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(button("Hentikan",v->stopSelf()),new LinearLayout.LayoutParams(0,dp(48),1));page.addView(actions);ScrollView scroll=new ScrollView(this);LinearLayout list=column();if(translations.isEmpty())list.addView(label("Belum ada hasil. Tutup lalu ketuk balon untuk menerjemahkan.",16));for(int i=0;i<translations.size();i++){TextView source=label("Inggris: "+sources.get(i),14);source.setTextColor(0xff94a3b8);source.setTextIsSelectable(true);list.addView(source);TextView target=label(translations.get(i).isEmpty()?"Bagian ini belum berhasil diterjemahkan.":translations.get(i),19);target.setTextIsSelectable(true);target.setPadding(0,dp(6),0,dp(22));target.setLineSpacing(dp(2),1.15f);list.addView(target);}scroll.addView(list);page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));addResult(page);}
 private void dismissResult(){remove(resultView);resultView=null;if(snapshot!=null&&!snapshot.isRecycled())snapshot.recycle();snapshot=null;paragraphs=Collections.emptyList();}
 private void closeResult(){dismissResult();showBubble();refreshBubble();notifyStatus("Ketuk balon untuk menerjemahkan layar. Tahan untuk menu.");}
 private LinearLayout column(){LinearLayout view=new LinearLayout(this);view.setOrientation(LinearLayout.VERTICAL);view.setBackgroundColor(0xff0f172a);view.setPadding(dp(12),dp(12),dp(12),dp(12));return view;}
 private LinearLayout row(){LinearLayout view=new LinearLayout(this);view.setGravity(Gravity.CENTER_VERTICAL);return view;}
 private TextView label(String value,int size){TextView view=new TextView(this);view.setText(value);view.setTextSize(size);view.setTextColor(0xffe2e8f0);view.setPadding(dp(8),dp(8),dp(8),dp(8));return view;}
 private Button button(String value,View.OnClickListener action){Button button=new Button(this);button.setText(value);button.setAllCaps(false);button.setTextSize(12);button.setTextColor(0xffd9f99d);button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff1e293b));button.setOnClickListener(action);return button;}
 private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
 @Override public IBinder onBind(Intent intent){return null;}
 @Override public void onDestroy(){destroyed=true;running=false;generation++;waitingFrame=false;main.removeCallbacksAndMessages(null);if(screenOff!=null)try{unregisterReceiver(screenOff);}catch(RuntimeException ignored){}dismissMenu();dismissResult();hideBubble();if(display!=null)display.release();display=null;if(reader!=null)reader.close();reader=null;if(projection!=null)projection.stop();projection=null;if(captureThread!=null)captureThread.quitSafely();if(ocr!=null)ocr.close();if(translator!=null)translator.close();worker.shutdown();sources.clear();translations.clear();stopForeground(true);super.onDestroy();}
}
