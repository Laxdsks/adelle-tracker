package com.komiklingo.app;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.*;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.*;
import android.os.*;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import com.google.mlkit.nl.translate.*;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.*;
import java.util.concurrent.*;

/** Explicit projection session; the user starts manual capture or a bounded live dialogue session. Never stores screen images. */
public class FloatingTranslateService extends Service {
 public static final String STOP="com.komiklingo.app.STOP_FLOATING",GRANT="projection-grant",RESULT="projection-result";
 private static final String CHANNEL="tcd-screen-translation";private static final int NOTIFICATION=1707;
 private static volatile boolean running=false;
 public static boolean isRunning(){return running;}
 private final Handler main=new Handler(Looper.getMainLooper());private final ExecutorService worker=Executors.newSingleThreadExecutor();
 private HandlerThread captureThread;private Handler captureHandler;private WindowManager windows;private MediaProjection projection;private VirtualDisplay display;private volatile ImageReader reader;
 private TextRecognizer ocr;private Translator translator;private View bubble,menu,resultView;private WindowManager.LayoutParams bubblePosition;
 private ImageView bubbleImage;private ProgressBar bubbleProgress;private Bitmap snapshot;private List<OcrAppearance.Paragraph> paragraphs=Collections.emptyList();
 private List<String> sources=new ArrayList<>(),translations=new ArrayList<>();private volatile boolean destroyed=false;private boolean busy=false,ready=false;private volatile long generation=0,frameTicket=0;private volatile boolean waitingFrame=false;
 private boolean liveEnabled=false,livePaused=false,liveFullScreen=false;private RectF liveArea;private TextView livePanel;private View areaPicker;
 private final LiveDialogueGate liveGate=new LiveDialogueGate();private String livePrevious="";
 private final Runnable liveTick=()->{if(liveEnabled&&!livePaused&&!destroyed&&!busy)requestCapture();};
 private int captureWidth=0,captureHeight=0,density=0;private BroadcastReceiver screenOff;
 // Used by isolated test subclasses; production uses Google online with on-device ML Kit fallback.
 protected void prepareLanguage(Runnable success,Runnable failure){if(GoogleTranslator.enabled(this)){translator.downloadModelIfNeeded();success.run();return;}translator.downloadModelIfNeeded().addOnSuccessListener(v->success.run()).addOnFailureListener(e->failure.run());}
 private GoogleTranslator google;
 protected void translateSource(String source,NameTranslation.Result result){
  if(google==null)google=new GoogleTranslator(this,(input,done)->translator.translate(input).addOnSuccessListener(text->done.done(text,null)).addOnFailureListener(error->done.done(null,error)),()->{if(!destroyed)notifyStatus("Google belum bisa dipakai. Mencoba terjemahan offline; ketuk balon untuk jeda.");});
  google.translate(source,result);
 }
 protected void outcome(String value){} // Test subclasses observe outcomes, without production logging of screen text.
 @Override public void onCreate(){super.onCreate();windows=(WindowManager)getSystemService(WINDOW_SERVICE);captureThread=new HandlerThread("tcd-screen-frame");captureThread.start();captureHandler=new Handler(captureThread.getLooper());}
 @Override public int onStartCommand(Intent intent,int flags,int id){
  if(intent==null||STOP.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
  if(projection!=null)return START_NOT_STICKY;
  Intent grant=Build.VERSION.SDK_INT>=33?intent.getParcelableExtra(GRANT,Intent.class):intent.getParcelableExtra(GRANT);int result=intent.getIntExtra(RESULT,Activity.RESULT_CANCELED);
  if(result!=Activity.RESULT_OK||grant==null||!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY;}
  try{
   NotificationManager manager=getSystemService(NotificationManager.class);manager.createNotificationChannel(new NotificationChannel(CHANNEL,"Balon terjemahan TCD",NotificationManager.IMPORTANCE_LOW));
   Notification notification=notification("Menyiapkan balon. Ketuk untuk membuka TCD.");if(Build.VERSION.SDK_INT>=29)startForeground(NOTIFICATION,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);else startForeground(NOTIFICATION,notification);
   projection=((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).getMediaProjection(result,grant);
   if(projection==null)throw new SecurityException("No projection");
   projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){stopSelf();}@Override public void onCapturedContentResize(int width,int height){if(Build.VERSION.SDK_INT>=34)resizeCapture(width,height);}},main);
   setupCapture();running=true;showBubble();
   screenOff=new BroadcastReceiver(){@Override public void onReceive(Context context,Intent event){stopSelf();}};if(Build.VERSION.SDK_INT>=33)registerReceiver(screenOff,new IntentFilter(Intent.ACTION_SCREEN_OFF),Context.RECEIVER_NOT_EXPORTED);else registerReceiver(screenOff,new IntentFilter(Intent.ACTION_SCREEN_OFF));
   ocr=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);translator=Translation.getClient(new TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.INDONESIAN).build());
   worker.execute(()->{try{OcrQuality.load(getAssets().open("english-ocr-words.txt"));TessFallback.prepare(this);}catch(java.io.IOException ignored){}main.post(()->{if(destroyed)return;prepareLanguage(()->{if(destroyed)return;ready=true;refreshBubble();notifyStatus("Ketuk balon untuk mulai otomatis di game. Tahan untuk menu.");outcome("READY");},()->{if(!destroyed){toast("Model belum siap. Periksa internet dan aktifkan ulang balon.");stopSelf();}});});});
   toast("Buka game, lalu ketuk balon untuk mulai otomatis. Tahan untuk menu.");
  }catch(RuntimeException error){toast("Balon belum bisa aktif. Periksa izin lalu mulai lagi dari TCD.");stopSelf();}
  return START_NOT_STICKY;
 }
 private Notification notification(String message){
  PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,FloatingSetupActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,getClass()).setAction(STOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  return new Notification.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_translation_status).setContentTitle("TCD · Balon terjemahan aktif").setContentText(message).setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true).addAction(new Notification.Action.Builder(null,"Hentikan",stop).build()).build();
 }
 private void notifyStatus(String message){if(!destroyed)getSystemService(NotificationManager.class).notify(NOTIFICATION,notification(message));}
 @SuppressWarnings("deprecation") private DisplayMetrics realMetrics(){DisplayMetrics metrics=new DisplayMetrics();windows.getDefaultDisplay().getRealMetrics(metrics);return metrics;}
 private void setupCapture(){DisplayMetrics metrics=realMetrics();density=metrics.densityDpi;setReader(metrics.widthPixels,metrics.heightPixels);display=projection.createVirtualDisplay("TCD translation",captureWidth,captureHeight,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,captureHandler);pauseCapture();}
 private void pauseCapture(){try{if(display!=null)display.setSurface(null);}catch(RuntimeException ignored){}}
 private void setReader(int width,int height){
  double scale=Math.min(1,Math.min(1440.0/Math.max(1,width),Math.sqrt(4000000.0/Math.max(1,(double)width*height))));captureWidth=Math.max(1,(int)Math.round(width*scale));captureHeight=Math.max(1,(int)Math.round(height*scale));
  reader=ImageReader.newInstance(captureWidth,captureHeight,PixelFormat.RGBA_8888,2);ImageReader current=reader;
  reader.setOnImageAvailableListener(available->{Image image=null;try{image=available.acquireLatestImage();if(image==null)return;if(!waitingFrame||destroyed||available!=reader)return;long ticket=frameTicket;waitingFrame=false;Bitmap bitmap=ScreenFrame.decode(image);main.post(()->{if(destroyed||current!=reader||ticket!=generation){bitmap.recycle();return;}pauseCapture();if(liveEnabled)recognizeLive(bitmap,ticket);else{showBubble();recognize(bitmap,ticket);}});}catch(RuntimeException|OutOfMemoryError error){waitingFrame=false;main.post(()->captureFailed("Cuplikan belum bisa dibaca. Coba lagi."));}finally{if(image!=null)image.close();}},captureHandler);
 }
 private void resizeCapture(int width,int height){
  if(destroyed||display==null||width<1||height<1)return;double scale=Math.min(1,Math.min(1440.0/width,Math.sqrt(4000000.0/((double)width*height))));if(captureWidth==Math.round(width*scale)&&captureHeight==Math.round(height*scale))return;
  boolean wasLive=liveEnabled;stopLive();if(wasLive){toast("Ukuran layar berubah. Pilih ulang area Game otomatis.");notifyStatus("Ukuran layar berubah. Tahan balon untuk memilih ulang area game.");}remove(areaPicker);areaPicker=null;generation++;main.removeCallbacks(frameTimeout);waitingFrame=false;busy=false;dismissResult();hideBubble();pauseCapture();if(reader!=null)reader.close();setReader(width,height);display.resize(captureWidth,captureHeight,density);showBubble();refreshBubble();outcome("RESIZED");
 }
 @Override public void onConfigurationChanged(Configuration configuration){super.onConfigurationChanged(configuration);if(projection!=null){DisplayMetrics metrics=realMetrics();resizeCapture(metrics.widthPixels,metrics.heightPixels);}}
 private WindowManager.LayoutParams params(int width,int height,int flags){WindowManager.LayoutParams layout=new WindowManager.LayoutParams(width,height,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,flags,PixelFormat.TRANSLUCENT);layout.gravity=Gravity.TOP|Gravity.LEFT;return layout;}
 private void showBubble(){if(destroyed||bubble!=null)return;try{
  FrameLayout tile=new FrameLayout(this);GradientDrawable background=new GradientDrawable();background.setColor(0xff0f172a);background.setCornerRadius(dp(28));background.setStroke(dp(1),0xffa3e635);tile.setBackground(background);
  bubbleImage=new ImageView(this);bubbleImage.setImageResource(R.drawable.tcd_balloon);bubbleImage.setContentDescription("TCD. Ketuk untuk terjemahkan layar. Tahan untuk menu.");tile.addView(bubbleImage,new FrameLayout.LayoutParams(-1,-1));bubbleProgress=new ProgressBar(this);FrameLayout.LayoutParams progress=new FrameLayout.LayoutParams(dp(18),dp(18),Gravity.BOTTOM|Gravity.RIGHT);tile.addView(bubbleProgress,progress);
  if(bubblePosition==null){bubblePosition=params(dp(58),dp(58),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);DisplayMetrics screen=realMetrics();bubblePosition.x=Math.max(0,screen.widthPixels-dp(70));bubblePosition.y=screen.heightPixels/3;}
  DisplayMetrics screenBounds=realMetrics();bubblePosition.x=Math.max(0,Math.min(screenBounds.widthPixels-dp(58),bubblePosition.x));bubblePosition.y=Math.max(dp(24),Math.min(screenBounds.heightPixels-dp(84),bubblePosition.y));
  bubble=tile;tile.setOnTouchListener(new View.OnTouchListener(){float x,y;int originalX,originalY;boolean moved,longPress;final Runnable hold=()->{longPress=true;showMenu();};@Override public boolean onTouch(View view,android.view.MotionEvent event){switch(event.getActionMasked()){
   case android.view.MotionEvent.ACTION_DOWN:x=event.getRawX();y=event.getRawY();originalX=bubblePosition.x;originalY=bubblePosition.y;moved=false;longPress=false;main.postDelayed(hold,550);return true;
   case android.view.MotionEvent.ACTION_MOVE:float dx=event.getRawX()-x,dy=event.getRawY()-y;if(Math.hypot(dx,dy)>dp(7)){moved=true;main.removeCallbacks(hold);}if(moved){DisplayMetrics screen=realMetrics();bubblePosition.x=Math.max(0,Math.min(screen.widthPixels-dp(58),originalX+Math.round(dx)));bubblePosition.y=Math.max(dp(24),Math.min(screen.heightPixels-dp(84),originalY+Math.round(dy)));try{windows.updateViewLayout(tile,bubblePosition);}catch(RuntimeException ignored){}}return true;
   case android.view.MotionEvent.ACTION_UP:main.removeCallbacks(hold);if(!moved&&!longPress){if(liveEnabled)toggleLive();else selectLiveArea();}return true;
   case android.view.MotionEvent.ACTION_CANCEL:main.removeCallbacks(hold);return true;default:return true;}}});
  windows.addView(tile,bubblePosition);refreshBubble();
 }catch(RuntimeException error){bubble=null;stopSelf();}}
 private void refreshBubble(){if(bubbleProgress!=null)bubbleProgress.setVisibility(busy||!ready?View.VISIBLE:View.GONE);if(bubbleImage!=null){bubbleImage.setAlpha(busy?.5f:1f);bubbleImage.setContentDescription(liveEnabled?(livePaused?"TCD. Game otomatis dijeda. Ketuk untuk lanjut.":"TCD. Game otomatis aktif. Ketuk untuk jeda."):"TCD. Ketuk untuk mulai otomatis di game. Tahan untuk menu.");}}
 private void remove(View view){if(view!=null)try{windows.removeViewImmediate(view);}catch(RuntimeException ignored){}}
 private void hideBubble(){remove(bubble);bubble=null;bubbleProgress=null;bubbleImage=null;}
 private void showMenu(){if(menu!=null||destroyed)return;if(liveEnabled&&!livePaused)toggleLive();LinearLayout items=column();items.addView(label("TCD · Inggris → Indonesia",16));items.addView(button("Game layar penuh · otomatis",v->{dismissMenu();startLiveFullScreen();}));items.addView(button("Warna & latar terjemahan",v->showLiveStyle()));items.addView(button("Game otomatis · pilih area",v->{dismissMenu();selectLiveArea();}));if(liveEnabled){items.addView(button(livePaused?"Lanjut otomatis":"Jeda otomatis",v->{dismissMenu();toggleLive();}));items.addView(button("Akhiri mode otomatis",v->{dismissMenu();stopLive();}));}items.addView(button("Terjemahkan layar",v->{dismissMenu();stopLive();requestCapture();}));items.addView(button("Lihat teks terakhir",v->{dismissMenu();if(liveEnabled&&!livePaused)toggleLive();showText();}));items.addView(button("Hentikan balon",v->stopSelf()));items.addView(button("Tutup menu",v->dismissMenu()));menu=items;var layout=params(dp(260),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);DisplayMetrics screen=realMetrics();layout.x=Math.max(dp(8),Math.min(screen.widthPixels-dp(268),bubblePosition.x-dp(200)));layout.y=Math.max(dp(24),Math.min(screen.heightPixels-dp(320),bubblePosition.y));try{windows.addView(menu,layout);}catch(RuntimeException error){menu=null;stopSelf();}}
 private void dismissMenu(){remove(menu);menu=null;}
 private final Runnable frameTimeout=()->{if(waitingFrame){waitingFrame=false;pauseCapture();captureFailed("Layar belum bisa ditangkap. Buka aplikasinya lalu coba lagi.");}};
 protected void requestCapture(){
  if(destroyed||liveEnabled&&livePaused)return;if(!ready){toast("Model sedang disiapkan. Tunggu sebentar.");return;}if(busy){toast("Layar sedang diproses. Tahan balon jika ingin menghentikan.");return;}
  if(projection==null||display==null){stopSelf();return;}final long ticket=++generation;busy=true;dismissMenu();dismissResult();if(!liveEnabled)hideBubble();else placeBubbleOutsideLive();outcome("CAPTURING");
  main.postDelayed(()->{if(destroyed||!busy||ticket!=generation)return;try{Image stale=reader.acquireLatestImage();if(stale!=null)stale.close();frameTicket=ticket;waitingFrame=true;display.setSurface(reader.getSurface());main.postDelayed(frameTimeout,7000);}catch(RuntimeException error){captureFailed("Izin tangkap layar berakhir. Aktifkan lagi dari TCD.");stopSelf();}},250);
 }
 private void captureFailed(String message){if(destroyed)return;if(liveEnabled){stopLive();toast(message+" Mode otomatis dihentikan.");return;}pauseCapture();busy=false;waitingFrame=false;main.removeCallbacks(frameTimeout);showBubble();refreshBubble();toast(message);outcome("FAILED");}
 private List<String> terms(){try{return ProtectedTerms.parse(getSharedPreferences("reader",MODE_PRIVATE).getString("floating-terms",""));}catch(IllegalArgumentException error){return new ArrayList<>();}}
 private void recognize(Bitmap bitmap,long ticket){
  main.removeCallbacks(frameTimeout);if(destroyed||ticket!=generation){bitmap.recycle();return;}
  notifyStatus("Membaca layar di HP…");List<String> names=terms();
  OcrReader.read(ocr,bitmap,worker,()->!destroyed&&ticket==generation,names,new OcrReader.Result(){@Override public void success(Text result){
   if(destroyed||ticket!=generation){bitmap.recycle();return;}worker.execute(()->{List<OcrAppearance.Paragraph> found=new ArrayList<>();
   for(OcrAppearance.Paragraph paragraph:OcrAppearance.readingParagraphs(bitmap,result,names,false)){if(!ContextMeaning.dangling(paragraph.source,names)&&paragraph.source.length()>=2&&paragraph.source.matches("(?s).*[A-Za-z].*")&&paragraph.bounds.width()>8&&paragraph.bounds.height()>7)found.add(paragraph);if(found.size()>=40)break;}
   if(found.size()>40)found=new ArrayList<>(found.subList(0,40));final List<OcrAppearance.Paragraph> appearance=found;main.post(()->{if(destroyed||ticket!=generation){bitmap.recycle();return;}if(appearance.isEmpty()){bitmap.recycle();busy=false;refreshBubble();toast("Tidak ada teks terbaca. Beberapa aplikasi melindungi layarnya.");notifyStatus("Ketuk balon untuk mencoba layar lain.");outcome("NO_TEXT");return;}
   List<String> raw=new ArrayList<>();for(var paragraph:appearance)raw.add(paragraph.source);List<String> known=new ArrayList<>(names);for(String name:ProtectedTerms.discover(raw))if(known.size()<80&&!contains(known,name))known.add(name);
   List<ProtectedTerms.Plan> plans=new ArrayList<>();int index=0;for(String source:raw){var plan=ProtectedTerms.prepare(ProtectedTerms.cleanOcr(source,known),known,index);plans.add(plan);index+=plan.names().size()+1;}
   TranslationFlow.translate(plans,FloatingTranslateService.this::translateSource,()->{if(destroyed||ticket!=generation){if(!bitmap.isRecycled())bitmap.recycle();return false;}return true;},(values,failures)->{
    sources=new ArrayList<>();translations=new ArrayList<>();String style=getSharedPreferences("reader",MODE_PRIVATE).getString("floating-style",ReadingText.DIALOGUE);
    for(int i=0;i<plans.size();i++){var plan=plans.get(i);sources.add(plan.source);String value=values.get(i);String translated="";if(plan.valid(value)){String adjusted=ReadingText.style(plan.source,value,style);if(plan.valid(adjusted))translated=ReadingText.emotion(plan.source,plan.restore(adjusted));}translations.add(translated);}
    busy=false;refreshBubble();snapshot=bitmap;paragraphs=appearance;notifyStatus("Hasil siap. Tutup hasil untuk kembali ke aplikasi.");showPicture();outcome("RESULT");
   });});});
  }@Override public void failure(Exception error){bitmap.recycle();if(destroyed||ticket!=generation)return;captureFailed("Teks belum bisa dibaca. Coba perbesar huruf di aplikasi asal.");}});
 }
 private WindowManager.LayoutParams fullOverlay(int flags){var layout=params(-1,-1,flags|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);if(Build.VERSION.SDK_INT>=28)layout.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;return layout;}
 private void applyLiveStyle(TextView view){var prefs=getSharedPreferences("reader",MODE_PRIVATE);int opacity=prefs.getInt("live-background",70),color=prefs.getInt("live-color",Color.WHITE);view.setTextColor(color);view.setBackgroundColor(Color.argb(Math.round(opacity*2.55f),15,23,42));view.setShadowLayer(2,0,1,color==Color.BLACK?Color.WHITE:Color.BLACK);}
 private void showLiveStyle(){
  dismissMenu();LinearLayout items=column();items.addView(label("Warna & latar terjemahan",17));TextView preview=label("Contoh teks terjemahan",18);applyLiveStyle(preview);items.addView(preview);
  var prefs=getSharedPreferences("reader",MODE_PRIVATE);TextView opacity=label("Kepekatan latar: "+prefs.getInt("live-background",70)+"% · 0% = teks saja",13);items.addView(opacity);SeekBar slider=new SeekBar(this);slider.setMax(100);slider.setProgress(prefs.getInt("live-background",70));slider.setContentDescription("Kepekatan latar terjemahan");items.addView(slider);slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar v){}public void onStopTrackingTouch(SeekBar v){}public void onProgressChanged(SeekBar v,int progress,boolean user){prefs.edit().putInt("live-background",progress).apply();opacity.setText("Kepekatan latar: "+progress+"% · 0% = teks saja");applyLiveStyle(preview);if(livePanel!=null)applyLiveStyle(livePanel);}});
  int[] colors={Color.WHITE,Color.YELLOW,0xffa3e635,Color.CYAN,Color.BLACK};String[] names={"Putih","Kuning","Hijau","Biru muda","Hitam"};for(int i=0;i<colors.length;i++){final int color=colors[i];items.addView(button(names[i],v->{prefs.edit().putInt("live-color",color).apply();applyLiveStyle(preview);if(livePanel!=null)applyLiveStyle(livePanel);}));}
  items.addView(button("Selesai",v->dismissMenu()));ScrollView scroll=new ScrollView(this);scroll.addView(items);menu=scroll;DisplayMetrics screen=realMetrics();var layout=params(Math.min(dp(320),screen.widthPixels-dp(24)),Math.min(dp(500),screen.heightPixels-dp(48)),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);layout.x=dp(12);layout.y=dp(24);try{windows.addView(menu,layout);}catch(RuntimeException error){dismissMenu();}
 }
 private void startLiveFullScreen(){
  if(!ready){toast("Tunggu model bahasa siap.");return;}
  stopLive();dismissMenu();dismissResult();remove(areaPicker);areaPicker=null;
  DisplayMetrics screen=realMetrics();float top=Math.min(dp(140),screen.heightPixels*.36f);
  liveArea=new RectF(0,top/screen.heightPixels,1,1);liveFullScreen=true;liveEnabled=true;livePaused=false;liveGate.reset();livePrevious="";sources.clear();translations.clear();showBubble();showLiveText("Menunggu dialog game…");notifyStatus("Otomatis di game aktif. Langsung tekan Next di game. Ketuk balon untuk jeda.");scheduleLive();outcome("LIVE_STARTED");
 }
 private void selectLiveArea(){
  if(!ready){toast("Tunggu model bahasa siap.");return;}stopLive();generation++;waitingFrame=false;busy=false;pauseCapture();main.removeCallbacks(frameTimeout);dismissResult();hideBubble();
  FrameLayout page=new FrameLayout(this);LiveAreaPicker picker=new LiveAreaPicker(this);page.addView(picker,new FrameLayout.LayoutParams(-1,-1));
  TextView help=label("Geser kotak untuk memindah. Tarik sudut untuk mengubah ukuran. Garis pilihan hilang setelah Mulai.",16);help.setBackgroundColor(0xe60f172a);FrameLayout.LayoutParams helpLayout=new FrameLayout.LayoutParams(-1,-2,Gravity.TOP);helpLayout.topMargin=dp(28);page.addView(help,helpLayout);
  LinearLayout actions=row();actions.addView(button("Warna & latar",v->showLiveStyle()),new LinearLayout.LayoutParams(0,dp(50),1));actions.addView(button("Mulai otomatis",v->{DisplayMetrics screen=realMetrics();RectF area=picker.screenArea();area.intersect(0,0,screen.widthPixels,screen.heightPixels);if(area.width()<dp(100)||area.height()<dp(32)||Math.max(area.top,screen.heightPixels-area.bottom)<dp(150)){toast("Pilih kotak dialog lebih kecil dan sisakan ruang untuk subtitle.");return;}dismissMenu();liveArea=new RectF(area.left/screen.widthPixels,area.top/screen.heightPixels,area.right/screen.widthPixels,area.bottom/screen.heightPixels);remove(areaPicker);areaPicker=null;liveEnabled=true;livePaused=false;liveGate.reset();livePrevious="";sources.clear();translations.clear();showBubble();showLiveText("Menunggu teks dialog…");notifyStatus("Game otomatis aktif. Ketuk balon untuk jeda; tahan untuk menu.");scheduleLive();outcome("LIVE_STARTED");}),new LinearLayout.LayoutParams(0,dp(50),1));
  actions.addView(button("Batal",v->{remove(areaPicker);areaPicker=null;showBubble();}),new LinearLayout.LayoutParams(0,dp(50),1));FrameLayout.LayoutParams actionLayout=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);actionLayout.bottomMargin=dp(30);page.addView(actions,actionLayout);areaPicker=page;
  try{windows.addView(page,fullOverlay(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE));}catch(RuntimeException error){remove(areaPicker);areaPicker=null;showBubble();toast("Pemilih area belum bisa dibuka.");}
 }
 private void placeBubbleOutsideLive(){
  if(bubble==null||liveArea==null)return;DisplayMetrics screen=realMetrics();RectF area=new RectF(liveArea.left*screen.widthPixels,liveArea.top*screen.heightPixels,liveArea.right*screen.widthPixels,liveArea.bottom*screen.heightPixels);RectF bounds=new RectF(bubblePosition.x,bubblePosition.y,bubblePosition.x+dp(58),bubblePosition.y+dp(58));
  if(RectF.intersects(area,bounds)){bubblePosition.y=area.top>=dp(100)?dp(28):screen.heightPixels-dp(84);try{windows.updateViewLayout(bubble,bubblePosition);}catch(RuntimeException ignored){}}
 }
 private void scheduleLive(){main.removeCallbacks(liveTick);if(liveEnabled&&!livePaused&&!destroyed)main.postDelayed(liveTick,900);}
 private void stopLive(){if(google!=null)google.cancel();boolean wasActive=liveEnabled;liveEnabled=false;liveFullScreen=false;livePaused=false;main.removeCallbacks(liveTick);generation++;waitingFrame=false;busy=false;main.removeCallbacks(frameTimeout);pauseCapture();remove(livePanel);livePanel=null;liveGate.reset();livePrevious="";refreshBubble();if(wasActive&&!destroyed)notifyStatus("Game otomatis diakhiri. Ketuk balon untuk mulai otomatis lagi.");}
 private void toggleLive(){if(!liveEnabled)return;if(google!=null)google.cancel();livePaused=!livePaused;generation++;waitingFrame=false;busy=false;main.removeCallbacks(frameTimeout);main.removeCallbacks(liveTick);pauseCapture();if(livePaused){remove(livePanel);livePanel=null;notifyStatus("Game otomatis dijeda. Ketuk balon untuk lanjut.");outcome("LIVE_PAUSED");}else{liveGate.reset();showLiveText("Menunggu teks dialog…");scheduleLive();notifyStatus("Game otomatis aktif. Ketuk balon untuk jeda.");outcome("LIVE_RESUMED");}refreshBubble();}
 private void showLiveText(String text){if(!liveEnabled||livePaused||destroyed)return;
  if(livePanel==null){DisplayMetrics screen=realMetrics();int top=Math.round(liveArea.top*screen.heightPixels),bottom=Math.round(liveArea.bottom*screen.heightPixels);boolean above=liveFullScreen||top>=dp(150);int space=above?top-dp(30):screen.heightPixels-bottom-dp(30);int height=Math.min(dp(210),space);livePanel=label("",17);livePanel.setMaxHeight(height);livePanel.setMaxLines(Math.max(2,height/dp(25)-1));livePanel.setEllipsize(android.text.TextUtils.TruncateAt.END);applyLiveStyle(livePanel);
   var layout=params(liveFullScreen?Math.max(dp(120),screen.widthPixels-dp(90)):Math.max(dp(120),Math.round(liveArea.width()*screen.widthPixels)),liveFullScreen?WindowManager.LayoutParams.WRAP_CONTENT:height,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);layout.x=liveFullScreen?dp(8):Math.round(liveArea.left*screen.widthPixels);layout.y=liveFullScreen?dp(12):above?top-height-dp(8):bottom+dp(8);layout.alpha=.75f;
   try{windows.addView(livePanel,layout);}catch(RuntimeException error){livePanel=null;stopLive();toast("Subtitle belum bisa ditampilkan.");return;}
  }livePanel.setText(text);
 }
 private void finishLive(long ticket){if(destroyed||ticket!=generation)return;busy=false;refreshBubble();scheduleLive();}
 private void recognizeLive(Bitmap frame,long ticket){
  main.removeCallbacks(frameTimeout);if(destroyed||ticket!=generation||liveArea==null){frame.recycle();return;}
  Rect crop=new Rect(Math.max(0,(int)(liveArea.left*frame.getWidth())),Math.max(0,(int)(liveArea.top*frame.getHeight())),Math.min(frame.getWidth(),(int)(liveArea.right*frame.getWidth())),Math.min(frame.getHeight(),(int)(liveArea.bottom*frame.getHeight())));
  Bitmap image;try{image=Bitmap.createBitmap(frame,crop.left,crop.top,crop.width(),crop.height());if(image!=frame)frame.recycle();}catch(RuntimeException|OutOfMemoryError error){frame.recycle();captureFailed("Area dialog belum bisa dibaca.");return;}
  ocr.process(com.google.mlkit.vision.common.InputImage.fromBitmap(image,0)).addOnSuccessListener(result->{
   if(destroyed||ticket!=generation){image.recycle();return;}
   String observed=liveSource(result);
   if(observed.length()>2000){image.recycle();showLiveText("Area terlalu luas. Tahan balon lalu pilih hanya kotak dialog.");finishLive(ticket);return;}
   if(liveGate.changed(observed))showLiveText(observed.isEmpty()?"Menunggu teks dialog…":"Membaca dialog baru…");
   if(!liveGate.observe(observed)){image.recycle();finishLive(ticket);return;}
   List<String> known=terms();for(String name:ProtectedTerms.discover(Collections.singletonList(observed)))if(known.size()<80&&!contains(known,name))known.add(name);
   OcrReader.refineLive(ocr,image,result,worker,()->!destroyed&&ticket==generation,known,new OcrReader.Result(){
    public void success(Text refined){image.recycle();if(destroyed||ticket!=generation)return;translateLive(liveSource(refined),known,ticket);}
    public void failure(Exception error){image.recycle();if(destroyed||ticket!=generation)return;liveGate.retry();showLiveText("Mencoba membaca dialog lagi…");finishLive(ticket);}
   });
  }).addOnFailureListener(error->{image.recycle();if(destroyed||ticket!=generation)return;showLiveText("Mencoba membaca dialog lagi…");finishLive(ticket);});
 }
 private String liveSource(Text result){
  List<Text.Line> ordered=new ArrayList<>();for(Text.TextBlock block:result.getTextBlocks())ordered.addAll(block.getLines());
  // A line may be split into adjacent OCR blocks: compare rows, then left to right.
  ordered.sort(Comparator.comparingInt(l->l.getBoundingBox()==null?Integer.MAX_VALUE:l.getBoundingBox().top));
  List<String> lines=new ArrayList<>();for(int start=0;start<ordered.size();){int end=start+1;Rect row=ordered.get(start).getBoundingBox();
   while(row!=null&&end<ordered.size()){Rect next=ordered.get(end).getBoundingBox();if(next==null||Math.abs(next.centerY()-row.centerY())>Math.min(next.height(),row.height())*.45f)break;end++;}
   List<Text.Line> group=new ArrayList<>(ordered.subList(start,end));group.sort(Comparator.comparingInt(l->l.getBoundingBox()==null?Integer.MAX_VALUE:l.getBoundingBox().left));
   StringBuilder joined=new StringBuilder();for(Text.Line line:group){if(joined.length()>0)joined.append(' ');joined.append(line.getText());}lines.add(joined.toString());start=end;
  }return ReadingText.joinLines(lines,terms());
 }
 private void translateLive(String source,List<String> known,long ticket){
  for(String name:ProtectedTerms.discover(Collections.singletonList(source)))if(known.size()<80&&!contains(known,name))known.add(name);
  var plan=ProtectedTerms.prepare(ProtectedTerms.cleanOcr(source,known),known);String previous=livePrevious;
  TranslationFlow.translate(Collections.singletonList(plan),Collections.singletonList(previous),Collections.singletonList(""),FloatingTranslateService.this::translateSource,()->!destroyed&&ticket==generation,(values,failed)->{
   if(destroyed||ticket!=generation)return;String raw=values.get(0);if(plan.valid(raw)&&!ReadingText.garbledTranslation(plan.source,raw)){String styled=ReadingText.style(plan.source,raw,getSharedPreferences("reader",MODE_PRIVATE).getString("floating-style",ReadingText.DIALOGUE));if(plan.valid(styled)){String translated=ReadingText.emotion(plan.source,plan.restore(styled));sources=new ArrayList<>(Collections.singletonList(plan.source));translations=new ArrayList<>(Collections.singletonList(translated));livePrevious=plan.source;showLiveText(translated);outcome("LIVE_RESULT");}else{liveGate.retry();showLiveText("Dialog belum berhasil diterjemahkan…");}}else{liveGate.retry();showLiveText("Dialog belum berhasil diterjemahkan…");}finishLive(ticket);
  });
 }

 private static boolean contains(List<String> names,String name){for(String value:names)if(value.equalsIgnoreCase(name))return true;return false;}
 private void addResult(View view){dismissMenu();hideBubble();remove(resultView);resultView=view;WindowManager.LayoutParams layout=params(-1,-1,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);layout.softInputMode=WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING;view.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});view.setFocusableInTouchMode(true);view.setOnKeyListener((v,key,event)->{if(key==KeyEvent.KEYCODE_BACK&&event.getAction()==KeyEvent.ACTION_UP){closeResult();return true;}return false;});try{windows.addView(view,layout);view.requestFocus();}catch(RuntimeException error){closeResult();stopSelf();}}
 private void showPicture(){
  if(snapshot==null||snapshot.isRecycled()){showText();return;}LinearLayout page=column();page.setPadding(0,0,0,0);page.addView(label("TCD · Hasil layar. Tutup untuk menggulir aplikasi.",13));LinearLayout actions=row();BubbleOverlay translated=new BubbleOverlay(this);Button original=button("Asli",v->{boolean visible=translated.getVisibility()==View.VISIBLE;translated.setVisibility(visible?View.INVISIBLE:View.VISIBLE);((Button)v).setText(visible?"Indonesia":"Asli");});actions.addView(button("Otomatis di game",v->selectLiveArea()),new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(original,new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(button("Teks",v->showText()),new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(button("Ulang",v->{closeResult();requestCapture();}),new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(button("Tutup",v->closeResult()),new LinearLayout.LayoutParams(0,dp(48),1));page.addView(actions);
  FrameLayout picture=new FrameLayout(this);ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_CENTER);image.setImageBitmap(snapshot);picture.addView(image,new FrameLayout.LayoutParams(-1,-1));picture.addView(translated,new FrameLayout.LayoutParams(-1,-1));page.addView(picture,new LinearLayout.LayoutParams(-1,0,1));
  picture.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{if(snapshot==null||snapshot.isRecycled())return;float scale=Math.min(picture.getWidth()/(float)snapshot.getWidth(),picture.getHeight()/(float)snapshot.getHeight());float x=(picture.getWidth()-snapshot.getWidth()*scale)/2,y=(picture.getHeight()-snapshot.getHeight()*scale)/2;List<BubbleOverlay.Bubble> bubbles=new ArrayList<>();for(int i=0;i<paragraphs.size()&&i<translations.size();i++){String value=translations.get(i);if(value.isEmpty())continue;var source=paragraphs.get(i);RectF box=new RectF(source.bounds);box.inset(-4,-3);box.left=box.left*scale+x;box.right=box.right*scale+x;box.top=box.top*scale+y;box.bottom=box.bottom*scale+y;boolean caps=source.source.equals(source.source.toUpperCase(Locale.ROOT));bubbles.add(new BubbleOverlay.Bubble(box,caps?value.toUpperCase(new Locale("id")):value,source.background,caps,new BubbleOverlay.Appearance(source.ink,source.sourceSize*scale,source.leftAligned,source.italic)));}translated.show(bubbles);});addResult(page);
 }
 private void showText(){LinearLayout page=column();page.addView(label("TCD · Teks layar terakhir",18));LinearLayout actions=row();if(snapshot!=null)actions.addView(button("Gambar",v->showPicture()),new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(button("Tutup",v->closeResult()),new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(button("Hentikan",v->stopSelf()),new LinearLayout.LayoutParams(0,dp(48),1));page.addView(actions);ScrollView scroll=new ScrollView(this);LinearLayout list=column();if(translations.isEmpty())list.addView(label("Belum ada hasil. Tutup lalu ketuk balon untuk menerjemahkan.",16));for(int i=0;i<translations.size();i++){TextView source=label("Inggris: "+sources.get(i),14);source.setTextColor(0xff94a3b8);source.setTextIsSelectable(true);list.addView(source);TextView target=label(translations.get(i).isEmpty()?"Bagian ini belum berhasil diterjemahkan.":translations.get(i),19);target.setTextIsSelectable(true);target.setPadding(0,dp(6),0,dp(22));target.setLineSpacing(dp(2),1.15f);list.addView(target);}scroll.addView(list);page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));addResult(page);}
 private void dismissResult(){remove(resultView);resultView=null;if(snapshot!=null&&!snapshot.isRecycled())snapshot.recycle();snapshot=null;paragraphs=Collections.emptyList();}
 private void closeResult(){dismissResult();showBubble();refreshBubble();notifyStatus(liveEnabled?"Game otomatis dijeda. Ketuk balon untuk lanjut.":"Ketuk balon untuk mulai otomatis di game. Tahan untuk menu.");}
 private LinearLayout column(){LinearLayout view=new LinearLayout(this);view.setOrientation(LinearLayout.VERTICAL);view.setBackgroundColor(0xff0f172a);view.setPadding(dp(12),dp(12),dp(12),dp(12));return view;}
 private LinearLayout row(){LinearLayout view=new LinearLayout(this);view.setGravity(Gravity.CENTER_VERTICAL);return view;}
 private TextView label(String value,int size){TextView view=new TextView(this);view.setText(value);view.setTextSize(size);view.setTextColor(0xffe2e8f0);view.setPadding(dp(8),dp(8),dp(8),dp(8));return view;}
 private Button button(String value,View.OnClickListener action){Button button=new Button(this);button.setText(value);button.setAllCaps(false);button.setTextSize(12);button.setTextColor(0xffd9f99d);button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff1e293b));button.setOnClickListener(action);return button;}
 private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
 @Override public IBinder onBind(Intent intent){return null;}
 @Override public void onDestroy(){destroyed=true;running=false;generation++;waitingFrame=false;main.removeCallbacksAndMessages(null);if(screenOff!=null)try{unregisterReceiver(screenOff);}catch(RuntimeException ignored){}stopLive();remove(areaPicker);areaPicker=null;dismissMenu();dismissResult();hideBubble();if(display!=null)display.release();display=null;if(reader!=null)reader.close();reader=null;if(projection!=null)projection.stop();projection=null;if(captureThread!=null)captureThread.quitSafely();if(ocr!=null)ocr.close();if(google!=null)google.close();if(translator!=null)translator.close();worker.shutdown();sources.clear();translations.clear();stopForeground(true);super.onDestroy();}
}
