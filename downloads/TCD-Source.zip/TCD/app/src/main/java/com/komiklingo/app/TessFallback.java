package com.komiklingo.app;
import android.content.Context;
import android.graphics.*;
import java.io.*;
import com.googlecode.tesseract.android.TessBaseAPI;

/** Independent on-device recognition, only for unresolved lines. No word substitution. */
public final class TessFallback {
 private static volatile File directory;
 public static synchronized void prepare(Context context)throws IOException{
  File root=new File(context.getFilesDir(),"ocr-model"),data=new File(root,"tessdata");if(!data.isDirectory()&&!data.mkdirs())throw new IOException("Model directory");
  File model=new File(data,"eng.traineddata");if(!model.isFile()||model.length()!=4113088){File temporary=new File(data,"eng.tmp");try(InputStream input=context.getAssets().open("tessdata/eng.traineddata");OutputStream output=new FileOutputStream(temporary)){byte[] buffer=new byte[8192];int n;while((n=input.read(buffer))!=-1)output.write(buffer,0,n);}if(!temporary.renameTo(model))throw new IOException("Model copy");}directory=root;
 }
 public static final class Read {final String text;final float confidence;Read(String text,float confidence){this.text=text;this.confidence=confidence;}}
 public static synchronized Read read(Bitmap original,Rect bounds){
  if(directory==null)return null;Rect area=new Rect(bounds);area.inset(-Math.max(3,Math.round(bounds.height()*.12f)),-Math.max(3,Math.round(bounds.height()*.12f)));if(!area.intersect(0,0,original.getWidth(),original.getHeight()))return null;
  Bitmap cropped=Bitmap.createBitmap(original,area.left,area.top,area.width(),area.height());float scale=Math.min(3f,50f/Math.max(8,bounds.height()));scale=Math.min(scale,1400f/area.width());Bitmap image=Bitmap.createScaledBitmap(cropped,Math.max(1,Math.round(cropped.getWidth()*scale)),Math.max(1,Math.round(cropped.getHeight()*scale)),true);if(image!=cropped&&cropped!=original)cropped.recycle();
  TessBaseAPI engine=new TessBaseAPI();try{
   if(!engine.init(directory.getAbsolutePath(),"eng",TessBaseAPI.OEM_LSTM_ONLY))return null;engine.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_LINE);
   Read best=null;
   for(float shear:new float[]{0,.30f,-.30f}){
    Bitmap variant=image;
    if(shear!=0){
     variant=Bitmap.createBitmap(image.getWidth()+(int)Math.ceil(Math.abs(shear)*image.getHeight())+16,image.getHeight()+16,Bitmap.Config.ARGB_8888);
     Canvas canvas=new Canvas(variant);canvas.drawColor(OcrAppearance.background(original,bounds));
     Matrix transform=new Matrix();transform.setValues(new float[]{1,shear,8-Math.min(0,shear*image.getHeight()),0,1,8,0,0,1});
     canvas.drawBitmap(image,transform,new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG));
    }
    try{engine.setImage(variant);String text=engine.getUTF8Text().replaceAll("\\s+"," ").trim();float confidence=engine.meanConfidence()/100f;
     if(!text.isEmpty()&&confidence>=.55f&&(best==null||OcrQuality.better(best.text,best.confidence,text,confidence,java.util.Collections.emptyList())))best=new Read(text,confidence);
    }finally{if(variant!=image)variant.recycle();}
   }
   return best;
  }finally{engine.recycle();if(image!=original)image.recycle();}
 }
}
