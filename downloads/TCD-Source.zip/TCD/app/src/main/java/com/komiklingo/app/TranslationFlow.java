package com.komiklingo.app;

import java.util.*;
import java.util.function.BooleanSupplier;

/** Bounded dialogue groups; retries preserve balloon order and protected names. */
public final class TranslationFlow {
 public interface Result {void done(List<String> translations,int failures);}
 private final List<ProtectedTerms.Plan> plans;private final NameTranslation.Engine engine;
 private final BooleanSupplier active;private final Result result;
 private final List<String> output;private int failures=0;
 private final Map<Integer,String> reuseKeys=new HashMap<>();
 private TranslationFlow(List<ProtectedTerms.Plan> plans,NameTranslation.Engine engine,BooleanSupplier active,Result result){this.plans=new ArrayList<>(plans);this.engine=engine;this.active=active;this.result=result;output=new ArrayList<>(Collections.nCopies(plans.size(),""));}
 public static void translate(List<ProtectedTerms.Plan> plans,NameTranslation.Engine engine,BooleanSupplier active,Result result){new TranslationFlow(plans,engine,active,result).group(0);}
 private void group(int start){
  if(!active.getAsBoolean())return;if(start>=plans.size()){result.done(output,failures);return;}
  String saved=remembered(start);if(plans.get(start).valid(saved)){output.set(start,ContextMeaning.polish(plans.get(start).masked,saved));group(start+1);return;}
  int end=start,characters=0;List<String> source=new ArrayList<>();
  while(end<plans.size()&&end-start<8){String text=input(end,plans.get(end).masked);if(end>start&&(characters+text.length()+2>4000||plans.get(end).valid(remembered(end))))break;source.add(text);characters+=text.length()+2;end++;}
  final int until=end;
  if(until-start<2){individual(start,until,()->group(until));return;}
  engine.translate(String.join("\n\n",source),(value,error)->{
   if(!active.getAsBoolean())return;
   List<String> parts=error==null?ReadingText.splitBatch(value,until-start):null;
   if(parts==null){individual(start,until,()->group(until));return;}
   // Each protected name belongs to its own balloon, even if a batch rearranges tokens.
   repair(start,until,parts,()->group(until));
  });
 }
 private void repair(int at,int until,List<String> parts,Runnable done){
  if(!active.getAsBoolean())return;if(at>=until){done.run();return;}
  int first=until-parts.size();ProtectedTerms.Plan plan=plans.get(at);String value=parts.get(at-first);
  if(plan.valid(value)){remember(at,value);output.set(at,ContextMeaning.polish(plan.masked,value));repair(at+1,until,parts,done);return;}
  NameTranslation.translate(plan,normalizedEngine(at),(translated,error)->{if(!active.getAsBoolean())return;if(error==null&&plan.valid(translated)){remember(at,translated);output.set(at,ContextMeaning.polish(plan.masked,translated));}else failures++;repair(at+1,until,parts,done);});
 }
 private String input(int at,String source){String text=ReadingText.translationInput(source);return at+1<plans.size()&&plans.get(at).masked.equals(source)?PhrasalVerbs.withNextClause(text,plans.get(at+1).masked):text;}
 private String remembered(int at){return engine.reusesTranslations()?engine.cached(reuseKey(at)):null;}
 private void remember(int at,String value){if(engine.reusesTranslations())engine.remember(reuseKey(at),value);}
 private String reuseKey(int at){if(reuseKeys.containsKey(at))return reuseKeys.get(at);String context=(at>0?input(at-1,plans.get(at-1).masked):"")+"\u0001"+input(at,plans.get(at).masked)+"\u0001"+(at+1<plans.size()?input(at+1,plans.get(at+1).masked):"");try{byte[] hash=java.security.MessageDigest.getInstance("SHA-256").digest(context.getBytes(java.nio.charset.StandardCharsets.UTF_8));StringBuilder key=new StringBuilder("\u0000tcd.unit:");for(byte value:hash)key.append(Character.forDigit((value>>>4)&15,16)).append(Character.forDigit(value&15,16));String result=key.toString();reuseKeys.put(at,result);return result;}catch(java.security.NoSuchAlgorithmException impossible){throw new AssertionError(impossible);}}
 private NameTranslation.Engine normalizedEngine(int at){return (source,callback)->engine.translate(input(at,source),callback);}
 private void individual(int at,int until,Runnable done){
  if(!active.getAsBoolean())return;if(at>=until){done.run();return;}
  ProtectedTerms.Plan plan=plans.get(at);
  NameTranslation.translate(plan,normalizedEngine(at),(translated,error)->{if(!active.getAsBoolean())return;if(error==null&&plan.valid(translated)){remember(at,translated);output.set(at,ContextMeaning.polish(plan.masked,translated));}else failures++;individual(at+1,until,done);});
 }
}
