package com.komiklingo.app;
import android.graphics.RectF;
import java.util.*;

/** Memory-only translation positions for exactly one loaded document. */
public final class PageTranslations {
 public static final class Entry {
  public final String source,target;public final RectF css;public final int background,ink;public final float font;public final boolean caps,left,italic;
  Entry(String source,String target,RectF css,int background,int ink,float font,boolean caps,boolean left,boolean italic){this.source=source;this.target=target;this.css=css;this.background=background;this.ink=ink;this.font=font;this.caps=caps;this.left=left;this.italic=italic;}
 }
 private final List<Entry> entries=new ArrayList<>();
 public void clear(){entries.clear();}public int size(){return entries.size();}
 public List<Entry> entries(){List<Entry> ordered=new ArrayList<>(entries);ordered.sort(Comparator.comparingDouble(entry->entry.css.top));return ordered;}
 public void put(String source,String target,RectF viewport,int background,boolean caps,BubbleOverlay.Appearance appearance,float scale,int scrollX,int scrollY){
  if(target==null||target.isEmpty()||scale<=0)return;RectF css=new RectF((viewport.left+scrollX)/scale,(viewport.top+scrollY)/scale,(viewport.right+scrollX)/scale,(viewport.bottom+scrollY)/scale);
  for(Iterator<Entry> iterator=entries.iterator();iterator.hasNext();){Entry old=iterator.next();RectF intersect=new RectF(css);if(intersect.intersect(old.css)){float shared=intersect.width()*intersect.height(),union=css.width()*css.height()+old.css.width()*old.css.height()-shared;if(union>0&&shared/union>.6f)iterator.remove();}}
  if(entries.size()>=6000)return;
  entries.add(new Entry(source,target,css,background,appearance==null?0xff18181c:appearance.ink,appearance==null?24:appearance.sourceSize/scale,caps,appearance!=null&&appearance.leftAligned,appearance!=null&&appearance.italic));
 }
 public List<BubbleOverlay.Bubble> visible(float scale,int scrollX,int scrollY,int width,int height){
  List<BubbleOverlay.Bubble> result=new ArrayList<>();for(Entry entry:entries){RectF box=new RectF(entry.css.left*scale-scrollX,entry.css.top*scale-scrollY,entry.css.right*scale-scrollX,entry.css.bottom*scale-scrollY);if(box.right<=0||box.left>=width||box.bottom<=0||box.top>=height)continue;String text=entry.caps?entry.target.toUpperCase(new Locale("id")):entry.target;result.add(new BubbleOverlay.Bubble(box,text,entry.background,entry.caps,new BubbleOverlay.Appearance(entry.ink,entry.font*scale,entry.left,entry.italic)));}return result;
 }
}
