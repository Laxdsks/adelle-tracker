package com.komiklingo.app;

import android.graphics.*;
import com.google.mlkit.vision.text.Text;
import java.util.*;

/** Estimates visible ink and type size from OCR glyph regions, not the entire picture. */
public final class OcrAppearance {
 public static final class Paragraph {
  public final String source;public final Rect bounds;public final int background,ink;
  public final float sourceSize;public final boolean leftAligned,italic;
  Paragraph(String source,Rect bounds,int background,int ink,float sourceSize,boolean leftAligned,boolean italic){this.source=source;this.bounds=bounds;this.background=background;this.ink=ink;this.sourceSize=sourceSize;this.leftAligned=leftAligned;this.italic=italic;}
 }
 /** Rejoin adjacent OCR blocks only when syntax and the pixels support a continuation. */
 public static List<Paragraph> readingParagraphs(Bitmap bitmap,Text text,List<String> names,boolean scanning){
  List<Paragraph> all=new ArrayList<>();for(Text.TextBlock block:text.getTextBlocks()){
   if(scanning&&block.getBoundingBox()!=null&&block.getBoundingBox().height()>bitmap.getHeight()*.75f)all.addAll(visibleLines(bitmap,block,names,2));else all.addAll(paragraphs(bitmap,block,names));if(all.size()>=120)break;
  }List<Paragraph> joined=joinFragments(bitmap,all,names);joined.removeIf(p->ReadingText.publisherNotice(p.source));return joined;
 }
 static List<Paragraph> joinFragments(Bitmap bitmap,List<Paragraph> input){return joinFragments(bitmap,input,Collections.emptyList());}
 static List<Paragraph> joinFragments(Bitmap bitmap,List<Paragraph> input,List<String> names){
  List<Paragraph> all=new ArrayList<>(input);all.sort(Comparator.comparingInt((Paragraph p)->p.bounds.top).thenComparingInt(p->p.bounds.left));EnclosedRegions regions=new EnclosedRegions(bitmap);
  for(int i=0;i<all.size();i++){
   Paragraph first=all.get(i);boolean joined=true,reconsider=false;while(joined){joined=false;for(int j=i+1;j<all.size();j++){
    Paragraph next=all.get(j);if((ContextMeaning.pausedAuxiliary(first.source)&&ContextMeaning.startsNamed(next.source,names))||ContextMeaning.named(first.source,names)||!near(first,next)||!clearBridge(bitmap,first,next))continue;
    // A bounded, plain interior can establish sentence continuity even when the
    // last word is an arbitrary adjective. Unbounded page whitespace cannot.
    if(!ContextMeaning.continues(first.source,next.source)&&(!(ContextMeaning.openFragment(first.source)||PhrasalVerbs.temporalEntry(next.source))||!regions.sameInterior(first,next)))continue;
    Rect union=new Rect(first.bounds);union.union(next.bounds);boolean occupied=false;for(int k=0;k<all.size();k++)if(k!=i&&k!=j&&Rect.intersects(union,all.get(k).bounds)){occupied=true;break;}if(occupied)continue;
    first=new Paragraph(first.source+" "+next.source,union,first.background,first.ink,Math.max(first.sourceSize,next.sourceSize),first.leftAligned&&next.leftAligned,first.italic&&next.italic);all.set(i,first);all.remove(j);joined=true;reconsider=true;break;
   }}if(reconsider&&i>0)i-=2; // A newly complete continuation may now attach to its predecessor.
  }return all;
 }
 /** One lazily sampled mask, at most two background colours per viewport. */
 private static final class EnclosedRegions {
  final Bitmap image;final int stride,width,height;int[] labels,queue;int colour,analyses=0;final List<Boolean> enclosed=new ArrayList<>();
  EnclosedRegions(Bitmap image){this.image=image;stride=Math.max(2,(int)Math.ceil(Math.sqrt(image.getWidth()*(double)image.getHeight()/350000)));width=(image.getWidth()+stride-1)/stride;height=(image.getHeight()+stride-1)/stride;}
  boolean sameInterior(Paragraph a,Paragraph b){
   if(image.getWidth()*(long)image.getHeight()>8000000)return false;
   if(labels==null||distance(colour,a.background)>10){if(analyses>=2)return false;prepare(a.background);}
   int[] first=around(a.bounds),second=around(b.bounds);
   for(int id:first){if(id<=0||!enclosed.get(id))continue;int left=0,right=0;for(int value:first)if(value==id)left++;for(int value:second)if(value==id)right++;if(left>=2&&right>=2)return true;}return false;
  }
  void prepare(int background){
   analyses++;colour=background;if(labels==null){labels=new int[width*height];queue=new int[labels.length];}else Arrays.fill(labels,0);enclosed.clear();enclosed.add(false);int[] stripe=new int[image.getWidth()*stride];
   // Every pixel in a cell must match; thin/diagonal outlines cannot be skipped
   // by sampling only cell centres.
   for(int gy=0;gy<height;gy++){int rows=Math.min(stride,image.getHeight()-gy*stride);image.getPixels(stripe,0,image.getWidth(),0,gy*stride,image.getWidth(),rows);for(int gx=0;gx<width;gx++){
    boolean plain=true;for(int y=0;y<rows&&plain;y++)for(int x=gx*stride;x<Math.min(image.getWidth(),(gx+1)*stride);x++)if(distance(stripe[y*image.getWidth()+x],background)>35){plain=false;break;}
    if(!plain)labels[gy*width+gx]=-1;
   }}
  }
  int[] around(Rect r){int margin=stride*2;return new int[]{region(r.centerX(),r.top-margin),region(r.centerX(),r.bottom+margin),region(r.left-margin,r.centerY()),region(r.right+margin,r.centerY())};}
  int region(int x,int y){
   if(x<0||y<0||x>=image.getWidth()||y>=image.getHeight())return -1;int index=(y/stride)*width+x/stride;if(labels[index]!=0)return labels[index];
   int id=enclosed.size(),head=0,tail=0;boolean bounded=true;enclosed.add(false);labels[index]=id;queue[tail++]=index;
   while(head<tail){int at=queue[head++],cx=at%width,cy=at/width;if(cx==0||cy==0||cx==width-1||cy==height-1)bounded=false;
    if(cx>0&&labels[at-1]==0){labels[at-1]=id;queue[tail++]=at-1;}if(cx+1<width&&labels[at+1]==0){labels[at+1]=id;queue[tail++]=at+1;}
    if(cy>0&&labels[at-width]==0){labels[at-width]=id;queue[tail++]=at-width;}if(cy+1<height&&labels[at+width]==0){labels[at+width]=id;queue[tail++]=at+width;}
   }enclosed.set(id,bounded);return id;
  }
 }
 private static boolean near(Paragraph first,Paragraph next){
  Rect a=first.bounds,b=next.bounds;float size=Math.max(first.sourceSize,next.sourceSize),small=Math.min(first.sourceSize,next.sourceSize);int overlap=Math.min(a.right,b.right)-Math.max(a.left,b.left),gap=b.top-a.bottom;
  return gap>=-Math.min(a.height(),b.height())*.12f&&gap<=size*.95f&&small>=size*.5f&&overlap>Math.min(a.width(),b.width())*.45f&&(Math.abs(a.exactCenterX()-b.exactCenterX())<size*.7f||Math.abs(a.left-b.left)<size*.5f)&&distance(first.background,next.background)<(darkContinuation(first,next)?90:35)&&distance(first.ink,next.ink)<65;
 }
 private static boolean darkContinuation(Paragraph first,Paragraph next){return luminance(first.background)<.06&&luminance(next.background)<.06&&ConversationMeaning.holdContinuation(first.source,next.source);}
 private static boolean clearBridge(Bitmap image,Paragraph first,Paragraph next){
  Rect a=first.bounds,b=next.bounds;int left=Math.max(a.left,b.left),right=Math.min(a.right,b.right),threshold=darkContinuation(first,next)?90:55;if(right<=left)return false;
  // Reject a balloon border or image between fragments, including thin dark separators.
  int darkRows=0;for(int y=Math.max(0,a.bottom+2);y<Math.min(image.getHeight(),b.top-1);y++){
   int samples=0,dark=0;for(int x=left;x<right;x+=Math.max(1,(right-left)/40)){samples++;if(distance(image.getPixel(x,y),first.background)>threshold)dark++;}
   if(samples>0&&dark>samples*.2)darkRows++;
  }if(darkRows>=2)return false;
  // Side strips of a narrow first line must not contain a balloon outline or illustration.
  Rect union=new Rect(a);union.union(b);int checked=0,contrasting=0;for(int y=union.top;y<union.bottom;y+=3)for(int x=union.left;x<union.right;x+=3){if(x<0||y<0||x>=image.getWidth()||y>=image.getHeight()||a.contains(x,y)||b.contains(x,y))continue;checked++;if(distance(image.getPixel(x,y),first.background)>threshold)contrasting++;}
  return checked==0||contrasting<=checked*.025;
 }
 public static List<Paragraph> paragraphs(Bitmap bitmap,Text.TextBlock block){return paragraphs(bitmap,block,Collections.emptyList());}
 public static List<Paragraph> paragraphs(Bitmap bitmap,Text.TextBlock block,List<String> names){
  List<Text.Line> lines=new ArrayList<>(block.getLines());List<Paragraph> result=new ArrayList<>();
  lines.removeIf(line->line.getBoundingBox()==null||line.getText().trim().isEmpty());
  lines.sort(Comparator.comparingInt(line->line.getBoundingBox().top));if(lines.isEmpty())return result;
  List<Integer> heights=new ArrayList<>();for(Text.Line line:lines)heights.add(line.getBoundingBox().height());Collections.sort(heights);float median=heights.get(heights.size()/2);
  List<Text.Line> current=new ArrayList<>();Text.Line previous=null;
  for(Text.Line line:lines){
   if(previous!=null&&line.getBoundingBox().top-previous.getBoundingBox().bottom>Math.max(8,median*.9f)){result.add(describe(bitmap,current,names));current=new ArrayList<>();}
   current.add(line);previous=line;
  }
  if(!current.isEmpty())result.add(describe(bitmap,current,names));return result;
 }
 public static List<Paragraph> visibleLines(Bitmap bitmap,Text.TextBlock block,List<String> names,int edge){List<Paragraph> result=new ArrayList<>();for(Text.Line line:block.getLines())if(line.getBoundingBox()!=null&&line.getBoundingBox().top>edge&&line.getBoundingBox().bottom<bitmap.getHeight()-edge)result.add(describe(bitmap,Collections.singletonList(line),names));return result;}
 private static Paragraph describe(Bitmap bitmap,List<Text.Line> lines,List<String> names){
  Rect bounds=new Rect(lines.get(0).getBoundingBox());List<String> source=new ArrayList<>();List<Rect> glyphs=new ArrayList<>();List<Integer> heights=new ArrayList<>();
  float minLeft=Float.MAX_VALUE,maxLeft=-1,minCenter=Float.MAX_VALUE,maxCenter=-1;
  for(Text.Line line:lines){Rect r=line.getBoundingBox();bounds.union(r);source.add(line.getText());heights.add(r.height());minLeft=Math.min(minLeft,r.left);maxLeft=Math.max(maxLeft,r.left);minCenter=Math.min(minCenter,r.exactCenterX());maxCenter=Math.max(maxCenter,r.exactCenterX());for(Text.Element element:line.getElements())if(element.getBoundingBox()!=null)glyphs.add(element.getBoundingBox());}
  Collections.sort(heights);float size=heights.get(heights.size()/2)*1.30f;
  int background=background(bitmap,bounds);int ink=foreground(bitmap,glyphs,background);
  boolean left=lines.size()>1&&maxLeft-minLeft<Math.max(5,size*.3f)&&maxCenter-minCenter>size*.3f;
  return new Paragraph(ReadingText.joinLines(source,names),bounds,background,ink,size,left,italic(bitmap,glyphs,background));
 }
 private static boolean italic(Bitmap bitmap,List<Rect> glyphs,int background){
  List<Float> slants=new ArrayList<>();float[] candidates={-.45f,-.3f,-.15f,0,.15f,.3f,.45f};
  for(Rect glyph:glyphs){if(slants.size()>=10)break;Rect box=new Rect(glyph);if(!box.intersect(0,0,bitmap.getWidth(),bitmap.getHeight())||box.height()<10||box.width()<8)continue;int stride=Math.max(1,(int)Math.sqrt(box.width()*(double)box.height()/2500));List<Point> ink=new ArrayList<>();
   for(int y=box.top;y<box.bottom;y+=stride)for(int x=box.left;x<box.right;x+=stride){int color=bitmap.getPixel(x,y);if(contrast(color,background)>2&&distance(color,background)>60)ink.add(new Point(x-box.left,y-box.top));}
   if(ink.size()<20)continue;float best=0;double score=-1;for(float shear:candidates){int[] histogram=new int[box.width()+box.height()+4];for(Point point:ink){int x=Math.round(point.x+shear*(point.y-box.height()/2f))+box.height()/2+1;if(x>=0&&x<histogram.length)histogram[x]++;}double value=0;for(int count:histogram)value+=(double)count*count;if(value>score){score=value;best=shear;}}slants.add(best);
  }
  if(slants.size()<2)return false;Collections.sort(slants);return Math.abs(slants.get(slants.size()/2))>=.2f;
 }
 public static int background(Bitmap bitmap,Rect bounds){
  Map<Integer,Integer> histogram=new HashMap<>();
  int step=Math.max(1,Math.min(bounds.width(),bounds.height())/50);
  for(int x=bounds.left-5;x<=bounds.right+5;x+=step)for(int y=bounds.top-5;y<=bounds.bottom+5;y+=step){
   if(x<0||y<0||x>=bitmap.getWidth()||y>=bitmap.getHeight()||(x>bounds.left&&x<bounds.right&&y>bounds.top&&y<bounds.bottom))continue;
   count(histogram,bitmap.getPixel(x,y));
  }
  return dominant(histogram,Color.WHITE);
 }
 public static int foreground(Bitmap bitmap,List<Rect> glyphs,int background){
  Map<Integer,Integer> histogram=new HashMap<>();
  for(Rect glyph:glyphs){Rect r=new Rect(glyph);if(!r.intersect(0,0,bitmap.getWidth(),bitmap.getHeight()))continue;
   int step=Math.max(1,(int)Math.sqrt(Math.max(1,(long)r.width()*r.height()/5000)));
   for(int y=r.top;y<r.bottom;y+=step)for(int x=r.left;x<r.right;x+=step){int color=bitmap.getPixel(x,y);if((contrast(color,background)>=1.55||chroma(color)>80)&&distance(color,background)>55)count(histogram,color);}
  }
  int fallback=luminance(background)>.4?Color.rgb(24,24,28):Color.WHITE;
  int ink=dominant(histogram,fallback);return contrast(ink,background)<1.55&&chroma(ink)<=80?fallback:ink;
 }
 private static void count(Map<Integer,Integer> histogram,int color){int key=((Color.red(color)/16)<<8)|((Color.green(color)/16)<<4)|(Color.blue(color)/16);histogram.put(key,histogram.getOrDefault(key,0)+1);}
 private static int dominant(Map<Integer,Integer> histogram,int fallback){int best=-1,count=0;for(var item:histogram.entrySet())if(item.getValue()>count){count=item.getValue();best=item.getKey();}if(best<0)return fallback;if(best==0xfff)return Color.WHITE;if(best==0)return Color.BLACK;return Color.rgb(((best>>8)&15)*16+8,((best>>4)&15)*16+8,(best&15)*16+8);}
 private static int chroma(int color){return Math.max(Color.red(color),Math.max(Color.green(color),Color.blue(color)))-Math.min(Color.red(color),Math.min(Color.green(color),Color.blue(color)));}
 private static int distance(int a,int b){return Math.max(Math.abs(Color.red(a)-Color.red(b)),Math.max(Math.abs(Color.green(a)-Color.green(b)),Math.abs(Color.blue(a)-Color.blue(b))));}
 private static final double[] LINEAR=new double[256];static{for(int i=0;i<256;i++){double s=i/255.0;LINEAR[i]=s<=.04045?s/12.92:Math.pow((s+.055)/1.055,2.4);}}
 private static double linear(int channel){return LINEAR[channel];}
 private static double luminance(int color){return .2126*linear(Color.red(color))+.7152*linear(Color.green(color))+.0722*linear(Color.blue(color));}
 static double contrast(int a,int b){double la=luminance(a),lb=luminance(b);return (Math.max(la,lb)+.05)/(Math.min(la,lb)+.05);}
}
