package com.komiklingo.app;

/** Two matching observations avoid translating each letter of animated game dialogue. */
public final class LiveDialogueGate {
 private String candidate="",submitted="";private int matches;
 public boolean changed(String source){return !key(source).equals(candidate);}
 public boolean observe(String source){String next=key(source);if(!next.equals(candidate)){candidate=next;matches=1;}else matches++;if(next.isEmpty()){submitted="";return false;}if(matches<2||next.equals(submitted))return false;submitted=next;return true;}
 public void retry(){submitted="";matches=0;}
 public void reset(){candidate="";submitted="";matches=0;}
 private static String key(String source){return source==null?"":source.replaceAll("\\s+"," ").trim();}
}
