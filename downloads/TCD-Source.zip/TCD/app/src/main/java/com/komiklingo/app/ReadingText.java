package com.komiklingo.app;

import java.util.*;
import java.util.regex.*;

/** Conservative OCR cleanup and an explicit reading register, not a story-understanding model. */
public final class ReadingText {
 public static final String DIALOGUE="dialogue", NEUTRAL="neutral", FORMAL="formal";
 private static final Pattern MERGED_I=Pattern.compile("\\b(AFTER|BEFORE|WHEN|IF|SINCE|WHILE)I(?=\\s+(?:WENT|HAVE|HAD|GO|DID|WAS|AM|WILL|WOULD|DON['’]T|DIDN['’]T)\\b)",Pattern.CASE_INSENSITIVE);
 private static final Set<String> KNOWN=new HashSet<>(Arrays.asList("suddenly","everyone","everything","something","nothing","because","through","yourself","myself","anything"));
 /** Publisher notices are not part of the conversation. Require an entire notice. */
 public static boolean publisherNotice(String text){
  String s=text.trim().replaceAll("\\s+"," ");
  return s.matches("(?iu)^(?:read|please read)\\s+(?:this|the)\\s+(?:series|chapter|comic)\\s+(?:at|on)\\s+.{2,100}\\s+to\\s+support\\s+us[! .]*$")
    ||s.matches("(?iu)^(?:https?://)?(?:www\\.)?[a-z0-9-]+\\.(?:com|net|org)(?:/)?[! .]*$");
 }
 /** Reject plainly broken mixed-language output instead of displaying it as dialogue. */
 public static boolean garbledTranslation(String source,String target){
  if(source==null||target==null||source.length()<15)return false;
  return Pattern.compile("(?iu)\\$\\s*[a-z]|\\b(?:dont|wont|cant|sulking)\\b|//").matcher(target).find();
 }
 public static String cleanOcr(String source){
  String s=source.replace('\u2019','\'').replaceAll("\\s+"," ").trim();
  s=MERGED_I.matcher(s).replaceAll("$1 I");
  Matcher words=Pattern.compile("[A-Za-z]+").matcher(s);StringBuffer out=new StringBuffer();
  while(words.find()){
   String word=words.group(),lower=word.toLowerCase(Locale.ROOT),candidate=lower;
   // Correct a duplicated final OCR letter only when it yields a known common word.
   if(lower.length()>6&&lower.charAt(lower.length()-1)==lower.charAt(lower.length()-2)&&KNOWN.contains(lower.substring(0,lower.length()-1)))candidate=lower.substring(0,lower.length()-1);
   if(candidate.equals(lower)&&lower.startsWith("fe")&&KNOWN.contains(lower.substring(1)))candidate=lower.substring(1);
   if(candidate.equals(lower)){words.appendReplacement(out,Matcher.quoteReplacement(word));continue;}
   if(word.equals(word.toUpperCase(Locale.ROOT)))candidate=candidate.toUpperCase(Locale.ROOT);
   else if(Character.isUpperCase(word.charAt(0)))candidate=Character.toUpperCase(candidate.charAt(0))+candidate.substring(1);
   words.appendReplacement(out,Matcher.quoteReplacement(candidate));
  }
  words.appendTail(out);return out.toString();
 }
 public static String style(String source,String target,String requested){
  if(target==null)return "";
  String style=requested;
  // A visible direct honorific is evidence to keep the basic engine's formal register.
  if(DIALOGUE.equals(style)&&Pattern.compile("\\b(?:your majesty|your highness|sir|madam)\\b",Pattern.CASE_INSENSITIVE).matcher(source).find())style=FORMAL;
  String result=target.trim();
  if(!FORMAL.equals(style))result=replaceWord(result,"anda","kamu");
  else result=replaceWord(result,"kamu","Anda");
  if(DIALOGUE.equals(style))result=replaceWord(result,"saya","aku");
  else result=replaceWord(result,"aku","saya");
  // Normalize duplicated OCR/engine whitespace, leaving emphasis and punctuation intact.
  if(Pattern.compile("(?iu)\\bmr\\.\\s+").matcher(source).find())result=result.replaceAll("(?iu)\\bbp\\.\\s+", "Tuan ");
  return paragraphs(result);
 }
 // Only known word-wrap joins, so stutters, interrupted speech and names are not guessed.
 private static final Set<String> WRAPPED=new HashSet<>(Arrays.asList("suddenly","because","although","however","someone","somebody","something","somewhere","anyone","anybody","anything","anywhere","everyone","everybody","everything","everywhere","nothing","nobody","nowhere","understand","understood","remember","remembered","forgotten","another","without","together","alone","already","always","different","difference","important","impossible","probably","promise","promised","protect","protected","protection","yourself","myself","himself","herself","ourselves","themselves","conversation","beautiful","believe","believed","happened","happening","happens","tomorrow","yesterday","disappeared","disappear","abandoned","reason","really","people","please","through","world"));
 public static String joinLines(List<String> lines){return joinLines(lines,Collections.emptyList());}
 public static String joinLines(List<String> lines,List<String> names){
  StringBuilder result=new StringBuilder();for(String raw:lines){String line=raw.trim().replaceAll("\\s+"," ");if(line.isEmpty())continue;
   if(result.length()==0){result.append(line);continue;}
   Matcher left=Pattern.compile("([A-Za-z]{2,})-$").matcher(result);Matcher right=Pattern.compile("^([A-Za-z]{2,})").matcher(line);
   boolean split=left.find()&&right.find(),named=false;
   if(split)for(String name:names)if(name.equalsIgnoreCase(left.group(1)+"-"+right.group(1))){named=true;break;}
   if(named)result.append(line);
   else if(split&&WRAPPED.contains((left.group(1)+right.group(1)).toLowerCase(Locale.ROOT))){result.deleteCharAt(result.length()-1);result.append(line);}
   else result.append(' ').append(line);
  }return result.toString();
 }
 private static final Pattern STUTTER=Pattern.compile("(?iu)^([a-z])[-‐‑]\\s*([a-z]+(?:['’][a-z]+)?)");
 private static boolean stutter(String source){Matcher match=STUTTER.matcher(source.trim());if(!match.find())return false;String next=match.group(2).toLowerCase(Locale.ROOT).replace('’','\'');return match.group(1).equalsIgnoreCase(next.substring(0,1))||Arrays.asList("don't","can't","won't","didn't","isn't","wasn't","couldn't","wouldn't","shouldn't").contains(next);}
 public static String emotion(String source,String target){
  if(!stutter(source)||STUTTER.matcher(target.trim()).find())return target;Matcher word=Pattern.compile("^([\\p{L}])([\\p{L}’']*)").matcher(target);if(!word.find())return target;
  String first=word.group(1);return first+"-"+target;
 }
 /** Expand only unambiguous contractions; do not guess whether 'd/'s means had/would/is/has. */
 public static String translationInput(String source){
  String result=source.replace('’','\'');if(stutter(result)){Matcher start=STUTTER.matcher(result);if(start.find())result=result.substring(start.start(2));}
  String[][] pairs={{"won't","will not"},{"can't","cannot"},{"don't","do not"},{"doesn't","does not"},{"didn't","did not"},{"isn't","is not"},{"aren't","are not"},{"wasn't","was not"},{"weren't","were not"},{"haven't","have not"},{"hasn't","has not"},{"hadn't","had not"},{"couldn't","could not"},{"wouldn't","would not"},{"shouldn't","should not"},{"I'm","I am"},{"you're","you are"},{"we're","we are"},{"they're","they are"},{"I've","I have"},{"you've","you have"},{"we've","we have"},{"they've","they have"},{"I'll","I will"},{"you'll","you will"},{"he'll","he will"},{"she'll","she will"},{"we'll","we will"},{"they'll","they will"},{"it'll","it will"}};
  for(String[] pair:pairs)result=replaceWord(result,pair[0],pair[1]);return ContextMeaning.normalize(result);
 }
 public static String paragraphs(String value){
  if(value==null)return "";String normalized=value.replace("\r\n","\n").replace('\r','\n');
  StringBuilder result=new StringBuilder();for(String paragraph:normalized.split("\n[ \t]*\n+")){
   String text=paragraph.replaceAll("\\s+"," ").trim();if(text.isEmpty())continue;
   text=text.replaceAll("[ \t]+([,.;:!?])","$1").replaceAll("([!?])[ \t]+(?=[!?])","$1").replaceAll("([,;:!?])(?=[\\p{L}])","$1 ");
   if(result.length()>0)result.append("\n\n");result.append(text);
  }
  return result.toString();
 }
 private static String replaceWord(String text,String from,String to){
  Matcher m=Pattern.compile("(?iu)(?<![\\p{L}\\p{N}_])"+from+"(?![\\p{L}\\p{N}_])").matcher(text);StringBuffer b=new StringBuffer();
  while(m.find()){String word=m.group(),replacement=to;if(word.equals(word.toUpperCase(Locale.ROOT)))replacement=to.toUpperCase(Locale.ROOT);else if(Character.isUpperCase(word.charAt(0))&&(text.substring(0,m.start()).trim().isEmpty()||text.substring(0,m.start()).matches("(?s).*[.!?:\\n][\\s\"“]*")))replacement=Character.toUpperCase(to.charAt(0))+to.substring(1);m.appendReplacement(b,Matcher.quoteReplacement(replacement));}
  m.appendTail(b);return b.toString();
 }
 public static List<String> splitBatch(String output,int expected){
  if(output==null)return null;String[] parts=output.trim().split("\\n\\s*\\n",-1);
  if(parts.length!=expected)return null;List<String> result=new ArrayList<>();
  for(String p:parts){if(p.trim().isEmpty())return null;result.add(p.trim());}return result;
 }
}
