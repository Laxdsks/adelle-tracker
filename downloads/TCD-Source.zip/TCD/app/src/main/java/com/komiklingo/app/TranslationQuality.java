package com.komiklingo.app;

import java.util.*;
import java.util.regex.*;

/** Detect verifiable omissions, not a claim to judge arbitrary semantic correctness. */
public final class TranslationQuality {
 private static final String[] NUMBERS={"nol|kosong","satu|seorang|sebuah|suatu","dua|kedua","tiga|ketiga","empat|keempat","lima|kelima","enam|keenam","tujuh|ketujuh","delapan|kedelapan","sembilan|kesembilan","sepuluh|kesepuluh","sebelas|kesebelas","dua belas|kedua belas","tiga belas|ketiga belas","empat belas|keempat belas","lima belas|kelima belas","enam belas|keenam belas","tujuh belas|ketujuh belas","delapan belas|kedelapan belas","sembilan belas|kesembilan belas","dua puluh|kedua puluh"};
 private static String withoutMarkers(String value){return value.replaceAll("(?i)ZXQNAMEX*\\d+QXZ", " ");}
 public static boolean suspicious(String source,String target){
  if(target==null)return true;String from=withoutMarkers(source),to=withoutMarkers(target);
  // Numeric values may be written as Indonesian words. Protected names are not numbers.
  Matcher values=Pattern.compile("(?i)(?<![\\p{L}\\p{N}])([0-9]+(?:[.,][0-9]+)?)(?:st|nd|rd|th)?(?![\\p{L}\\p{N}])").matcher(from);
  while(values.find()){
   String number=values.group(1);String[] parts=number.split("[.,]",-1);String digits=Pattern.quote(parts[0]);if(parts.length==2)digits+="[.,]"+Pattern.quote(parts[1]);
   if(Pattern.compile("(?<![\\p{L}\\p{N}])"+digits+"(?![\\p{L}\\p{N}])").matcher(to).find())continue;
   long integer=-1;try{integer=Long.parseLong(number);}catch(NumberFormatException ignored){}
   if(integer>=0&&integer<NUMBERS.length&&Pattern.compile("(?iu)\\b(?:"+NUMBERS[(int)integer]+")\\b").matcher(to).find())continue;
   if(integer>=0&&integer<1000000000000L&&Pattern.compile("(?iu)\\b(?:ke[- ]?)?"+Pattern.quote(spelled(integer)).replace(" ","\\E\\s+\\Q")+"\\b").matcher(to).find())continue;
   // Decimal and formatted quantities can be expressed many valid ways (1.5 -> satu setengah).
   // Only compare plain integer literals; do not guess their decimal/localized equivalence.
   if(integer<0)continue;
   return true;
  }
  int sourceWords=words(from),targetWords=words(to);
  return sourceWords>=16&&targetWords<Math.max(3,sourceWords/5);
 }
 private static String spelled(long n){
  String[] small={"nol","satu","dua","tiga","empat","lima","enam","tujuh","delapan","sembilan","sepuluh","sebelas"};
  if(n<12)return small[(int)n];if(n<20)return spelled(n-10)+" belas";
  if(n<100)return spelled(n/10)+" puluh"+(n%10==0?"":" "+spelled(n%10));
  if(n<200)return "seratus"+(n==100?"":" "+spelled(n-100));
  if(n<1000)return spelled(n/100)+" ratus"+(n%100==0?"":" "+spelled(n%100));
  if(n<2000)return "seribu"+(n==1000?"":" "+spelled(n-1000));
  long base=n<1000000?1000:n<1000000000?1000000:1000000000;
  return spelled(n/base)+(base==1000?" ribu":base==1000000?" juta":" miliar")+(n%base==0?"":" "+spelled(n%base));
 }
 private static int words(String text){Matcher words=Pattern.compile("[\\p{L}]+(?:['’][\\p{L}]+)?").matcher(text);int count=0;while(words.find())count++;return count;}
 private TranslationQuality(){}
}
