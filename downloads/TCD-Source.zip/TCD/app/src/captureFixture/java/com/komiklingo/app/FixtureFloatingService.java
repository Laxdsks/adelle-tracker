package com.komiklingo.app;
import java.util.*;
public class FixtureFloatingService extends FloatingTranslateService {
 public static volatile boolean delay=false;public static volatile NameTranslation.Result pending;public static volatile String pendingSource;
 public static volatile FixtureFloatingService instance;public static volatile String last="";public static volatile List<String> read=new ArrayList<>();public static volatile int requests=0;
 @Override public void onCreate(){super.onCreate();instance=this;last="CREATED";requests=0;delay=false;pending=null;}
 @Override protected void prepareLanguage(Runnable ready,Runnable failed){ready.run();}
 @Override protected void translateSource(String source,NameTranslation.Result result){requests++;if(delay){pending=result;pendingSource=source;return;}result.done(source.replace("HELLO","HALO").replace("ANOTHER APP","APLIKASI LAIN"),null);}
 @Override protected void outcome(String value){last=value;if(value.equals("RESULT")||value.equals("LIVE_RESULT"))try{var field=FloatingTranslateService.class.getDeclaredField("sources");field.setAccessible(true);read=new ArrayList<>((List<String>)field.get(this));}catch(Exception error){throw new AssertionError(error);}}
 @Override public void onDestroy(){super.onDestroy();last="STOPPED";instance=null;}
}
