package com.komiklingo.app;
public class FixtureTextActivity extends TextTranslationActivity {
 @Override protected void prepareLanguage(Runnable success,Runnable failure){success.run();}
 @Override protected void translateLocal(String source,NameTranslation.Result result){result.done(source.replace("HELLO","HALO").replace("WORLD","DUNIA"),null);}
}
