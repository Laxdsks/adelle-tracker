package com.komiklingo.app;
public class FixturePageActivity extends MainActivity {
 @Override protected void prepareLanguage(Runnable ready,Runnable failed){ready.run();}
 @Override protected void translateLocal(String source,NameTranslation.Result result){result.done(source.replace("HELLO","HALO").replace("WORLD","DUNIA"),null);}
}
