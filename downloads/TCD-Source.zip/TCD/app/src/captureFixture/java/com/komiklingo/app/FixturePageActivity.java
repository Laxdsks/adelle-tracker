package com.komiklingo.app;
public class FixturePageActivity extends MainActivity {
 public static volatile int requests=0;public static volatile boolean fail=false;public static volatile String suffix="";public static final java.util.List<String> inputs=java.util.Collections.synchronizedList(new java.util.ArrayList<>());
 public static volatile java.util.function.UnaryOperator<String> outputMapper=null;
 @Override protected void prepareLanguage(Runnable ready,Runnable failed){ready.run();}
 @Override protected void translateLocal(String source,NameTranslation.Result result){requests++;inputs.add(source);if(fail){result.done(null,new IllegalStateException("Fixture failure"));return;}result.done(outputMapper==null?(source+suffix).replace("HELLO","HALO").replace("WORLD","DUNIA"):outputMapper.apply(source),null);}
}
