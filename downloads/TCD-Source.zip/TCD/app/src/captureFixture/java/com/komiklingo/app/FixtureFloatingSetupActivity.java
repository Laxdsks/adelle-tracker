package com.komiklingo.app;
public class FixtureFloatingSetupActivity extends FloatingSetupActivity {
 @Override protected Class<? extends FloatingTranslateService> serviceClass(){return FixtureFloatingService.class;}
 @Override protected void prepareLanguage(Runnable ready,Runnable failed){ready.run();}
}
