package com.komiklingo.app;
import android.graphics.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.junit.*;
import org.junit.runner.RunWith;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
public class ContextAssemblyTest {
 private Text.TextBlock block(String text,Rect bounds){var points=List.of(new Point(bounds.left,bounds.top),new Point(bounds.right,bounds.top),new Point(bounds.right,bounds.bottom),new Point(bounds.left,bounds.bottom));var word=new Text.Element(text,bounds,points,"en",new Matrix(),.99f,0,List.of());var line=new Text.Line(text,bounds,points,"en",new Matrix(),List.of(word),.99f,0);return new Text.TextBlock(text,bounds,points,"en",new Matrix(),List.of(line));}
 private OcrAppearance.Paragraph paragraph(String source,Rect box){return new OcrAppearance.Paragraph(source,box,Color.WHITE,Color.BLACK,50,false,false);}
 @Test public void joinsDependentPrefixAcrossBlocksButNotCompleteSentences(){
  Bitmap image=Bitmap.createBitmap(700,600,Bitmap.Config.ARGB_8888);new Canvas(image).drawColor(Color.WHITE);
  var prefix=paragraph("ARE A",new Rect(270,60,430,100));var body=paragraph("BRAND OF FATE, AND A CURSE FROM GOD.",new Rect(160,125,540,280));var combined=OcrAppearance.joinFragments(image,List.of(body,prefix));assertEquals(1,combined.size());assertEquals("ARE A BRAND OF FATE, AND A CURSE FROM GOD.",combined.get(0).source);assertEquals(new Rect(160,60,540,280),combined.get(0).bounds);
  assertEquals(2,OcrAppearance.joinFragments(image,List.of(paragraph("I AM READY!",new Rect(200,60,500,100)),paragraph("ARE YOU READY?",new Rect(200,125,500,165)))).size());
  assertEquals(2,OcrAppearance.joinFragments(image,List.of(paragraph("THE",new Rect(270,60,430,100)),body),List.of("The")).size());assertFalse(ContextMeaning.dangling("AN",List.of("An")));image.recycle();
 }
 @Test public void keepsPausedModalConnectedToVerbButNotAnotherSpeaker(){
  Bitmap image=Bitmap.createBitmap(700,600,Bitmap.Config.ARGB_8888);new Canvas(image).drawColor(Color.WHITE);var prefix=paragraph("I COULDN'T...",new Rect(220,60,480,100));var body=paragraph("SENSE HER PRESENCE AT ALL!",new Rect(130,125,570,240));var result=OcrAppearance.joinFragments(image,List.of(prefix,body));assertEquals(1,result.size());assertEquals("I COULDN'T... SENSE HER PRESENCE AT ALL!",result.get(0).source);
  assertEquals(2,OcrAppearance.joinFragments(image,List.of(prefix,paragraph("WHY NOT?",new Rect(220,125,480,165)))).size());assertEquals(2,OcrAppearance.joinFragments(image,List.of(prefix,body),List.of("Sense")).size());
  var strength=OcrAppearance.joinFragments(image,List.of(paragraph("SHE'S A POWERHOUSE",new Rect(180,60,520,100)),paragraph("ON THE LEVEL OF ACRATOS.",new Rect(150,125,550,220))));assertEquals(1,strength.size());assertEquals("SHE'S A POWERHOUSE ON THE LEVEL OF ACRATOS.",strength.get(0).source);image.recycle();
 }
 @Test public void respectsBalloonBordersAndDifferentColumns(){
  Bitmap image=Bitmap.createBitmap(700,600,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(image);canvas.drawColor(Color.WHITE);Paint paint=new Paint();paint.setColor(Color.BLACK);canvas.drawRect(100,110,600,114,paint);var a=paragraph("THIS IS A",new Rect(200,60,500,100));var b=paragraph("DIFFERENT STORY",new Rect(180,130,520,170));assertEquals(2,OcrAppearance.joinFragments(image,List.of(a,b)).size());canvas.drawColor(Color.WHITE);assertEquals(2,OcrAppearance.joinFragments(image,List.of(a,paragraph("DIFFERENT STORY",new Rect(550,130,695,170)))).size());image.recycle();
 }
 @Test public void realOcrFeedsOneCompletePredicateFromComicStyleImage()throws Exception{
  Bitmap image=Bitmap.createBitmap(900,650,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(image);canvas.drawColor(Color.WHITE);Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setColor(Color.BLACK);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(4);canvas.drawOval(90,40,810,610,paint);paint.setStyle(Paint.Style.FILL);paint.setTypeface(Typeface.create("sans-serif",Typeface.ITALIC));paint.setTextSize(46);String[] lines={"ARE A","BRAND OF FATE,","AND A CURSE","FROM GOD."};for(int i=0;i<lines.length;i++)canvas.drawText(lines[i],450-paint.measureText(lines[i])/2,170+i*70,paint);
  var recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);var worker=Executors.newSingleThreadExecutor();var done=new CountDownLatch(1);var result=new AtomicReference<Text>();var failure=new AtomicReference<Exception>();try{InstrumentationRegistry.getInstrumentation().runOnMainSync(()->OcrReader.read(recognizer,image,worker,()->true,new OcrReader.Result(){public void success(Text text){result.set(text);done.countDown();}public void failure(Exception error){failure.set(error);done.countDown();}}));assertTrue(done.await(90,TimeUnit.SECONDS));assertNull(failure.get());var paragraphs=OcrAppearance.readingParagraphs(image,result.get(),List.of(),false);assertTrue(result.get().getText()+" | assembled: "+paragraphs.stream().map(p->p.source+" "+p.bounds).reduce("",(a,b)->a+" / "+b),paragraphs.stream().anyMatch(p->p.source.replaceAll("\\s+"," ").contains("ARE A BRAND OF FATE, AND A CURSE FROM GOD.")));}finally{recognizer.close();worker.shutdown();image.recycle();}
 }
}
