package com.komiklingo.app;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.widget.*;
import android.view.*;
/** Lives in the test APK's distinct application/UID, never in the user APK. */
public class OtherAppScreen extends Activity {
 @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON|WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);if(getIntent().getBooleanExtra("secure",false))getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(30,getIntent().getBooleanExtra("lower-dialogue",false)?getResources().getDisplayMetrics().heightPixels/3:80,30,30);page.setBackgroundColor(Color.WHITE);TextView title=new TextView(this);title.setText(getIntent().getBooleanExtra("secure",false)?"PRIVATE SECRET SCREEN":"HELLO FROM ANOTHER APP");title.setTextColor(Color.BLACK);title.setTextSize(26);page.addView(title);TextView subtitle=new TextView(this);subtitle.setText("DO YOU UNDERSTAND?");subtitle.setTextSize(22);subtitle.setTextColor(Color.rgb(180,20,20));page.addView(subtitle);FrameLayout stage=new FrameLayout(this);stage.addView(page,new FrameLayout.LayoutParams(-1,-1));Button next=new Button(this);next.setText("Next dialogue");next.setOnClickListener(v->title.setText(title.getText().toString().contains("AGAIN")?"HELLO THIRD FROM ANOTHER APP":"HELLO AGAIN FROM ANOTHER APP"));stage.addView(next,new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER));setContentView(stage);}
}
