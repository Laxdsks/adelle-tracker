package com.komiklingo.app;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.widget.*;
import android.view.*;
/** Lives in the test APK's distinct application/UID, never in the user APK. */
public class OtherAppScreen extends Activity {
 @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON|WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);if(getIntent().getBooleanExtra("secure",false))getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(30,80,30,30);page.setBackgroundColor(Color.WHITE);TextView title=new TextView(this);title.setText(getIntent().getBooleanExtra("secure",false)?"PRIVATE SECRET SCREEN":"HELLO FROM ANOTHER APP");title.setTextColor(Color.BLACK);title.setTextSize(26);page.addView(title);TextView subtitle=new TextView(this);subtitle.setText("DO YOU UNDERSTAND?");subtitle.setTextSize(22);subtitle.setTextColor(Color.rgb(180,20,20));page.addView(subtitle);setContentView(page);}
}
