package com.komiklingo.app;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.junit.*;
import org.junit.runner.RunWith;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class ReaderRepairTest {
 private Text.TextBlock block(String text,float confidence){Rect r=new Rect(50,50,550,100);var line=new Text.Line(text,r,List.of(),"en",new Matrix(),List.of(),confidence,0);return new Text.TextBlock(text,r,List.of(),"en",new Matrix(),List.of(line));}
 @Test public void suspiciousPronounNeedsAnIndependentCandidateAndNamesStayProtected()throws Exception{
  OcrQuality.load(InstrumentationRegistry.getInstrumentation().getTargetContext().getAssets().open("english-ocr-words.txt"));var old=block("NE PLAN TO HEAD",.99f);var replacement=block("WE PLAN TO HEAD",.90f);Text first=new Text(old.getText(),List.of(old));assertTrue(OcrReader.weak(first));assertEquals("NE PLAN TO HEAD",first.getText());assertEquals("WE PLAN TO HEAD",OcrReader.merge(first,new Text(replacement.getText(),List.of(replacement))).getText());assertFalse(OcrQuality.keepsNames("MOE","MOVE",List.of("Moe")));
 }
 @Test public void oversizedTranslationNeverCoversOrCutsOriginalText(){
  var ins=InstrumentationRegistry.getInstrumentation();ins.runOnMainSync(()->{BubbleOverlay overlay=new BubbleOverlay(ins.getTargetContext());overlay.layout(0,0,700,500);String text=String.join(" ",Collections.nCopies(40,"Terjemahan panjang"));RectF box=new RectF(80,80,260,102);overlay.show(List.of(new BubbleOverlay.Bubble(box,text,Color.WHITE,true,null,42,false,false)));Bitmap image=Bitmap.createBitmap(700,500,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(image);canvas.drawColor(Color.RED);Paint ink=new Paint();ink.setColor(Color.BLACK);canvas.drawRect(90,85,250,97,ink);Bitmap before=image.copy(Bitmap.Config.ARGB_8888,false);overlay.draw(canvas);for(int y=80;y<102;y++)for(int x=80;x<260;x++)assertEquals("Overflow masked source pixels",before.getPixel(x,y),image.getPixel(x,y));assertTrue(overlay.getChildCount()>0);assertTrue(((TextView)overlay.getChildAt(0)).getText().toString().startsWith("Terjemahan"));before.recycle();image.recycle();});
 }
 private TextView find(View root,String text){if(root instanceof TextView&&((TextView)root).getText().toString().equals(text))return (TextView)root;if(root instanceof ViewGroup)for(int i=0;i<((ViewGroup)root).getChildCount();i++){TextView v=find(((ViewGroup)root).getChildAt(i),text);if(v!=null)return v;}return null;}
 @Test public void overflowChipOpensFullSelectableTextAndCopy()throws Exception{
  var ins=InstrumentationRegistry.getInstrumentation();var context=ins.getTargetContext();context.getSharedPreferences("reader",Context.MODE_PRIVATE).edit().putBoolean("automatic",false).putBoolean("reader-tools-hidden",false).commit();FixturePageActivity a=(FixturePageActivity)ins.startActivitySync(new Intent(context,FixturePageActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));String full="Aaah! Sakit kepalaku kambuh lagi! "+String.join(" ",Collections.nCopies(25,"Hasil lengkap tetap dapat dibaca."));
  try{var overlay=new AtomicReference<BubbleOverlay>();ins.runOnMainSync(()->{try{var show=MainActivity.class.getDeclaredMethod("showReader");show.setAccessible(true);show.invoke(a);var f=MainActivity.class.getDeclaredField("overlay");f.setAccessible(true);overlay.set((BubbleOverlay)f.get(a));}catch(Exception e){throw new AssertionError(e);}});ins.waitForIdleSync();var dialog=new AtomicReference<AlertDialog>();
   ins.runOnMainSync(()->{overlay.get().show(List.of(new BubbleOverlay.Bubble(new RectF(60,80,240,100),full,Color.WHITE,true,null,9,false,false)));TextView chip=find(overlay.get(),"Terjemahan ↗");assertNotNull(chip);chip.performClick();try{var f=BubbleOverlay.class.getDeclaredField("expanded");f.setAccessible(true);dialog.set((AlertDialog)f.get(overlay.get()));}catch(Exception e){throw new AssertionError(e);}TextView result=find(dialog.get().getWindow().getDecorView(),full);assertNotNull(result);assertTrue(result.isTextSelectable());assertNotNull(dialog.get().getButton(AlertDialog.BUTTON_NEUTRAL));dialog.get().getButton(AlertDialog.BUTTON_NEGATIVE).performClick();});ins.waitForIdleSync();ins.runOnMainSync(()->{var clipboard=(ClipboardManager)context.getSystemService(Context.CLIPBOARD_SERVICE);assertEquals(full,clipboard.getPrimaryClip().getItemAt(0).getText().toString());});
  }finally{ins.runOnMainSync(a::finish);}
 }
 @Test public void actualOcrReadsWeMoveAndKingdomNameInItalicText()throws Exception{
  var context=InstrumentationRegistry.getInstrumentation().getTargetContext();OcrQuality.load(context.getAssets().open("english-ocr-words.txt"));TessFallback.prepare(context);Bitmap b=Bitmap.createBitmap(1100,900,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(b);canvas.drawColor(Color.WHITE);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(Color.BLACK);p.setTextSize(53);p.setTypeface(Typeface.create("sans-serif",Typeface.ITALIC));String[] lines={"GAHAHAHAHA! ENOUGH!","WE PLAN TO HEAD","TO THE UHWANA KINGDOM","IMMEDIATELY!","GET READY TO MOVE!"};for(int i=0;i<lines.length;i++)canvas.drawText(lines[i],550-p.measureText(lines[i])/2,170+i*95,p);
  var recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);var worker=Executors.newSingleThreadExecutor();var done=new CountDownLatch(1);var result=new AtomicReference<Text>();var error=new AtomicReference<Exception>();
  try{InstrumentationRegistry.getInstrumentation().runOnMainSync(()->OcrReader.read(recognizer,b,worker,()->true,new OcrReader.Result(){public void success(Text t){result.set(t);done.countDown();}public void failure(Exception e){error.set(e);done.countDown();}}));assertTrue(done.await(90,TimeUnit.SECONDS));assertNull(error.get());String source=result.get().getText();assertTrue(source,source.contains("WE PLAN"));assertTrue(source,source.contains("MOVE"));assertTrue(source,source.contains("UHWANA"));assertTrue(ProtectedTerms.discover(List.of(source)).contains("UHWANA"));}finally{recognizer.close();worker.shutdown();b.recycle();}
 }
 @Test public void nonActivityFallbackUsesTheGrantedOverlayWindow(){
  var ins=InstrumentationRegistry.getInstrumentation();var context=ins.getTargetContext();assertTrue("Test setup must grant overlay app-op",android.provider.Settings.canDrawOverlays(context));ins.runOnMainSync(()->{BubbleOverlay overlay=new BubbleOverlay(context);overlay.layout(0,0,700,500);try{overlay.show(List.of(new BubbleOverlay.Bubble(new RectF(80,80,230,100),String.join(" ",Collections.nCopies(40,"Hasil lengkap")),Color.WHITE,true)));find(overlay,"Terjemahan ↗").performClick();var f=BubbleOverlay.class.getDeclaredField("expanded");f.setAccessible(true);AlertDialog dialog=(AlertDialog)f.get(overlay);assertNotNull(dialog);assertTrue(dialog.isShowing());assertEquals(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,dialog.getWindow().getAttributes().type);}catch(Exception e){throw new AssertionError(e);}finally{overlay.clear();}});
 }
}
