package com.komiklingo.app;
import android.graphics.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.junit.*;
import org.junit.runner.RunWith;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class PhrasalContextTest {
 private OcrAppearance.Paragraph p(String source,Rect box){return new OcrAppearance.Paragraph(source,box,Color.WHITE,Color.BLACK,50,false,false);}
 @Test public void particleInAnotherOcrBlockStaysAttachedToHumanVerb(){
  Bitmap b=Bitmap.createBitmap(700,600,Bitmap.Config.ARGB_8888);new Canvas(b).drawColor(Color.WHITE);
  try{var text=OcrAppearance.joinFragments(b,List.of(p("BY THE TIME I BURST",new Rect(160,70,540,115)),p("IN-",new Rect(290,140,410,185))));assertEquals(1,text.size());assertEquals("BY THE TIME I BURST IN-",text.get(0).source);assertEquals("BY THE TIME I BURST IN-",ReadingText.translationInput(text.get(0).source));assertEquals("Saat aku menerobos masuk-",ContextMeaning.polish(text.get(0).source,"Saat aku meledak-"));
   assertEquals(2,OcrAppearance.joinFragments(b,List.of(p("THE BOMB BURST",new Rect(160,70,540,115)),p("IN THE ROOM.",new Rect(200,140,500,185)))).size());
   var emotion=OcrAppearance.joinFragments(b,List.of(p("SHE BURST",new Rect(220,70,480,115)),p("INTO TEARS.",new Rect(200,140,500,185))));assertEquals(1,emotion.size());assertEquals("SHE BURST INTO TEARS.",ReadingText.translationInput(emotion.get(0).source));
  }finally{b.recycle();}
 }
 @Test public void particleCannotCrossOutlineEvenWithMatchingSyntax(){
  Bitmap b=Bitmap.createBitmap(700,600,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);c.drawColor(Color.WHITE);Paint pen=new Paint();pen.setColor(Color.BLACK);c.drawRect(100,125,600,130,pen);
  try{assertEquals(2,OcrAppearance.joinFragments(b,List.of(p("BY THE TIME I BURST",new Rect(160,70,540,115)),p("IN-",new Rect(290,145,410,190)))).size());}finally{b.recycle();}
 }
 @Test public void closedInteriorCarriesPreviousSentenceIntoTemporalEntryClause(){
  Bitmap b=Bitmap.createBitmap(700,600,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);c.drawColor(Color.WHITE);Paint pen=new Paint();pen.setColor(Color.BLACK);pen.setStyle(Paint.Style.STROKE);pen.setStrokeWidth(2);
  var text=List.of(p("IT WAS A FAILURE.",new Rect(180,80,520,120)),p("BY THE TIME I BURST IN-",new Rect(130,145,570,240)));
  try{assertEquals(2,OcrAppearance.joinFragments(b,text).size());c.drawRect(60,35,640,350,pen);var combined=OcrAppearance.joinFragments(b,text);assertEquals(1,combined.size());assertTrue(ReadingText.translationInput(combined.get(0).source).contains("entered abruptly"));
   var cascade=OcrAppearance.joinFragments(b,List.of(p("IT WAS A FAILURE.",new Rect(180,80,520,120)),p("BY THE TIME",new Rect(220,145,480,185)),p("I BURST IN-",new Rect(230,210,470,250))));assertEquals(1,cascade.size());assertTrue(ReadingText.translationInput(cascade.get(0).source).contains("entered abruptly"));
   assertEquals(2,OcrAppearance.joinFragments(b,List.of(p("WAIT HERE!",new Rect(180,80,520,120)),p("I AM READY.",new Rect(180,145,520,185)))).size());
  }finally{b.recycle();}
 }
 @Test public void realOcrPreservesTwoDisplayUnitsAndTemporalMeaningInput()throws Exception{
  Bitmap b=Bitmap.createBitmap(900,1000,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);c.drawColor(Color.WHITE);Paint pen=new Paint(Paint.ANTI_ALIAS_FLAG);pen.setColor(Color.BLACK);pen.setStrokeWidth(4);pen.setStyle(Paint.Style.STROKE);c.drawOval(80,60,820,430,pen);c.drawOval(120,530,780,900,pen);pen.setStyle(Paint.Style.FILL);pen.setTypeface(Typeface.create("sans-serif",Typeface.ITALIC));pen.setTextSize(46);
  String[] top={"IT WAS A FAILURE.","BY THE TIME","I BURST IN-"},bottom={"IT HAD ALL","ALREADY VANISHED."};for(int i=0;i<top.length;i++)c.drawText(top[i],450-pen.measureText(top[i])/2,185+i*65,pen);for(int i=0;i<bottom.length;i++)c.drawText(bottom[i],450-pen.measureText(bottom[i])/2,680+i*65,pen);
  var recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);var worker=Executors.newSingleThreadExecutor();var done=new CountDownLatch(1);var result=new AtomicReference<Text>();var error=new AtomicReference<Exception>();
  try{InstrumentationRegistry.getInstrumentation().runOnMainSync(()->OcrReader.read(recognizer,b,worker,()->true,new OcrReader.Result(){public void success(Text value){result.set(value);done.countDown();}public void failure(Exception value){error.set(value);done.countDown();}}));assertTrue(done.await(90,TimeUnit.SECONDS));assertNull(error.get());var parts=OcrAppearance.readingParagraphs(b,result.get(),List.of(),false);assertEquals(result.get().getText(),2,parts.size());assertTrue(parts.get(0).source,parts.get(0).source.contains("I BURST IN"));assertTrue(parts.get(1).source,parts.get(1).source.contains("VANISHED"));
   assertTrue(parts.get(0).source,ReadingText.translationInput(parts.get(0).source).contains("entered abruptly"));assertFalse(ReadingText.translationInput(parts.get(1).source).contains("entered"));
  }finally{recognizer.close();worker.shutdown();b.recycle();}
 }
}
