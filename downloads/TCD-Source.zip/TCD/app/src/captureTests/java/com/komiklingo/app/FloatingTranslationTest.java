package com.komiklingo.app;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.os.*;
import android.view.*;
import android.view.accessibility.*;
import android.widget.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.*;
import org.junit.runner.RunWith;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
public class FloatingTranslationTest {
 private Object get(Object target,String name){try{var field=FloatingTranslateService.class.getDeclaredField(name);field.setAccessible(true);return field.get(target);}catch(Exception error){throw new AssertionError(error);}}
 private TextView find(View root,String text){if(root instanceof TextView&&((TextView)root).getText().toString().equals(text))return (TextView)root;if(root instanceof ViewGroup){var group=(ViewGroup)root;for(int i=0;i<group.getChildCount();i++){var found=find(group.getChildAt(i),text);if(found!=null)return found;}}return null;}
 private boolean systemClick(String... values){var ui=InstrumentationRegistry.getInstrumentation().getUiAutomation();for(AccessibilityWindowInfo window:ui.getWindows()){var root=window.getRoot();if(root==null)continue;for(String value:values)for(var node:root.findAccessibilityNodeInfosByText(value))if(node.isClickable()&&node.performAction(AccessibilityNodeInfo.ACTION_CLICK))return true;}var root=ui.getRootInActiveWindow();if(root!=null)for(String value:values)for(var node:root.findAccessibilityNodeInfosByText(value))if(node.isClickable()&&node.performAction(AccessibilityNodeInfo.ACTION_CLICK))return true;return false;}
 private void await(java.util.function.BooleanSupplier condition,String message)throws Exception{for(int i=0;i<180;i++){if(condition.getAsBoolean())return;Thread.sleep(500);}throw new AssertionError(message+" (outcome="+FixtureFloatingService.last+")");}
 private FixtureFloatingSetupActivity setup()throws Exception{var ins=InstrumentationRegistry.getInstrumentation();var info=ins.getUiAutomation().getServiceInfo();info.flags|=android.accessibilityservice.AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;ins.getUiAutomation().setServiceInfo(info);var context=ins.getTargetContext();context.startService(new Intent(context,FixtureFloatingService.class).setAction(FloatingTranslateService.STOP));await(()->!FloatingTranslateService.isRunning(),"Prior service did not stop");FixtureFloatingSetupActivity activity=(FixtureFloatingSetupActivity)ins.startActivitySync(new Intent(context,FixtureFloatingSetupActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));ins.runOnMainSync(()->find(activity.getWindow().getDecorView(),"Mulai balon TCD").performClick());return activity;}
 // Send the gesture to the actual overlay view. Software-emulator SystemUI ANR windows can intercept injected system taps.
 private void tapBubble(){var ins=InstrumentationRegistry.getInstrumentation();ins.runOnMainSync(()->{View bubble=(View)get(FixtureFloatingService.instance,"bubble");long now=SystemClock.uptimeMillis();var down=MotionEvent.obtain(now,now,MotionEvent.ACTION_DOWN,25,25,0);var up=MotionEvent.obtain(now,now+80,MotionEvent.ACTION_UP,25,25,0);bubble.dispatchTouchEvent(down);bubble.dispatchTouchEvent(up);down.recycle();up.recycle();});}
 @Test public void projectionCancellationDoesNotStartFloatingCapture()throws Exception{var ins=InstrumentationRegistry.getInstrumentation();FixtureFloatingSetupActivity activity=setup();try{await(()->systemClick("Cancel","Batal"),"Projection cancel button missing");assertFalse(FloatingTranslateService.isRunning());ins.waitForIdleSync();}finally{ins.runOnMainSync(activity::finish);ins.waitForIdleSync();}}
 @Test public void consentCapturesAnotherAppAndStopsFromNotification()throws Exception{
  var ins=InstrumentationRegistry.getInstrumentation();var context=ins.getTargetContext();FixtureFloatingSetupActivity activity=setup();try{
   await(()->systemClick("Start now","Mulai sekarang"),"Projection consent button missing");await(()->FixtureFloatingService.last.equals("READY"),"Floating service not ready");
   var other=new Intent().setComponent(new ComponentName(ins.getContext().getPackageName(),OtherAppScreen.class.getName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);context.startActivity(other);Thread.sleep(6000);tapBubble();await(()->FixtureFloatingService.last.equals("RESULT"),"Capture/OCR did not complete");assertTrue(FixtureFloatingService.read.toString(),FixtureFloatingService.read.toString().contains("ANOTHER APP"));assertTrue(FixtureFloatingService.requests>0);
   ins.runOnMainSync(()->find((View)get(FixtureFloatingService.instance,"resultView"),"Tutup").performClick());assertNull(get(FixtureFloatingService.instance,"snapshot"));
   ins.getUiAutomation().setRotation(UiAutomation.ROTATION_FREEZE_90);Thread.sleep(2000);int before=FixtureFloatingService.requests;tapBubble();await(()->FixtureFloatingService.requests>before&&FixtureFloatingService.last.equals("RESULT"),"Second capture failed");assertTrue(FixtureFloatingService.read.toString().contains("ANOTHER APP"));
   var manager=context.getSystemService(android.app.NotificationManager.class);var notifications=manager.getActiveNotifications();boolean stopped=false;for(var notification:notifications)if(notification.getId()==1707){notification.getNotification().actions[0].actionIntent.send();stopped=true;break;}assertTrue(stopped);await(()->!FloatingTranslateService.isRunning()&&FixtureFloatingService.instance==null,"Notification stop did not release service");
  }finally{context.startService(new Intent(context,FixtureFloatingService.class).setAction(FloatingTranslateService.STOP));ins.getUiAutomation().setRotation(UiAutomation.ROTATION_UNFREEZE);ins.runOnMainSync(activity::finish);}
 }
 @Test public void rgbaFrameDecoderKeepsVisiblePixelsAndDimensions()throws Exception{
  ImageReader reader=ImageReader.newInstance(80,48,PixelFormat.RGBA_8888,2);android.os.HandlerThread thread=new android.os.HandlerThread("frame-test");thread.start();var done=new CountDownLatch(1);var value=new AtomicReference<Bitmap>();var failure=new AtomicReference<Throwable>();reader.setOnImageAvailableListener(source->{try(Image image=source.acquireLatestImage()){if(image!=null)value.set(ScreenFrame.decode(image));}catch(Throwable error){failure.set(error);}finally{done.countDown();}},new Handler(thread.getLooper()));
  try{Canvas canvas=reader.getSurface().lockCanvas(null);canvas.drawColor(Color.RED);android.graphics.Paint paint=new android.graphics.Paint();paint.setColor(Color.BLUE);canvas.drawRect(40,0,80,48,paint);reader.getSurface().unlockCanvasAndPost(canvas);assertTrue(done.await(10,TimeUnit.SECONDS));assertNull(failure.get());assertEquals(80,value.get().getWidth());assertEquals(48,value.get().getHeight());assertEquals(Color.RED,value.get().getPixel(5,5));assertEquals(Color.BLUE,value.get().getPixel(70,40));}finally{if(value.get()!=null)value.get().recycle();reader.close();thread.quitSafely();}
 }
}
