package com.komiklingo.app;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.*;
import org.junit.runner.RunWith;
import java.util.*;
import java.util.concurrent.atomic.*;
import java.io.*;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class BrowserTest {
 private Object field(MainActivity a,String name){try{var f=MainActivity.class.getDeclaredField(name);f.setAccessible(true);return f.get(a);}catch(Exception e){throw new AssertionError(e);}}
 private Object call(MainActivity a,String name,Class<?>[] types,Object... values){try{var m=MainActivity.class.getDeclaredMethod(name,types);m.setAccessible(true);return m.invoke(a,values);}catch(Exception e){throw new AssertionError(e);}}
 private TextView find(View v,String prefix){if(v instanceof TextView&&((TextView)v).getText().toString().startsWith(prefix))return (TextView)v;if(v instanceof ViewGroup)for(int i=0;i<((ViewGroup)v).getChildCount();i++){TextView found=find(((ViewGroup)v).getChildAt(i),prefix);if(found!=null)return found;}return null;}
 private void await(java.util.function.BooleanSupplier condition,String message)throws Exception{for(int i=0;i<240;i++){if(condition.getAsBoolean())return;Thread.sleep(350);}throw new AssertionError(message);}
 private void shot(String filename)throws Exception{var ins=InstrumentationRegistry.getInstrumentation();ins.waitForIdleSync();Thread.sleep(1000);Bitmap image=ins.getUiAutomation().takeScreenshot();assertNotNull(image);try(var out=new FileOutputStream(new File(ins.getTargetContext().getCacheDir(),filename))){image.compress(Bitmap.CompressFormat.PNG,100,out);}finally{image.recycle();}}
 @Test public void metadataPersistsAndBoundsTabsBookmarksAndSiteExceptions(){
  var prefs=InstrumentationRegistry.getInstrumentation().getTargetContext().getSharedPreferences("browser-store-test",Context.MODE_PRIVATE);prefs.edit().clear().commit();BrowserStore store=new BrowserStore(prefs);
  String first=store.current().id;store.update(first,"https://first.example/page","First",620);String second=store.newTab().id;store.update(second,"https://second.example/","Second",0);store.select(first);
  assertTrue(store.toggleBookmark("https://first.example/page","First"));store.setProtected("https://first.example/page",false);store=new BrowserStore(prefs);assertEquals(first,store.activeId());assertEquals(620,store.current().scroll,.1);assertEquals(2,store.tabs().size());assertEquals(1,store.bookmarks().size());assertFalse(store.protectedSite("https://first.example/other"));assertTrue(store.protectedSite("https://notfirst.example/"));store.setProtected("https://first.example/",true);assertTrue(store.protectedSite("https://first.example/page"));
  store.update(first,"javascript:alert(1)","Bad",0);assertEquals("https://first.example/page",store.current().url);store.close(second);assertEquals(first,store.activeId());assertFalse(store.toggleBookmark("https://first.example/page","First"));assertEquals(0,new BrowserStore(prefs).bookmarks().size());
  while(store.tabs().size()<BrowserStore.MAX_TABS)assertNotNull(store.newTab());assertNull(store.newTab());for(BrowserStore.Page p:store.tabs())store.close(p.id);assertEquals(1,store.tabs().size());assertEquals("",store.current().url);prefs.edit().clear().commit();
 }
 @Test public void tabsBookmarkProtectionAndRestartPreserveUserChoices()throws Exception{
  var ins=InstrumentationRegistry.getInstrumentation();Context context=ins.getTargetContext();var prefs=context.getSharedPreferences("reader",Context.MODE_PRIVATE);Map<String,?> backup=new HashMap<>(prefs.getAll());prefs.edit().clear().putBoolean("automatic",false).commit();FixturePageActivity activity=(FixturePageActivity)ins.startActivitySync(new Intent(context,FixturePageActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));final MainActivity a=activity;
  try{
   WebView web=(WebView)field(a,"web");BrowserStore store=(BrowserStore)field(a,"browser");String firstId=store.activeId();var loaded=new AtomicInteger();var blocked=new AtomicInteger();var allowedImage=new AtomicInteger();
   ins.runOnMainSync(()->{a.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);WebViewClient original=web.getWebViewClient();web.setWebViewClient(new WebViewClient(){
    public void onPageStarted(WebView w,String url,Bitmap icon){original.onPageStarted(w,url,icon);}
    public void onPageFinished(WebView w,String url){original.onPageFinished(w,url);loaded.incrementAndGet();}
    public void doUpdateVisitedHistory(WebView w,String url,boolean reload){original.doUpdateVisitedHistory(w,url,reload);}
    public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){return original.shouldOverrideUrlLoading(w,r);}
    public WebResourceResponse shouldInterceptRequest(WebView w,WebResourceRequest r){WebResourceResponse filtered=original.shouldInterceptRequest(w,r);if(filtered!=null){if(BrowserRules.tracker(r.getUrl().toString()))blocked.incrementAndGet();return filtered;}if(r.getUrl().getPath().endsWith("panel.svg")){allowedImage.incrementAndGet();return new WebResourceResponse("image/svg+xml","UTF-8",new ByteArrayInputStream("<svg xmlns='http://www.w3.org/2000/svg' width='2' height='2'><rect width='2' height='2' fill='white'/></svg>".getBytes()));}
     if(!r.isForMainFrame())return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));String title=r.getUrl().getPath().endsWith("two")?"Second site":"First site";String html="<!doctype html><meta name='viewport' content='width=device-width'><title>"+title+"</title><body style='margin:20px;font:24px sans-serif;height:8000px'><p>HELLO WORLD</p><img src='https://cdn.read.example/panel.svg'><ins class='adsbygoogle'>AD SLOT</ins><script src='https://ads.doubleclick.net/ad.js'></script><script>window.open('https://popads.net/popup');</script><p>Saved browser fixture</p>";return new WebResourceResponse("text/html","UTF-8",new ByteArrayInputStream(html.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
    }
   });a.onNewIntent(new Intent(context,FixturePageActivity.class).putExtra(Intent.EXTRA_TEXT,"https://site.example/one"));});
   await(()->loaded.get()>=1&&blocked.get()>0&&allowedImage.get()>0,"Fixture did not load/filter");Thread.sleep(600);
   var hidden=new AtomicReference<String>();ins.runOnMainSync(()->{assertEquals(1,store.tabs().size());assertFalse(web.getSettings().getAllowFileAccess());assertFalse(web.getSettings().getAllowContentAccess());assertFalse(web.getSettings().getJavaScriptCanOpenWindowsAutomatically());assertTrue(web.getSettings().getSafeBrowsingEnabled());assertFalse(android.webkit.CookieManager.getInstance().acceptThirdPartyCookies(web));web.evaluateJavascript("getComputedStyle(document.querySelector('.adsbygoogle')).display",hidden::set);AlertDialog menu=(AlertDialog)call(a,"settings",new Class<?>[]{});menu.getListView().performItemClick(null,0,0);menu.dismiss();});await(()->"\"none\"".equals(hidden.get()),"Cosmetic blocker missing");assertEquals(1,store.bookmarks().size());shot("browser-reader.png");
   ins.runOnMainSync(()->{web.scrollTo(0,Math.round(900*web.getScale()));call(a,"saveReadingPosition",new Class<?>[]{});AlertDialog tabs=(AlertDialog)call(a,"showTabs",new Class<?>[]{});tabs.getButton(AlertDialog.BUTTON_POSITIVE).performClick();});var made=new AtomicBoolean();await(()->{ins.runOnMainSync(()->made.set(store.tabs().size()==2&&(Boolean)field(a,"homeVisible")));return made.get();},"New tab action did not complete");ins.runOnMainSync(()->a.onNewIntent(new Intent(context,FixturePageActivity.class).putExtra(Intent.EXTRA_TEXT,"https://site.example/two")));await(()->loaded.get()>=2,"Second tab did not load");Thread.sleep(350);
   ins.runOnMainSync(()->{AlertDialog tabs=(AlertDialog)call(a,"showTabs",new Class<?>[]{});assertNotNull(find(tabs.getWindow().getDecorView(),"First site"));find(tabs.getWindow().getDecorView(),"First site").performClick();});await(()->loaded.get()>=3,"First tab did not reopen");var restored=new AtomicBoolean();await(()->{ins.runOnMainSync(()->restored.set(web.getScrollY()>500));return restored.get();},"Tab scroll was not restored");ins.runOnMainSync(()->{assertEquals(firstId,store.activeId());assertEquals("https://site.example/one",store.current().url);assertFalse("Back must not expose another tab",web.canGoBack());});shot("browser-tabs-restored.png");
   var dialog=new AtomicReference<AlertDialog>();ins.runOnMainSync(()->dialog.set((AlertDialog)call(a,"showTabs",new Class<?>[]{})));shot("browser-tabs.png");ins.runOnMainSync(()->dialog.get().getButton(AlertDialog.BUTTON_NEGATIVE).performClick());
   ins.runOnMainSync(()->{dialog.set((AlertDialog)call(a,"showBookmarks",new Class<?>[]{}));assertEquals(1,store.bookmarks().size());});shot("browser-bookmarks.png");ins.runOnMainSync(()->dialog.get().getButton(AlertDialog.BUTTON_NEGATIVE).performClick());
   ins.runOnMainSync(a::finish);ins.waitForIdleSync();activity=(FixturePageActivity)ins.startActivitySync(new Intent(context,FixturePageActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));MainActivity restarted=activity;ins.runOnMainSync(()->{BrowserStore again=(BrowserStore)field(restarted,"browser");assertEquals(2,again.tabs().size());assertEquals(1,again.bookmarks().size());assertEquals(firstId,again.activeId());assertEquals(true,field(restarted,"homeVisible"));assertNull("Restart should not fetch all saved tabs",((WebView)field(restarted,"web")).getUrl());});shot("browser-home.png");
  }finally{MainActivity end=activity;ins.runOnMainSync(end::finish);var editor=prefs.edit().clear();for(var entry:backup.entrySet()){Object value=entry.getValue();String key=entry.getKey();if(value instanceof String)editor.putString(key,(String)value);else if(value instanceof Boolean)editor.putBoolean(key,(Boolean)value);else if(value instanceof Long)editor.putLong(key,(Long)value);else if(value instanceof Integer)editor.putInt(key,(Integer)value);else if(value instanceof Float)editor.putFloat(key,(Float)value);else if(value instanceof Set)editor.putStringSet(key,(Set<String>)value);}editor.commit();}
 }
}
