package com.komiklingo.app;

import android.graphics.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.junit.*;
import org.junit.runner.RunWith;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class BalloonContextTest {
 private OcrAppearance.Paragraph p(String text,int l,int t,int r,int b){return new OcrAppearance.Paragraph(text,new Rect(l,t,r,b),Color.WHITE,Color.BLACK,50,false,false);}
 private Bitmap image(){Bitmap b=Bitmap.createBitmap(700,600,Bitmap.Config.ARGB_8888);new Canvas(b).drawColor(Color.WHITE);return b;}
 private void outline(Bitmap image,RectF bounds,float width){Paint pen=new Paint();pen.setColor(Color.BLACK);pen.setStrokeWidth(width);pen.setStyle(Paint.Style.STROKE);new Canvas(image).drawRect(bounds,pen);}
 @Test public void enclosedInteriorJoinsUnknownAdjectiveAndItsNounAcrossThreeBlocks(){
  Bitmap b=image();try{outline(b,new RectF(60,35,640,350),2);
   var found=OcrAppearance.joinFragments(b,List.of(p("DON'T",270,80,430,120),p("GLARE AT ME LIKE SUCH A PRICKLY",120,145,580,200),p("CAT.",300,225,400,265)));
   assertEquals(1,found.size());assertEquals("DON'T GLARE AT ME LIKE SUCH A PRICKLY CAT.",found.get(0).source);
   var arbitrary=OcrAppearance.joinFragments(b,List.of(p("THE ANCIENT CRIMSON",170,80,530,120),p("GATE.",275,145,425,185)));
   assertEquals("Unknown adjective must not require a dictionary entry",1,arbitrary.size());
  }finally{b.recycle();}
 }
 @Test public void doesNotJoinOpenPageClippedBalloonDifferentInteriorsOrCompletedSentences(){
  Bitmap b=image();try{var text=List.of(p("LIKE SUCH A PRICKLY",170,80,530,120),p("CAT.",300,145,400,185));
   assertEquals(2,OcrAppearance.joinFragments(b,text).size());
   outline(b,new RectF(-30,30,640,350),2);assertEquals("Clipped interior must remain uncertain",2,OcrAppearance.joinFragments(b,text).size());
   new Canvas(b).drawColor(Color.WHITE);outline(b,new RectF(60,35,640,135),1);outline(b,new RectF(100,140,600,220),1);
   assertEquals("Thin border must separate text regions",2,OcrAppearance.joinFragments(b,text).size());
   new Canvas(b).drawColor(Color.WHITE);outline(b,new RectF(60,35,640,350),1);
   assertEquals(2,OcrAppearance.joinFragments(b,List.of(p("WAIT HERE!",220,80,480,120),p("I AM READY.",220,145,480,185))).size());
   assertEquals(2,OcrAppearance.joinFragments(b,List.of(p("THE",270,80,430,120),p("ANCIENT GATE.",220,145,480,185)),List.of("The")).size());
  }finally{b.recycle();}
 }
 @Test public void keepsInterveningTextAndOtherColumnsSeparate(){
  Bitmap b=image();try{outline(b,new RectF(40,25,660,500),2);
   assertEquals(2,OcrAppearance.joinFragments(b,List.of(p("LIKE SUCH A PRICKLY",80,80,360,120),p("CAT.",480,145,600,185))).size());
   var text=List.of(p("LIKE SUCH A PRICKLY",170,80,530,120),p("ANOTHER LINE!",220,130,480,145),p("CAT.",300,160,400,200));
   var result=OcrAppearance.joinFragments(b,text);assertTrue(result.stream().noneMatch(v->v.source.equals("LIKE SUCH A PRICKLY CAT.")));
  }finally{b.recycle();}
 }
 @Test public void realOcrReassemblesStylizedSentenceIntoOneTranslationUnit()throws Exception{
  Bitmap b=Bitmap.createBitmap(900,800,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(b);canvas.drawColor(Color.WHITE);Paint pen=new Paint(Paint.ANTI_ALIAS_FLAG);pen.setColor(Color.BLACK);pen.setStrokeWidth(4);pen.setStyle(Paint.Style.STROKE);canvas.drawOval(60,60,840,730,pen);pen.setStyle(Paint.Style.FILL);pen.setTypeface(Typeface.create("sans-serif",Typeface.ITALIC));pen.setTextSize(44);
  String[] lines={"DON'T","GLARE AT ME LIKE","SUCH A PRICKLY","CAT."};for(int i=0;i<lines.length;i++)canvas.drawText(lines[i],450-pen.measureText(lines[i])/2,255+i*70,pen);
  var recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);var worker=Executors.newSingleThreadExecutor();var done=new CountDownLatch(1);var result=new AtomicReference<Text>();var error=new AtomicReference<Exception>();
  try{InstrumentationRegistry.getInstrumentation().runOnMainSync(()->OcrReader.read(recognizer,b,worker,()->true,new OcrReader.Result(){public void success(Text value){result.set(value);done.countDown();}public void failure(Exception value){error.set(value);done.countDown();}}));
   assertTrue(done.await(90,TimeUnit.SECONDS));assertNull(error.get());var parts=OcrAppearance.readingParagraphs(b,result.get(),List.of(),false);
   assertEquals(result.get().getText()+" | "+parts.stream().map(v->v.source).reduce("",(a,v)->a+" / "+v),1,parts.size());
   assertEquals("DON'T GLARE AT ME LIKE SUCH A PRICKLY CAT.",parts.get(0).source);
   assertTrue(ReadingText.translationInput(parts.get(0).source).contains("grumpy"));
  }finally{recognizer.close();worker.shutdown();b.recycle();}
 }
}
