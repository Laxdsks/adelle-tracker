package com.komiklingo.app;
import android.graphics.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.*;
import org.junit.runner.RunWith;
import java.util.*;
import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
public class MaskRegressionTest {
 @Test public void neighbouringCoverCannotEraseLastLineAndMaskCornersAreOpaque(){
  var ins=InstrumentationRegistry.getInstrumentation();ins.runOnMainSync(()->{BubbleOverlay overlay=new BubbleOverlay(ins.getTargetContext());overlay.layout(0,0,900,650);var first=new BubbleOverlay.Bubble(new RectF(20,20,600,180),"TUNGGU AKU!",Color.WHITE,true,new BubbleOverlay.Appearance(Color.BLACK,75,false));overlay.show(List.of(first));Bitmap single=Bitmap.createBitmap(900,650,Bitmap.Config.ARGB_8888);Canvas before=new Canvas(single);before.drawColor(Color.RED);overlay.draw(before);assertEquals(Color.WHITE,single.getPixel(20,20));int lastInk=0;for(int y=20;y<180;y++)for(int x=30;x<590;x++)if(Color.red(single.getPixel(x,y))<80)lastInk=Math.max(lastInk,y);assertTrue(lastInk>40);
   int sharedTop=lastInk-4;overlay.show(List.of(first,new BubbleOverlay.Bubble(new RectF(20,sharedTop,600,sharedTop+350),"TEKS LAIN",Color.WHITE,false,new BubbleOverlay.Appearance(Color.BLACK,28,false))));Bitmap combined=Bitmap.createBitmap(900,650,Bitmap.Config.ARGB_8888);Canvas after=new Canvas(combined);after.drawColor(Color.RED);overlay.draw(after);int count=0;for(int y=sharedTop;y<=lastInk;y++)for(int x=30;x<590;x++)if(Color.red(single.getPixel(x,y))<80){assertEquals("A neighbouring cover erased an existing letter",single.getPixel(x,y),combined.getPixel(x,y));count++;}assertTrue(count>10);single.recycle();combined.recycle();
  });
 }
}
