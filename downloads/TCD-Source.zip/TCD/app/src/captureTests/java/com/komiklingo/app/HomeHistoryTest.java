package com.komiklingo.app;
import android.content.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.*;
import org.junit.runner.RunWith;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.io.ByteArrayInputStream;
import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
public class HomeHistoryTest {
 private Object get(Object target,String field){try{var f=target.getClass().getDeclaredField(field);f.setAccessible(true);return f.get(target);}catch(Exception error){throw new AssertionError(error);}}
 private Object invoke(Object target,String name,Class<?>[] types,Object... args){try{var m=target.getClass().getDeclaredMethod(name,types);m.setAccessible(true);return m.invoke(target,args);}catch(Exception error){throw new AssertionError(error);}}
 private TextView find(View view,String prefix){if(view instanceof TextView&&((TextView)view).getText().toString().startsWith(prefix))return (TextView)view;if(view instanceof ViewGroup){var group=(ViewGroup)view;for(int i=0;i<group.getChildCount();i++){var value=find(group.getChildAt(i),prefix);if(value!=null)return value;}}return null;}
 @Test public void stalePageSavesDoNotReplaceNewerChapters(){
  var prefs=InstrumentationRegistry.getInstrumentation().getTargetContext().getSharedPreferences("history-test",Context.MODE_PRIVATE);prefs.edit().clear().commit();var history=new ReadingHistory(prefs);
  String old="https://comic.example/book/chapter/48",fresh="https://comic.example/book/chapter/50";
  history.record(old,"Chapter 48",200,100);history.record(fresh,"Chapter 50",600,200);history.record(old,"Chapter 48",700,100);history.record(fresh,"Old callback",0,199);
  assertEquals(fresh,history.entries().get(0).url);assertEquals(600,history.entries().get(0).scroll,.1);assertEquals("Chapter 50",new ReadingHistory(prefs).entries().get(0).title);
  history.record("https://duckduckgo.com/?q=comic","Search",0,400);history.record("javascript:alert(1)","Bad",0,500);assertEquals(2,history.entries().size());
  for(int i=0;i<40;i++)history.record("https://comic.example/book/chapter/"+(100+i),"Chapter "+i,0,1000+i);assertEquals(30,new ReadingHistory(prefs).entries().size());prefs.edit().clear().commit();
 }
 @Test public void launcherShowsHomeAndResumeShareAndStaleCallbacksUseCorrectChapter()throws Exception{
  var ins=InstrumentationRegistry.getInstrumentation();Context context=ins.getTargetContext();var prefs=context.getSharedPreferences("reader",Context.MODE_PRIVATE);Map<String,?> backup=new HashMap<>(prefs.getAll());prefs.edit().clear().putBoolean("automatic",false).putString("url","https://comic.example/book/chapter/48").commit();
  var history=new ReadingHistory(prefs);String old="https://comic.example/book/chapter/48",latest="https://comic.example/book/chapter/50",fresh="https://comic.example/book/chapter/51";history.record(old,"Chapter 48",200,100);history.record(latest,"Chapter 50",600,200);
  MainActivity activity=(MainActivity)ins.startActivitySync(new Intent(context,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  try{
   WebView web=(WebView)get(activity,"web");AtomicReference<WebViewClient> client=new AtomicReference<>();ins.runOnMainSync(()->client.set(web.getWebViewClient()));WebViewClient original=client.get();AtomicReference<CountDownLatch> loaded=new AtomicReference<>();AtomicReference<String> expected=new AtomicReference<>();
   ins.runOnMainSync(()->{activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON|WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);assertEquals(true,get(activity,"homeVisible"));assertNotNull(find((View)get(activity,"homeScreen"),"Cari komik / buka tautan"));assertNull(web.getUrl());
    web.setWebViewClient(new WebViewClient(){public void onPageStarted(WebView w,String url,android.graphics.Bitmap icon){original.onPageStarted(w,url,icon);}public WebResourceResponse shouldInterceptRequest(WebView w,WebResourceRequest request){return new WebResourceResponse("text/html","UTF-8",new ByteArrayInputStream(("<html><meta name='viewport' content='width=device-width'><title>Chapter "+request.getUrl().getLastPathSegment()+"</title><body style='height:8000px'>Reading fixture</body></html>").getBytes(java.nio.charset.StandardCharsets.UTF_8)));}public void onPageFinished(WebView w,String url){original.onPageFinished(w,url);var latch=loaded.get();if(latch!=null&&url.equals(expected.get()))latch.countDown();}});
   });
   CountDownLatch first=new CountDownLatch(1);loaded.set(first);expected.set(latest);ins.runOnMainSync(()->find((View)get(activity,"homeScreen"),"Lanjutkan ·").performClick());assertTrue(first.await(60,TimeUnit.SECONDS));
   AtomicInteger position=new AtomicInteger();for(int i=0;i<30;i++){ins.runOnMainSync(()->position.set(web.getScrollY()));if(position.get()>500)break;android.os.SystemClock.sleep(100);}assertTrue("Resume scroll lost",position.get()>500);
   CountDownLatch second=new CountDownLatch(1);loaded.set(second);expected.set(fresh);ins.runOnMainSync(()->activity.onNewIntent(new Intent(context,MainActivity.class).putExtra(Intent.EXTRA_TEXT,fresh)));assertTrue(second.await(60,TimeUnit.SECONDS));
   ins.runOnMainSync(()->{assertEquals(fresh,web.getUrl());assertFalse(activity.getIntent().hasExtra(Intent.EXTRA_TEXT));original.onPageFinished(web,old);assertEquals(fresh,prefs.getString("url",""));web.scrollTo(0,Math.round(1200*web.getScale()));invoke(activity,"saveReadingPosition",new Class<?>[]{});find(activity.getWindow().getDecorView(),activity.getString(R.string.home_brand)).performClick();assertEquals(true,get(activity,"homeVisible"));assertEquals(fresh,history.entries().get(0).url);assertTrue(history.entries().get(0).scroll>500);});
   ins.waitForIdleSync();ins.runOnMainSync(()->{View view=activity.getWindow().getDecorView();var screen=android.graphics.Bitmap.createBitmap(view.getWidth(),view.getHeight(),android.graphics.Bitmap.Config.ARGB_8888);view.draw(new android.graphics.Canvas(screen));try(var out=new java.io.FileOutputStream(new java.io.File(context.getCacheDir(),"home-preview.png"))){screen.compress(android.graphics.Bitmap.CompressFormat.PNG,100,out);}catch(Exception error){throw new AssertionError(error);}finally{screen.recycle();}});
   CountDownLatch previous=new CountDownLatch(1);loaded.set(previous);expected.set(old);ins.runOnMainSync(()->find((View)get(activity,"homeScreen"),"Chapter 48").performClick());assertTrue(previous.await(60,TimeUnit.SECONDS));ins.runOnMainSync(()->assertEquals(old,web.getUrl()));
  }finally{ins.runOnMainSync(activity::finish);var editor=prefs.edit().clear();for(var entry:backup.entrySet()){Object value=entry.getValue();String key=entry.getKey();if(value instanceof String)editor.putString(key,(String)value);else if(value instanceof Boolean)editor.putBoolean(key,(Boolean)value);else if(value instanceof Long)editor.putLong(key,(Long)value);else if(value instanceof Integer)editor.putInt(key,(Integer)value);else if(value instanceof Float)editor.putFloat(key,(Float)value);else if(value instanceof Set)editor.putStringSet(key,(Set<String>)value);}editor.commit();}
 }
}
