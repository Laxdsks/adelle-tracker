package com.komiklingo.app;

import android.content.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.*;
import org.junit.runner.RunWith;
import java.util.*;
import java.util.concurrent.atomic.*;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class GoogleProviderTest {
 @Test public void onlineStartsWithoutWaitingForOfflineModelAndOfflineRouteStaysLocal()throws Exception{
  var ins=InstrumentationRegistry.getInstrumentation();var context=ins.getTargetContext();var prefs=context.getSharedPreferences("reader",Context.MODE_PRIVATE);
  String previous=prefs.getString(GoogleTranslator.PREFERENCE,null);prefs.edit().remove(GoogleTranslator.PREFERENCE).commit();
  TextTranslationActivity activity=null;
  try{
   assertTrue(GoogleTranslator.enabled(context));
   activity=(TextTranslationActivity)ins.startActivitySync(new Intent(context,TextTranslationActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));ins.waitForIdleSync();
   var ready=TextTranslationActivity.class.getDeclaredField("ready");ready.setAccessible(true);assertTrue("Online must not be blocked by model download",ready.getBoolean(activity));
   prefs.edit().putString(GoogleTranslator.PREFERENCE,"offline").commit();assertFalse(GoogleTranslator.enabled(context));
   var pending=new AtomicReference<NameTranslation.Result>();var count=new AtomicInteger();var route=new AtomicReference<GoogleTranslator>();
   ins.runOnMainSync(()->{
    GoogleTranslator google=new GoogleTranslator(context,(source,done)->{assertEquals("Please wait.",source);pending.set(done);},()->fail("Offline selection must not use network fallback"));route.set(google);
    google.translate("Please wait.",(text,error)->count.incrementAndGet());google.cancel();pending.get().done("Tunggu dulu.",null);assertEquals(0,count.get());
    google.translate("Please wait.",(text,error)->{assertNull(error);assertEquals("Tunggu dulu.",text);count.incrementAndGet();});pending.get().done("Tunggu dulu.",null);assertEquals(1,count.get());assertFalse(google.onlineResult());google.close();
   });
  }finally{
   if(activity!=null){TextTranslationActivity finished=activity;ins.runOnMainSync(finished::finish);ins.waitForIdleSync();}
   if(previous==null)prefs.edit().remove(GoogleTranslator.PREFERENCE).commit();else prefs.edit().putString(GoogleTranslator.PREFERENCE,previous).commit();
  }
 }
}
