package com.komiklingo.app;
import android.content.*;
import android.graphics.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.*;
import org.junit.runner.RunWith;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.io.ByteArrayInputStream;
import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
public class PageScanTest {
 private Object get(Object target,String name){try{var field=MainActivity.class.getDeclaredField(name);field.setAccessible(true);return field.get(target);}catch(Exception error){throw new AssertionError(error);}}
 private void call(Object target,String name){try{var method=MainActivity.class.getDeclaredMethod(name);method.setAccessible(true);method.invoke(target);}catch(Exception error){throw new AssertionError(error);}}
 private void await(java.util.function.BooleanSupplier value,String message)throws Exception{for(int i=0;i<360;i++){if(value.getAsBoolean())return;Thread.sleep(500);}throw new AssertionError(message);}
 private void restore(android.content.SharedPreferences prefs,Map<String,?> backup){var editor=prefs.edit().clear();for(var entry:backup.entrySet()){Object v=entry.getValue();String k=entry.getKey();if(v instanceof String)editor.putString(k,(String)v);else if(v instanceof Boolean)editor.putBoolean(k,(Boolean)v);else if(v instanceof Long)editor.putLong(k,(Long)v);else if(v instanceof Integer)editor.putInt(k,(Integer)v);else if(v instanceof Float)editor.putFloat(k,(Float)v);else if(v instanceof Set)editor.putStringSet(k,(Set<String>)v);}editor.commit();}
 @Test public void coordinatesDedupeAndStyleSurviveScrollAndZoom(){
  PageTranslations cache=new PageTranslations();var appearance=new BubbleOverlay.Appearance(Color.RED,40,true,true);
  cache.put("HELLO","Halo",new RectF(20,40,220,120),Color.WHITE,false,appearance,2,0,600);
  cache.put("HELLO","Halo baru",new RectF(20,140,220,220),Color.WHITE,false,appearance,2,0,500);
  assertEquals(1,cache.size());var visible=cache.visible(1,0,300,400,600);assertEquals(1,visible.size());assertEquals(320,cache.entries().get(0).css.top,.1);assertEquals(20,cache.entries().get(0).font,.1);assertTrue(cache.entries().get(0).italic);assertEquals(0,cache.visible(1,0,900,400,600).size());assertEquals(1,cache.size());cache.clear();assertEquals(0,cache.size());
 }
 @Test public void currentPageScanPersistsOnScrollClearsReloadNextBackAndNeverOpensNextChapter()throws Exception{
  var ins=InstrumentationRegistry.getInstrumentation();var context=ins.getTargetContext();var prefs=context.getSharedPreferences("reader",Context.MODE_PRIVATE);var backup=new HashMap<String,Object>(prefs.getAll());prefs.edit().clear().putBoolean("automatic",false).commit();
  String first="https://comic.example/story/chapter/1",next="https://comic.example/story/chapter/2";
  FixturePageActivity activity=(FixturePageActivity)ins.startActivitySync(new Intent(context,FixturePageActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  try{
   WebView web=(WebView)get(activity,"web");var loaded=new AtomicInteger();AtomicReference<WebViewClient> originalRef=new AtomicReference<>();
   ins.runOnMainSync(()->{activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);var original=web.getWebViewClient();originalRef.set(original);web.setWebViewClient(new WebViewClient(){
    @Override public void onPageStarted(WebView w,String url,Bitmap icon){original.onPageStarted(w,url,icon);}
    @Override public void onPageFinished(WebView w,String url){original.onPageFinished(w,url);loaded.incrementAndGet();}
    @Override public void doUpdateVisitedHistory(WebView w,String url,boolean reload){original.doUpdateVisitedHistory(w,url,reload);}
    @Override public WebResourceResponse shouldInterceptRequest(WebView w,WebResourceRequest request){String html="<html><meta name='viewport' content='width=device-width,initial-scale=1'><title>Page test</title><body style='margin:0;background:white;color:black;font:bold 24px sans-serif'><section style='height:550px;padding:30px'>HELLO FIRST WORLD</section><section style='height:550px;padding:30px'>HELLO MIDDLE WORLD</section><section style='height:550px;padding:30px'>HELLO LAST WORLD</section><a href='/story/chapter/2'>NEXT CHAPTER</a></body></html>";return new WebResourceResponse("text/html","UTF-8",new ByteArrayInputStream(html.getBytes(java.nio.charset.StandardCharsets.UTF_8)));}
   });activity.onNewIntent(new Intent(context,FixturePageActivity.class).putExtra(Intent.EXTRA_TEXT,first));});
   await(()->loaded.get()>0,"Page failed to load");Thread.sleep(700);
   ins.runOnMainSync(()->{web.scrollTo(0,Math.round(180*web.getScale()));call(activity,"beginFullPage");});
   var finished=new AtomicBoolean();await(()->{ins.runOnMainSync(()->{finished.set(!(Boolean)get(activity,"fullPageActive"));android.util.Log.i("PageScanRegression",((TextView)get(activity,"status")).getText()+"; scroll="+web.getScrollY()+"; busy="+get(activity,"busy")+"; steps="+get(activity,"scanSteps"));});return finished.get();},"Full page scan did not finish");
   ins.runOnMainSync(()->{PageTranslations cache=(PageTranslations)get(activity,"pageTranslations");String all=cache.entries().stream().map(e->e.source).reduce("",(a,b)->a+" "+b);assertTrue(all,all.contains("FIRST"));assertTrue(all,all.contains("LAST"));assertTrue((Boolean)get(activity,"pageComplete"));assertEquals(first,web.getUrl());assertEquals(180,web.getScrollY()/web.getScale(),4);int count=cache.size();web.scrollTo(0,1000);assertEquals(count,cache.size());web.scrollTo(0,0);assertEquals(count,cache.size());originalRef.get().doUpdateVisitedHistory(web,first+"#panel",false);assertEquals(count,cache.size());web.reload();});
   int afterReload=loaded.get();await(()->loaded.get()>afterReload,"Reload failed");
   ins.runOnMainSync(()->{var cache=(PageTranslations)get(activity,"pageTranslations");assertEquals(0,cache.size());cache.put("A","B",new RectF(10,20,80,70),Color.WHITE,false,null,1,0,0);activity.onNewIntent(new Intent(context,FixturePageActivity.class).putExtra(Intent.EXTRA_TEXT,next));});
   int afterNext=loaded.get();await(()->loaded.get()>afterNext,"Next page failed");
   ins.runOnMainSync(()->{var cache=(PageTranslations)get(activity,"pageTranslations");assertEquals(0,cache.size());cache.put("A","B",new RectF(10,20,80,70),Color.WHITE,false,null,1,0,0);activity.onBackPressed();assertEquals(0,cache.size());});
  }finally{ins.runOnMainSync(activity::finish);restore(prefs,backup);}
 }
}
