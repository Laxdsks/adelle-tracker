package com.komiklingo.app;
import android.graphics.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.junit.*;
import org.junit.runner.RunWith;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
public class CapsOcrTest {
 @Test public void difficultItalicPanelGetsNormalizedBeforeTranslation()throws Exception{check(1);}
 @Test public void largeCapitalViewportIsNormalizedBeforeTranslation()throws Exception{check(2.56f);}
 private void check(float scale)throws Exception{
  var context=InstrumentationRegistry.getInstrumentation().getTargetContext();var file=new java.io.File(context.getFilesDir(),"ocr-panel.png");Assume.assumeTrue("Private optional fixture is not redistributed",file.exists());
  OcrQuality.load(context.getAssets().open("english-ocr-words.txt"));TessFallback.prepare(context);Bitmap decoded=BitmapFactory.decodeFile(file.toString());final Bitmap image;if(scale==1)image=decoded;else{image=Bitmap.createScaledBitmap(decoded,Math.round(decoded.getWidth()*scale),Math.round(decoded.getHeight()*scale),true);decoded.recycle();}var recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);var worker=Executors.newSingleThreadExecutor();
  try{
   var done=new CountDownLatch(1);var result=new AtomicReference<Text>();var failure=new AtomicReference<Exception>();
   InstrumentationRegistry.getInstrumentation().runOnMainSync(()->OcrReader.read(recognizer,image,worker,()->true,new OcrReader.Result(){public void success(Text text){result.set(text);done.countDown();}public void failure(Exception error){failure.set(error);done.countDown();}}));
   assertTrue(done.await(90,TimeUnit.SECONDS));assertNull(failure.get());String text=result.get().getText().toUpperCase(Locale.ROOT).replaceAll("\\s+"," ");android.util.Log.i("CapsRegression","OCR scale="+scale+" result: "+text);
   assertTrue("LAUGH missing: "+text,text.contains("LAUGH"));assertTrue("DIRECTLY missing: "+text,text.contains("DIRECTLY"));assertTrue("SOUL missing: "+text,text.contains("SOUL"));
   for(Text.TextBlock block:result.get().getTextBlocks())if(block.getBoundingBox()!=null){assertTrue(block.getBoundingBox().left>=-10);assertTrue(block.getBoundingBox().right<image.getWidth()+10);}
  }finally{recognizer.close();worker.shutdownNow();image.recycle();}
 }
}
