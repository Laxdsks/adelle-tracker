package com.komiklingo.app;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import com.google.mlkit.nl.translate.*;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.android.gms.tasks.Tasks;
import org.junit.*;
import org.junit.runner.RunWith;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.io.*;
import androidx.test.platform.app.InstrumentationRegistry;
import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
public class RealTranslationTest {
 @Test public void actualMlKitModelTranslatesPredicateAndKeepsCommercialBrandSense()throws Exception{
  Translator translator=Translation.getClient(new TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.INDONESIAN).build());StringBuilder log=new StringBuilder();
  try{Tasks.await(translator.downloadModelIfNeeded(new DownloadConditions.Builder().build()),180,TimeUnit.SECONDS);
   String source="ARE A BRAND OF FATE, AND A CURSE FROM GOD.";String before=Tasks.await(translator.translate(source),60,TimeUnit.SECONDS);log.append("Original source: ").append(source).append("\nRaw ML Kit: ").append(before).append('\n');
   var plan=ProtectedTerms.prepare(source,List.of());var done=new CountDownLatch(1);var output=new AtomicReference<String>();var failures=new AtomicInteger();TranslationFlow.translate(List.of(plan),(text,result)->translator.translate(text).addOnSuccessListener(value->result.done(value,null)).addOnFailureListener(error->result.done(null,error)),()->true,(values,failed)->{output.set(ReadingText.style(source,values.get(0),ReadingText.DIALOGUE));failures.set(failed);done.countDown();});assertTrue(done.await(90,TimeUnit.SECONDS));assertEquals(0,failures.get());String text=output.get();log.append("TCD pipeline: ").append(text).append('\n');assertFalse(text,text.toLowerCase(Locale.ROOT).contains("merek nasib"));assertFalse(text,text.matches("(?is).*\\badalah\\s+a\\b.*"));assertTrue(text,text.toLowerCase(Locale.ROOT).contains("takdir"));assertTrue(text,text.toLowerCase(Locale.ROOT).contains("kutukan"));
   String shoes=Tasks.await(translator.translate(ReadingText.translationInput("This company sells a brand of shoes.")),60,TimeUnit.SECONDS);log.append("Commercial: ").append(shoes).append('\n');assertTrue(shoes,shoes.toLowerCase(Locale.ROOT).matches("(?s).*(?:merek|merk).*"));
   for(String sample:List.of("I will not leave you alone.","I will keep my promise.")){String translated=Tasks.await(translator.translate(ReadingText.translationInput(sample)),60,TimeUnit.SECONDS);log.append(sample).append(" -> ").append(ReadingText.style(sample,translated,ReadingText.DIALOGUE)).append('\n');}
  }finally{translator.close();File file=new File(InstrumentationRegistry.getInstrumentation().getTargetContext().getCacheDir(),"real-translation.txt");try(var writer=new FileWriter(file)){writer.write(log.toString());}android.util.Log.i("RealTranslation",log.toString());}
 }
}
