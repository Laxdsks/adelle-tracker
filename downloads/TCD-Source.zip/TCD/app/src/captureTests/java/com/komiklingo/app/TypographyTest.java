package com.komiklingo.app;

import android.graphics.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import com.google.mlkit.vision.text.Text;
import org.junit.*;
import org.junit.runner.RunWith;
import java.util.*;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class TypographyTest {
 private Text.Line line(String text,Rect rect,float confidence){
  List<Point> corners=List.of(new Point(rect.left,rect.top),new Point(rect.right,rect.top),new Point(rect.right,rect.bottom),new Point(rect.left,rect.bottom));
  Text.Element word=new Text.Element(text,rect,corners,"en",new Matrix(),confidence,0,List.of());return new Text.Line(text,rect,corners,"en",new Matrix(),List.of(word),confidence,0);
 }
 private Text.TextBlock block(List<Text.Line> lines){Rect bounds=new Rect(lines.get(0).getBoundingBox());StringBuilder text=new StringBuilder();for(var line:lines){bounds.union(line.getBoundingBox());if(text.length()>0)text.append('\n');text.append(line.getText());}return new Text.TextBlock(text.toString(),bounds,List.of(),"en",new Matrix(),lines);}
 private List<BubbleOverlay.Rendered> entries(BubbleOverlay overlay){try{var field=BubbleOverlay.class.getDeclaredField("rendered");field.setAccessible(true);return (List<BubbleOverlay.Rendered>)field.get(overlay);}catch(Exception e){throw new AssertionError(e);}}
 @Test public void samplesColoredInkAndReconstructsWrappedWordsWithoutRemovingParagraphs(){
  Bitmap bitmap=Bitmap.createBitmap(600,500,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(bitmap);canvas.drawColor(Color.WHITE);Paint paint=new Paint();paint.setColor(0xffc82020);
  var lines=List.of(line("SUD-",new Rect(60,40,280,80),.95f),line("DENLY!",new Rect(60,90,360,130),.95f),line("A NEW PARAGRAPH",new Rect(60,240,480,280),.95f));
  for(var line:lines){Rect r=line.getBoundingBox();canvas.drawRect(r.left+12,r.top+5,r.right-12,r.bottom-5,paint);}
  var paragraphs=OcrAppearance.paragraphs(bitmap,block(lines));assertEquals(2,paragraphs.size());assertEquals("SUDDENLY!",paragraphs.get(0).source);assertEquals("A NEW PARAGRAPH",paragraphs.get(1).source);assertTrue(paragraphs.get(0).leftAligned);
  int ink=paragraphs.get(0).ink;assertTrue(Color.red(ink)>170);assertTrue(Color.green(ink)<70);assertEquals(Color.WHITE,paragraphs.get(0).background);assertTrue(paragraphs.get(0).sourceSize>40);
  Bitmap enhanced=OcrReader.contrast(bitmap);assertEquals(bitmap.getWidth(),enhanced.getWidth());assertEquals(bitmap.getHeight(),enhanced.getHeight());assertTrue(Color.red(enhanced.getPixel(100,60))==Color.green(enhanced.getPixel(100,60)));assertEquals(0xffc82020,bitmap.getPixel(100,60));enhanced.recycle();paint.setColor(Color.YELLOW);canvas.drawRect(72,45,268,75,paint);int yellow=OcrAppearance.foreground(bitmap,List.of(lines.get(0).getBoundingBox()),Color.WHITE);assertTrue(Color.red(yellow)>230&&Color.green(yellow)>230&&Color.blue(yellow)<30);bitmap.recycle();
 }
 @Test public void normalizedPassDoesNotTurnRealNumbersIntoWords(){
  var number=block(List.of(line("60!",new Rect(20,20,160,70),.96f)));var word=block(List.of(line("GO!",new Rect(20,20,160,70),.99f)));
  assertTrue(OcrReader.weak(new Text("60!",List.of(number))));assertEquals("60!",OcrReader.merge(new Text("60!",List.of(number)),new Text("GO!",List.of(word))).getText());
 }
 @Test public void actualOcrDistinguishesGoAndSixty()throws Exception{
  var context=InstrumentationRegistry.getInstrumentation().getTargetContext();OcrQuality.load(context.getAssets().open("english-ocr-words.txt"));TessFallback.prepare(context);
  var recognizer=com.google.mlkit.vision.text.TextRecognition.getClient(com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS);var worker=java.util.concurrent.Executors.newSingleThreadExecutor();
  Bitmap image=Bitmap.createBitmap(700,420,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(image);canvas.drawColor(Color.WHITE);Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setTextSize(96);paint.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD_ITALIC));paint.setColor(Color.BLACK);canvas.drawText("GO!",70,160,paint);canvas.drawText("60",70,350,paint);
  var done=new java.util.concurrent.CountDownLatch(1);var result=new java.util.concurrent.atomic.AtomicReference<Text>();var failure=new java.util.concurrent.atomic.AtomicReference<Exception>();
  try{InstrumentationRegistry.getInstrumentation().runOnMainSync(()->OcrReader.read(recognizer,image,worker,()->true,new OcrReader.Result(){public void success(Text text){result.set(text);done.countDown();}public void failure(Exception error){failure.set(error);done.countDown();}}));assertTrue(done.await(90,java.util.concurrent.TimeUnit.SECONDS));assertNull(failure.get());String text=result.get().getText();assertTrue(text,text.contains("GO"));assertTrue(text,text.contains("60"));}finally{recognizer.close();worker.shutdown();image.recycle();}
 }
 @Test public void keepsGoodOcrAndOnlyReplacesWeakerOverlappingBlocks(){
  var weak=block(List.of(line("H3LL",new Rect(20,20,160,70),.25f)));var good=block(List.of(line("HELLO",new Rect(20,20,160,70),.95f)));var extra=block(List.of(line("WORLD",new Rect(20,100,180,150),.9f)));
  Text first=new Text("H3LL",List.of(weak)),second=new Text("HELLO WORLD",List.of(good,extra));assertTrue(OcrReader.weak(first));assertFalse(OcrReader.weak(second));assertEquals("HELLO\nWORLD",OcrReader.merge(first,second).getText());assertEquals("HELLO\nWORLD",OcrReader.merge(second,first).getText());
 }
 @Test public void actualOcrReadsColoredLetteringAndKeepsItsInk()throws Exception{
  var recognizer=com.google.mlkit.vision.text.TextRecognition.getClient(com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS);var worker=java.util.concurrent.Executors.newSingleThreadExecutor();
  Bitmap image=Bitmap.createBitmap(700,230,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(image);canvas.drawColor(Color.WHITE);Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setTextSize(64);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setColor(0xffc82020);canvas.drawText("WAIT FOR ME!",40,130,paint);
  var done=new java.util.concurrent.CountDownLatch(1);var result=new java.util.concurrent.atomic.AtomicReference<Text>();var failure=new java.util.concurrent.atomic.AtomicReference<Exception>();
  try{
   InstrumentationRegistry.getInstrumentation().runOnMainSync(()->OcrReader.read(recognizer,image,worker,()->true,new OcrReader.Result(){public void success(Text text){result.set(text);done.countDown();}public void failure(Exception error){failure.set(error);done.countDown();}}));
   assertTrue(done.await(60,java.util.concurrent.TimeUnit.SECONDS));assertNull(failure.get());assertTrue(result.get().getText().contains("WAIT"));var paragraphs=OcrAppearance.paragraphs(image,result.get().getTextBlocks().get(0));assertFalse(paragraphs.isEmpty());int ink=paragraphs.get(0).ink;assertTrue(Color.red(ink)>160);assertTrue(Color.green(ink)<80);assertTrue(paragraphs.get(0).sourceSize>45);
  }finally{recognizer.close();worker.shutdownNow();image.recycle();}
 }
 @Test public void fitsLargeColoredTextAndSpacesParagraphsWithoutTinyUnreadableLetters()throws Exception{
  var ins=InstrumentationRegistry.getInstrumentation();ins.runOnMainSync(()->{
   BubbleOverlay overlay=new BubbleOverlay(ins.getTargetContext());overlay.layout(0,0,1080,1200);
   var red=new BubbleOverlay.Appearance(0xffc82020,72,false);var blue=new BubbleOverlay.Appearance(0xff2050c0,32,true);
   overlay.show(List.of(new BubbleOverlay.Bubble(new RectF(20,20,1060,220),"AKU AKAN KEMBALI!",Color.WHITE,true,red),new BubbleOverlay.Bubble(new RectF(20,260,1060,470),"Tunggu aku.\n\nAku segera menyusul.",Color.WHITE,false,blue),new BubbleOverlay.Bubble(new RectF(20,520,180,570),String.join(" ",Collections.nCopies(60,"panjang")),Color.WHITE,false,red)));
   var rendered=entries(overlay);assertEquals(3,rendered.size());assertFalse(rendered.get(0).overflow);assertTrue("Large type must exceed old 38 px cap",rendered.get(0).layout.getPaint().getTextSize()>50);assertEquals(red.ink,rendered.get(0).layout.getPaint().getColor());assertEquals(blue.ink,rendered.get(1).layout.getPaint().getColor());assertTrue(rendered.get(1).layout.getLineCount()>=2);assertTrue(rendered.get(1).layout.getLineTop(1)>rendered.get(1).layout.getPaint().getTextSize()*1.2f);assertTrue(rendered.get(2).overflow);
   Bitmap preview=Bitmap.createBitmap(1080,1200,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(preview);canvas.drawColor(0xffe2e8f0);overlay.draw(canvas);assertEquals(0xffe2e8f0,preview.getPixel(0,0));
   try(var output=new java.io.FileOutputStream(new java.io.File(ins.getTargetContext().getCacheDir(),"typography-preview.png"))){preview.compress(Bitmap.CompressFormat.PNG,100,output);}catch(Exception e){throw new AssertionError(e);}finally{preview.recycle();}
  });
 }
}
