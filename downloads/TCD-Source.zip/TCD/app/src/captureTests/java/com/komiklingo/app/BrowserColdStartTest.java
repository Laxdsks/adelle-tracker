package com.komiklingo.app;
import android.content.*;
import android.webkit.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Run seed and verify in separate instrumentation processes with force-stop between. */
@RunWith(AndroidJUnit4.class)
public class BrowserColdStartTest {
 @Test public void seed(){var prefs=InstrumentationRegistry.getInstrumentation().getTargetContext().getSharedPreferences("reader",Context.MODE_PRIVATE);prefs.edit().clear().putBoolean("automatic",false).commit();var store=new BrowserStore(prefs);store.update(store.current().id,"https://cold.example/one","Saved one",720);String id=store.newTab().id;store.update(id,"https://cold.example/two","Saved two",320);store.toggleBookmark("https://cold.example/one","Saved star");prefs.edit().putString("cold-id",id).commit();}
 @Test public void verify(){var ins=InstrumentationRegistry.getInstrumentation();var context=ins.getTargetContext();var prefs=context.getSharedPreferences("reader",Context.MODE_PRIVATE);var store=new BrowserStore(prefs);assertEquals(2,store.tabs().size());assertEquals(prefs.getString("cold-id",""),store.activeId());assertEquals("Saved two",store.current().title);assertEquals(320,store.current().scroll,.1);assertEquals("Saved star",store.bookmarks().get(0).title);
  FixturePageActivity a=(FixturePageActivity)ins.startActivitySync(new Intent(context,FixturePageActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));try{ins.runOnMainSync(()->{try{var f=MainActivity.class.getDeclaredField("web");f.setAccessible(true);assertNull(((WebView)f.get(a)).getUrl());}catch(Exception e){throw new AssertionError(e);}});}finally{ins.runOnMainSync(a::finish);}
 }
}
