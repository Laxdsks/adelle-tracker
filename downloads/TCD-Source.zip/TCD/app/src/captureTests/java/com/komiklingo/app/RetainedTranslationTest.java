package com.komiklingo.app;
import android.content.*;
import android.graphics.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.*;
import org.junit.runner.RunWith;
import java.util.*;
import java.util.concurrent.atomic.*;
import java.io.ByteArrayInputStream;
import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
public class RetainedTranslationTest {
 private Object field(Object target,String name){try{var f=MainActivity.class.getDeclaredField(name);f.setAccessible(true);return f.get(target);}catch(Exception error){throw new AssertionError(error);}}
 private void call(Object target,String name,Class<?>[] types,Object... args){try{var m=MainActivity.class.getDeclaredMethod(name,types);m.setAccessible(true);m.invoke(target,args);}catch(Exception error){throw new AssertionError(error);}}
 private void await(java.util.function.BooleanSupplier value,String message)throws Exception{for(int i=0;i<300;i++){if(value.getAsBoolean())return;Thread.sleep(400);}throw new AssertionError(message);}
 private TextView find(View view,String text){if(view instanceof TextView&&((TextView)view).getText().toString().equals(text))return (TextView)view;if(view instanceof ViewGroup)for(int i=0;i<((ViewGroup)view).getChildCount();i++){TextView result=find(((ViewGroup)view).getChildAt(i),text);if(result!=null)return result;}return null;}
 @Test public void ordinaryTranslationIsRetainedAndResetOnlyReplacesChosenBlock()throws Exception{
  var ins=InstrumentationRegistry.getInstrumentation();var context=ins.getTargetContext();var prefs=context.getSharedPreferences("reader",Context.MODE_PRIVATE);var backup=new HashMap<String,Object>(prefs.getAll());prefs.edit().clear().putBoolean("automatic",false).commit();FixturePageActivity.requests=0;FixturePageActivity.fail=false;FixturePageActivity.suffix="";FixturePageActivity.inputs.clear();
  String first="https://comic.example/cache/chapter/1",next="https://comic.example/cache/chapter/2";FixturePageActivity activity=(FixturePageActivity)ins.startActivitySync(new Intent(context,FixturePageActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  try{
   WebView web=(WebView)field(activity,"web");PageTranslations cache=(PageTranslations)field(activity,"pageTranslations");var loaded=new AtomicInteger();
   ins.runOnMainSync(()->{activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);WebViewClient original=web.getWebViewClient();web.setWebViewClient(new WebViewClient(){
    public void onPageStarted(WebView w,String url,Bitmap icon){original.onPageStarted(w,url,icon);}public void onPageFinished(WebView w,String url){original.onPageFinished(w,url);loaded.incrementAndGet();}public void doUpdateVisitedHistory(WebView w,String url,boolean reload){original.doUpdateVisitedHistory(w,url,reload);}
    public WebResourceResponse shouldInterceptRequest(WebView w,WebResourceRequest request){String html="<!doctype html><html><meta name='viewport' content='width=device-width,initial-scale=1'><body style='margin:0;background:white;color:black;font:22px sans-serif'><p style='margin:30px 25px 120px'>HELLO FIRST WORLD</p><p style='margin:20px 25px 0'>HELLO SECOND WORLD</p><div style='height:1600px'></div></body></html>";return new WebResourceResponse("text/html","UTF-8",new ByteArrayInputStream(html.getBytes(java.nio.charset.StandardCharsets.UTF_8)));}
   });activity.onNewIntent(new Intent(context,FixturePageActivity.class).putExtra(Intent.EXTRA_TEXT,first));});await(()->loaded.get()>0,"Page load missing");Thread.sleep(700);ins.runOnMainSync(()->find(activity.getWindow().getDecorView(),"Terjemahkan").performClick());
   var done=new AtomicBoolean();await(()->{ins.runOnMainSync(()->done.set(!(Boolean)field(activity,"busy")&&cache.size()>=2));return done.get();},"Ordinary results missing");
   var firstEntry=new AtomicReference<PageTranslations.Entry>();var secondEntry=new AtomicReference<PageTranslations.Entry>();ins.runOnMainSync(()->{for(var entry:cache.entries())if(entry.source.contains("FIRST"))firstEntry.set(entry);else if(entry.source.contains("SECOND"))secondEntry.set(entry);assertNotNull(firstEntry.get());assertNotNull(secondEntry.get());assertFalse((Boolean)field(activity,"fullPageActive"));web.scrollTo(0,1100);assertEquals(2,cache.size());web.scrollTo(0,0);assertEquals(2,cache.size());});
   int before=FixturePageActivity.requests;ins.runOnMainSync(()->find(activity.getWindow().getDecorView(),"Terjemahkan").performClick());Thread.sleep(1000);assertEquals("Revisit must not call translator",before,FixturePageActivity.requests);
   FixturePageActivity.suffix=" UPDATED";ins.runOnMainSync(()->{BubbleOverlay overlay=(BubbleOverlay)field(activity,"overlay");TextView reset=find(overlay,"Reset");assertNotNull("Inline Reset below text is missing",reset);reset.performClick();});
   await(()->{ins.runOnMainSync(()->done.set(!(Boolean)field(activity,"busy")&&cache.entries().stream().anyMatch(entry->entry.updated)));return done.get();},"Reset did not complete");
   ins.runOnMainSync(()->{assertEquals(2,cache.size());assertTrue(cache.entries().stream().anyMatch(entry->entry.source.contains("FIRST")&&entry.updated&&entry.target.contains("UPDATED")));assertSame("Other result must remain unchanged",secondEntry.get(),cache.get(secondEntry.get().id));assertNotNull(find((BubbleOverlay)field(activity,"overlay"),"Reset ✓"));});
   Bitmap preview=ins.getUiAutomation().takeScreenshot();if(preview!=null)try(var output=new java.io.FileOutputStream(new java.io.File(context.getCacheDir(),"retained-preview.png"))){preview.compress(Bitmap.CompressFormat.PNG,100,output);}finally{preview.recycle();}
   String resent=String.join(" ",FixturePageActivity.inputs.subList(before,FixturePageActivity.inputs.size()));assertTrue(resent,resent.contains("FIRST"));assertFalse("Reset must not translate other block",resent.contains("SECOND"));
   FixturePageActivity.fail=true;ins.runOnMainSync(()->find((BubbleOverlay)field(activity,"overlay"),"Reset ✓").performClick());Thread.sleep(700);await(()->{ins.runOnMainSync(()->done.set(!(Boolean)field(activity,"busy")&&(Long)field(activity,"retryEntryId")==0));return done.get();},"Failed reset did not end");ins.runOnMainSync(()->{assertEquals(2,cache.size());assertTrue(cache.entries().stream().anyMatch(entry->entry.updated&&entry.target.contains("UPDATED")));assertSame(secondEntry.get(),cache.get(secondEntry.get().id));});FixturePageActivity.fail=false;
   final int beforeReload=loaded.get();ins.runOnMainSync(web::reload);await(()->loaded.get()>beforeReload,"Reload failed");ins.runOnMainSync(()->assertEquals(0,cache.size()));
   int beforeNext=loaded.get();ins.runOnMainSync(()->{cache.put("A","B",new RectF(20,20,150,80),Color.WHITE,false,null,1,0,0);activity.onNewIntent(new Intent(context,FixturePageActivity.class).putExtra(Intent.EXTRA_TEXT,next));});final int previous=beforeNext;await(()->loaded.get()>previous,"Next failed");ins.runOnMainSync(()->{assertEquals(0,cache.size());cache.put("A","B",new RectF(20,20,150,80),Color.WHITE,false,null,1,0,0);activity.onBackPressed();assertEquals(0,cache.size());});
  }finally{FixturePageActivity.fail=false;FixturePageActivity.suffix="";ins.runOnMainSync(activity::finish);var editor=prefs.edit().clear();for(var item:backup.entrySet()){Object v=item.getValue();String k=item.getKey();if(v instanceof String)editor.putString(k,(String)v);else if(v instanceof Boolean)editor.putBoolean(k,(Boolean)v);else if(v instanceof Long)editor.putLong(k,(Long)v);else if(v instanceof Integer)editor.putInt(k,(Integer)v);else if(v instanceof Float)editor.putFloat(k,(Float)v);else if(v instanceof Set)editor.putStringSet(k,(Set<String>)v);}editor.commit();}
 }
 @Test public void cacheDoesNotStackOverlappingCorrectionsAndClearRemovesCoverage(){
  PageTranslations cache=new PageTranslations();var first=cache.put("FIRST","Pertama",new RectF(20,30,220,100),Color.WHITE,false,null,1,0,0);cache.put("SECOND","Kedua",new RectF(20,200,220,270),Color.WHITE,false,null,1,0,0);cache.markScanned(1,0,0,400,600);assertTrue(cache.scanned(2,0,0,400,600));cache.put("FIRST","Baru",new RectF(22,32,215,98),Color.WHITE,false,null,1,0,0,true);assertEquals(2,cache.size());assertEquals("Baru",cache.get(first.id).target);assertTrue(cache.get(first.id).updated);cache.clear();assertEquals(0,cache.size());assertFalse(cache.scanned(1,0,0,400,600));
 }
 @Test public void resetDragScrollsInsteadOfClickingAndUncoveredAreaPassesThrough(){
  var ins=InstrumentationRegistry.getInstrumentation();ins.runOnMainSync(()->{var presses=new AtomicInteger();var scrolls=new AtomicInteger();View underneath=new View(ins.getTargetContext()){@Override public boolean onTouchEvent(MotionEvent event){if(event.getActionMasked()==MotionEvent.ACTION_MOVE)scrolls.incrementAndGet();return true;}};
   BubbleOverlay overlay=new BubbleOverlay(ins.getTargetContext());overlay.setResetListener(id->presses.incrementAndGet(),underneath);overlay.layout(0,0,900,1200);overlay.show(List.of(new BubbleOverlay.Bubble(new RectF(100,100,600,260),"HALO",Color.WHITE,true,null,55,false,false)));overlay.measure(View.MeasureSpec.makeMeasureSpec(900,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1200,View.MeasureSpec.EXACTLY));overlay.layout(0,0,900,1200);TextView reset=find(overlay,"Reset");assertNotNull(reset);float x=reset.getTranslationX()+20,y=reset.getTranslationY()+12;long now=android.os.SystemClock.uptimeMillis();MotionEvent down=MotionEvent.obtain(now,now,0,x,y,0),move=MotionEvent.obtain(now,now+30,2,x,y-100,0),up=MotionEvent.obtain(now,now+60,1,x,y-100,0);assertTrue(overlay.dispatchTouchEvent(down));overlay.dispatchTouchEvent(move);overlay.dispatchTouchEvent(up);assertTrue(scrolls.get()>0);assertEquals(0,presses.get());down.recycle();move.recycle();up.recycle();MotionEvent blank=MotionEvent.obtain(now,now,0,10,900,0);assertFalse(overlay.dispatchTouchEvent(blank));blank.recycle();
  });
 }
}
