package com.komiklingo.app;
import android.graphics.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import com.google.mlkit.vision.text.Text;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.*;
import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
public class OcrCropTest {
 @Test public void renderedItalicDialogueUsesRealRecognizer()throws Exception{
  var instrumentation=androidx.test.platform.app.InstrumentationRegistry.getInstrumentation();var context=instrumentation.getTargetContext();
  OcrQuality.load(context.getAssets().open("english-ocr-words.txt"));TessFallback.prepare(context);
  Bitmap image=Bitmap.createBitmap(1000,420,Bitmap.Config.ARGB_8888);image.eraseColor(Color.WHITE);Canvas canvas=new Canvas(image);Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setColor(Color.BLACK);paint.setTextSize(42);paint.setTypeface(Typeface.create("sans-serif",Typeface.BOLD_ITALIC));
  int y=70;for(String line:Arrays.asList("OF COURSE, MY LADY! BAN! DON'T", "JUST STAND THERE SULKING", "TAKE A LOOK AT THAT MAJESTIC SIGHT!")){canvas.drawText(line,30,y,paint);y+=80;}
  var recognizer=com.google.mlkit.vision.text.TextRecognition.getClient(com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS);var worker=java.util.concurrent.Executors.newSingleThreadExecutor();
  var latch=new java.util.concurrent.CountDownLatch(1);var result=new java.util.concurrent.atomic.AtomicReference<Text>();var error=new java.util.concurrent.atomic.AtomicReference<Exception>();
  try{instrumentation.runOnMainSync(()->OcrReader.read(recognizer,image,worker,()->true,Collections.singletonList("Ban"),new OcrReader.Result(){public void success(Text value){result.set(value);latch.countDown();}public void failure(Exception value){error.set(value);latch.countDown();}}));
   assertTrue(latch.await(90,java.util.concurrent.TimeUnit.SECONDS));assertNull(error.get());String text=result.get().getText().toUpperCase(java.util.Locale.ROOT);android.util.Log.i("OcrRegression",text);
   assertTrue(text,text.contains("BAN"));assertTrue(text,text.contains("SULKING"));assertTrue(text,text.contains("MAJESTIC SIGHT"));
  }finally{recognizer.close();worker.shutdownNow();image.recycle();}
 }
 @Test public void chapterLinesAreRemovedBeforeJoiningDialogue(){
  Bitmap image=Bitmap.createBitmap(400,800,Bitmap.Config.ARGB_8888);image.eraseColor(Color.WHITE);
  List<Text.Line> lines=new ArrayList<>();int y=20;
  for(String value:Arrays.asList("Ch. 56 Chronicle of","Runes","I AM TELLING YOU TO DEPART TOMORROW")){
   lines.add(new Text.Line(value,new Rect(20,y,380,y+30),Collections.emptyList(),"en",new Matrix(),Collections.emptyList(),.9f,0));y+=34;
  }
  Text.TextBlock block=new Text.TextBlock("Ch. 56 Chronicle of Runes I AM TELLING YOU TO DEPART TOMORROW",new Rect(20,20,380,118),Collections.emptyList(),"en",new Matrix(),lines);
  List<OcrAppearance.Paragraph> result=OcrAppearance.readingParagraphs(image,new Text(block.getText(),Collections.singletonList(block)),Collections.emptyList(),false,"Ch. 56 - Chronicle of Runes | Kaynscans");
  assertEquals(1,result.size());assertEquals("I AM TELLING YOU TO DEPART TOMORROW",result.get(0).source);image.recycle();
 }
 @Test public void bothShearsKeepAllFourCornersAndMapBack(){
  Bitmap image=Bitmap.createBitmap(320,240,Bitmap.Config.ARGB_8888);image.eraseColor(Color.WHITE);
  Canvas canvas=new Canvas(image);Paint paint=new Paint();paint.setColor(Color.BLACK);
  Rect box=new Rect(60,50,220,170);
  Text.Line line=new Text.Line("TEST TEXT",box,Collections.emptyList(),"en",new Matrix(),Collections.emptyList(),.8f,0);
  Text.TextBlock block=new Text.TextBlock("TEST TEXT",box,Collections.emptyList(),"en",new Matrix(),Collections.singletonList(line));
  for(float shear:new float[]{-.3f,0,.3f}){
   // Marks near all original text corners expose clipping in either shear direction.
   canvas.drawRect(60,50,66,56,paint);canvas.drawRect(214,50,220,56,paint);
   canvas.drawRect(60,164,66,170,paint);canvas.drawRect(214,164,220,170,paint);
   OcrReader.Crop crop=OcrReader.normalized(image,block,shear,120);Matrix forward=new Matrix();assertTrue(crop.inverse.invert(forward));
   for(float[] point:new float[][]{{63,53},{217,53},{63,167},{217,167}}){float[] mapped=point.clone();forward.mapPoints(mapped);assertTrue(mapped[0]>=0&&mapped[0]<crop.bitmap.getWidth());assertTrue(mapped[1]>=0&&mapped[1]<crop.bitmap.getHeight());assertEquals(Color.BLACK,crop.bitmap.getPixel(Math.round(mapped[0]),Math.round(mapped[1])));crop.inverse.mapPoints(mapped);assertEquals(point[0],mapped[0],.01f);assertEquals(point[1],mapped[1],.01f);}
   crop.bitmap.recycle();
  }image.recycle();
 }
}
