// Public map data only. No Firebase credentials are sent to these providers.
const memory = new Map();
export async function publicJson(url, options = {}) {
  const abort = new AbortController();
  const timer = setTimeout(() => abort.abort(), 20000);
  try {
    const response = await fetch(url, { ...options, signal: abort.signal, headers: { Accept: 'application/json', ...options.headers } });
    if (!response.ok) throw new Error(`Layanan merespons ${response.status}.`);
    return await response.json();
  } finally { clearTimeout(timer); }
}
export async function cachedPublic(key, get, ttl = 300000) {
  const entry = memory.get(key);
  if (entry && Date.now() - entry.time < ttl) return entry.value;
  if (memory.size >= 20) memory.delete(memory.keys().next().value);
  const value = Promise.resolve().then(get).catch(error => { memory.delete(key); throw error; });
  memory.set(key, { value, time: Date.now() }); return value;
}
export function elementPoint(element) {
  if (Number.isFinite(element.lat) && Number.isFinite(element.lon)) return { lat: element.lat, lng: element.lon };
  if (element.center) return { lat: element.center.lat, lng: element.center.lon };
  if (!element.geometry?.length) return null;
  const points = element.geometry.filter(p => Number.isFinite(p.lat) && Number.isFinite(p.lon));
  return points.length ? { lat: points.reduce((n, p) => n + p.lat, 0) / points.length, lng: points.reduce((n, p) => n + p.lon, 0) / points.length } : null;
}
export function placeCategory(tags = {}) {
  if (['restaurant', 'cafe', 'fast_food', 'food_court', 'bar'].includes(tags.amenity)) return 'food';
  if (tags.shop) return 'shop';
  if (tags.public_transport || tags.highway === 'bus_stop' || ['station', 'halt', 'tram_stop'].includes(tags.railway)) return 'transit';
  if (tags.healthcare || ['hospital', 'clinic', 'pharmacy', 'doctors'].includes(tags.amenity)) return 'health';
  if (tags.tourism) return 'travel';
  if (tags.amenity === 'fuel') return 'fuel';
  return 'place';
}
export function elementName(element) {
  const t = element.tags || {};
  return t.name || t['name:id'] || t.brand || t.operator || (t.building ? 'Bangunan di peta' : t.highway === 'bus_stop' ? 'Halte' : t.shop ? `Toko ${t.shop.replaceAll('_', ' ')}` : t.amenity ? t.amenity.replaceAll('_', ' ') : 'Tempat di peta');
}
export function boundsForDetails(center, zoom) {
  const step = zoom >= 18 ? .003 : .008;
  const lat = Math.round(Math.max(-84, Math.min(84, center.lat)) / step) * step;
  const lng = Math.round(Math.max(-179, Math.min(179, center.lng)) / step) * step;
  const lonRadius = Math.min(.04, step / Math.max(.2, Math.cos(lat * Math.PI / 180)));
  return { key: `${lat.toFixed(4)},${lng.toFixed(4)},${step}`, box: [Math.max(-85, lat-step), Math.max(-180, lng-lonRadius), Math.min(85, lat+step), Math.min(180, lng+lonRadius)] };
}
export async function osmDetails(center, zoom) {
  const bounds = boundsForDetails(center, zoom);
  return cachedPublic('osm:' + bounds.key, async () => {
    const b = bounds.box.join(',');
    const query = `[out:json][timeout:18];(way["building"](${b});nwr["name"]["amenity"](${b});nwr["shop"](${b});nwr["tourism"](${b});nwr["public_transport"](${b});node["highway"="bus_stop"](${b});nwr["railway"~"^(station|halt|tram_stop)$"](${b});way["highway"="cycleway"](${b});way["cycleway"](${b});way["cycleway:left"](${b});way["cycleway:right"](${b});way["highway"]["name"](${b}););out body geom 1800;`;
    let lastError;
    for (const host of ['https://overpass-api.de/api/interpreter', 'https://overpass.kumi.systems/api/interpreter']) {
      try {
        const data = await publicJson(host, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ data: query }) });
        if (!Array.isArray(data.elements) || data.remark) throw new Error('Detail area belum lengkap dari penyedia.');
        return { elements: data.elements, limited: data.elements.length >= 1800, bounds };
      } catch (error) { lastError = error; }
    }
    throw lastError;
  }, 600000);
}
function plain(value = '') {
  return new DOMParser().parseFromString(String(value), 'text/html').body.textContent || '';
}
export async function commonsFile(filename) {
  if (!filename) return null;
  const title = filename.startsWith('File:') ? filename : `File:${filename}`;
  const url = new URL('https://commons.wikimedia.org/w/api.php');
  url.search = new URLSearchParams({ action: 'query', format: 'json', origin: '*', prop: 'imageinfo', iiprop: 'url|extmetadata|mime', iiurlwidth: '1200', titles: title });
  const result = await publicJson(url);
  const page = Object.values(result.query?.pages || {})[0];
  return photoFromPage(page);
}
function photoFromPage(page) {
  const info = page?.imageinfo?.[0];
  const src = info?.thumburl || info?.url;
  if (!src || !src.startsWith('https://upload.wikimedia.org/') || (info.mime && !info.mime.startsWith('image/'))) return null;
  const m = info.extmetadata || {};
  return { src, title: page.title.replace(/^File:/, ''), author: plain(m.Artist?.value) || 'Kontributor Wikimedia Commons', license: plain(m.LicenseShortName?.value) || 'Lihat lisensi pada sumber', description: plain(m.ImageDescription?.value), source: info.descriptionurl, licenseURL: m.LicenseUrl?.value };
}
export async function photosForPlace(place) {
  const tags = place.tags || {};
  let file = tags.wikimedia_commons?.startsWith('File:') ? tags.wikimedia_commons : '';
  if (!file && /^Q\d+$/.test(tags.wikidata || '')) {
    const url = new URL('https://www.wikidata.org/w/api.php');
    url.search = new URLSearchParams({ action: 'wbgetentities', format: 'json', origin: '*', props: 'claims', ids: tags.wikidata });
    try { file = (await publicJson(url)).entities?.[tags.wikidata]?.claims?.P18?.[0]?.mainsnak?.datavalue?.value || ''; } catch { }
  }
  if (!file && /^https:\/\/commons\.wikimedia\.org\/wiki\/File:/.test(tags.image || '')) {
    try { file = decodeURIComponent(new URL(tags.image).pathname.split('/wiki/')[1]); } catch { }
  }
  if (!file) return [];
  const photo = await commonsFile(file); return photo ? [photo] : [];
}
export async function photosNear(point) {
  const key = `photos:${point.lat.toFixed(3)},${point.lng.toFixed(3)}`;
  return cachedPublic(key, async () => {
    const url = new URL('https://commons.wikimedia.org/w/api.php');
    url.search = new URLSearchParams({ action: 'query', format: 'json', origin: '*', generator: 'geosearch', ggscoord: `${point.lat}|${point.lng}`, ggsradius: '2000', ggsnamespace: '6', ggslimit: '12', prop: 'imageinfo', iiprop: 'url|extmetadata|mime', iiurlwidth: '1200' });
    const result = await publicJson(url);
    if (result.error) throw new Error('Foto sekitar belum tersedia.');
    return Object.values(result.query?.pages || {}).map(photoFromPage).filter(Boolean);
  });
}
export async function airQuality(point) {
  const url = new URL('https://air-quality-api.open-meteo.com/v1/air-quality');
  url.search = new URLSearchParams({ latitude: point.lat.toFixed(3), longitude: point.lng.toFixed(3), current: 'us_aqi,pm2_5,pm10', timezone: 'auto' });
  const data = await cachedPublic('air:' + url.search, () => publicJson(url), 600000);
  if (!Number.isFinite(data.current?.us_aqi)) throw new Error('Perkiraan kualitas udara belum tersedia.');
  return data;
}
export function airLabel(aqi) {
  return aqi <= 50 ? { text: 'Baik', color: '#bcf27c' } : aqi <= 100 ? { text: 'Sedang', color: '#f4d675' } : aqi <= 150 ? { text: 'Kurang baik bagi kelompok sensitif', color: '#f5a263' } : aqi <= 200 ? { text: 'Tidak sehat', color: '#ff747b' } : aqi <= 300 ? { text: 'Sangat tidak sehat', color: '#bd88d5' } : { text: 'Berbahaya', color: '#b95772' };
}
export async function wildfireEvents() {
  const data = await cachedPublic('wildfires', () => publicJson('https://eonet.gsfc.nasa.gov/api/v3/events?category=wildfires&status=open&days=30&limit=500'), 900000);
  if (!Array.isArray(data.events)) throw new Error('Laporan kebakaran belum tersedia.');
  return data.events;
}
