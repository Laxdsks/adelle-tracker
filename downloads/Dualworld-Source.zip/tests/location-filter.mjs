import assert from 'node:assert/strict';
import { createLocationFilter, locationDistance } from '../location-filter.js';
let now = Date.now();
Date.now = () => now;
const raw = (meters, accuracy = 6, time = now += 1000) => ({ lat: -8.54, lng: 118.43 + meters / 110000, accuracy, updatedAt: time });
const f = createLocationFilter(), initial = f.accept(raw(0));
for (const drift of [1, -2, 3, -1, 2, 0]) {
  const held = f.accept(raw(drift));
  assert.equal(held.lng, initial.lng, 'Stationary drift moves the pin');
  assert(held.updatedAt > initial.updatedAt, 'Real fix timestamp not retained');
  assert(held.accuracy >= 6 + locationDistance(initial, raw(drift, 6, held.updatedAt)) - .1);
}
// One implausible spike cannot move the anchor or disguise its accuracy.
assert.equal(f.accept(raw(500)), null);
assert.equal(f.accept(raw(0)).lng, initial.lng);
assert.equal(f.accept(raw(100, 450)), null);
assert.equal(f.accept(raw(100, 5, Date.now()-120000)), null);
assert.equal(f.accept(raw(100, 5, Date.now()+60000)), null);
// Coherent walking fixes move both sides, even without a sensor speed estimate.
const candidate = raw(7); assert.equal(f.accept(candidate).lng, initial.lng);
const walking = raw(9); assert.equal(f.accept(walking).lng, walking.lng);
const speedFix = raw(12); assert.equal(f.accept(speedFix, 1.1).lng, speedFix.lng);
assert.equal(f.accept({ ...speedFix, lng: 119 }), null, 'Duplicate measurement time accepted');
f.reset(); assert.equal(f.accept(raw(500)).lng, raw(500).lng);
console.log('GPS filter passed: stationary drift, honest uncertainty/timestamps, isolated spikes, coarse/stale/future fixes, and coherent walking.');
