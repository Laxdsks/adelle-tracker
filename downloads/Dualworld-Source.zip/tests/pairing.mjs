// Two independent browser stores, real RTDB emulator and deployed rules. Only
// authentication and map providers are fixtures; room and location writes are real.
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import path from 'node:path';
import { chromium } from 'playwright';
import { initializeTestEnvironment } from '@firebase/rules-unit-testing';

// The Node RTDB transport otherwise sends loopback emulator reads to the proxy.
delete process.env.HTTP_PROXY;
delete process.env.http_proxy;

const projectId = 'demo-dualworld';
const config = { projectId, apiKey: 'test-public-api-key', appId: '1:123:web:dualworld', databaseURL: `https://${projectId}.firebaseio.com` };
const jar = path.resolve('../.dualworld-toolchain/firebase-database-emulator-v4.11.2.jar');
assert.equal(createHash('sha256').update(await readFile(jar)).digest('hex'), 'b70d99344caf17c98b6f910fa8f6edf32a7c016cb1035e8915f70d38901eb97f');
const temporary = createServer(); await new Promise(resolve => temporary.listen(0, '127.0.0.1', resolve));
const port = temporary.address().port; await new Promise(resolve => temporary.close(resolve));
const emulator = spawn('java', ['-jar', jar, '--host', '127.0.0.1', '--port', String(port)], { stdio: ['ignore', 'pipe', 'pipe'] });
let logs = ''; emulator.stdout.on('data', data => { logs = (logs + data).slice(-8000); }); emulator.stderr.on('data', data => { logs = (logs + data).slice(-8000); });
const root = path.resolve('dist/web');
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.json': 'application/json' };
const server = createServer(async (request, response) => {
  const pathname = new URL(request.url, 'http://localhost').pathname;
  const file = path.resolve(root, '.' + (pathname === '/' ? '/index.html' : pathname));
  if (!file.startsWith(root + path.sep)) { response.writeHead(403).end(); return; }
  try { response.setHeader('Content-Type', types[path.extname(file)] || 'text/plain'); response.end(await readFile(file)); }
  catch { response.writeHead(404).end(); }
});
const sockets = new Set();
let browser, environment;
const errors = [];
const pages = [];
const diagnostics = [];
try {
  let ready = false;
  for (let attempt = 0; attempt < 100; attempt++) {
    try { if ((await fetch(`http://127.0.0.1:${port}/.json?ns=${projectId}`)).ok) { ready = true; break; } } catch {}
    if (emulator.exitCode !== null) throw new Error(logs);
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  assert(ready, logs);
  environment = await initializeTestEnvironment({ projectId, database: { host: '127.0.0.1', port, rules: await readFile('database.rules.json', 'utf8') } });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  browser = await chromium.launch({ executablePath: process.env.DUALWORLD_BROWSER || '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] });
  const tile = await readFile('icon-192.png');
  async function device(uid, configured = true) {
    const context = await browser.newContext({ viewport: { width: 390, height: 844 }, geolocation: { latitude: -8.5408, longitude: uid === 'dill' ? 118.4365 : 118.44, accuracy: 11 }, permissions: ['geolocation'] });
    await context.addInitScript(() => {
      window.DualworldAndroid = { shareInvite(text) { window.lastShare = text; }, copyInvite(text) { window.lastCopy = text; } };
      const watch = navigator.geolocation.watchPosition.bind(navigator.geolocation);
      navigator.geolocation.watchPosition = (callback, error, options) => { window.testGpsReading = callback; return watch(callback, error, options); };
    });
    await context.route('**/firebase-config.json', route => route.fulfill(configured ? { json: config } : { status: 404 }));
    await context.route('**/maps-config.json', route => route.fulfill({ status: 404 }));
    await context.route('https://overpass-api.de/**', route => route.fulfill({ json: { elements: [] } }));
    await context.route(/https:\/\/.*(?:tile\.openstreetmap\.org|server\.arcgisonline\.com)\//, route => route.fulfill({ contentType: 'image/png', body: tile }));
    await context.route('https://nominatim.openstreetmap.org/**', route => route.fulfill({ json: { address: { road: 'Jalan Uji' } } }));
    const now = Math.floor(Date.now() / 1000);
    const token = Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64url') + '.' + Buffer.from(JSON.stringify({ iss: `https://securetoken.google.com/${projectId}`, aud: projectId, sub: uid, user_id: uid, iat: now, auth_time: now, exp: now + 3600, firebase: { sign_in_provider: 'anonymous', identities: {} } })).toString('base64url') + '.';
    await context.route('https://identitytoolkit.googleapis.com/**', route => route.fulfill({ json: route.request().url().includes('accounts:lookup') ? { users: [{ localId: uid, providerUserInfo: [], createdAt: String(now * 1000), lastLoginAt: String(now * 1000) }] } : { localId: uid, idToken: token, refreshToken: 'test-refresh', expiresIn: '3600' } }));
    await context.routeWebSocket(/firebaseio\.com/, ws => {
      diagnostics.push('WS connected: ' + uid);
      const url = new URL(ws.url()); url.protocol = 'ws:'; url.host = `127.0.0.1:${port}`;
      url.searchParams.set('ns', projectId);
      const socket = new WebSocket(url); sockets.add(socket);
      const pending = [];
      ws.onMessage(data => { if (socket.readyState === WebSocket.OPEN) socket.send(data); else pending.push(data); });
      socket.addEventListener('open', () => { for (const data of pending.splice(0)) socket.send(data); });
      socket.addEventListener('message', event => {
        let data = String(event.data);
        try {
          const message = JSON.parse(data);
          if (message.t === 'c' && message.d?.t === 'h') { message.d.d.h = `${projectId}.firebaseio.com`; data = JSON.stringify(message); }
        } catch {}
        ws.send(data);
      });
      socket.addEventListener('error', () => errors.push('WebSocket relay failed'));
      socket.addEventListener('close', () => { sockets.delete(socket); ws.close(); });
      ws.onClose(() => socket.close());
    });
    const page = await context.newPage(); page.setDefaultTimeout(12000);
    pages.push(page);
    page.on('console', message => { if (message.type() === 'error' || message.type() === 'warning') diagnostics.push(message.text()); });
    page.on('pageerror', error => errors.push(error.message));
    await page.goto(base); await page.locator('#profile-name').fill(uid === 'dill' ? 'Raka' : 'Maya'); await page.locator('[data-avatar="🦊"]').click(); await page.locator('#enter-app-button').click();
    return { context, page };
  }
  const dill = await device('dill');
  const adelle = await device('adelle');
  for (const device of [dill, adelle]) await device.page.waitForFunction(() => document.querySelector('#connection-pill').textContent.includes('SIAP TERHUBUNG'));
  await adelle.page.waitForFunction(() => document.querySelector('#people-status').textContent.startsWith('Cari nama'));
  await dill.page.locator('#people-button').click();
  await dill.page.locator('#people-query').fill('Maya'); await dill.page.locator('#people-search-button').click();
  await dill.page.locator('#people-results button').filter({ hasText: 'Maya' }).click();
  await dill.page.locator('#confirm-ok').click();
  await adelle.page.locator('#people-button').click();
  await adelle.page.locator('#people-inbox button').filter({ hasText: 'TERIMA' }).click();
  await adelle.page.locator('#confirm-ok').click();
  await adelle.page.waitForFunction(() => document.querySelector('#room-state').textContent === 'TERHUBUNG');
  await dill.page.waitForFunction(() => document.querySelector('#room-state').textContent === 'TERHUBUNG');
  await dill.page.evaluate(() => window.dualworldHandleBack());
  for (const device of [dill, adelle]) await device.page.waitForFunction(() => document.querySelector('#share-button').textContent.includes('HENTIKAN BERBAGI'));
  await dill.page.waitForFunction(() => document.querySelector('#distance-label').textContent.includes('terpisah'));
  assert.equal(await dill.page.locator('#partner-name').textContent(), 'Maya');
  assert.equal(await adelle.page.locator('#partner-name').textContent(), 'Raka');
  assert.equal(await dill.page.evaluate(() => localStorage.getItem('dualworld-role')), 'profile');
  assert.equal(await adelle.page.evaluate(() => localStorage.getItem('dualworld-role')), 'profile');
  const pairId = await dill.page.evaluate(() => localStorage.getItem('dualworld-pair'));
  const ownerDb = environment.authenticatedContext('dill').database();
  const locationRef = ownerDb.ref(`pairs/${pairId}/locations/dill`);
  await dill.page.locator('#me-card').click();
  await adelle.page.locator('#partner-card').click();
  const previousPin = await adelle.page.locator('.dw-marker.partner').evaluate(el => el.parentElement.style.transform);
  const previousOwnPin = await dill.page.locator('.dw-marker.me').evaluate(el => el.parentElement.style.transform);
  for (const longitude of [118.43665, 118.4368]) {
    await dill.page.evaluate(longitude => window.testGpsReading({ coords: { latitude: -8.5408, longitude, accuracy: 8, speed: 1.1 }, timestamp: Date.now() }), longitude);
    for (const page of [dill.page, adelle.page]) await page.waitForFunction(value => document.querySelector('#location-coordinates').textContent.includes(value), longitude.toFixed(6));
    assert.equal((await locationRef.once('value')).val().lng, longitude, 'Koordinat terbaru belum sampai ke server');
  }
  await adelle.page.waitForFunction(previous => document.querySelector('.dw-marker.partner').parentElement.style.transform !== previous, previousPin);
  await dill.page.waitForFunction(previous => document.querySelector('.dw-marker.me').parentElement.style.transform !== previous, previousOwnPin);
  const goodFix = (await locationRef.once('value')).val();
  // A fresh but coarse indoor/cell reading must not move either phone's accurate pin.
  await dill.context.setGeolocation({ latitude: -8.54, longitude: 118.43, accuracy: 450 });
  await dill.page.waitForFunction(() => document.querySelector('#share-status').textContent.includes('MENUNGGU GPS AKURAT'));
  assert((await dill.page.locator('#location-coordinates').textContent()).includes('118.436800'));
  assert.equal((await locationRef.once('value')).val().lng, goodFix.lng);
  await dill.page.evaluate(() => window.testGpsReading({ coords: { latitude: -8.55, longitude: 118.45, accuracy: 5 }, timestamp: Date.now() - 120000 }));
  assert((await dill.page.locator('#location-coordinates').textContent()).includes('118.436800'), 'Bacaan GPS lama mengganti posisi terbaru');
  await dill.page.evaluate(() => window.testGpsReading({ coords: { latitude: -8.55, longitude: 118.45, accuracy: 5 }, timestamp: Date.now() + 60000 }));
  assert((await dill.page.locator('#location-coordinates').textContent()).includes('118.436800'), 'Waktu pengukuran masa depan memblokir GPS terbaru');
  for (const page of [dill.page, adelle.page]) await page.evaluate(() => window.dualworldHandleBack());
  await dill.page.locator('#locate-button').click();
  assert.equal(await dill.page.locator('#locate-button').getAttribute('aria-pressed'), 'true');
  await adelle.page.locator('#focus-partner-button').click();
  assert.equal(await adelle.page.locator('#focus-partner-button').getAttribute('aria-pressed'), 'true');
  await dill.page.evaluate(() => window.testGpsReading({ coords: { latitude: -8.5408, longitude: 118.43695, accuracy: 7, speed: 1.1 }, timestamp: Date.now() }));
  await adelle.page.locator('#partner-card').click();
  await adelle.page.waitForFunction(() => document.querySelector('#location-coordinates').textContent.includes('118.436950'));
  // Closing the web session keeps the last measurement and its original timestamp.
  await adelle.page.evaluate(() => window.dualworldHandleBack());
  const retained = (await locationRef.once('value')).val();
  await adelle.page.waitForFunction(() => document.querySelector('#partner-location-meta').textContent.includes('Online') && document.querySelector('#partner-location-meta').textContent.includes('GPS') && document.querySelector('#partner-dot').classList.contains('online'), null, { timeout: 45000 });
  assert.equal((await locationRef.once('value')).val().updatedAt, retained.updatedAt, 'Posisi lama diberi waktu baru tanpa pembacaan GPS');
  await adelle.page.locator('#partner-card').click();
  assert((await adelle.page.locator('#location-coordinates').textContent()).includes('118.436950'), 'Lokasi hilang saat GPS tidak memperbarui');
  await adelle.page.evaluate(() => window.dualworldHandleBack());
  await dill.page.reload();
  await dill.page.waitForFunction(() => document.querySelector('#room-state').textContent === 'TERHUBUNG');
  await dill.page.waitForFunction(() => document.querySelector('#share-button').textContent.includes('HENTIKAN BERBAGI'));
  assert.equal((await locationRef.once('value')).val().lng, retained.lng);
  await adelle.page.locator('#share-button').click(); await adelle.page.locator('#confirm-ok').click();
  await dill.page.waitForFunction(() => document.querySelector('#focus-partner-button').disabled === true);
  await dill.page.locator('#menu-button').click(); await dill.page.locator('#leave-room-button').click(); await dill.page.locator('#confirm-ok').click();
  await dill.page.waitForFunction(() => document.querySelector('#room-state').textContent === 'PRIBADI');
  await adelle.page.waitForFunction(() => document.querySelector('#room-state').textContent === 'PRIBADI');
  assert.equal(await adelle.page.evaluate(() => localStorage.getItem('dualworld-pair')), null, 'Pasangan masih terjebak pada ruang yang sudah ditutup');
  await dill.page.locator('#menu-button').click();
  await dill.page.locator('#delete-profile-button').click(); await dill.page.locator('#confirm-ok').click();
  await dill.page.locator('#identity-dialog').waitFor({ state:'visible' });
  await environment.withSecurityRulesDisabled(async context => { assert.equal((await context.database().ref('publicProfiles/dill').once('value')).exists(), false); assert.equal((await context.database().ref('connectionInvites/dill').once('value')).exists(), false); });
  assert.equal(await dill.page.evaluate(() => localStorage.getItem('dualworld-profile-complete')), null);
  const blocked = await device('blocked', false);
  await blocked.context.route('https://identitytoolkit.googleapis.com/**', route => route.fulfill({ status: 400, json: { error: { code: 400, message: 'OPERATION_NOT_ALLOWED' } } }));
  await blocked.page.locator('#menu-button').click();
  await blocked.page.locator('.sync-config').evaluate(el => { el.open = true; });
  await blocked.page.locator('#firebase-config-input').fill(JSON.stringify(config));
  await blocked.page.locator('#save-config-button').click();
  await blocked.page.waitForFunction(() => document.querySelector('#connection-pill').textContent.includes('KONEKSI GAGAL'));
  assert.match(await blocked.page.locator('#backend-note').textContent(), /Anonymous/);
  assert.deepEqual(errors, []);
  console.log('Dua profil umum lulus: cari nama, kirim permintaan, terima tanpa kode, berbagi otomatis sesuai izin, persetujuan, gerakan GPS di kedua layar/server, pin bergerak, bacaan kasar/lama ditolak, mode ikuti, presence tetap online ketika GPS lama dan waktu pengukuran tetap asli, pilihan berbagi pulih setelah reload, berhenti berbagi dan hapus ruang. RTDB/aturan asli; auth dan GPS memakai fixture, tanpa proyek produksi.');
} catch (error) {
  for (const page of pages) console.error('Device UI:', await page.locator('#connection-pill').textContent(), await page.locator('#backend-note').textContent(), await page.locator('#pair-feedback').textContent());
  console.error('Transport:', diagnostics);
  console.error('Pairing diagnostics:', errors, logs.slice(-2000)); throw error;
} finally {
  for (const socket of sockets) socket.close();
  if (browser) await browser.close();
  if (environment) await environment.cleanup();
  if (server.listening) await new Promise(resolve => server.close(resolve));
  emulator.kill('SIGTERM');
}
