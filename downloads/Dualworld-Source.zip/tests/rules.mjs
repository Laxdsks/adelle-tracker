import assert from 'node:assert/strict';
import { initializeTestEnvironment, assertSucceeds, assertFails } from '@firebase/rules-unit-testing';
import { ref, set, get, remove, query, orderByChild, startAt, endAt, limitToFirst, serverTimestamp } from 'firebase/database';
import { setLogLevel } from 'firebase/app';
import { readFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { createServer } from 'node:net';
import path from 'node:path';

setLogLevel('silent');
const toolchain = path.resolve(process.env.DUALWORLD_TOOLCHAIN_DIR || '../.dualworld-toolchain');
const jar = path.join(toolchain, 'firebase-database-emulator-v4.11.2.jar');
await mkdir(toolchain, { recursive: true });
try { await readFile(jar); } catch (error) {
  if (error.code !== 'ENOENT') throw error;
  const download = spawnSync('curl', ['--fail', '--location', '--silent', '--show-error', '--retry', '3', 'https://storage.googleapis.com/firebase-preview-drop/emulator/firebase-database-emulator-v4.11.2.jar', '-o', jar], { encoding: 'utf8' });
  assert.equal(download.status, 0, download.stderr);
}
// Published SHA-256 from firebase-tools 14.4.0 downloadableEmulatorInfo.json.
assert.equal(createHash('sha256').update(await readFile(jar)).digest('hex'), 'b70d99344caf17c98b6f910fa8f6edf32a7c016cb1035e8915f70d38901eb97f', 'Checksum emulator tidak cocok');
// Firebase's Node WebSocket transport ignores NO_PROXY. These tests only connect to loopback.
delete process.env.HTTP_PROXY;
delete process.env.http_proxy;
const socket = createServer(); await new Promise(resolve => socket.listen(0, '127.0.0.1', resolve));
const port = socket.address().port; await new Promise(resolve => socket.close(resolve));
const emulator = spawn('java', ['-Duser.language=en', '-jar', jar, '--host', '127.0.0.1', '--port', String(port)], { stdio: ['ignore', 'pipe', 'pipe'] });
let logs = ''; emulator.stdout.on('data', data => { logs = (logs + data).slice(-16000); }); emulator.stderr.on('data', data => { logs = (logs + data).slice(-16000); });
let environment;
try {
  let ready = false;
  for (let attempt = 0; attempt < 100; attempt++) {
    if (emulator.exitCode !== null) throw new Error(logs);
    try { if ((await fetch(`http://127.0.0.1:${port}/.json?ns=demo-dualworld`)).ok) { ready = true; break; } } catch {}
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  assert(ready, logs);
  environment = await initializeTestEnvironment({ projectId: 'demo-dualworld', database: { host: '127.0.0.1', port, rules: await readFile('database.rules.json', 'utf8') } });
  const dill = environment.authenticatedContext('dill').database();
  const adelle = environment.authenticatedContext('adelle').database();
  const outsider = environment.authenticatedContext('outsider').database();
  const guest = environment.unauthenticatedContext().database();
  const initial = { owner: 'dill', members: { dill: true }, profiles: { dill: { name: 'Dill' } }, createdAt: Date.now() };
  const coords = { lat: -8.5408, lng: 118.4365, accuracy: 11, updatedAt: Date.now() };
  await assertFails(set(ref(guest, 'pairs/guest-room'), initial));
  await assertFails(set(ref(dill, 'pairs/forged-members'), { ...initial, members: { dill: true, adelle: true } }));
  await assertFails(set(ref(dill, 'pairs/forged-location'), { ...initial, locations: { adelle: coords } }));
  await assertSucceeds(set(ref(dill, 'pairs/pair'), initial));
  await assertFails(get(ref(outsider, 'pairs/pair')));
  await assertSucceeds(set(ref(adelle, 'pairs/pair/requests/adelle'), 'Adelle'));
  await assertSucceeds(get(ref(adelle, 'pairs/pair/requests/adelle')));
  await assertFails(get(ref(outsider, 'pairs/pair/requests/adelle')));
  await assertSucceeds(remove(ref(adelle, 'pairs/pair/requests/adelle')));
  await assertSucceeds(set(ref(adelle, 'pairs/pair/requests/adelle'), 'Adelle'));
  await assertFails(set(ref(adelle, 'pairs/pair/locations/adelle'), coords));
  await assertFails(set(ref(adelle, 'pairs/pair/members/adelle'), true));
  await assertSucceeds(set(ref(dill, 'pairs/pair/partnerUid'), 'adelle'));
  await assertSucceeds(set(ref(dill, 'pairs/pair/members/adelle'), true));
  await assertSucceeds(remove(ref(dill, 'pairs/pair/requests/adelle')));
  await assertSucceeds(set(ref(adelle, 'pairs/pair/profiles/adelle'), { name: 'Adelle' }));
  await assertSucceeds(set(ref(dill, 'pairs/pair/locations/dill'), coords));
  await assertSucceeds(set(ref(adelle, 'pairs/pair/locations/adelle'), { ...coords, lng: 118.44 }));
  assert.equal((await assertSucceeds(get(ref(dill, 'pairs/pair/locations/adelle')))).val().lng, 118.44);
  await assertFails(set(ref(dill, 'pairs/pair/locations/adelle'), coords));
  await assertFails(set(ref(dill, 'pairs/pair/members/outsider'), true));
  await assertFails(set(ref(dill, 'pairs/pair/partnerUid'), 'outsider'));
  await assertFails(remove(ref(dill, 'pairs/pair/partnerUid')));
  await assertFails(set(ref(adelle, 'pairs/pair/owner'), 'adelle'));
  await assertFails(set(ref(dill, 'pairs/pair/locations/dill'), { ...coords, lat: 100 }));
  await assertFails(set(ref(dill, 'pairs/pair/locations/dill'), { ...coords, extra: 'data' }));
  await assertSucceeds(remove(ref(adelle, 'pairs/pair/locations/adelle')));
  assert.equal((await get(ref(dill, 'pairs/pair/locations/adelle'))).val(), null);
  await assertSucceeds(remove(ref(adelle, 'pairs/pair/profiles/adelle')));
  await assertSucceeds(remove(ref(adelle, 'pairs/pair/members/adelle')));
  await assertSucceeds(remove(ref(adelle, 'pairs/pair/partnerUid')));
  await assertFails(get(ref(adelle, 'pairs/pair/locations/dill')));
  await assertSucceeds(remove(ref(dill, 'pairs/pair')));
  await environment.withSecurityRulesDisabled(async context => assert.equal((await get(ref(context.database(), 'pairs/pair'))).exists(), false));
  const profile = { name: 'User One', searchName: 'user one', avatar: '🌙', handle: 'dw-dill' };
  await assertSucceeds(set(ref(dill, 'publicProfiles/dill'), profile));
  await assertSucceeds(set(ref(adelle, 'publicProfiles/adelle'), { ...profile, name: 'User Two', searchName: 'user two', handle: 'dw-adelle' }));
  await assertFails(set(ref(outsider, 'publicProfiles/dill'), profile));
  await assertFails(set(ref(dill, 'publicProfiles/dill'), { ...profile, lat: coords.lat }));
  await assertFails(get(ref(guest, 'publicProfiles/dill')));
  await assertFails(get(ref(outsider, 'publicProfiles')));
  await assertFails(get(query(ref(outsider, 'publicProfiles'), orderByChild('searchName'), startAt('user'), endAt('user\uf8ff'), limitToFirst(50))));
  const directory = await assertSucceeds(get(query(ref(outsider, 'publicProfiles'), orderByChild('searchName'), startAt('user'), endAt('user\uf8ff'), limitToFirst(12))));
  assert.equal(directory.size, 2);
  const room = 'abcdefghijklmnopqrstuv0123456789';
  await assertSucceeds(set(ref(dill, `pairs/${room}`), initial));
  await assertSucceeds(set(ref(dill, `pairs/${room}/partnerUid`), 'adelle'));
  await assertFails(set(ref(adelle, `pairs/${room}/members/adelle`), true));
  const invitation = { pairId: room, createdAt: serverTimestamp() };
  await assertSucceeds(set(ref(dill, 'connectionInvites/adelle/dill'), invitation));
  await assertFails(get(ref(outsider, 'connectionInvites/adelle')));
  await assertFails(set(ref(outsider, 'connectionInvites/adelle/dill'), invitation));
  await assertFails(set(ref(outsider, `pairs/${room}/members/outsider`), true));
  await assertSucceeds(set(ref(adelle, `pairs/${room}/members/adelle`), true));
  await assertSucceeds(remove(ref(adelle, 'connectionInvites/adelle/dill')));
  await assertSucceeds(set(ref(adelle, `pairs/${room}/presence/adelle`), { sharing: true, phase: 'active', lastSeen: serverTimestamp() }));
  await assertSucceeds(get(ref(dill, `pairs/${room}/presence/adelle`)));
  await assertFails(set(ref(dill, `pairs/${room}/presence/adelle`), { sharing: true, phase: 'active', lastSeen: serverTimestamp() }));
  await assertFails(set(ref(outsider, `pairs/${room}/presence/outsider`), { sharing: true, phase: 'active', lastSeen: serverTimestamp() }));
  await assertFails(set(ref(adelle, `pairs/${room}/presence/adelle`), { sharing: true, phase: 'active', lastSeen: Date.now() + 600000 }));
  await assertSucceeds(remove(ref(adelle, `pairs/${room}/presence/adelle`)));
  await assertFails(remove(ref(outsider, 'connectionInvites/adelle')));
  await assertSucceeds(remove(ref(adelle, 'connectionInvites/adelle')));
  await assertSucceeds(remove(ref(adelle, 'publicProfiles/adelle')));
  await assertSucceeds(remove(ref(dill, 'publicProfiles/dill')));
  console.log('Multiuser: bounded directory, approved profile invitation, room/location/presence isolation, deletion, and legacy invitation rules passed.');
  console.log('Firebase emulator: persetujuan, batas dua anggota, isolasi lokasi, pembatalan undangan, validasi koordinat, berhenti berbagi, dan pemutusan ruang berhasil.');
} finally {
  if (environment) await environment.cleanup();
  if (emulator.exitCode === null) {
    const stopped = new Promise(resolve => emulator.once('exit', resolve));
    emulator.kill('SIGTERM'); await stopped;
  }
}
