import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { chromium } from 'playwright';
const root = path.resolve('dist/web'), errors = [];
const server = createServer(async (req, res) => {
  const pathname = new URL(req.url, 'http://localhost').pathname;
  const file = path.resolve(root, '.' + (pathname === '/' ? '/index.html' : pathname));
  if (!file.startsWith(root + '/')) { res.writeHead(403).end(); return; }
  try { res.setHeader('Content-Type', { '.html':'text/html', '.js':'text/javascript', '.css':'text/css', '.json':'application/json', '.png':'image/png', '.svg':'image/svg+xml' }[path.extname(file)] || 'application/octet-stream'); res.end(await readFile(file)); }
  catch { res.writeHead(404).end(); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox', '--enable-unsafe-swiftshader'] });
try {
  const context = await browser.newContext({ viewport: { width:390, height:844 }, deviceScaleFactor:2, hasTouch:true, geolocation: { latitude:-8.5408, longitude:118.4365, accuracy:6 }, permissions:['geolocation'] });
  const tile = await readFile('icon-192.png'); let detailRequests = 0;
  const elements = Array.from({length:500}, (_, i) => ({type:'node',id:i,lat:-8.5408+(i%20-10)*.0001,lon:118.4365+(Math.floor(i/20)-12)*.0001,tags:{name:'Tempat '+i,shop:'yes'}}));
  elements.push({type:'way',id:1001,tags:{building:'yes',name:'Gedung uji','building:levels':'2'},geometry:[{lat:-8.5409,lon:118.4364},{lat:-8.5409,lon:118.4366},{lat:-8.5407,lon:118.4366},{lat:-8.5407,lon:118.4364},{lat:-8.5409,lon:118.4364}]});
  await context.route('**/firebase-config.json', route => route.fulfill({status:404}));
  await context.route('**/maps-config.json', route => route.fulfill({status:404}));
  await context.route(/https:\/\/.*tile\.openstreetmap\.org\//, route => route.fulfill({contentType:'image/png',body:tile}));
  await context.route('https://overpass-api.de/**', route => { detailRequests++; return route.fulfill({json:{elements}}); });
  await context.route('https://nominatim.openstreetmap.org/**', route => route.fulfill({json:{address:{road:'Jalan Uji'}}}));
  await context.route('https://tiles.openfreemap.org/**', route => route.fulfill({status:503,body:'fixture provider outage'}));
  await context.route('https://elevation-tiles-prod.s3.amazonaws.com/**', route => route.fulfill({status:503,body:'fixture terrain outage'}));
  await context.route('https://server.arcgisonline.com/**', route => {
    const match = route.request().url().match(/\/tilemap\/(\d+)\/(\d+)\/(\d+)\/(\d+)\/(\d+)/);
    if (match) { const [,z,top,left,width,height] = match.map(Number); return route.fulfill({json:{location:{top,left,width,height},data:Array(width*height).fill(1)}}); }
    return route.fulfill({contentType:'image/png',body:tile});
  });
  const page = await context.newPage(); page.setDefaultTimeout(20000); page.on('pageerror', e => errors.push(e.message)); page.on('console', m => { if (m.type()==='error') console.log('Render diagnostic:',m.text().slice(0,300)); });
  await page.goto(`http://127.0.0.1:${server.address().port}`);
  await page.locator('#profile-name').fill('Penguji Peta'); await page.locator('#enter-app-button').click();
  await page.waitForFunction(() => document.querySelectorAll('.place-map-marker').length > 0);
  assert(await page.locator('.place-map-marker').count() <= 28, 'Mobile POIs exceed rendering budget');
  assert.equal(await page.locator('.panel').first().evaluate(e => getComputedStyle(e).backdropFilter), 'none');
  assert(!(await page.locator('.leaflet-control-attribution').textContent()).includes('Leaflet'));
  const cdp = await context.newCDPSession(page); await cdp.send('Emulation.setCPUThrottlingRate', {rate:4});
  const before = detailRequests;
  await page.evaluate(() => { window.framesSample=[]; window.sampling=true; let last=performance.now(); const frame=now=>{window.framesSample.push(now-last);last=now;if(window.sampling)requestAnimationFrame(frame)};requestAnimationFrame(frame); });
  await page.mouse.move(220,380); await page.mouse.down(); await page.mouse.move(135,420,{steps:24}); await page.mouse.up();
  await page.locator('#layer-button').click(); await page.locator('[data-basemap="satellite"]').click(); await page.locator('#layers-done-button').click();
  await page.waitForFunction(() => document.querySelectorAll('#map canvas.leaflet-tile-loaded').length > 0);
  const sizes = await page.locator('#map canvas.leaflet-tile-loaded').evaluateAll(nodes => nodes.map(n => n.width)); assert(sizes.every(n=>n===512), 'Retina tiles not rendered at native display resolution');
  const timings = await page.evaluate(() => {window.sampling=false;return window.framesSample.sort((a,b)=>a-b)});
  assert(detailRequests-before <= 2, 'Panning repeatedly fetches area details');
  console.log(JSON.stringify({mobileLabels:await page.locator('.place-map-marker').count(),detailRequestsDuringPan:detailRequests-before,p95FrameMs:Math.round(timings[Math.floor(timings.length*.95)]),cpuThrottle:4,retinaCanvas:512}));
  await cdp.send('Emulation.setCPUThrottlingRate', {rate:1});
  await page.locator('#quick-3d-button').click();
  try { await page.waitForFunction(() => document.querySelector('#three-d-status').textContent.startsWith('Peta cadangan aktif'), null, {timeout:15000}); } catch(e) { console.log('3D status:',await page.locator('#three-d-status').textContent(),errors); await page.locator('#three-d-dialog').screenshot({path:'/workspace/.dualworld-toolchain/checks/three-d-failure.png'}); throw e; }
  assert.equal(await page.locator('#three-d-canvas canvas').count(), 1);
  assert.equal(await page.locator('#three-d-terrain-button').getAttribute('aria-pressed'), 'false', 'Failed terrain kept active over the basemap');
  await page.locator('#three-d-dialog').screenshot({path:'/workspace/.dualworld-toolchain/checks/three-d-fallback.png'});
  await page.locator('#three-d-back-button').click();
  await page.waitForFunction(() => !document.querySelector('#three-d-canvas canvas'));
  assert.equal(await page.locator('#three-d-canvas canvas').count(), 0, 'Closed 3D canvas retains GPU resources');
  assert.deepEqual(errors, []);
  console.log('Map rendering passed: dense POI budget, bounded requests, lightweight mobile panels, retina satellite, actual WebGL fallback basemap/extrusions after provider outage, terrain failure recovery and canvas cleanup.');
} finally { await browser.close(); await new Promise(resolve=>server.close(resolve)); }
