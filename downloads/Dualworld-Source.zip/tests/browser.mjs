import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { chromium } from 'playwright';

const root = path.resolve('dist/web');
let workerOverride;
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.svg': 'image/svg+xml' };
const server = createServer(async (request, response) => {
  const pathname = new URL(request.url, 'http://localhost').pathname;
  response.setHeader('Cache-Control', 'no-store');
  if (pathname === '/test-old-sw.js') {
    response.setHeader('Content-Type', 'text/javascript'); response.setHeader('Service-Worker-Allowed', '/');
    response.end(`self.addEventListener('install',e=>e.waitUntil((async()=>{const c=await caches.open('dualworld-shell-v1');await c.put('/app.js',new Response('throw new Error("old-version-fixture")',{headers:{'Content-Type':'text/javascript'}}));await self.skipWaiting()})()));self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));self.addEventListener('fetch',e=>{if(new URL(e.request.url).pathname==='/app.js')e.respondWith(caches.match('/app.js'))});`); return;
  }
  const file = path.resolve(root, '.' + (pathname === '/' ? '/index.html' : decodeURIComponent(pathname)));
  if (!file.startsWith(root + path.sep)) { response.writeHead(403); response.end(); return; }
  try {
    const data = pathname === '/sw.js' && workerOverride ? workerOverride : await readFile(file);
    response.setHeader('Content-Type', types[path.extname(file)] || 'text/plain'); response.end(data);
  } catch { response.writeHead(404); response.end(); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const base = `http://127.0.0.1:${server.address().port}`;
const browser = await chromium.launch({ executablePath: process.env.DUALWORLD_BROWSER || '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] });
const tile = await readFile('icon-192.png');
async function fixtures(context) {
  // Never send fixture locations or test accounts to the bundled production project.
  await context.route('**/maps-config.json', route => route.fulfill({ status: 404 }));
  await context.route('https://overpass-api.de/**', route => route.fulfill({ json: { elements: [] } }));
  await context.route('**/firebase-config.json', route => route.fulfill({ status: 404 }));
  await context.route(/https:\/\/.*(?:tile\.openstreetmap\.org|server\.arcgisonline\.com)\//, route => {
    const match = route.request().url().match(/\/tilemap\/(\d+)\/(\d+)\/(\d+)\/(\d+)\/(\d+)/);
    if (match) {
      const [, z, top, left, width, height] = match.map(Number);
      return route.fulfill({ json: { location: { top, left, width, height }, data: Array(width * height).fill(z >= 19 ? 0 : 1) } });
    }
    return route.fulfill({ contentType: 'image/png', body: tile });
  });
  await context.route('https://nominatim.openstreetmap.org/**', route => {
    const reverse = route.request().url().includes('/reverse');
    const place = { lat: '-8.5418', lon: '118.4415', name: 'Toko Uji', display_name: 'Toko Uji, Jalan Uji, Bima, Nusa Tenggara Barat', address: { road: 'Jalan Uji', city: 'Bima', state: 'Nusa Tenggara Barat', shop: 'Toko Uji' } };
    return route.fulfill({ json: reverse ? place : [place] });
  });
  await context.route('https://router.project-osrm.org/**', route => route.fulfill({ json: { code: 'Ok', routes: [{ distance: 1400, duration: 300, geometry: { type: 'LineString', coordinates: [[118.4365, -8.5408], [118.4415, -8.5418]] }, legs: [{ steps: [{ distance: 100, name: 'Jalan Uji', maneuver: { type: 'turn', modifier: 'right' } }, { distance: 0, name: 'Toko Uji', maneuver: { type: 'arrive' } }] }] }] } }));
}
async function enter(page, name = 'Raka') {
  await page.locator('#profile-name').fill(name);
  await page.locator('#profile-location-consent').uncheck();
  await page.locator('[data-avatar="🐼"]').click();
  await page.locator('#enter-app-button').click();
  await page.waitForFunction(() => !document.querySelector('#identity-dialog').open);
}
const errors = [];
try {
  const context = await browser.newContext({ viewport: { width: 390, height: 844 }, geolocation: { latitude: -8.5408, longitude: 118.4365, accuracy: 11 }, permissions: ['geolocation'] });
  await fixtures(context);
  const page = await context.newPage(); page.on('pageerror', error => errors.push(error.message));
  await page.goto(base);
  await page.locator('#identity-dialog').waitFor({ state: 'visible' });
  await page.screenshot({ path: '/workspace/.dualworld-toolchain/checks/profile.png' });
  await enter(page, 'Maya');
  assert.equal(await page.locator('#my-name').textContent(), 'Maya');
  await page.locator('#locate-button').click();
  await page.waitForFunction(() => document.querySelector('#share-status').textContent.includes('GPS DI PERANGKAT'));
  await page.locator('#me-card').click();
  await page.waitForFunction(() => document.querySelector('#location-road').textContent === 'Jalan Uji');
  assert.match(await page.locator('#location-area').textContent(), /Bima/);
  assert.match(await page.locator('#location-coordinates').textContent(), /-8\.540800/);
  assert.equal(await page.locator('#location-accuracy').textContent(), '±11 m');
  await page.screenshot({ path: '/workspace/.dualworld-toolchain/checks/location.png' });
  assert.equal(await page.evaluate(() => window.dualworldHandleBack()), true);
  await page.locator('#place-query').fill('Toko Uji'); await page.locator('#place-search-button').click();
  await page.locator('.search-result').click(); await page.locator('#route-button').click();
  await page.waitForFunction(() => document.querySelector('#route-distance').textContent === '1.4 km');
  assert.match(await page.locator('#route-steps').textContent(), /Belok kanan/);
  assert.equal(context.pages().length, 1, 'Rute membuka halaman lain');
  assert.equal(page.url(), base + '/');
  await page.evaluate(() => window.dualworldHandleBack());
  await page.locator('#menu-button').click(); await page.locator('#switch-profile-button').click(); await enter(page);
  assert.equal(await page.locator('#my-name').textContent(), 'Raka');
  await page.locator('#share-button').click();
  assert.equal(await page.locator('#settings-dialog').evaluate(el => el.open), true);
  assert.equal(await page.locator('#confirm-dialog').evaluate(el => el.open), false, 'Berbagi aktif tanpa koneksi/keanggotaan');
  assert.equal(await page.locator('#invite-box').isVisible(), false, 'Kolom undangan kosong tetap tampil');
  assert.equal(await page.locator('#copy-invite-button').isEnabled(), false);
  try {
    await readFile('dist/web/downloads/dualworld-android.apk');
    await page.locator('#android-download-card').waitFor({ state: 'visible' });
    const received = page.waitForEvent('download');
    await page.locator('#android-download-button').click();
    const download = await received;
    assert.equal(download.suggestedFilename(), 'dualworld-android.apk');
    assert.equal(page.url(), base + '/');
    await download.cancel();
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  await page.locator('.sync-config').evaluate(el => { el.open = true; });
  await page.locator('#firebase-config-input').fill('{"private_key":"not-a-web-config"}');
  await page.locator('#save-config-button').click();
  assert.equal(await page.evaluate(() => localStorage.getItem('dualworld-firebase-config')), null);
  await page.evaluate(() => window.dualworldHandleBack());
  await page.evaluate(() => navigator.serviceWorker.ready);
  await page.waitForFunction(() => navigator.serviceWorker.controller !== null);
  const cacheCheck = await page.evaluate(async () => {
    const keys = await caches.keys(); const cache = await caches.open(keys.find(key => key.startsWith('dualworld-shell-')));
    await cache.put('/styles.css', new Response('old-styles-fixture'));
    return { css: await (await fetch('/styles.css')).text(), requests: (await cache.keys()).map(request => request.url) };
  });
  assert(!cacheCheck.css.includes('old-styles-fixture'), 'Cache lama mengalahkan jaringan');
  assert(cacheCheck.requests.every(url => !url.includes('firebase-config.json') && !url.includes('?pair=')));
  const currentWorker = await readFile('dist/web/sw.js', 'utf8');
  workerOverride = currentWorker.replace(/dualworld-shell-[a-f0-9]+/, 'dualworld-shell-test-update');
  await page.evaluate(async () => (await navigator.serviceWorker.getRegistration()).update());
  await page.waitForFunction(() => !document.querySelector('#update-banner').hidden);
  workerOverride = undefined;
  await page.evaluate(async () => (await navigator.serviceWorker.getRegistration()).update());
  await page.waitForFunction(async () => !(await caches.keys()).includes('dualworld-shell-test-update'));
  await context.setOffline(true); await page.reload();
  await page.waitForFunction(() => document.querySelector('#my-name').textContent === 'Raka');
  assert.equal(await page.locator('#menu-button').isVisible(), true, 'Shell offline gagal');
  await context.close();

  const native = await browser.newContext({ viewport: { width: 390, height: 844 }, geolocation: { latitude: -8.5408, longitude: 118.4365, accuracy: 11 }, permissions: ['geolocation'] });
  await fixtures(native);
  await native.addInitScript(() => { window.DualworldAndroid = { shareInvite(text) { window.lastNativeInvite = text; } }; });
  const nativePage = await native.newPage(); nativePage.on('pageerror', error => errors.push(error.message));
  await nativePage.goto(base); await enter(nativePage);
  assert.equal(await nativePage.evaluate(async () => (await navigator.serviceWorker.getRegistrations()).length), 0);
  await nativePage.locator('#locate-button').click();
  await nativePage.waitForFunction(() => document.querySelector('#accuracy-label').textContent.includes('11'));
  const missingTiles = [];
  nativePage.on('request', request => { if (request.url().includes('World_Imagery/MapServer/tile/19/')) missingTiles.push(request.url()); });
  await nativePage.locator('#layer-button').click();
  await nativePage.locator('[data-basemap="satellite"]').click();
  await nativePage.locator('#layers-done-button').click();
  await nativePage.locator('#me-card').click();
  await nativePage.locator('#location-focus-button').click();
  await nativePage.locator('#map-availability').waitFor({ state: 'visible' });
  await nativePage.waitForFunction(() => document.querySelectorAll('#map canvas.leaflet-tile-loaded').length > 0);
  assert.deepEqual(missingTiles, [], 'Tile satelit kosong masih diminta pada zoom 19');
  await nativePage.locator('#use-streets-button').click();
  assert.equal(await nativePage.locator('#map-mode').textContent(), 'PETA JALAN');
  await nativePage.evaluate(() => window.dispatchEvent(new Event('dualworld-native-stop')));
  assert.equal(await nativePage.evaluate(() => window.dualworldHandleBack()), false);
  await nativePage.evaluate(() => window.dispatchEvent(new Event('dualworld-native-resume')));
  await nativePage.locator('#locate-button').click();
  assert.equal(native.pages().length, 1);
  await native.close();

  const migration = await browser.newContext(); await fixtures(migration);
  const oldPage = await migration.newPage(); await oldPage.goto(base);
  await oldPage.evaluate(async () => {
    for (const registration of await navigator.serviceWorker.getRegistrations()) await registration.unregister();
    await navigator.serviceWorker.register('/test-old-sw.js', { scope: '/' });
  });
  await oldPage.waitForFunction(() => navigator.serviceWorker.controller?.scriptURL.endsWith('/test-old-sw.js'));
  await oldPage.reload();
  await oldPage.waitForFunction(() => navigator.serviceWorker.controller?.scriptURL.endsWith('/sw.js'));
  await oldPage.reload(); await enter(oldPage);
  assert(!(await oldPage.evaluate(() => caches.keys())).includes('dualworld-shell-v1'), 'Cache v1 tidak dibersihkan');
  assert.equal(await oldPage.locator('#my-name').textContent(), 'Raka');
  await migration.close();
  assert.deepEqual(errors, []);
  console.log('Browser: profil, GPS pribadi, detail lokasi, pencarian/rute internal, konfigurasi, back Android, pembaruan/migrasi cache, dan shell offline berhasil (layanan peta memakai fixture).');
} finally { await browser.close(); await new Promise(resolve => server.close(resolve)); }
