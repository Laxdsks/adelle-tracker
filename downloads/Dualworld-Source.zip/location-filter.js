import { validLocation, MAX_SHARED_ACCURACY, isFreshLocation } from './location-quality.js';

export function locationDistance(a, b) {
  const rad = Math.PI / 180, lat = (b.lat - a.lat) * rad, lng = (b.lng - a.lng) * rad;
  const n = Math.sin(lat / 2) ** 2 + Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(lng / 2) ** 2;
  return 6371000 * 2 * Math.atan2(Math.sqrt(n), Math.sqrt(Math.max(0, 1 - n)));
}

// Hold small changes inside GPS uncertainty. Two coherent fixes release a move;
// reliable sensor speed can release it sooner. Every accepted time is a real fix.
export function createLocationFilter() {
  let anchor, anchorAccuracy, pending;
  return {
    reset() { anchor = null; pending = null; },
    accept(next, speed = null) {
      if (!validLocation(next) || !isFreshLocation(next) || next.accuracy > MAX_SHARED_ACCURACY) return null;
      if (anchor && next.updatedAt <= anchor.updatedAt) return null;
      if (!anchor) { anchor = { ...next }; anchorAccuracy = next.accuracy; return { ...anchor }; }
      const distance = locationDistance(anchor, next);
      const radius = Math.min(12, Math.max(4, .8 * Math.max(anchorAccuracy, next.accuracy)));
      const moving = Number.isFinite(speed) && speed >= .75;
      const coherent = pending && next.updatedAt - pending.updatedAt <= 6000
        && locationDistance(pending, next) <= Math.max(radius, (next.updatedAt - pending.updatedAt) / 1000 * 3)
        && distance > radius;
      if ((moving && distance >= 2) || coherent) {
        anchor = { ...next }; anchorAccuracy = next.accuracy; pending = null;
      } else {
        pending = distance > radius ? { ...next } : null;
        const uncertainty = Math.max(anchorAccuracy, next.accuracy + distance);
        if (uncertainty > MAX_SHARED_ACCURACY) return null;
        anchor = { ...anchor, updatedAt: next.updatedAt, accuracy: uncertainty };
      }
      return { ...anchor };
    }
  };
}
