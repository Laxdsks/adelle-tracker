import { validLocation, MAX_SHARED_ACCURACY, isFreshLocation } from './location-quality.js';

export function locationDistance(a, b) {
  const rad = Math.PI / 180, lat = (b.lat - a.lat) * rad, lng = (b.lng - a.lng) * rad;
  const n = Math.sin(lat / 2) ** 2 + Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(lng / 2) ** 2;
  return 6371000 * 2 * Math.atan2(Math.sqrt(n), Math.sqrt(Math.max(0, 1 - n)));
}

// Hold GPS wander. A move must exceed the reported accuracy and persist across
// four fresh readings; every accepted time still comes from the actual sensor.
export function createLocationFilter() {
  let anchor, anchorAccuracy, pending, pendingCount;
  return {
    reset() { anchor = null; pending = null; pendingCount = 0; },
    accept(next, speed = null) {
      if (!validLocation(next) || !isFreshLocation(next) || next.accuracy > MAX_SHARED_ACCURACY) return null;
      if (anchor && next.updatedAt <= anchor.updatedAt) return null;
      if (!anchor) { anchor = { ...next }; anchorAccuracy = next.accuracy; return { ...anchor }; }
      const distance = locationDistance(anchor, next);
      const radius = Math.min(12, Math.max(4, .8 * Math.max(anchorAccuracy, next.accuracy)));
      const movementThreshold = Math.max(9, 2 * Math.max(anchorAccuracy, next.accuracy));
      const elapsed = pending ? next.updatedAt - pending.updatedAt : 0;
      const speedBound = Number.isFinite(speed) && speed >= 0 ? Math.max(3, speed) : 3;
      const coherent = pending && elapsed > 0 && elapsed <= 8000
        && locationDistance(pending, next) <= Math.max(radius, elapsed / 1000 * speedBound * 1.5 + 2);
      if (distance > movementThreshold) {
        if (coherent) pendingCount++; else { pending = { ...next }; pendingCount = 1; }
        if (pendingCount >= 4) {
          anchor = { ...next }; anchorAccuracy = next.accuracy; pending = null; pendingCount = 0;
          return { ...anchor };
        }
      } else { pending = null; pendingCount = 0; }
      const uncertainty = Math.max(anchorAccuracy, next.accuracy + distance);
      if (uncertainty > MAX_SHARED_ACCURACY) return null;
      anchor = { ...anchor, updatedAt: next.updatedAt, accuracy: uncertainty };
      return { ...anchor };
    }
  };
}
