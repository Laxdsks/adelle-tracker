import { osmDetails, elementPoint, elementName, placeCategory, photosForPlace, photosNear, airQuality, airLabel, wildfireEvents } from './map-data.js';

const $ = id => document.getElementById(id);
const words = { all: 'Tempat sekitar', food: 'Tempat makan', shop: 'Toko sekitar', transit: 'Halte & stasiun', health: 'Layanan kesehatan', fuel: 'SPBU' };
const marks = { food: '◉', shop: '▣', transit: 'T', health: '+', fuel: 'P', travel: '◇', place: '⌖' };
const panels = ['layers-dialog', 'place-dialog', 'three-d-dialog', 'licensed-map-dialog', 'maps-config-dialog', 'street-dialog', 'street-config-dialog'];
const safeText = value => String(value).replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
export function createMapExplorer({ L, map, setBaseMap, getLocations, onDestination, onRoute, toast }) {
  const overlays = Object.fromEntries(['places', 'buildings', 'transit', 'cycling', 'roads', 'wildfires'].map(key => [key, L.layerGroup().addTo(map)]));
  let enabled = { places: true, buildings: false, transit: false, cycling: false, roads: false, wildfires: false, air: false };
  try { enabled = { ...enabled, ...JSON.parse(localStorage.getItem('dualworld-map-details') || '{}') }; } catch { }
  let details = [];
  let moving = false;
  const mobile = matchMedia('(pointer: coarse)').matches || innerWidth < 700;
  let category = 'all';
  let detailGeneration = 0;
  let detailTimer;
  let nextRequestAt = 0;
  let currentPlace;
  let nearbyListOpen = false;
  let galleryGeneration = 0;
  let airGeneration = 0;
  let fireGeneration = 0;
  let threeD;
  let threeDLoading;
  let licensed;
  let licensedLoading;
  let mapsConfig = {};
  let mapsConfigLoading;
  let pendingLicensedMode = '';
  let pendingLicensedPoint;
  let streetLoading, street;
  let pendingStreetPoint;
  const streetCoverage = L.layerGroup().addTo(map);

  const notices = {};
  const notice = (message, kind = 'details') => {
    notices[kind] = message;
    $('explore-notice-copy').textContent = Object.values(notices).filter(Boolean).join(' ');
    $('explore-notice').hidden = !Object.values(notices).some(Boolean);
  };
  function readPoint() { return selectedPoint() || map.getCenter(); }
  function selectedPoint() { return currentPlace ? { lat: currentPlace.lat, lng: currentPlace.lng } : null; }
  function marker(point, label, symbol, onClick) {
    const node = document.createElement('div'); node.className = 'place-pin';
    const icon = document.createElement('span'); icon.textContent = symbol; node.append(icon);
    const title = document.createElement('small'); title.textContent = label; node.append(title);
    return L.marker([point.lat, point.lng], { icon: L.divIcon({ className: 'place-map-marker', html: node, iconSize: [130, 30], iconAnchor: [14, 15] }), title: label }).on('click', onClick);
  }
  function normalize(element) {
    const point = elementPoint(element); if (!point) return null;
    return { ...point, name: elementName(element), tags: element.tags || {}, osmId: `${element.type}/${element.id}` };
  }
  function drawDetails() {
    if (moving) return;
    for (const [name, layer] of Object.entries(overlays)) if (name !== 'wildfires') layer.clearLayers();
    let rendered = 0, buildingCount = 0, roadCount = 0, pathCount = 0;
    const labels = new Set(), bounds = map.getBounds().pad(.15);
    const freeLabel = place => { const p = map.latLngToContainerPoint([place.lat, place.lng]); const key = Math.floor(p.x / 110) + ':' + Math.floor(p.y / 42); if (labels.has(key)) return false; labels.add(key); return true; };
    for (const element of details) {
      const tags = element.tags || {}, place = normalize(element); if (!place || !bounds.contains([place.lat, place.lng])) continue;
      const points = (element.geometry || []).filter(p => Number.isFinite(p.lat) && Number.isFinite(p.lon)).map(p => [p.lat, p.lon]);
      if (enabled.buildings && tags.building && points.length > 2 && buildingCount++ < (mobile ? 100 : 300)) {
        L.polygon(points, { color: '#9cddd1', weight: 1, fillColor: '#83bfb3', fillOpacity: .2 }).on('click', () => openPlace(place)).addTo(overlays.buildings);
      }
      if (enabled.cycling && tags.highway && (tags.highway === 'cycleway' || tags.cycleway || tags['cycleway:left'] || tags['cycleway:right']) && points.length > 1) {
        const dedicated = tags.highway === 'cycleway';
        const lane = [tags.cycleway, tags['cycleway:left'], tags['cycleway:right']].some(value => /lane|track|shared_lane/.test(value || ''));
        if ((dedicated || lane) && pathCount++ < (mobile ? 25 : 60)) L.polyline(points, { color: '#77ddd1', weight: dedicated ? 4 : 2, dashArray: dedicated ? null : '5,6' }).bindTooltip(dedicated ? 'Jalur sepeda · OpenStreetMap' : 'Lajur sepeda tercatat · OpenStreetMap').addTo(overlays.cycling);
      }
      if (enabled.roads && map.getZoom() >= 17 && tags.highway && tags.name && points.length > 1 && roadCount < (mobile ? 12 : 30) && freeLabel(place)) {
        roadCount++;
        const road = L.divIcon({ className: 'road-name-marker', html: `<span>${safeText(tags.name)}</span>`, iconSize: [150, 20] });
        L.marker(points[Math.floor(points.length / 2)], { icon: road, interactive: false }).addTo(overlays.roads);
      }
      const kind = placeCategory(tags);
      if (kind === 'transit') {
        if (enabled.transit && rendered < (mobile ? 28 : 70) && freeLabel(place)) { rendered++; marker(place, place.name, marks.transit, () => openPlace(place)).addTo(overlays.transit); }
      } else if (enabled.places && (tags.amenity || tags.shop || tags.tourism) && (category === 'all' || category === kind) && rendered < (mobile ? 28 : 70) && freeLabel(place)) {
        marker(place, place.name, marks[kind], () => openPlace(place)).addTo(overlays.places); rendered++;
      }
    }
  }
  async function refreshDetails(force = false) {
    const generation = ++detailGeneration;
    if (!['places', 'buildings', 'transit', 'cycling', 'roads'].some(k => enabled[k])) { notice(''); return; }
    if (map.getZoom() < 16) { notice('Perbesar peta untuk nama tempat, bangunan, dan jalur yang lebih lengkap.'); return; }
    const wait = Math.max(0, nextRequestAt - Date.now());
    if (wait && !force) { clearTimeout(detailTimer); detailTimer = setTimeout(() => void refreshDetails(), wait); return; }
    nextRequestAt = Date.now() + 8000;
    notice('Memuat tempat, bangunan, dan detail area…');
    try {
      const result = await osmDetails(map.getCenter(), map.getZoom());
      if (generation !== detailGeneration) return;
      details = result.elements; drawDetails(); if (nearbyListOpen && $('place-dialog').open) renderNearby();
      notice(!details.length ? 'Belum ada detail tambahan yang tercatat di area ini.' : result.limited ? 'Area padat. Perbesar peta untuk detail bangunan yang lebih lengkap.' : '');
    } catch { if (generation === detailGeneration) notice('Detail area belum dapat dimuat. Peta dasar tetap bisa digunakan. Tekan Muat area untuk mencoba lagi.'); }
  }
  function updateDetailButtons() {
    for (const button of document.querySelectorAll('[data-map-detail]')) {
      const active = Boolean(enabled[button.dataset.mapDetail]); button.classList.toggle('selected', active); button.setAttribute('aria-pressed', String(active));
    }
    $('air-quality-panel').hidden = !enabled.air;
  }
  function persistDetails() { localStorage.setItem('dualworld-map-details', JSON.stringify(enabled)); updateDetailButtons(); }
  async function changeDetail(kind) {
    enabled[kind] = !enabled[kind]; persistDetails();
    if (kind === 'air') { if (enabled.air) await refreshAir(); else airGeneration++; return; }
    if (kind === 'wildfires') { if (enabled.wildfires) await refreshFires(); else { fireGeneration++; overlays.wildfires.clearLayers(); notice('', 'fires'); } return; }
    drawDetails(); void refreshDetails();
  }
  async function refreshAir() {
    const generation = ++airGeneration;
    $('air-quality-value').textContent = 'AQI …'; $('air-quality-copy').textContent = 'Memuat perkiraan kualitas udara area…';
    try {
      const result = await airQuality(map.getCenter());
      if (generation !== airGeneration || !enabled.air) return;
      const { us_aqi: aqi, pm2_5: fine, pm10: coarse, time } = result.current;
      const label = airLabel(aqi); $('air-quality-value').textContent = `AQI ${Math.round(aqi)} · ${label.text}`; $('air-quality-value').style.color = label.color;
      $('air-quality-copy').textContent = `PM2.5 ${fine ?? '—'} · PM10 ${coarse ?? '—'} µg/m³ · ${time.replace('T', ' ')} ${result.timezone} · Model area CAMS/Open-Meteo, bukan pengukuran di bangunan.`;
    } catch { if (generation === airGeneration) { $('air-quality-value').textContent = 'AQI belum tersedia'; $('air-quality-copy').textContent = 'Penyedia belum dapat dihubungi. Geser peta atau coba lagi.'; } }
  }
  async function refreshFires() {
    const generation = ++fireGeneration;
    overlays.wildfires.clearLayers();
    notice('Memuat laporan kebakaran NASA…', 'fires');
    try {
      const events = await wildfireEvents();
      if (generation !== fireGeneration || !enabled.wildfires) return;
      let count = 0;
      const bounds = map.getBounds().pad(.2);
      for (const event of events) {
        const geometry = event.geometry?.[event.geometry.length - 1];
        if (geometry?.type !== 'Point') continue;
        const [lng, lat] = geometry.coordinates;
        if (!Number.isFinite(lat) || !Number.isFinite(lng) || !bounds.contains([lat, lng])) continue;
        count++;
        marker({ lat, lng }, event.title, '♨', () => {
          void openPlace({ lat, lng, name: event.title, note: `Laporan NASA EONET · ${geometry.date}. Lokasi kejadian yang dilaporkan, bukan batas wilayah terbakar atau pemantauan langsung.`, tags: {} });
        }).addTo(overlays.wildfires);
      }
      notice(count ? `${count} laporan kebakaran di area peta · NASA EONET, 30 hari terakhir.` : 'Belum ada laporan kebakaran NASA EONET di area peta untuk 30 hari terakhir. Ini bukan kepastian bahwa tidak ada kebakaran.', 'fires');
    } catch { if (generation === fireGeneration) notice('Laporan kebakaran belum dapat dimuat.', 'fires'); }
  }
  function appendFact(container, title, value) {
    if (!value) return;
    const fact = document.createElement('div'), key = document.createElement('small'), text = document.createElement('strong');
    key.textContent = title; text.textContent = value; fact.append(key, text); container.append(fact);
  }
  function renderPhotos(photos) {
    const gallery = $('place-photo-gallery'); gallery.replaceChildren();
    for (const photo of photos) {
      const figure = document.createElement('figure');
      const image = document.createElement('img'); image.src = photo.src; image.alt = photo.description || photo.title; image.loading = 'lazy'; image.referrerPolicy = 'no-referrer';
      image.addEventListener('error', () => { image.hidden = true; caption.textContent += ' · Foto belum dapat dimuat.'; });
      const caption = document.createElement('figcaption');
      const title = document.createElement('strong'); title.textContent = photo.title;
      const credit = document.createElement('span'); credit.textContent = `${photo.author} · ${photo.license}`;
      caption.append(title, credit);
      for (const [label, href] of [['SUMBER FOTO', photo.source], ['LISENSI', photo.licenseURL]]) {
        if (!/^https:\/\//.test(href || '')) continue;
        const link = document.createElement('a'); link.textContent = label; link.href = href; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.dataset.attribution = 'true'; caption.append(link);
      }
      figure.append(image, caption); gallery.append(figure);
    }
  }
  async function openPlace(place, nearbyOnly = false) {
    if (!Number.isFinite(place.lat) || !Number.isFinite(place.lng)) return;
    nearbyListOpen = false;
    currentPlace = place;
    const generation = ++galleryGeneration;
    $('place-title').textContent = place.name || 'Tempat di sekitar';
    const tags = place.tags || {};
    $('place-address').textContent = place.note || place.address || [tags['addr:street'], tags['addr:housenumber'], tags['addr:city']].filter(Boolean).join(', ') || `${place.lat.toFixed(5)}, ${place.lng.toFixed(5)}`;
    const facts = $('place-facts'); facts.replaceChildren();
    appendFact(facts, 'JENIS', tags.building ? `Bangunan · ${tags.building}` : tags.amenity || tags.shop || tags.tourism || tags.public_transport);
    appendFact(facts, 'LANTAI', tags['building:levels']); appendFact(facts, 'TINGGI TERCATAT', tags.height);
    appendFact(facts, 'JAM BUKA TERCATAT', tags.opening_hours);
    appendFact(facts, 'SUMBER', place.osmId ? `OpenStreetMap · ${place.osmId}` : 'Posisi yang dipilih di peta');
    $('photos-heading').textContent = nearbyOnly ? 'FOTO SEKITAR · RADIUS 2 KM' : 'FOTO TEMPAT';
    $('place-photo-gallery').replaceChildren(); $('nearby-place-list').replaceChildren();
    $('place-photo-status').textContent = 'Mencari foto yang tersedia…';
    if (!$('place-dialog').open) $('place-dialog').showModal();
    try {
      let photos = nearbyOnly ? [] : await photosForPlace(place);
      let nearby = nearbyOnly;
      if (!photos.length) { nearby = true; photos = await photosNear(place); }
      if (generation !== galleryGeneration) return;
      $('photos-heading').textContent = nearby ? 'FOTO SEKITAR · RADIUS 2 KM' : 'FOTO TEMPAT';
      $('place-photo-status').textContent = photos.length ? nearby ? 'Foto dengan penanda geografis dari Wikimedia Commons. Belum tentu foto bangunan yang dipilih.' : 'Foto yang ditautkan ke tempat ini pada data OpenStreetMap/Wikidata.' : 'Belum ada foto publik yang tersedia untuk titik ini atau sekitarnya. Bentuk bangunan tetap dapat dilihat di peta/3D jika datanya tercatat.';
      renderPhotos(photos);
    } catch { if (generation === galleryGeneration) $('place-photo-status').textContent = 'Foto belum dapat diambil dari penyedia. Coba lagi saat internet tersambung.'; }
  }
  function showNearby(kind = 'all') {
    category = kind; enabled.places = true; persistDetails(); drawDetails(); void refreshDetails();
    const center = map.getCenter();
    currentPlace = { lat: center.lat, lng: center.lng, name: words[kind] || words.all, tags: {} };
    $('place-title').textContent = currentPlace.name; $('place-address').textContent = 'Tempat yang tercatat di area peta. Perbesar atau geser peta jika daftar belum tersedia.';
    $('place-facts').replaceChildren(); $('place-photo-gallery').replaceChildren(); $('photos-heading').textContent = 'TEMPAT DI AREA PETA'; $('place-photo-status').textContent = '';
    nearbyListOpen = true; renderNearby();
    galleryGeneration++;
    if (!$('place-dialog').open) $('place-dialog').showModal();
  }
  function renderNearby() {
    const list = $('nearby-place-list'); list.replaceChildren();
    const bounds = map.getBounds();
    const places = details.map(normalize).filter(p => p && bounds.contains([p.lat, p.lng]) && (p.tags.amenity || p.tags.shop || p.tags.tourism) && (category === 'all' || placeCategory(p.tags) === category));
    for (const place of places.slice(0, 50)) {
      const row = document.createElement('button'); row.className = 'nearby-place-item'; row.textContent = `${marks[placeCategory(place.tags)]} ${place.name}`; row.addEventListener('click', () => { void openPlace(place); }); list.append(row);
    }
    $('place-photo-status').textContent = places.length ? `${places.length} tempat tercatat di area peta · OpenStreetMap` : 'Menunggu detail tempat. Perbesar peta ke area yang lebih dekat; daftar diperbarui ketika data tersedia.';
  }
  async function open3D(point = readPoint()) {
    $('layers-dialog').close(); $('place-dialog').close();
    if (!$('three-d-dialog').open) $('three-d-dialog').showModal();
    try {
      if (!threeDLoading) threeDLoading = import('./map-3d.js').then(({ createThreeD }) => createThreeD({ getLocations, onPlace: place => void openPlace(place) }));
      threeD = await threeDLoading;
      if ($('three-d-dialog').open) await threeD.open(point, Math.max(15, map.getZoom()));
    } catch { $('three-d-status').textContent = 'Tampilan 3D belum dapat dibuka. Periksa internet dan dukungan grafis HP; peta biasa tetap bisa dipakai.'; }
  }
  function applyMapsConfig(config) {
    mapsConfig = config || {};
    for (const label of document.querySelectorAll('.maps-access-label')) label.textContent = mapsConfig.googleMapsApiKey ? 'Konfigurasi tersimpan' : 'Perlu aktivasi layanan';
    for (const label of document.querySelectorAll('.street-access-label')) label.textContent = mapsConfig.mapillaryClientToken ? 'Mapillary · konfigurasi tersimpan' : 'Gratis · perlu token aplikasi';
  }
  async function loadMapsConfig() {
    let bundled = {};
    try {
      const response = await fetch('./maps-config.json', { cache: 'no-store' });
      if (response.ok) bundled = await response.json();
    } catch { /* Saved client configuration also works without the bundle request. */ }
    try {
      const stored = localStorage.getItem('dualworld-maps-config');
      let saved = {}; try { saved = stored ? JSON.parse(stored) : {}; } catch { }
      // Empty saved fields must not hide client configuration bundled in an update.
      applyMapsConfig({ ...bundled, ...Object.fromEntries(Object.entries(saved).filter(([, value]) => typeof value === 'string' && value.trim())) });
    } catch { }
  }
  async function openLicensed(mode = 'map', point = readPoint()) {
    await mapsConfigLoading;
    $('layers-dialog').close(); $('place-dialog').close(); pendingLicensedMode = mode; pendingLicensedPoint = { lat: point.lat, lng: point.lng };
    if (!mapsConfig.googleMapsApiKey) {
      $('maps-config-status').textContent = 'Layanan ini belum diaktifkan. Peta, medan, bangunan 3D, dan foto publik gratis tetap tersedia.';
      if (!$('maps-config-dialog').open) $('maps-config-dialog').showModal(); return;
    }
    if (!$('licensed-map-dialog').open) $('licensed-map-dialog').showModal();
    $('licensed-status').textContent = 'Menghubungkan layanan peta…';
    try {
      if (!licensedLoading) licensedLoading = import('./google-explorer.js').then(({ createGoogleExplorer }) => createGoogleExplorer({ getLocations }));
      licensed = await licensedLoading;
      if ($('licensed-map-dialog').open) await licensed.open(mapsConfig, point, mode);
    } catch (error) { $('licensed-status').textContent = error.message || 'Layanan belum dapat dibuka. Periksa aktivasi, kuota, dan pembatasan kunci peta.'; }
  }
  function configureMaps() {
    $('layers-dialog').close(); $('licensed-map-dialog').close();
    $('maps-key-input').value = mapsConfig.googleMapsApiKey || ''; $('maps-id-input').value = mapsConfig.googleMapsMapId || '';
    $('maps-config-status').textContent = 'Simpan kunci browser setelah Maps JavaScript API, Places API (New), billing, dan pembatasan alamat siap. Jika mengganti kunci yang sudah dimuat, muat ulang Dualworld.';
    if (!$('maps-config-dialog').open) $('maps-config-dialog').showModal();
  }
  function configureStreet() {
    $('layers-dialog').close(); $('place-dialog').close(); $('street-dialog').close();
    $('street-token-input').value = mapsConfig.mapillaryClientToken || '';
    $('street-config-status').textContent = 'Daftar akun pembuat aplikasi sekali, lalu gunakan Client Access Token untuk menampilkan rekaman jalan. Ini terpisah dari koneksi dua HP yang sudah siap.';
    if (!$('street-config-dialog').open) $('street-config-dialog').showModal();
  }
  async function openStreet(point = readPoint(), imageId) {
    await mapsConfigLoading;
    pendingStreetPoint = { lat: point.lat, lng: point.lng };
    $('layers-dialog').close(); $('place-dialog').close();
    if (!mapsConfig.mapillaryClientToken) { configureStreet(); return; }
    if (!$('street-dialog').open) $('street-dialog').showModal();
    $('street-status').textContent = 'Memuat tampilan jalan…';
    try {
      if (!streetLoading) streetLoading = import('./mapillary-explorer.js').then(({ createStreetExplorer }) => createStreetExplorer({
        onConfigure: configureStreet,
        onCoverage: images => {
          streetCoverage.clearLayers();
          for (const image of images) L.circleMarker([image.lat, image.lng], { radius: image.pano ? 5 : 3, color: '#49bfff', fillOpacity: .7, weight: 1 }).bindTooltip(image.pano ? 'Panorama 360° · Mapillary' : 'Foto jalan · Mapillary').on('click', () => void openStreet(image, image.id)).addTo(streetCoverage);
        }
      }));
      street = await streetLoading;
      if ($('street-dialog').open) await street.open(mapsConfig, point, imageId);
    } catch { $('street-status').textContent = 'Tampilan jalan belum dapat dibuka. Periksa internet atau dukungan grafis HP.'; }
  }
  for (const button of document.querySelectorAll('[data-basemap]')) button.addEventListener('click', () => {
    setBaseMap(button.dataset.basemap);
    for (const other of document.querySelectorAll('[data-basemap]')) { const active = other === button; other.classList.toggle('selected', active); other.setAttribute('aria-pressed', String(active)); }
  });
  for (const button of document.querySelectorAll('[data-map-detail]')) button.addEventListener('click', () => void changeDetail(button.dataset.mapDetail));
  for (const button of document.querySelectorAll('[data-nearby]')) button.addEventListener('click', () => showNearby(button.dataset.nearby));
  $('layers-done-button').addEventListener('click', () => $('layers-dialog').close());
  $('configure-maps-button').addEventListener('click', configureMaps);
  $('configure-street-button').addEventListener('click', configureStreet);
  $('licensed-config-button').addEventListener('click', configureMaps);
  $('explore-refresh-button').addEventListener('click', () => { void refreshDetails(); if (enabled.air) void refreshAir(); if (enabled.wildfires) void refreshFires(); });
  $('air-quality-close').addEventListener('click', () => { enabled.air = false; airGeneration++; persistDetails(); });
  $('nearby-photos-button').addEventListener('click', () => { const point = map.getCenter(); void openPlace({ lat: point.lat, lng: point.lng, name: 'Foto di sekitar peta', tags: {} }, true); });
  $('quick-street-button').addEventListener('click', () => void openStreet(map.getCenter()));
  $('quick-3d-button').addEventListener('click', () => void open3D(map.getCenter()));
  $('open-3d-button').addEventListener('click', () => void open3D(map.getCenter()));
  $('open-street-button').addEventListener('click', () => void openStreet(map.getCenter()));
  $('open-traffic-button').addEventListener('click', () => void openLicensed('traffic', map.getCenter()));
  $('place-focus-button').addEventListener('click', () => { if (!currentPlace) return; $('place-dialog').close(); onDestination(currentPlace); });
  $('place-route-button').addEventListener('click', () => { if (!currentPlace) return; $('place-dialog').close(); onDestination(currentPlace); onRoute(); });
  $('place-3d-button').addEventListener('click', () => void open3D());
  $('place-street-button').addEventListener('click', () => void openStreet());
  $('place-dialog').addEventListener('close', () => { galleryGeneration++; nearbyListOpen = false; });
  $('save-maps-config-button').addEventListener('click', () => {
    const key = $('maps-key-input').value.trim(), mapId = $('maps-id-input').value.trim();
    if (!/^[A-Za-z0-9_-]{20,100}$/.test(key)) { $('maps-config-status').textContent = 'Masukkan kunci browser Maps yang valid, bukan konfigurasi Firebase.'; return; }
    if (mapId && !/^[A-Za-z0-9_-]{8,100}$/.test(mapId)) { $('maps-config-status').textContent = 'Map ID belum valid.'; return; }
    applyMapsConfig({ ...mapsConfig, googleMapsApiKey: key, googleMapsMapId: mapId }); localStorage.setItem('dualworld-maps-config', JSON.stringify(mapsConfig));
    $('maps-key-input').value = ''; $('maps-config-dialog').close(); void openLicensed(pendingLicensedMode || 'map', pendingLicensedPoint || readPoint());
  });
  $('save-street-config-button').addEventListener('click', () => {
    const token = $('street-token-input').value.trim();
    if (!/^MLY\|[A-Za-z0-9_|.-]{20,2000}$/.test(token)) { $('street-config-status').textContent = 'Masukkan Client Access Token Mapillary yang diawali MLY|, bukan token akun pribadi atau konfigurasi Firebase.'; return; }
    applyMapsConfig({ ...mapsConfig, mapillaryClientToken: token }); localStorage.setItem('dualworld-maps-config', JSON.stringify(mapsConfig));
    $('street-token-input').value = ''; $('street-config-dialog').close(); void openStreet(pendingStreetPoint || map.getCenter());
  });
  map.on('movestart', () => { moving = true; clearTimeout(detailTimer); });
  map.on('moveend', () => {
    moving = false; drawDetails();
    clearTimeout(detailTimer); detailTimer = setTimeout(() => void refreshDetails(), 900);
    if (enabled.air) { clearTimeout(map._dualworldAirTimer); map._dualworldAirTimer = setTimeout(() => void refreshAir(), 1500); }
    if (enabled.wildfires) { clearTimeout(map._dualworldFireTimer); map._dualworldFireTimer = setTimeout(() => void refreshFires(), 1500); }
  });
  updateDetailButtons(); mapsConfigLoading = loadMapsConfig();
  if (enabled.air) void refreshAir(); if (enabled.wildfires) void refreshFires();
  return {
    baseMapChanged: type => { enabled.roads = type !== 'streets'; persistDetails(); drawDetails(); void refreshDetails(); },
    openLayers: () => $('layers-dialog').showModal(), openPlace, open3D, openLicensed, openStreet,
    explorePoint: point => { map.setView([point.lat, point.lng], Math.max(17, map.getZoom())); enabled.buildings = true; persistDetails(); void refreshDetails(); void openPlace({ ...point, name: 'Bangunan & foto sekitar', tags: {} }, true); },
    syncLocations: () => { threeD?.syncLocations(); licensed?.syncLocations(); },
    handleBack: () => { const active = document.activeElement?.closest('dialog'); if (active && panels.includes(active.id)) { active.close(); return true; } return false; }
  };
}
