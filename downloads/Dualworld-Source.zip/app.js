import * as L from 'leaflet';
import { coveredSatelliteLayer } from './satellite.js';
import { createMapExplorer } from './map-explorer.js';
import { publicFirebaseConfig, parseFirebaseConfigInput, readInvitation, makeInvitation } from './invitations.js';
import { MAX_SHARED_ACCURACY, LOCATION_PUBLISH_MS, isFreshLocation as isFresh, validLocation } from './location-quality.js';
import { createLocationFilter } from './location-filter.js';
import { AVATARS, avatar, profileFields } from './people.js';
import { createSocial, friendshipId } from './friendships.js';

const $ = (id) => document.getElementById(id);
const map = L.map('map', { zoomControl: false, maxZoom: 20, preferCanvas: true }).setView([-2.3, 118], 5);
map.attributionControl.setPrefix(false);
const streets = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  subdomains: 'abc', maxNativeZoom: 19, maxZoom: 20, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
});
const satellite = coveredSatelliteLayer(L, 'World_Imagery', {
  maxZoom: 20, attribution: 'Tiles &copy; Esri — Source: Esri, Maxar, Earthstar Geographics'
}, z => {
  if (satelliteMode) {
    if (z >= 16 && z < map.getMaxZoom()) map.setMaxZoom(z);
    $('map-availability-copy').textContent = 'Batas detail citra area ini tercapai. Zoom disesuaikan agar tidak terus memperbesar piksel; peta jalan menampilkan nama jalan dengan lebih jelas.';
    $('map-availability').hidden = false;
  }
});
const labels = coveredSatelliteLayer(L, 'Reference/World_Transportation', {
  maxNativeZoom: 18, maxZoom: 20, attribution: 'Labels &copy; Esri'
});
const terrain = coveredSatelliteLayer(L, 'World_Topo_Map', {
  maxZoom: 20, attribution: 'Topography &copy; Esri, HERE, Garmin, USGS, OpenStreetMap contributors'
});
streets.addTo(map);
let satelliteMode = false;
let baseMap = 'streets';
let explorer;
let ownMarker = null;
let partnerMarker = null;
let ownAccuracyCircle = null;
let partnerAccuracyCircle = null;
let destinationMarker = null;
let routeLine = null;
let ownCoords = null;
let partnerCoords = null;
const ownFilter = createLocationFilter();
let partnerPresence = null;
let presenceTimer = null;
let selectedPlace = null;
let ownWatch = null;
let watchStartedForMap = false;
let latestPosition = null;
let ownLocationRef = null;
let pairRef = null;
let db = null;
let auth = null;
let uid = null;
let firebase = null;
let firebaseApp = null;
let connectionConfig = null;
let syncState = 'connecting';
let syncError = '';
let syncListener = null;
let loadingConnection = null;
let creatingRoom = false;
let pendingRequestWatch = false;
let isOwner = false;
let roomMemberCount = 0;
let approvedMember = false;
let memberWatchStarted = false;
let sharing = false;
let lastLocationSentAt = 0;
let locationPublishTimer = null;
let locationWrite = null;
let followingLocation = null;
const markerMotion = { own: null, partner: null };
let lastReverse = { own: null, partner: null };
let toastTimeout;
let deferredInstall;
let reverseQueue = Promise.resolve();
let lastReverseRequest = 0;
let searchGeneration = 0;
let locationDetails = { own: null, partner: null };
let inspectedLocation = 'own';
const nativeAndroid = Boolean(window.DualworldAndroid);
const nativeSharing = typeof window.DualworldAndroid?.startSharing === 'function' && typeof window.DualworldAndroid?.getLocationState === 'function';
let nativeState = null;
let startingSharing = false;
let leavingRoom = false;
let people;
let partnerAvatar = '🌸';
let requestWatchStarted = false;
const pairListeners = [];
let activePairId = localStorage.getItem('dualworld-pair') || '';
let pendingRole = localStorage.getItem('dualworld-role') || '';
let waitingInvite = false;
const inviteAtLoad = new URLSearchParams(location.search).get('invite') || (new URLSearchParams(location.search).has('pair') ? location.href : '');

const dialog = $('settings-dialog');
const confirmDialog = $('confirm-dialog');
const identityDialog = $('identity-dialog');
const routeDialog = $('route-dialog');
const locationDialog = $('location-dialog');
const meIcon = L.divIcon({ className: '', html: '<div class="dw-marker me"><span>ME</span></div>', iconSize: [42, 48], iconAnchor: [21, 43] });
const partnerIcon = L.divIcon({ className: '', html: '<div class="dw-marker partner"><span>DW</span></div>', iconSize: [42, 48], iconAnchor: [21, 43] });

function toast(message) {
  if (dialog.open) { $('pair-feedback').textContent = message; $('pair-feedback').hidden = false; }
  const el = $('toast'); el.textContent = message; el.classList.add('show');
  clearTimeout(toastTimeout); toastTimeout = setTimeout(() => el.classList.remove('show'), 3200);
}
function setStatusCardVisible(visible, persist = true) {
  const card = $('status-card'), restore = $('show-status-button');
  card.classList.toggle('is-hidden', !visible);
  card.setAttribute('aria-hidden', String(!visible));
  card.inert = !visible;
  restore.hidden = visible;
  restore.setAttribute('aria-expanded', String(visible));
  if (persist) localStorage.setItem('dualworld-status-card', visible ? 'shown' : 'hidden');
}
function syncControls() {
  $('create-room-button').disabled = creatingRoom || syncState === 'connecting';
  $('create-room-button').textContent = creatingRoom ? 'MEMBUAT UNDANGAN…' : syncState === 'connecting' ? 'MENGHUBUNGKAN…' : syncState === 'missing' ? 'SIAPKAN KONEKSI UNTUK UNDANGAN' : syncState === 'error' || syncState === 'offline' ? 'COBA KONEKSI LAGI' : activePairId && isOwner ? 'TAMPILKAN UNDANGAN' : 'BUAT TAUTAN UNDANGAN';
  const invite = isOwner && activePairId && connectionConfig ? invitationValue() : '';
  $('invite-input').value = invite;
  $('invite-box').hidden = !invite;
  $('copy-invite-button').disabled = !invite;
  $('share-invite-button').disabled = !invite;
}
function setupRequired(message = syncError || 'Koneksi dua perangkat belum disiapkan. Masukkan konfigurasi proyek satu kali; undangan akan membawa koneksi yang sama ke HP pasangan.') {
  toast(message);
  document.querySelector('.sync-config').open = true;
  $('backend-note').hidden = false;
  $('backend-note').textContent = message;
  $('backend-note').scrollIntoView({ behavior: 'smooth', block: 'center' });
}
async function timed(promise, ms = 15000) {
  let timer;
  try { return await Promise.race([promise, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('Koneksi terlalu lama merespons. Periksa internet dan coba lagi.')), ms); })]); }
  finally { clearTimeout(timer); }
}
function connectionError(error) {
  const code = error.code || '';
  if (code.includes('operation-not-allowed') || code.includes('admin-restricted')) return 'Aktifkan metode masuk Anonymous pada Authentication proyek Firebase ini.';
  if (code.includes('configuration-not-found')) return 'Aktifkan Authentication dan metode masuk Anonymous pada proyek Firebase ini.';
  if (code.includes('api-key') || code.includes('project-not-found')) return 'Konfigurasi proyek belum benar. Periksa konfigurasi aplikasi Web Firebase.';
  if (/permission.denied/i.test(code + error.message)) return 'Akses database ditolak. Pasang aturan database.rules.json Dualworld pada Realtime Database proyek ini.';
  if (code.includes('network')) return 'Server tidak dapat dihubungi. Periksa internet kedua HP.';
  return error.message?.startsWith('Koneksi terlalu') ? error.message : 'Koneksi belum berhasil. Periksa internet, databaseURL, dan pengaturan proyek.';
}
function roleName(role = localStorage.getItem('dualworld-role')) {
  return role === 'adelle' ? 'Adelle' : role === 'dill' ? 'Dill' : 'Saya';
}
function profileName() { return localStorage.getItem('dualworld-name') || roleName(); }
function chooseRole(role) {
  pendingRole = role;
  document.querySelectorAll('.identity-choice').forEach(button => {
    const active = button.dataset.role === role;
    button.classList.toggle('selected', active);
    button.setAttribute('aria-pressed', String(active));
  });
  $('enter-app-button').disabled = !role;
}
function showProfileEditor() {
  $('profile-name').value = localStorage.getItem('dualworld-name') || (pendingRole ? roleName(pendingRole) : '');
  $('profile-gender').value = localStorage.getItem('dualworld-gender') || '';
  $('profile-discoverable').checked = localStorage.getItem('dualworld-discoverable') !== 'false';
  $('profile-location-consent').checked = localStorage.getItem('dualworld-sharing-consent') !== 'paused';
  for (const button of document.querySelectorAll('[data-avatar]')) button.setAttribute('aria-pressed', String(button.dataset.avatar === avatar()));
  $('enter-app-button').disabled = $('profile-name').value.trim().length < 2;
  identityDialog.showModal();
}
async function enterAsRole() {
  const name = $('profile-name').value.trim().slice(0, 32); if (name.length < 2) return;
  pendingRole = 'profile'; localStorage.setItem('dualworld-role', 'profile');
  localStorage.setItem('dualworld-name', name); localStorage.setItem('dualworld-profile-complete', 'yes');
  localStorage.setItem('dualworld-gender', $('profile-gender').value);
  localStorage.setItem('dualworld-discoverable', String($('profile-discoverable').checked));
  localStorage.setItem('dualworld-sharing-consent', $('profile-location-consent').checked ? 'yes' : 'paused');
  $('my-name').textContent = profileName();
  $('nickname-input').value = profileName();
  $('current-role-label').textContent = profileName();
  document.querySelector('#me-card .avatar').textContent = avatar();
  if (ownCoords) setMarker('own', ownCoords, name);
  identityDialog.close();
  void people?.save();
  if (uid && activePairId && pairRef) await firebase.set(firebase.ref(db, `pairs/${activePairId}/profiles/${uid}`), profileFields(profileName())).catch(() => {});
  if (!$('profile-location-consent').checked) await people?.stopAll();
  if ($('profile-location-consent').checked) {
    if (window.DualworldAndroid?.preparePermissions) { setFollowing('own'); window.DualworldAndroid.preparePermissions(); }
    else locateMe();

  }
  if (waitingInvite) { waitingInvite = false; dialog.showModal(); toast('Undangan siap. Tekan Minta akses untuk bergabung.'); }
}
function setConnection(text, state = '') {
  const pill = $('connection-pill'); pill.className = `connection-pill ${state}`; pill.querySelector('span').textContent = text;
}
function distanceMeters(a, b) {
  const rad = v => v * Math.PI / 180;
  const dLat = rad(b.lat - a.lat), dLon = rad(b.lng - a.lng);
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLon / 2) ** 2;
  return 6371000 * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}
function distanceText(m) { return m >= 1000 ? `${(m / 1000).toFixed(1)} km terpisah` : `${Math.round(m)} m terpisah`; }
function setMarker(which, coords, name) {
  const marker = which === 'own' ? ownMarker : partnerMarker;
  const face = which === 'own' ? avatar() : partnerAvatar;
  const icon = !marker || marker.options.face !== face ? L.divIcon({ className: '', html: `<div class="dw-marker ${which === 'own' ? 'me' : 'partner'}"><span>${escapeHtml(face)}</span></div>`, iconSize: [42, 48], iconAnchor: [21, 43] }) : marker.options.icon;
  let circle = which === 'own' ? ownAccuracyCircle : partnerAccuracyCircle;
  cancelAnimationFrame(markerMotion[which]); markerMotion[which] = null;
  if (!coords) {
    if (marker) map.removeLayer(marker);
    if (circle) map.removeLayer(circle);
    if (which === 'own') ownAccuracyCircle = null; else partnerAccuracyCircle = null;
    if (which === 'own') ownMarker = null; else partnerMarker = null;
    return;
  }
  const point = [coords.lat, coords.lng];
  const accuracy = Number.isFinite(coords.accuracy) ? Math.max(1, Math.min(coords.accuracy, 10000)) : 100;
  if (circle) circle.setRadius(accuracy);
  else circle = L.circle(point, { radius: accuracy, color: which === 'own' ? '#bcf27c' : '#77ddd1', weight: 1, fillOpacity: .08, interactive: false }).addTo(map);
  if (which === 'own') ownAccuracyCircle = circle; else partnerAccuracyCircle = circle;
  const next = marker || L.marker(point, { icon, keyboard: true, title: name }).addTo(map);
  if (marker && marker.options.face !== face) next.setIcon(icon);
  next.options.face = face;
  const from = marker?.getLatLng();
  // Interpolate only between actual fresh measurements, never predict movement.
  if (from && isFresh(coords) && distanceMeters({ lat: from.lat, lng: from.lng }, coords) > .3 && distanceMeters({ lat: from.lat, lng: from.lng }, coords) < 250 && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const start = performance.now();
    const move = now => {
      const fraction = Math.min(1, (now - start) / 650);
      const frame = [from.lat + (coords.lat - from.lat) * fraction, from.lng + (coords.lng - from.lng) * fraction];
      next.setLatLng(frame); circle.setLatLng(frame);
      markerMotion[which] = fraction < 1 ? requestAnimationFrame(move) : null;
    };
    markerMotion[which] = requestAnimationFrame(move);
  } else { next.setLatLng(point); circle.setLatLng(point); }
  next.bindPopup(`<strong>${escapeHtml(name)}</strong><br>${coords.lat.toFixed(5)}, ${coords.lng.toFixed(5)}<br>${coords.accuracy ? `Akurasi ±${Math.round(coords.accuracy)} m` : 'Lokasi dibagikan'}`);
  if (!marker) next.on('click', () => inspectLocation(which));
  if (which === 'own') ownMarker = next; else partnerMarker = next;
}
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }
function updateDistance() {
  if (ownCoords && partnerCoords) {
    const meters = distanceMeters(ownCoords, partnerCoords);
    const last = isFresh(ownCoords) && isFresh(partnerCoords) ? '' : isPartnerOnline() ? 'GPS terakhir · ' : 'Terakhir: ';
    $('distance-label').textContent = ownCoords.accuracy > MAX_SHARED_ACCURACY || partnerCoords.accuracy > MAX_SHARED_ACCURACY ? 'Sinyal GPS belum cukup baik' : meters <= ownCoords.accuracy + partnerCoords.accuracy ? `${last}Dekat · dalam rentang akurasi GPS` : `${last}${distanceText(meters)}`;
  } else {
    $('distance-label').textContent = ownCoords ? 'Posisi Anda tampil di peta' : partnerCoords ? 'Aktifkan GPS untuk melihat jarak' : 'Aktifkan GPS untuk melihat jarak';
  }
  $('route-button').disabled = !ownCoords || !(selectedPlace || partnerCoords);
  $('focus-partner-button').disabled = !partnerCoords;
}
function ageText(coords) {
  if (!coords?.updatedAt) return 'Waktu belum tersedia';
  if (coords.updatedAt - Date.now() > 5000) return 'Waktu HP berbeda';
  const seconds = Math.max(0, Math.floor((Date.now() - coords.updatedAt) / 1000));
  return seconds < 15 ? 'baru saja' : seconds < 60 ? `${seconds} dtk lalu` : seconds < 3600 ? `${Math.floor(seconds / 60)} mnt lalu` : seconds < 86400 ? `${Math.floor(seconds / 3600)} jam lalu` : `${Math.floor(seconds / 86400)} hari lalu`;
}
function updateLocationFreshness() {
  for (const kind of ['own', 'partner']) {
    const coords = kind === 'own' ? ownCoords : partnerCoords;
    const meta = $(kind === 'own' ? 'my-location-meta' : 'partner-location-meta');
    if (meta) {
      const waiting = kind === 'partner' && isPartnerOnline() && !isFresh(coords);
      meta.textContent = coords ? `${waiting ? 'Online · GPS ' : isFresh(coords) ? '' : 'Terakhir · '}±${Math.round(coords.accuracy || 0)} m · ${ageText(coords)}` : kind === 'own' ? 'Menunggu GPS' : isPartnerOnline() ? 'Online · mencari GPS' : 'Belum ada lokasi';
      meta.classList.toggle('location-stale', Boolean(coords && !isFresh(coords)));
    }
    const marker = kind === 'own' ? ownMarker : partnerMarker;
    marker?.getElement()?.classList.toggle('location-stale-pin', Boolean(coords && !isFresh(coords)));
  }
  const livePartner = Boolean(isPartnerOnline() || (isFresh(partnerCoords) && partnerCoords.accuracy <= MAX_SHARED_ACCURACY));
  $('partner-dot').classList.toggle('online', livePartner);
  $('partner-dot').classList.toggle('muted', !livePartner);
  $('my-dot').classList.toggle('online', Boolean(sharing && isFresh(ownCoords) && ownCoords.accuracy <= MAX_SHARED_ACCURACY));
  updateDistance();
  explorer?.syncLocations();
  if (locationDialog.open) updateLocationDetails();
}
function lookupPlace(url) {
  const request = reverseQueue.then(async () => {
    const wait = Math.max(0, 1100 - (Date.now() - lastReverseRequest));
    if (wait) await new Promise(resolve => setTimeout(resolve, wait));
    lastReverseRequest = Date.now();
    const response = await fetch(url, { headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error('Place lookup unavailable');
    return response.json();
  });
  reverseQueue = request.catch(() => {});
  return request;
}
function reversePlace(coords, kind) {
  const previous = lastReverse[kind];
  if (previous && distanceMeters(previous, coords) < 80 && Date.now() - previous.at < 120000) return Promise.resolve();
  lastReverse[kind] = { ...coords, at: Date.now() };
  const friendAtRequest=kind==='partner'?displayedFriend:null;
  const url = new URL('https://nominatim.openstreetmap.org/reverse');
  url.search = new URLSearchParams({ format: 'jsonv2', lat: coords.lat, lon: coords.lng, zoom: '18', addressdetails: '1', extratags: '1' });
  return lookupPlace(url).then(data => {
    const current = kind === 'own' ? ownCoords : partnerCoords;
    if (!current || distanceMeters(current, coords) > 100 || kind==='partner'&&friendAtRequest!==displayedFriend) return;
    locationDetails[kind] = data;
    const address = data.address || {};
    const label = data.name || address.amenity || address.shop || address.tourism || address.leisure || address.building || address.road || data.display_name?.split(',').slice(0, 2).join(',');
    if (label) (kind === 'own' ? $('my-place') : $('partner-place')).textContent = label;
    if (locationDialog.open && inspectedLocation === kind) updateLocationDetails();
  }).catch(() => { /* The live coordinates remain available if place lookup is offline. */ });
}
function onOwnPosition(position) {
  const measuredAt = position.timestamp || Date.now();
  let next = { lat: position.coords?.latitude, lng: position.coords?.longitude, accuracy: position.coords?.accuracy, updatedAt: measuredAt };
  if (!validLocation(next)) return;
  if (measuredAt - Date.now() > 5000) { $('share-status').textContent = 'Periksa tanggal dan waktu HP'; return; }
  if (ownCoords?.updatedAt > measuredAt) return;
  if (next.accuracy > MAX_SHARED_ACCURACY && ownCoords?.accuracy <= MAX_SHARED_ACCURACY && (sharing || isFresh(ownCoords))) {
    $('share-status').textContent = sharing ? 'Menunggu GPS lebih baik' : 'Menunggu GPS · memakai posisi terakhir';
    return;
  }
  latestPosition = position;
  if (!nativeSharing && next.accuracy <= MAX_SHARED_ACCURACY && isFresh(next)) {
    next = ownFilter.accept(next, position.coords?.speed) || ownCoords || next;
  }
  const firstFix = !ownCoords;
  ownCoords = next;
  setMarker('own', ownCoords, $('my-name').textContent);
  $('accuracy-label').textContent = `±${Math.round(ownCoords.accuracy)} M`;
  $('share-status').textContent = sharing ? ownCoords.accuracy > MAX_SHARED_ACCURACY || !isFresh(ownCoords) ? 'Menunggu GPS lebih baik' : 'Lokasi diperbarui' : 'GPS aktif di HP ini'; $('live-indicator').classList.toggle('on', sharing);
  if (!partnerCoords && firstFix) map.setView([ownCoords.lat, ownCoords.lng], 16, { animate: true });
  followLocation('own', ownCoords);
  updateDistance(); void reversePlace(ownCoords, 'own');
  updateLocationFreshness();
  if (locationDialog.open && inspectedLocation === 'own') updateLocationDetails();
  if (sharing) publishOwnPosition();
}
function isPartnerOnline() {
  return Boolean(partnerPresence?.sharing && Number.isFinite(partnerPresence.lastSeen) && Date.now() - partnerPresence.lastSeen >= -5000 && Date.now() - partnerPresence.lastSeen < 60000);
}
function publishPresence() {
  if (nativeSharing || !sharing || !firebase || !db || !uid || !approvedMember) return;
  firebase.set(firebase.ref(db, `pairs/${activePairId}/presence/${uid}`), { sharing: true, phase: isFresh(ownCoords) ? 'active' : 'searching', lastSeen: firebase.serverTimestamp() }).catch(() => {});
}
function publishOwnPosition() {
  if (nativeSharing || !sharing || !db || !ownLocationRef || !ownCoords || ownCoords.accuracy > MAX_SHARED_ACCURACY || !isFresh(ownCoords)) return;
  if (locationWrite) return;
  const wait = LOCATION_PUBLISH_MS - (Date.now() - lastLocationSentAt);
  if (wait > 0) {
    if (locationPublishTimer === null) locationPublishTimer = setTimeout(() => { locationPublishTimer = null; publishOwnPosition(); }, wait);
    return;
  }
  clearTimeout(locationPublishTimer); locationPublishTimer = null;
  lastLocationSentAt = Date.now();
  const sent = { ...ownCoords, accuracy: Math.ceil(ownCoords.accuracy) };
  locationWrite = firebase.set(ownLocationRef, sent)
    .catch(() => toast('Lokasi belum dapat dikirim. Periksa koneksi.'))
    .finally(() => { locationWrite = null; if (sharing && ownCoords?.updatedAt > sent.updatedAt) publishOwnPosition(); });
}
function locationError(error) {
  const messages = { 1: 'Izin lokasi ditolak. Aktifkan melalui pengaturan aplikasi/browser.', 2: 'GPS belum mendapat sinyal lokasi. Posisi terakhir tetap ditampilkan.', 3: 'Menunggu sinyal GPS. Coba dekat jendela atau di luar rumah.' };
  toast(messages[error.code] || 'Lokasi belum dapat dibaca.');
  if (error.code === 1) {
    if (ownWatch !== null) navigator.geolocation.clearWatch(ownWatch);
    ownWatch = null; watchStartedForMap = false;
  }
  if (!sharing) $('share-status').textContent = 'Lokasi belum dibagikan';
  if (sharing) $('share-status').textContent = 'Mencari lokasi…';
}
async function startSharing(ask = true) {
  if (sharing || startingSharing) return;
  if (!nativeSharing && !navigator.geolocation) { toast('Browser ini tidak mendukung GPS.'); return; }
  if (!pairRef || !uid || !approvedMember) { dialog.showModal(); toast('Buat ruang atau tunggu persetujuan pasangan sebelum berbagi.'); return; }
  if (ask) {
    const ok = await askConfirmation('Bagikan lokasi?', nativeSharing ? 'Teman yang kamu pilih dapat melihat posisimu. Berbagi tetap berjalan saat layar terkunci. Berhenti kapan saja dengan tombol di bawah peta.' : 'Teman yang kamu pilih dapat melihat posisimu selama halaman ini terbuka. Berhenti berbagi kapan saja.', 'Bagikan lokasi');
    if (!ok) return;
  }
  localStorage.setItem('dualworld-sharing-consent', 'yes');
  if (nativeSharing) {
    startingSharing = true; $('share-button').disabled = true;
    try {
      const idToken = await auth.currentUser.getIdToken();
      window.DualworldAndroid.startSharing(JSON.stringify({ apiKey: connectionConfig.apiKey, databaseURL: connectionConfig.databaseURL, pairId: activePairId, uid, idToken, refreshToken: auth.currentUser.refreshToken }));
      $('share-status').textContent = 'Izinkan lokasi akurat…';
    } catch { startingSharing = false; $('share-button').disabled = false; toast('Sesi lokasi belum dapat dimulai. Periksa koneksi.'); }
    return;
  }
  sharing = true; localStorage.setItem('dualworld-sharing-pair', activePairId); updateSharingControls();
  clearInterval(presenceTimer); publishPresence(); presenceTimer = setInterval(publishPresence, 20000);
  $('share-status').textContent = 'Menyalakan GPS…'; $('live-indicator').classList.add('on');
  ownLocationRef = firebase.ref(db, `pairs/${activePairId}/locations/${uid}`);
  try { await firebase.onDisconnect(ownLocationRef).cancel(); } catch { /* Last position is retained; explicit stop deletes it. */ }
  if (ownWatch === null) {
    watchStartedForMap = false;
    ownWatch = navigator.geolocation.watchPosition(onOwnPosition, locationError, { enableHighAccuracy: true, maximumAge: 0, timeout: 30000 });
  }
  publishOwnPosition();
}
async function stopSharing(ask = true) {
  if (!sharing && !startingSharing && !nativeState?.enabled) return;
  if (ask && !(await askConfirmation('Matikan berbagi?', 'Lokasi Anda akan dihapus dari ruang pasangan.', 'MATIKAN LOKASI'))) return;
  if (nativeSharing) window.DualworldAndroid.stopSharing();
  if (ownWatch !== null && !watchStartedForMap) { navigator.geolocation.clearWatch(ownWatch); ownWatch = null; }
  sharing = false;
  localStorage.setItem('dualworld-sharing-consent', 'paused');
  clearInterval(presenceTimer); presenceTimer = null;
  clearTimeout(locationPublishTimer); locationPublishTimer = null;
  startingSharing = false; localStorage.removeItem('dualworld-sharing-pair'); updateSharingControls();
  $('share-status').textContent = ownCoords ? 'GPS aktif di HP ini' : 'Lokasi belum dibagikan'; $('live-indicator').classList.remove('on'); $('my-dot').classList.remove('online');
  if (locationWrite) await locationWrite;
  if (db && ownLocationRef) await firebase.remove(ownLocationRef).catch(() => {});
  if (db && uid && activePairId) await firebase.remove(firebase.ref(db, `pairs/${activePairId}/presence/${uid}`)).catch(() => {});
  ownLocationRef = null;
  updateDistance();
}
function updateSharingControls() {
  $('share-button').disabled = startingSharing;
  $('share-button').classList.toggle('sharing', sharing);
  $('share-button').innerHTML = sharing ? '<span class="share-button-icon">■</span><span>Berhenti berbagi</span>' : '<span class="share-button-icon">◉</span><span>Bagikan lokasi</span>';
}
function readNativeState() {
  if (!nativeSharing) return;
  try { receiveNativeState(JSON.parse(window.DualworldAndroid.getLocationState())); } catch { /* Next service broadcast supplies the state. */ }
}
function receiveNativeState(state) {
  if (!state || typeof state.enabled !== 'boolean') return;
  const previouslyEnabled=nativeState?.enabled;nativeState = state;
  if(previouslyEnabled&&!state.enabled&&state.phase==='stopped'&&uid&&approvedMember)void people?.stopAll().catch(()=>{});
  // A stored session belongs only to its original authenticated room.
  const matches = state.pairId === activePairId && (!uid || uid === state.uid) && (!connectionConfig || connectionConfig.databaseURL.replace(/\/$/, '') === state.databaseURL);
  if (state.enabled && !matches) { window.DualworldAndroid.stopSharing(); return; }
  sharing = Boolean(state.enabled && matches);
  startingSharing = false; updateSharingControls();
  if (state.position && (matches || !state.enabled)) onOwnPosition({ coords: { latitude: state.position.lat, longitude: state.position.lng, accuracy: state.position.accuracy }, timestamp: state.position.updatedAt });
  if (sharing) {
    const messages = { searching: 'Mencari lokasi…', inaccurate: 'Menunggu GPS lebih baik', offline: 'Menunggu internet', gps_off: 'Nyalakan lokasi HP', permission: 'Izinkan lokasi akurat', resume_required: 'Buka pengaturan lokasi', active: 'Lokasi sedang dibagikan' };
    $('share-status').textContent = messages[state.phase] || 'Lokasi sedang dibagikan';
  } else if (state.deletePending) $('share-status').textContent = state.phase === 'delete_denied' ? 'Lokasi belum terhapus dari server' : 'Menunggu koneksi untuk menghapus lokasi';
  else $('share-status').textContent = ownCoords ? 'GPS aktif di HP ini' : 'Lokasi belum dibagikan';
  $('live-indicator').classList.toggle('on', sharing);
  const note = $('background-status');
  if (note) note.textContent = !state.precisePermission ? 'Izinkan Lokasi akurat agar posisi tidak meleset jauh.' : state.backgroundPermission ? 'Izin latar aktif. Berbagi dapat dilanjutkan setelah HP dinyalakan kembali.' : 'Layar terkunci dan menutup aplikasi tetap didukung. Untuk lanjut otomatis setelah HP dinyalakan, pilih Izin → Lokasi → Izinkan sepanjang waktu.';
  if (note && !state.notificationsEnabled) note.textContent += ' Aktifkan notifikasi agar status dan tombol berhenti terlihat.';
  if (note && state.phase === 'delete_denied') note.textContent = 'Berbagi sudah berhenti, tetapi server menolak penghapusan posisi terakhir. Putuskan ruang bersama saat internet terhubung; minta pembuat ruang menghapus ruang jika akses Anda sudah dicabut.';
  updateLocationFreshness();
}
window.dualworldNativeLocation = receiveNativeState;
window.dualworldNativeError = message => { startingSharing = false; updateSharingControls(); readNativeState(); toast(message); };
function locateMe() {
  if (!nativeSharing && !navigator.geolocation) { toast('Browser ini tidak mendukung GPS.'); return; }
  setFollowing('own');
  if (ownCoords) { map.flyTo([ownCoords.lat, ownCoords.lng], 18); ownMarker?.openPopup(); }
  if (nativeSharing) { $('share-status').textContent = sharing ? 'Memperbarui lokasi…' : 'Mencari lokasi…'; window.DualworldAndroid.watchLocation(); return; }
  if (ownWatch === null) {
    $('share-status').textContent = sharing ? 'Menyalakan GPS…' : 'Mencari lokasi…';
    watchStartedForMap = !sharing;
    ownWatch = navigator.geolocation.watchPosition(onOwnPosition, locationError, { enableHighAccuracy: true, maximumAge: 0, timeout: 30000 });
  }
}
function askConfirmation(title, copy, confirmLabel) {
  $('confirm-title').textContent = title; $('confirm-copy').textContent = copy; $('confirm-ok').textContent = confirmLabel;
  confirmDialog.showModal();
  return new Promise(resolve => {
    let settled = false;
    const done = value => { if (settled) return; settled = true; $('confirm-ok').removeEventListener('click', yes); $('confirm-cancel').removeEventListener('click', no); confirmDialog.removeEventListener('cancel', cancel); confirmDialog.removeEventListener('close', cancel); confirmDialog.close(); resolve(value); };
    const yes = event => { event.preventDefault(); done(true); }, no = event => { event.preventDefault(); done(false); }, cancel = () => done(false);
    $('confirm-ok').addEventListener('click', yes); $('confirm-cancel').addEventListener('click', no); confirmDialog.addEventListener('cancel', cancel, { once: true }); confirmDialog.addEventListener('close', cancel, { once: true });
  });
}
function showPartnerLocation(data) {
  if (validLocation(data) && partnerCoords?.updatedAt > data.updatedAt) return;
  partnerCoords = validLocation(data) ? { lat: data.lat, lng: data.lng, accuracy: data.accuracy, updatedAt: data.updatedAt } : null;
  setMarker('partner', partnerCoords, $('partner-name').textContent);
  if (!partnerCoords) { locationDetails.partner = null; lastReverse.partner = null; $('partner-place').textContent = 'Tidak sedang berbagi'; }
  else if (!locationDetails.partner) $('partner-place').textContent = 'Mencari nama tempat…';
  if (partnerCoords) { updateDistance(); void reversePlace(partnerCoords, 'partner'); followLocation('partner', partnerCoords); if (!ownCoords) map.setView([partnerCoords.lat, partnerCoords.lng], 16, { animate: true }); }
  else updateDistance();
  updateLocationFreshness();
  if (locationDialog.open && inspectedLocation === 'partner') updateLocationDetails();
}
function updateLocationDetails() {
  const own = inspectedLocation === 'own';
  const coords = own ? ownCoords : partnerCoords;
  const data = locationDetails[inspectedLocation];
  const address = data?.address || {};
  $('location-title').textContent = own ? profileName() : $('partner-name').textContent;
  $('location-address').textContent = coords ? data?.display_name || 'Mencari nama jalan dan tempat…' : 'Tidak sedang membagikan lokasi.';
  $('location-road').textContent = address.road || address.pedestrian || address.footway || 'Belum tersedia';
  $('location-area').textContent = [address.city || address.town || address.village || address.county, address.state].filter(Boolean).join(', ') || 'Belum tersedia';
  $('location-coordinates').textContent = coords ? `${coords.lat.toFixed(6)}, ${coords.lng.toFixed(6)}` : '—';
  $('location-accuracy').textContent = coords ? `±${Math.round(coords.accuracy || 0)} m` : '—';
  $('location-time').textContent = coords?.updatedAt ? `${isFresh(coords) ? 'Diperbarui' : 'Posisi terakhir'} ${new Date(coords.updatedAt).toLocaleString('id-ID')} · ${ageText(coords)} · ${own && !sharing ? 'GPS pribadi di perangkat ini' : isFresh(coords) ? 'Bacaan GPS terbaru' : 'Belum ada pembaruan; HP bisa offline, mati, atau GPS belum mendapat sinyal.'}` : '—';
  $('location-focus-button').disabled = !coords;
  $('location-route-button').hidden = own;
  $('location-route-button').disabled = !coords || !ownCoords;
  $('location-explore-button').disabled = !coords;
  $('location-street-button').disabled = !coords;
}
function inspectLocation(kind) {
  const coords = kind === 'own' ? ownCoords : partnerCoords;
  if (!coords) { kind === 'own' ? locateMe() : toast('Teman ini belum membagikan lokasi.'); return; }
  inspectedLocation = kind; updateLocationDetails();
  map.flyTo([coords.lat, coords.lng], 18);
  locationDialog.showModal();
}
function setSearchDestination(place) {
  setFollowing(null);
  const address = place.display_name || place.name || 'Titik di peta';
  selectedPlace = { lat: Number(place.lat), lng: Number(place.lon), name: place.name || address.split(',')[0], address, tags: place.extratags || {} };
  if (destinationMarker) map.removeLayer(destinationMarker);
  const icon = L.divIcon({ className: '', html: '<div class="destination-marker"></div>', iconSize: [20, 20], iconAnchor: [10, 10] });
  destinationMarker = L.marker([selectedPlace.lat, selectedPlace.lng], { icon, title: address }).addTo(map);
  const destination = { ...selectedPlace };
  destinationMarker.on('click', () => void explorer?.openPlace(destination));
  destinationMarker.bindPopup(`<strong>${escapeHtml(selectedPlace.name)}</strong><br>${escapeHtml(address)}`).openPopup();
  $('place-query').value = address.split(',').slice(0, 2).join(',');
  $('search-results').replaceChildren(); $('search-results').hidden = true;
  map.flyTo([selectedPlace.lat, selectedPlace.lng], 17);
  updateDistance();
}
async function searchPlaces() {
  const query = $('place-query').value.trim();
  if (query.length < 3) { toast('Ketik minimal tiga huruf untuk mencari.'); return; }
  const generation = ++searchGeneration;
  const results = $('search-results'); results.replaceChildren(); results.hidden = false;
  const loading = document.createElement('div'); loading.className = 'search-message'; loading.textContent = 'MENCARI TEMPAT…'; results.append(loading);
  try {
    const url = new URL('https://nominatim.openstreetmap.org/search');
    url.search = new URLSearchParams({ q: query, format: 'jsonv2', addressdetails: '1', extratags: '1', limit: '6' });
    const places = await lookupPlace(url);
    if (generation !== searchGeneration) return;
    results.replaceChildren();
    if (!places.length) { loading.textContent = 'TEMPAT TIDAK DITEMUKAN'; results.append(loading); return; }
    for (const place of places) {
      const option = document.createElement('button'); option.className = 'search-result'; option.setAttribute('role', 'option');
      const title = document.createElement('strong'); title.textContent = place.name || place.display_name.split(',')[0];
      const detail = document.createElement('small'); detail.textContent = place.display_name;
      option.append(title, detail); option.addEventListener('click', () => setSearchDestination(place)); results.append(option);
    }
  } catch { if (generation !== searchGeneration) return; results.replaceChildren(); const error = document.createElement('div'); error.className = 'search-message'; error.textContent = 'Pencarian tidak tersedia. Periksa koneksi.'; results.append(error); }
}
function routeDistance(meters) { return meters >= 1000 ? `${(meters / 1000).toFixed(1)} km` : `${Math.round(meters)} m`; }
function routeDuration(seconds) {
  const minutes = Math.max(1, Math.round(seconds / 60));
  return minutes >= 60 ? `${Math.floor(minutes / 60)} j ${minutes % 60} mnt` : `${minutes} mnt`;
}
function describeStep(step, index, total) {
  const maneuver = step.maneuver || {};
  const names = { depart: 'Mulai perjalanan', arrive: 'Tiba di tujuan', turn: 'Belok', 'new name': 'Lanjutkan', merge: 'Bergabung', fork: 'Ambil cabang', roundabout: 'Masuk bundaran', rotary: 'Masuk bundaran', 'exit roundabout': 'Keluar bundaran', continue: 'Lanjutkan', 'end of road': 'Ikuti jalan' };
  let text = names[maneuver.type] || 'Lanjutkan';
  const modifiers = { left: 'kiri', right: 'kanan', 'slight left': 'sedikit ke kiri', 'slight right': 'sedikit ke kanan', 'sharp left': 'tajam ke kiri', 'sharp right': 'tajam ke kanan', straight: 'lurus', uturn: 'putar balik' };
  if (maneuver.modifier) text += ` ${modifiers[maneuver.modifier] || maneuver.modifier.replaceAll('_', ' ')}`;
  if (step.name) text += ` ke ${step.name}`;
  if (!step.name && index < total - 1) text += ' di jalan';
  return `${text} · ${routeDistance(step.distance)}`;
}
async function showRoute() {
  const destination = selectedPlace || partnerCoords;
  if (!destination) { toast('Cari tujuan atau tunggu lokasi pasangan.'); return; }
  if (!ownCoords) { toast('Tekan tombol lokasi untuk mendapatkan GPS sebelum membuat rute.'); return; }
  setFollowing(null);
  $('route-title').textContent = `Rute ke ${destination.name || $('partner-name').textContent}`;
  $('route-distance').textContent = '…'; $('route-duration').textContent = '…';
  $('route-steps').replaceChildren(); const loading = document.createElement('li'); loading.textContent = 'Menghitung rute di peta…'; $('route-steps').append(loading);
  routeDialog.showModal();
  try {
    const path = `${ownCoords.lng},${ownCoords.lat};${destination.lng},${destination.lat}`;
    const url = new URL(`https://router.project-osrm.org/route/v1/driving/${path}`);
    url.search = new URLSearchParams({ overview: 'full', geometries: 'geojson', steps: 'true' });
    const response = await fetch(url, { headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error('Routing service unavailable');
    const data = await response.json();
    if (data.code !== 'Ok' || !data.routes?.length) throw new Error('No route');
    const route = data.routes[0];
    if (routeLine) map.removeLayer(routeLine);
    routeLine = L.geoJSON(route.geometry, { style: { color: '#bcf27c', weight: 5, opacity: .9, lineCap: 'round', lineJoin: 'round' } }).addTo(map);
    map.fitBounds(routeLine.getBounds(), { paddingTopLeft: [36, 150], paddingBottomRight: [36, 240], maxZoom: 17, animate: true });
    $('route-distance').textContent = routeDistance(route.distance); $('route-duration').textContent = routeDuration(route.duration);
    const steps = route.legs?.flatMap(leg => leg.steps || []) || [];
    $('route-steps').replaceChildren();
    for (let i = 0; i < steps.length; i++) { const item = document.createElement('li'); item.textContent = describeStep(steps[i], i, steps.length); $('route-steps').append(item); }
    if (!steps.length) { const item = document.createElement('li'); item.textContent = 'Rute tampil pada peta.'; $('route-steps').append(item); }
  } catch {
    $('route-distance').textContent = '—'; $('route-duration').textContent = '—';
    $('route-steps').replaceChildren(); const error = document.createElement('li'); error.textContent = 'Rute belum tersedia dari layanan saat ini. Coba lagi nanti.'; $('route-steps').append(error);
  }
}
function setFollowing(kind) {
  followingLocation = kind;
  $('locate-button').setAttribute('aria-pressed', String(kind === 'own'));
  $('locate-button').title = kind === 'own' ? 'Mengikuti posisi saya · geser peta untuk berhenti' : 'Ikuti lokasi saya';
  $('focus-partner-button').setAttribute('aria-pressed', String(kind === 'partner'));
  $('focus-partner-button').title = kind === 'partner' ? 'Mengikuti posisi teman · geser peta untuk berhenti' : 'Ikuti posisi teman';
}
function followLocation(kind, coords) {
  if (followingLocation === kind && isFresh(coords)) map.panTo([coords.lat, coords.lng], { animate: true, duration: .65 });
}
map.on('dragstart', () => setFollowing(null));
function focusPartner() {
  if (!partnerCoords) { toast('Teman ini belum membagikan lokasi.'); return; }
  selectedPlace = null;
  setFollowing('partner');
  map.flyTo([partnerCoords.lat, partnerCoords.lng], 18);
  partnerMarker?.openPopup(); updateDistance();
}
function showRequests(snapshot) {
  const section = $('request-section'), list = $('request-list'); list.replaceChildren();
  const requests = [];
  snapshot.forEach(child => requests.push({ uid: child.key, value: child.val() }));
  section.hidden = !isOwner || requests.length === 0;
  $('request-summary').textContent = requests.length ? `${requests.length} orang meminta bergabung.` : 'Tinjau siapa yang ingin terhubung.';
  for (const request of requests) {
    const row = document.createElement('div'); row.className = 'request-row';
    const label = document.createElement('span'); label.textContent = `${request.value || 'Perangkat'} · ${request.uid.slice(0, 6)}`;
    const actions = document.createElement('div'); actions.className = 'request-actions';
    const approve = document.createElement('button'); approve.className = 'secondary-button'; approve.textContent = 'TERIMA';
    approve.addEventListener('click', async () => {
      try {
        const members = await firebase.get(firebase.ref(db, `pairs/${activePairId}/members`));
        if (members.size >= 2 && !members.hasChild(request.uid)) { toast('Ruang ini sudah berisi dua orang.'); return; }
        const slot = firebase.ref(db, `pairs/${activePairId}/partnerUid`);
        const reserved = await firebase.get(slot);
        if (reserved.exists() && reserved.val() !== request.uid) { toast('Ruang ini sudah mempunyai pasangan.'); return; }
        const claim = await firebase.runTransaction(slot, value => value === null || value === request.uid ? request.uid : undefined);
        if (!claim.committed) { toast('Ruang ini sudah mempunyai pasangan.'); return; }
        await firebase.set(firebase.ref(db, `pairs/${activePairId}/members/${request.uid}`), true);
        await firebase.remove(firebase.ref(db, `pairs/${activePairId}/requests/${request.uid}`)); toast('Permintaan disetujui.');
      } catch { toast('Permintaan belum dapat disetujui.'); }
    });
    const reject = document.createElement('button'); reject.className = 'danger-button'; reject.textContent = 'TOLAK';
    reject.addEventListener('click', () => firebase.remove(firebase.ref(db, `pairs/${activePairId}/requests/${request.uid}`)).catch(() => toast('Permintaan belum dapat dihapus.')));
    actions.append(approve, reject); row.append(label, actions); list.append(row);
  }
}
function clearPairListeners() {
  for (const unsubscribe of pairListeners.splice(0)) unsubscribe();
  requestWatchStarted = false;
  roomMemberCount = 0;
  approvedMember = false;
  memberWatchStarted = false;
  pendingRequestWatch = false;
  partnerPresence = null;
}
function resetRoomLocal(message) {
  clearPairListeners(); localStorage.removeItem('dualworld-pair'); activePairId = ''; pairRef = null; isOwner = false;
  showPartnerLocation(null); $('partner-name').textContent = 'Teman'; $('partner-place').textContent = 'Belum terhubung';
  $('room-state').textContent = 'Pribadi'; $('leave-room-button').hidden = true; $('request-section').hidden = true;
  setConnection(syncState === 'ready' ? 'Online' : 'Offline', syncState === 'ready' ? 'online' : 'error');
  syncControls(); history.replaceState(null, '', location.pathname); if (message) toast(message);
}
function watchPair() {
  if (!db || !uid || !activePairId) return;
  clearPairListeners();
  pairRef = firebase.ref(db, `pairs/${activePairId}`);
  const memberRef = firebase.ref(db, `pairs/${activePairId}/members/${uid}`);
  pairListeners.push(firebase.onValue(memberRef, snapshot => {
    const wasApproved = approvedMember;
    approvedMember = snapshot.val() === true;
    if (!approvedMember) {
      if (sharing) void stopSharing(false);
      showPartnerLocation(null);
      if (wasApproved) {
        if (leavingRoom) return;
        if (nativeSharing) window.DualworldAndroid.forgetClosedRoom?.();
        resetRoomLocal('Ruang sudah ditutup. Buat atau gunakan undangan baru untuk terhubung lagi.'); return;
      }
      if (!isOwner && !pendingRequestWatch) {
        pendingRequestWatch = true;
        pairListeners.push(firebase.onValue(firebase.ref(db, `pairs/${activePairId}/requests/${uid}`), async request => {
          if (approvedMember || request.exists()) return;
          try {
            const member = await firebase.get(memberRef);
            if (!approvedMember && member.val() !== true) resetRoomLocal('Permintaan tidak aktif atau ruang sudah berakhir. Minta undangan baru.');
          } catch { /* Keep the pending room while the network is unavailable. */ }
        }));
      }
      setConnection('Menunggu izin'); $('room-state').textContent = 'Menunggu izin'; return;
    }
    if (memberWatchStarted) return;
    memberWatchStarted = true;
    firebase.set(firebase.ref(db, `pairs/${activePairId}/profiles/${uid}`), profileFields(profileName())).catch(() => {});
    localStorage.setItem('dualworld-pair', activePairId); $('room-state').textContent = 'Bersama'; setConnection('Terhubung', 'online');
    const locationsRef = firebase.ref(db, `pairs/${activePairId}/locations`);
    pairListeners.push(firebase.onValue(locationsRef, locations => {
      const partner = [];
      locations.forEach(child => { if (child.key !== uid) partner.push(child.val()); });
      showPartnerLocation(partner[0] || null);
    }, () => toast('Data lokasi tidak dapat dimuat.')));
    pairListeners.push(firebase.onValue(firebase.ref(db, `pairs/${activePairId}/presence`), presence => {
      partnerPresence = null;
      presence.forEach(child => { if (child.key !== uid) partnerPresence = child.val(); });
      updateLocationFreshness();
    }, () => { partnerPresence = null; }));
    pairListeners.push(firebase.onValue(firebase.ref(db, `pairs/${activePairId}/profiles`), profiles => {
      profiles.forEach(child => { if (child.key !== uid && child.val()?.name) {
        $('partner-name').textContent = child.val().name;
        partnerAvatar = AVATARS.includes(child.val().avatar) ? child.val().avatar : '🌸';
        document.querySelector('#partner-card .avatar').textContent = partnerAvatar;
        if (partnerCoords) setMarker('partner', partnerCoords, child.val().name);
      } });
    }));
    pairListeners.push(firebase.onValue(firebase.ref(db, `pairs/${activePairId}/members`), members => {
      roomMemberCount = members.size;
      if (isOwner) $('room-state').textContent = roomMemberCount > 1 ? 'Bersama' : 'Menunggu teman';
    }));
    pairListeners.push(firebase.onValue(firebase.ref(db, `pairs/${activePairId}/owner`), ownerSnapshot => {
      isOwner = ownerSnapshot.val() === uid;
      $('leave-room-button').hidden = false;
      if (isOwner) {
        $('room-state').textContent = roomMemberCount > 1 ? 'Bersama' : 'Menunggu teman';
        if (!requestWatchStarted) {
          requestWatchStarted = true;
          pairListeners.push(firebase.onValue(firebase.ref(db, `pairs/${activePairId}/requests`), showRequests));
        }
      }
      syncControls();
    }));
    if (nativeSharing) readNativeState();
    if (!sharing && (localStorage.getItem('dualworld-sharing-pair') === activePairId || localStorage.getItem('dualworld-sharing-consent') === 'yes')) void startSharing(false);
  }, error => { setConnection('Akses ditolak', 'error'); toast('Kode ruang tidak ditemukan atau akses belum disetujui.'); }));
}
function loadFirebase() {
  if (loadingConnection) return loadingConnection;
  loadingConnection = connectFirebase().finally(() => { loadingConnection = null; });
  return loadingConnection;
}
async function connectFirebase() {
  syncState = 'connecting'; syncControls();
  setConnection('Menyambungkan');
  try {
    let config;
    const storedConfig = localStorage.getItem('dualworld-firebase-config');
    if (storedConfig) config = JSON.parse(storedConfig);
    else {
      const response = await fetch('./firebase-config.json', { cache: 'no-store' });
      if (!response.ok) { syncState = 'missing'; throw new Error('Konfigurasi koneksi belum tersedia.'); }
      config = await response.json();
    }
    config = publicFirebaseConfig(config);
    connectionConfig = config;
    $('sync-project-label').textContent = config.projectId;
    $('firebase-config-input').value = JSON.stringify(config, null, 2);
    const [appSdk, authSdk, dbSdk] = await Promise.all([
      import('firebase/app'),
      import('firebase/auth'),
      import('firebase/database')
    ]);
    firebase = { ...authSdk, ...dbSdk };
    if (syncListener) { syncListener(); syncListener = null; }
    if (firebaseApp) await appSdk.deleteApp(firebaseApp);
    firebaseApp = appSdk.initializeApp(config);
    auth = authSdk.getAuth(firebaseApp); db = dbSdk.getDatabase(firebaseApp);
    await authSdk.setPersistence(auth, authSdk.browserLocalPersistence);
    await timed(auth.authStateReady());
    if (!auth.currentUser) await timed(authSdk.signInAnonymously(auth));
    uid = auth.currentUser.uid;
    $('sync-project-label').textContent = config.projectId;
    $('firebase-config-input').value = JSON.stringify(config, null, 2);
    await timed(new Promise((resolve, reject) => {
      let unsubscribe;
      unsubscribe = firebase.onValue(firebase.ref(db, '.info/connected'), snapshot => {
        if (snapshot.val() === true) { resolve(); queueMicrotask(() => unsubscribe()); }
      }, reject);
      // Clean up this temporary subscription whether connected or timed out.
      setTimeout(() => unsubscribe(), 15000);
    }));
    syncState = 'ready'; syncError = '';
    $('backend-note').hidden = true; setConnection('Online', 'online');
    syncListener = firebase.onValue(firebase.ref(db, '.info/connected'), snapshot => {
      syncState = snapshot.val() === true ? 'ready' : 'offline';
      if (syncState === 'offline') setConnection('Offline', 'error');
      else setConnection(approvedMember ? 'Terhubung' : 'Online', 'online');
      syncControls();
    });
    const savedName = profileName(); $('my-name').textContent = savedName; $('nickname-input').value = savedName;
    await people?.start();
  } catch (error) {
    uid = null;
    syncState = syncState === 'missing' ? 'missing' : 'error';
    syncError = syncState === 'missing' ? 'Koneksi dua perangkat belum disiapkan. Siapkan proyek sekali di sini, atau tempel undangan dari pasangan yang sudah terhubung.' : connectionError(error);
    setConnection(syncState === 'missing' ? 'Belum siap' : 'Gagal tersambung', 'error'); $('backend-note').hidden = false;
    $('backend-note').textContent = syncError;
    const savedName = profileName(); $('my-name').textContent = savedName; $('nickname-input').value = savedName;
  } finally { syncControls(); }
}
function newPairId() {
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  return btoa(String.fromCharCode(...bytes)).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '');
}
function invitationValue() {
  return makeInvitation(activePairId, connectionConfig, `${location.origin}${location.pathname}`, nativeAndroid);
}
async function saveFirebaseConfig() {
  if (activePairId) { toast('Putuskan ruang saat ini sebelum mengganti koneksi proyek.'); return; }
  try {
    const config = parseFirebaseConfigInput($('firebase-config-input').value);
    if (loadingConnection) await loadingConnection;
    localStorage.setItem('dualworld-firebase-config', JSON.stringify(config));
    $('save-config-button').disabled = true;
    await loadFirebase();
    toast(syncState === 'ready' ? 'Koneksi siap. Anda dapat membuat undangan sekarang.' : syncError);
    if (syncState === 'ready') document.querySelector('.sync-config').open = false;
  } catch { toast('Masukkan JSON konfigurasi Web Firebase yang valid, termasuk databaseURL HTTPS.'); }
  finally { $('save-config-button').disabled = false; }
}
async function createRoom(silent = false) {
  silent = silent === true;
  if (creatingRoom) return;
  if (activePairId) {
    if (isOwner) { syncControls(); if (!silent) toast('Undangan ruang Anda sudah siap di bawah.'); }
    else toast('Putuskan ruang saat ini sebelum membuat ruang baru.');
    return isOwner ? activePairId : null;
  }
  if (syncState === 'error' || syncState === 'offline') await loadFirebase();
  if (!uid || syncState !== 'ready') { setupRequired(); return; }
  creatingRoom = true; syncControls();
  try {
    const pairId = localStorage.getItem('dualworld-pending-create') || newPairId();
    localStorage.setItem('dualworld-pending-create', pairId);
    const ref = firebase.ref(db, `pairs/${pairId}`);
    const existingMember = await timed(firebase.get(firebase.ref(db, `pairs/${pairId}/members/${uid}`)));
    if (existingMember.val() !== true) await timed(firebase.set(ref, { owner: uid, members: { [uid]: true }, profiles: { [uid]: profileFields(profileName()) }, createdAt: firebase.serverTimestamp() }));
    activePairId = pairId; isOwner = true; localStorage.setItem('dualworld-pair', pairId);
    localStorage.removeItem('dualworld-pending-create');
    const invite = invitationValue();
    $('invite-input').value = invite; $('invite-box').hidden = false; $('room-state').textContent = 'Menunggu teman';
    history.replaceState(null, '', `${location.pathname}?pair=${pairId}`); watchPair(); if (!silent) toast('Tautan undangan siap dibagikan.');
    return pairId;
  } catch (error) { toast(connectionError(error)); }
  finally { creatingRoom = false; syncControls(); }
}
async function joinRoom() {
  let invitation;
  try { invitation = readInvitation($('join-input').value); }
  catch { toast('Konfigurasi pada tautan undangan tidak valid. Minta undangan baru.'); return; }
  if (!invitation) { toast('Tautan atau kode undangan tidak valid.'); return; }
  const { pairId, config } = invitation;
  if (activePairId && activePairId !== pairId) { toast('Putuskan ruang saat ini sebelum bergabung ke ruang lain.'); return; }
  $('join-room-button').disabled = true;
  try {
    if (loadingConnection) await loadingConnection;
    if (config && (!connectionConfig || config.projectId !== connectionConfig.projectId || config.databaseURL !== connectionConfig.databaseURL || syncState !== 'ready')) {
      if (activePairId) { toast('Undangan memakai koneksi lain. Putuskan ruang saat ini sebelum mengganti koneksi.'); return; }
      if (!(await askConfirmation('Gunakan koneksi undangan?', `Hubungkan perangkat ini ke proyek ${config.projectId} milik pembuat undangan? Lokasi belum dibagikan.`, 'GUNAKAN KONEKSI'))) return;
      localStorage.setItem('dualworld-firebase-config', JSON.stringify(config));
      await loadFirebase();
    }
    if (!uid || syncState !== 'ready') { setupRequired(); return; }
    if (pairId === localStorage.getItem('dualworld-pair')) { toast('Anda sudah berada di ruang ini.'); dialog.close(); return; }
    const requestRef = firebase.ref(db, `pairs/${pairId}/requests/${uid}`);
    const previousRequest = await timed(firebase.get(requestRef));
    if (previousRequest.exists()) { activePairId = pairId; isOwner = false; localStorage.setItem('dualworld-pair', pairId); watchPair(); toast('Permintaan Anda sedang menunggu persetujuan.'); return; }
    await timed(firebase.set(requestRef, profileName()));
    activePairId = pairId; isOwner = false; localStorage.setItem('dualworld-pair', pairId); history.replaceState(null, '', `${location.pathname}?pair=${pairId}`);
    $('room-state').textContent = 'Menunggu izin'; $('partner-name').textContent = 'Menunggu izin'; watchPair(); toast('Permintaan terkirim. Teman perlu menyetujuinya.');
  } catch (error) { toast(/permission.denied/i.test((error.code || '') + error.message) ? 'Undangan sudah berakhir atau ruang tidak ditemukan. Minta undangan baru kepada pasangan.' : connectionError(error)); }
  finally { $('join-room-button').disabled = false; }
}
async function saveName() {
  const name = $('nickname-input').value.trim().slice(0, 32);
  if (name.length < 2) { toast('Nama minimal dua karakter.'); return; }
  localStorage.setItem('dualworld-name', name); $('my-name').textContent = name;
  if (uid && activePairId && pairRef) await firebase.set(firebase.ref(db, `pairs/${activePairId}/profiles/${uid}`), profileFields(name)).catch(() => toast('Nama tersimpan di perangkat ini.'));
  void people?.save();
  toast('Nama tampilan disimpan.');
}
async function leaveRoom() {
  if (!activePairId || !uid) return;
  const ok = await askConfirmation('Putuskan ruang bersama?', 'Pasangan tidak lagi melihat lokasi Anda. Ruang undangan akan berakhir jika Anda pembuatnya.', 'PUTUSKAN');
  if (!ok) return;
  const leavingPairId = activePairId;
  const leavingUid = uid;
  const leavingOwner = isOwner;
  leavingRoom = true;
  await stopSharing(false);
  try {
    if (leavingOwner) await firebase.remove(firebase.ref(db, `pairs/${leavingPairId}`));
    else {
      if (approvedMember) {
        await firebase.remove(firebase.ref(db, `pairs/${leavingPairId}/locations/${leavingUid}`));
        await firebase.remove(firebase.ref(db, `pairs/${leavingPairId}/profiles/${leavingUid}`));
        await firebase.remove(firebase.ref(db, `pairs/${leavingPairId}/members/${leavingUid}`));
        await firebase.remove(firebase.ref(db, `pairs/${leavingPairId}/partnerUid`));
      } else await firebase.remove(firebase.ref(db, `pairs/${leavingPairId}/requests/${leavingUid}`));
    }
  } catch {
    toast('Ruang belum berhasil diputuskan di server. Periksa koneksi dan coba lagi.');
    return;
  } finally { leavingRoom = false; }
  if (nativeSharing) window.DualworldAndroid.forgetClosedRoom?.();
  resetRoomLocal(); dialog.close(); toast('Ruang bersama diputuskan.');
}

$('menu-button').addEventListener('click', () => { $('leave-room-button').hidden = true; syncControls(); dialog.showModal(); });
$('hide-status-button').addEventListener('click', () => setStatusCardVisible(false));
$('show-status-button').addEventListener('click', () => setStatusCardVisible(true));
setStatusCardVisible(localStorage.getItem('dualworld-status-card') !== 'hidden', false);
$('share-menu-button').addEventListener('click', () => $('people-button').click());
$('create-room-button').addEventListener('click', ()=>{toast('Versi ini memakai teman: cari nama atau ID melalui ♡.');});
$('join-room-button').addEventListener('click', ()=>toast('Cari nama atau ID teman melalui ♡, kemudian terima permintaannya.'));
$('save-name-button').addEventListener('click', saveName);
$('switch-profile-button').addEventListener('click', () => {
  const currentRole = localStorage.getItem('dualworld-role') || '';
  dialog.close();
  chooseRole(currentRole);
  showProfileEditor();
});
$('leave-room-button').addEventListener('click', ()=>void people.stopAll());
$('cancel-connection-button').addEventListener('click', async () => {
  if (!isOwner || !activePairId || roomMemberCount > 1) { toast('Tidak ada permintaan yang dapat dibatalkan.'); return; }
  try {
    const slot = firebase.ref(db, `pairs/${activePairId}/partnerUid`); const target = (await firebase.get(slot)).val();
    if (target) await firebase.remove(firebase.ref(db, `connectionInvites/${target}/${uid}`));
    await firebase.remove(slot); toast('Permintaan dibatalkan. Anda dapat memilih orang lain.');
  } catch { toast('Belum dapat membatalkan. Periksa internet.'); }
});
$('delete-profile-button').addEventListener('click', async () => {
  if (!uid || syncState !== 'ready') { toast('Hubungkan internet agar profil dapat dihapus dari server.'); return; }
  if (!(await askConfirmation('Hapus profil dan data Anda?', 'Nama publik, permintaan masuk, dan koneksi akan dihapus. Berbagi dihentikan. Tindakan ini tidak dapat dibatalkan.', 'HAPUS PROFIL'))) return;
  try {
    await firebase.remove(firebase.ref(db,`publicProfiles/${uid}`));
    await people.erase();
    if (activePairId) {
      await stopSharing(false);
      if (isOwner) {
        const target = (await firebase.get(firebase.ref(db, `pairs/${activePairId}/partnerUid`))).val();
        if (target) await firebase.remove(firebase.ref(db, `connectionInvites/${target}/${uid}`)).catch(() => {});
        await firebase.remove(firebase.ref(db, `pairs/${activePairId}`));
      } else if (approvedMember) {
        await firebase.remove(firebase.ref(db, `pairs/${activePairId}/profiles/${uid}`));
        await firebase.remove(firebase.ref(db, `pairs/${activePairId}/members/${uid}`));
        await firebase.remove(firebase.ref(db, `pairs/${activePairId}/partnerUid`));
      } else await firebase.remove(firebase.ref(db, `pairs/${activePairId}/requests/${uid}`));
      resetRoomLocal();
    }
    for(const legacyId of JSON.parse(localStorage.getItem('dualworld-legacy-pairs')||'[]')){
      const ownMember=(await firebase.get(firebase.ref(db,`pairs/${legacyId}/members/${uid}`))).val();
      if(ownMember!==true)continue;
      const owner=(await firebase.get(firebase.ref(db,`pairs/${legacyId}/owner`))).val();
      if(owner===uid)await firebase.remove(firebase.ref(db,`pairs/${legacyId}`));
      else {await firebase.remove(firebase.ref(db,`pairs/${legacyId}/locations/${uid}`));await firebase.remove(firebase.ref(db,`pairs/${legacyId}/presence/${uid}`));await firebase.remove(firebase.ref(db,`pairs/${legacyId}/profiles/${uid}`));await firebase.remove(firebase.ref(db,`pairs/${legacyId}/socialConsent/${uid}`));await firebase.remove(firebase.ref(db,`pairs/${legacyId}/members/${uid}`));await firebase.remove(firebase.ref(db,`pairs/${legacyId}/partnerUid`));}
    }
    await firebase.remove(firebase.ref(db, `publicProfiles/${uid}`));
    await firebase.remove(firebase.ref(db, `connectionInvites/${uid}`));
    if (nativeSharing) window.DualworldAndroid.forgetClosedRoom?.();
    people?.stop(); clearPairListeners();
    await firebase.deleteUser(auth.currentUser);
    for (const key of Object.keys(localStorage)) if (key.startsWith('dualworld-') && !['dualworld-firebase-config', 'dualworld-maps-config'].includes(key)) localStorage.removeItem(key);
    location.replace(location.pathname);
  } catch { toast('Penghapusan belum selesai. Periksa internet dan coba lagi agar data server benar-benar terhapus.'); }
});
$('share-button').addEventListener('click', async () => {
  if(!uid || !approvedMember){dialog.showModal();toast('Hubungkan internet dahulu.');return;}
  if(sharing){if(await askConfirmation('Hentikan berbagi ke semua teman?', 'Pertemanan tetap tersimpan; lokasi Anda tidak lagi dapat dilihat.', 'HENTIKAN'))await people.stopAll().catch(()=>toast('Belum dapat menghentikan berbagi. Periksa internet.'));}
  else await people.begin();
});
$('locate-button').addEventListener('click', locateMe);
$('me-card').addEventListener('click', () => inspectLocation('own'));
$('partner-card').addEventListener('click', () => inspectLocation('partner'));
$('focus-partner-button').addEventListener('click', focusPartner);
$('zoom-in').addEventListener('click', () => map.zoomIn()); $('zoom-out').addEventListener('click', () => map.zoomOut());
function setBaseMap(type) {
  if (!['streets', 'satellite', 'terrain'].includes(type)) return;
  $('map-availability').hidden = true;
  for (const layer of [streets, satellite, labels, terrain]) if (map.hasLayer(layer)) map.removeLayer(layer);
  ({ streets, satellite, terrain })[type].addTo(map);
  // Use vector road names from explorer rather than enlarged raster label tiles.
  satelliteMode = type === 'satellite'; baseMap = type;
  if (type !== 'streets') map.setMaxZoom(19); else map.setMaxZoom(20);
  $('map-mode').textContent = { streets: 'Jalan', satellite: 'Satelit', terrain: 'Medan' }[type];
  for (const button of document.querySelectorAll('[data-basemap]')) {
    const active = button.dataset.basemap === type; button.classList.toggle('selected', active); button.setAttribute('aria-pressed', String(active));
  }
  localStorage.setItem('dualworld-basemap', type);
  explorer?.baseMapChanged(type);
}
explorer = createMapExplorer({
  L, map, setBaseMap,
  getLocations: () => ({ own: { coords: ownCoords, name: profileName() }, partner: { coords: partnerCoords, name: $('partner-name').textContent } }),
  onDestination: place => setSearchDestination({ lat: place.lat, lon: place.lng, name: place.name, display_name: place.address || place.name, extratags: place.tags }),
  onRoute: () => void showRoute(), toast
});
setBaseMap(localStorage.getItem('dualworld-basemap') || baseMap);
$('layer-button').addEventListener('click', () => explorer.openLayers());
$('use-streets-button').addEventListener('click', () => setBaseMap('streets'));
for (const layer of [streets, satellite, terrain]) layer.on('tileerror', () => {
  $('map-availability-copy').textContent = 'Sebagian peta belum dapat dimuat. Periksa internet atau coba peta jalan.';
  $('map-availability').hidden = false;
});
$('route-button').addEventListener('click', showRoute);
$('place-search-button').addEventListener('click', searchPlaces);
$('place-query').addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); searchPlaces(); } if (event.key === 'Escape') $('search-results').hidden = true; });
$('identity-dialog').querySelectorAll('[data-avatar]').forEach(button => button.addEventListener('click', () => {
  localStorage.setItem('dualworld-avatar', button.dataset.avatar);
  for (const item of document.querySelectorAll('[data-avatar]')) item.setAttribute('aria-pressed', String(item === button));
}));
$('profile-name').addEventListener('input', () => { $('enter-app-button').disabled = $('profile-name').value.trim().length < 2; });
$('enter-app-button').addEventListener('click', enterAsRole);
$('copy-invite-button').addEventListener('click', async () => {
  const invite = $('invite-input').value.trim();
  if (!invite || !isOwner || !activePairId) { toast('Buat undangan yang valid sebelum menyalin.'); return; }
  try {
    if (nativeAndroid && window.DualworldAndroid.copyInvite) window.DualworldAndroid.copyInvite(invite);
    else await navigator.clipboard.writeText(invite);
    toast('Tautan undangan disalin.');
  } catch (error) {
    $('invite-input').select(); toast(document.execCommand('copy') ? 'Tautan undangan disalin.' : 'Tekan lama kolom undangan untuk menyalin tautannya.');
  }
});
$('share-invite-button').addEventListener('click', async () => {
  const invite = $('invite-input').value.trim();
  if (!invite || !isOwner || !activePairId) { toast('Buat undangan yang valid sebelum membagikan.'); return; }
  try {
    const text = `Undangan Dualworld:\n${invite}\nBuka Dualworld, pilih profil, lalu tempel seluruh tautan ini di Gabung ke ruang pasangan dan tekan Minta akses.`;
    if (nativeAndroid) window.DualworldAndroid.shareInvite(text);
    else if (navigator.share) await navigator.share({ title: 'Undangan Dualworld', text, ...(invite.startsWith('https:') ? { url: invite } : {}) });
    else $('copy-invite-button').click();
  } catch (error) { if (error.name !== 'AbortError') toast('Belum bisa membagikan. Gunakan tombol Salin.'); }
});
window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); deferredInstall = event; $('install-button').hidden = false; });
$('install-button').addEventListener('click', async () => { if (!deferredInstall) return; deferredInstall.prompt(); await deferredInstall.userChoice; deferredInstall = null; $('install-button').hidden = true; });
$('settings-dialog').addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
$('confirm-dialog').addEventListener('click', event => { if (event.target === confirmDialog) confirmDialog.close(); });
$('route-dialog').addEventListener('click', event => { if (event.target === routeDialog) routeDialog.close(); });
identityDialog.addEventListener('cancel', event => { if (!localStorage.getItem('dualworld-role')) event.preventDefault(); });
$('location-dialog').addEventListener('click', event => { if (event.target === locationDialog) locationDialog.close(); });
$('location-focus-button').addEventListener('click', () => {
  const coords = inspectedLocation === 'own' ? ownCoords : partnerCoords;
  locationDialog.close(); if (coords) map.flyTo([coords.lat, coords.lng], 19);
});
$('location-route-button').addEventListener('click', () => { locationDialog.close(); selectedPlace = null; showRoute(); });
$('location-explore-button').addEventListener('click', () => {
  const coords = inspectedLocation === 'own' ? ownCoords : partnerCoords;
  locationDialog.close(); if (coords) explorer.explorePoint(coords);
});
$('location-street-button').addEventListener('click', () => {
  const coords = inspectedLocation === 'own' ? ownCoords : partnerCoords;
  locationDialog.close(); if (coords) void explorer.openStreet(coords);
});
$('save-config-button').addEventListener('click', saveFirebaseConfig);
async function refreshApplication() {
  if (!nativeSharing && sharing && !await askConfirmation('Perbarui aplikasi?', 'GPS berhenti sementara saat halaman dimuat ulang, lalu melanjutkan pilihan berbagi yang sudah Anda aktifkan.', 'PERBARUI')) return;
  if ('serviceWorker' in navigator && !nativeAndroid) { const registration = await navigator.serviceWorker.getRegistration(); await registration?.update(); }
  location.reload();
}
$('refresh-app-button').addEventListener('click', refreshApplication);
$('reload-update-button').addEventListener('click', refreshApplication);
window.dualworldHandleBack = () => {
  if (explorer.handleBack()) return true;
  for (const modal of [confirmDialog, $('chat-dialog'), $('people-dialog'), locationDialog, routeDialog, dialog, identityDialog]) {
    if (modal.open) { if (modal === confirmDialog) $('confirm-cancel').click(); else if (modal !== identityDialog || localStorage.getItem('dualworld-role')) modal.close(); return true; }
  }
  if (!$('search-results').hidden) { $('search-results').hidden = true; return true; }
  return false;
};
document.addEventListener('click', event => {
  const link = event.target.closest('a');
  if (nativeAndroid && link?.dataset.attribution && window.DualworldAndroid.openAttribution) {
    event.preventDefault(); window.DualworldAndroid.openAttribution(link.href);
  }
});
window.addEventListener('dualworld-native-stop', () => {
  if (!nativeSharing) void stopSharing(false);
  if (ownWatch !== null) navigator.geolocation.clearWatch(ownWatch);
  ownWatch = null; watchStartedForMap = false;
  if (firebase && db) firebase.goOffline(db);
});
window.addEventListener('dualworld-native-resume', () => { if (firebase && db) firebase.goOnline(db); readNativeState(); });
$('background-settings-button').addEventListener('click', () => window.DualworldAndroid?.openBackgroundSettings?.());
$('background-sharing-settings').hidden = !nativeSharing;
if (nativeSharing) document.querySelector('.privacy-note p').textContent = 'Di Android, berbagi tetap aktif saat layar terkunci atau aplikasi ditutup, dengan notifikasi. Hentikan berbagi untuk menghapus posisi terakhir dari ruang.';
setInterval(updateLocationFreshness, 5000);
if (!nativeAndroid) fetch('./downloads/dualworld-android.apk', { method: 'HEAD', cache: 'no-store' })
  .then(response => { $('android-download-card').hidden = !response.ok; }).catch(() => {});
async function preparePersonalRoom() {
  const oldPair=activePairId;let personal=localStorage.getItem('dualworld-personal-pair') || '';
  const resume=localStorage.getItem('dualworld-sharing-consent')==='yes';
  if(oldPair && oldPair!==personal){
    const members=(await firebase.get(firebase.ref(db, `pairs/${oldPair}/members`)).catch(()=>null))?.val() || {};
    const other=Object.keys(members).find(id=>id!==uid&&members[id]===true);
    if(other&&members[uid]===true){
      const legacyPairs=JSON.parse(localStorage.getItem('dualworld-legacy-pairs')||'[]');if(!legacyPairs.includes(oldPair)){legacyPairs.push(oldPair);localStorage.setItem('dualworld-legacy-pairs',JSON.stringify(legacyPairs));}
      await firebase.set(firebase.ref(db,`pairs/${oldPair}/socialConsent/${uid}`),true).catch(()=>{});
      const consents=(await firebase.get(firebase.ref(db,`pairs/${oldPair}/socialConsent`))).val()||{};
      if(resume)localStorage.setItem('dualworld-migration-share-target',other);
      if(consents[uid]&&consents[other]){
        const edge=friendshipId(uid,other),edgeRef=firebase.ref(db,`friendships/${edge}`);
        const existing=await firebase.get(edgeRef).catch(()=>null);
        if(!existing?.exists()){
          try{await firebase.update(firebase.ref(db),{
            [`friendships/${edge}`]:{a:uid,b:other,members:{[uid]:true,[other]:true},profiles:{[uid]:profileFields(profileName())},legacyPairId:oldPair,createdAt:firebase.serverTimestamp()},
            [`friendIndex/${uid}/${other}`]:edge,[`friendIndex/${other}/${uid}`]:edge,[`pairs/${oldPair}/socialMigrated`]:true
          });}catch(error){if(!(await firebase.get(edgeRef).catch(()=>null))?.exists())throw error;}
        }
      }
    }
    await stopSharing(false);
    if(nativeSharing){
      const end=Date.now()+15000;
      while(JSON.parse(window.DualworldAndroid.getLocationState()).deletePending){
        if(Date.now()>end)throw new Error('Tunggu penghapusan sesi lokasi lama selesai, lalu buka kembali.');
        await new Promise(resolve=>setTimeout(resolve,250));
      }
    }
    if(resume)localStorage.setItem('dualworld-sharing-consent','yes');
  }
  clearPairListeners();
  if(!personal){personal=newPairId();localStorage.setItem('dualworld-personal-pair',personal);}
  const member=await firebase.get(firebase.ref(db,`pairs/${personal}/members/${uid}`));
  if(member.val()!==true)await firebase.set(firebase.ref(db,`pairs/${personal}`),{owner:uid,members:{[uid]:true},profiles:{[uid]:profileFields(profileName())},createdAt:firebase.serverTimestamp()});
  activePairId=personal;localStorage.setItem('dualworld-pair',personal);pairRef=firebase.ref(db,`pairs/${personal}`);
  approvedMember=true;isOwner=true;roomMemberCount=1;
  if(nativeSharing){readNativeState();if(!nativeState?.enabled&&nativeState?.phase==='stopped'&&nativeState?.pairId===personal)localStorage.setItem('dualworld-sharing-consent','paused');}
  return personal;
}
let displayedFriend=null;
people = createSocial({
  session: () => ({ firebase, db, uid, auth }), name:profileName, consent:askConfirmation, feedback:toast,
  prepareRoom:preparePersonalRoom, startGps:()=>startSharing(false), stopGps:()=>stopSharing(false),
  showFriend(profile,position,presence){
    const key=profile?.uid||null;
    if(displayedFriend!==key){displayedFriend=key;partnerCoords=null;locationDetails.partner=null;lastReverse.partner=null;if(routeLine&&!selectedPlace){map.removeLayer(routeLine);routeLine=null;}}
    $('partner-name').textContent=profile?.name||'Teman';
    partnerAvatar=AVATARS.includes(profile?.avatar)?profile.avatar:'🌙';document.querySelector('#partner-card .avatar').textContent=partnerAvatar;
    partnerPresence=presence;$('room-state').textContent=profile?'Bersama':'Pribadi';
    showPartnerLocation(position);
    if(!profile)$('partner-place').textContent='Tambahkan teman lewat ♡';
  }
});
document.querySelector('#me-card .avatar').textContent = avatar();
if (pendingRole && localStorage.getItem('dualworld-profile-complete')) {
  chooseRole(pendingRole); $('my-name').textContent = profileName(); $('nickname-input').value = profileName(); $('current-role-label').textContent = profileName();
} else showProfileEditor();
window.dualworldReceiveInvitation = value => {
  try {
    const invitation = readInvitation(value);
    if (!invitation) { toast('Tautan undangan tidak valid.'); return; }
    if (invitation.pairId === activePairId) return;
    $('join-input').value = value;
    if (localStorage.getItem('dualworld-role')) { dialog.showModal(); toast('Undangan siap. Tekan Minta akses untuk bergabung.'); }
    else waitingInvite = true;
  } catch { toast('Konfigurasi undangan tidak valid.'); }
};
void loadFirebase();
readNativeState();
if (inviteAtLoad) window.dualworldReceiveInvitation(inviteAtLoad);
