package com.dualworld.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class SharingRestartReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(intent.getAction())) return;
        if (LocationSharingService.preferences(context).getBoolean("enabled", false)) {
            if (LocationSharingService.background(context)) LocationSharingService.resume(context);
            else LocationSharingService.preferences(context).edit().putString("phase", "resume_required").apply();
        }
    }
}
