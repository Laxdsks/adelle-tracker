package com.dualworld.app;

import android.location.Location;

/** Suppress GPS drift without inventing motion or renewing an old sensor fix. */
final class LocationStabilizer {
    private Location anchor;
    private float anchorAccuracy;
    private Location pending;
    Location accept(Location next) {
        if (!LocationPolicy.fresh(next) || next.getAccuracy() > LocationPolicy.MAX_SHARED_ACCURACY_METERS) return null;
        if (anchor != null && next.getElapsedRealtimeNanos() <= anchor.getElapsedRealtimeNanos()) return null;
        if (anchor == null) { anchor = new Location(next); anchorAccuracy = next.getAccuracy(); return new Location(anchor); }
        float distance = anchor.distanceTo(next);
        float radius = Math.min(12f, Math.max(4f, .8f * Math.max(anchorAccuracy, next.getAccuracy())));
        boolean moving = next.hasSpeed() && next.getSpeed() >= .75f
            && (!next.hasSpeedAccuracy() || next.getSpeed() - next.getSpeedAccuracyMetersPerSecond() >= .5f);
        long sincePending = pending == null ? Long.MAX_VALUE : (next.getElapsedRealtimeNanos() - pending.getElapsedRealtimeNanos()) / 1000000;
        boolean coherent = pending != null && sincePending > 0 && sincePending <= 6000
            && pending.distanceTo(next) <= Math.max(radius, sincePending / 1000f * 3f) && distance > radius;
        if ((moving && distance >= 2f) || coherent) {
            anchor = new Location(next); anchorAccuracy = next.getAccuracy(); pending = null;
        } else {
            pending = distance > radius ? new Location(next) : null;
            Location held = new Location(next);
            held.setLatitude(anchor.getLatitude()); held.setLongitude(anchor.getLongitude());
            float uncertainty = Math.max(anchorAccuracy, next.getAccuracy() + distance);
            if (uncertainty > LocationPolicy.MAX_SHARED_ACCURACY_METERS) return null;
            held.setAccuracy(uncertainty);
            anchor = held;
        }
        return new Location(anchor);
    }
    void reset() { anchor = null; pending = null; }
}
