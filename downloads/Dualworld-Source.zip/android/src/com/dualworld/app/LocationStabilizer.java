package com.dualworld.app;

import android.location.Location;

/** Suppress GPS drift without inventing motion or renewing an old sensor fix. */
final class LocationStabilizer {
    private Location anchor;
    private float anchorAccuracy;
    private Location pending;
    private int pendingCount;
    Location accept(Location next) {
        if (!LocationPolicy.fresh(next) || next.getAccuracy() > LocationPolicy.MAX_SHARED_ACCURACY_METERS) return null;
        if (anchor != null && next.getElapsedRealtimeNanos() <= anchor.getElapsedRealtimeNanos()) return null;
        if (anchor == null) { anchor = new Location(next); anchorAccuracy = next.getAccuracy(); return new Location(anchor); }
        float distance = anchor.distanceTo(next);
        float radius = Math.min(12f, Math.max(4f, .8f * Math.max(anchorAccuracy, next.getAccuracy())));
        long sincePending = pending == null ? Long.MAX_VALUE : (next.getElapsedRealtimeNanos() - pending.getElapsedRealtimeNanos()) / 1000000;
        float movementThreshold = Math.max(9f, 2f * Math.max(anchorAccuracy, next.getAccuracy()));
        float speedBound = next.hasSpeed() && next.getSpeed() >= 0 ? Math.max(3f, next.getSpeed()) : 3f;
        boolean coherent = pending != null && sincePending > 0 && sincePending <= 8000
            && pending.distanceTo(next) <= Math.max(radius, sincePending / 1000f * speedBound * 1.5f + 2f);
        if (distance > movementThreshold) {
            if (coherent) pendingCount++; else { pending = new Location(next); pendingCount = 1; }
            if (pendingCount >= 4) {
                anchor = new Location(next); anchorAccuracy = next.getAccuracy(); pending = null; pendingCount = 0;
                return new Location(anchor);
            }
        } else {
            pending = null; pendingCount = 0;
        }
        Location held = new Location(next);
        held.setLatitude(anchor.getLatitude()); held.setLongitude(anchor.getLongitude());
        float uncertainty = Math.max(anchorAccuracy, next.getAccuracy() + distance);
        if (uncertainty > LocationPolicy.MAX_SHARED_ACCURACY_METERS) return null;
        held.setAccuracy(uncertainty);
        anchor = held;
        return new Location(anchor);
    }
    void reset() { anchor = null; pending = null; pendingCount = 0; }
}
