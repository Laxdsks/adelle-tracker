package com.dualworld.app;

import android.content.SharedPreferences;
import android.net.Uri;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLEncoder;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONObject;

/** Uses the same anonymous user as the WebView; never uses an admin credential. */
final class FirebaseTransport {
    static final class Denied extends IOException {}
    static final class Reply {
        final int code; final String body;
        Reply(int code, String body) { this.code = code; this.body = body; }
    }
    static JSONObject validate(String input) throws Exception {
        if (input == null || input.length() > 20000) throw new IllegalArgumentException();
        JSONObject value = new JSONObject(input);
        Uri uri = Uri.parse(value.getString("databaseURL"));
        String host = uri.getHost(); String pathname = uri.getPath();
        if (!"https".equals(uri.getScheme()) || host == null
            || !(host.endsWith(".firebasedatabase.app") || host.endsWith(".firebaseio.com"))
            || uri.getPort() != -1 || uri.getUserInfo() != null || uri.getQuery() != null || uri.getFragment() != null
            || !(pathname == null || pathname.isEmpty() || pathname.equals("/"))
            || !value.getString("pairId").matches("[A-Za-z0-9_-]{32}")
            || !value.getString("uid").matches("[A-Za-z0-9_-]{1,128}")
            || !value.getString("apiKey").matches("[A-Za-z0-9_-]{20,100}")
            || value.getString("idToken").length() < 50 || value.getString("refreshToken").length() < 10) throw new IllegalArgumentException();
        value.put("databaseURL", "https://" + host);
        return value;
    }
    static void refresh(SharedPreferences prefs) throws Exception {
        String body = "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(prefs.getString("refreshToken", ""), "UTF-8");
        Reply response = request("POST", "https://securetoken.googleapis.com/v1/token?key=" + Uri.encode(prefs.getString("apiKey", "")), body, "application/x-www-form-urlencoded");
        if (response.code == 400 || response.code == 401 || response.code == 403) throw new Denied();
        if (response.code != 200) throw new IOException("Authentication unavailable");
        JSONObject token = new JSONObject(response.body);
        if (!prefs.getString("uid", "").equals(token.getString("user_id"))) throw new Denied();
        prefs.edit().putString("idToken", token.getString("id_token"))
            .putString("refreshToken", token.getString("refresh_token"))
            .putLong("tokenUntil", System.currentTimeMillis() + token.getLong("expires_in") * 1000 - 60000).commit();
    }
    static Reply database(SharedPreferences prefs, String method, String path, String body) throws Exception {
        if (prefs.getLong("tokenUntil", 0) < System.currentTimeMillis()) refresh(prefs);
        for (int attempt = 0; attempt < 2; attempt++) {
            String address = prefs.getString("databaseURL", "") + "/pairs/" + prefs.getString("pairId", "") + "/" + path + ".json?auth=" + Uri.encode(prefs.getString("idToken", ""));
            Reply response = request(method, address, body, "application/json");
            if (response.code == 401 && attempt == 0) { refresh(prefs); continue; }
            if (response.code == 401 || response.code == 403) throw new Denied();
            if (response.code < 200 || response.code >= 300) throw new IOException("Database unavailable");
            return response;
        }
        throw new Denied();
    }
    private static Reply request(String method, String address, String body, String type) throws Exception {
        HttpsURLConnection connection = (HttpsURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(12000); connection.setReadTimeout(12000);
        connection.setInstanceFollowRedirects(false); connection.setRequestMethod(method);
        connection.setRequestProperty("Accept", "application/json");
        try {
            if (body != null) {
                byte[] bytes = body.getBytes("UTF-8");
                connection.setDoOutput(true); connection.setRequestProperty("Content-Type", type);
                connection.setFixedLengthStreamingMode(bytes.length);
                try (java.io.OutputStream out = connection.getOutputStream()) { out.write(bytes); }
            }
            int code = connection.getResponseCode();
            InputStream stream = code < 400 ? connection.getInputStream() : connection.getErrorStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            if (stream != null) try (InputStream in = stream) {
                byte[] bytes = new byte[4096]; int count;
                while ((count = in.read(bytes)) != -1) {
                    if (out.size() + count > 131072) throw new IOException("Response too large");
                    out.write(bytes, 0, count);
                }
            }
            return new Reply(code, out.toString("UTF-8"));
        } finally { connection.disconnect(); }
    }
}
