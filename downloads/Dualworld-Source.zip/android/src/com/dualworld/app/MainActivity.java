package com.dualworld.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.IntentFilter;
import android.content.Intent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Looper;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.provider.Settings;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.util.Base64;
import java.io.OutputStream;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.view.View;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import org.json.JSONObject;

/** All interface assets are bundled in the APK; remote services supply map data only. */
public final class MainActivity extends Activity {
    private static final String ORIGIN = "https://appassets.androidplatform.net";
    private static final String HOME = ORIGIN + "/assets/web/index.html";
    private static final int LOCATION_REQUEST = 20;
    private static final int SHARE_LOCATION_REQUEST = 21;
    private static final int NOTIFICATION_REQUEST = 22;
    private static final int PRIVATE_LOCATION_REQUEST = 23;
    private WebView web;
    private PermissionRequest microphoneRequest;
    private ValueCallback<Uri[]> fileCallback;
    private byte[] attachmentBytes;
    private static final int MICROPHONE_REQUEST=24, FILE_REQUEST=25, SAVE_REQUEST=26;
    private GeolocationPermissions.Callback locationCallback;
    private String locationOrigin;
    private JSONObject pendingSharing;
    private boolean resumed;
    private boolean notificationAsked;
    private boolean notificationPending;
    private boolean prepareInitialPermissions;
    private volatile Location privateLocation;
    private LocationManager privateGps;
    private final LocationStabilizer privateStabilizer = new LocationStabilizer();
    private final LocationListener privateListener = new LocationListener() {
        @Override public void onLocationChanged(Location location) {
            if (LocationPolicy.prefer(location, privateLocation)) {
                Location stable = privateStabilizer.accept(location);
                if (stable != null) privateLocation = stable;
                else if (privateLocation == null || privateLocation.getAccuracy() > LocationPolicy.MAX_SHARED_ACCURACY_METERS) privateLocation = new Location(location);
                emitLocationState();
            }
        }
        @Override public void onProviderEnabled(String provider) { }
        @Override public void onProviderDisabled(String provider) { emitError("Nyalakan Lokasi / GPS pada HP."); }
        @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
    };
    private final BroadcastReceiver locationReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { emitLocationState(); }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8, 13, 18));
        getWindow().setNavigationBarColor(Color.rgb(8, 13, 18));
        FrameLayout container = new FrameLayout(this);
        web = new WebView(this);
        container.addView(web, new FrameLayout.LayoutParams(-1, -1));
        // Android 15 uses edge-to-edge windows: keep controls outside system bars.
        container.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View view, WindowInsets insets) {
                view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                                insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
                return insets.consumeSystemWindowInsets();
            }
        });
        setContentView(container);
        privateGps = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(locationReceiver, new IntentFilter(LocationSharingService.STATE_CHANGED), Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(locationReceiver, new IntentFilter(LocationSharingService.STATE_CHANGED));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setGeolocationEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        web.setBackgroundColor(Color.rgb(8, 13, 18));
        web.addJavascriptInterface(new NativeBridge(), "DualworldAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) { emitLocationState(); }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!isLocal(uri)) return null;
                String pathname = uri.getPath();
                if (pathname == null || !pathname.startsWith("/assets/web/") || pathname.contains("..") || pathname.contains("\\")) return emptyResponse(404);
                String asset = pathname.substring("/assets/".length());
                if (asset.endsWith("/")) asset += "index.html";
                try {
                    HashMap<String, String> headers = new HashMap<>();
                    headers.put("Cache-Control", "no-store");
                    headers.put("Access-Control-Allow-Origin", ORIGIN);
                    return new WebResourceResponse(mime(asset), "UTF-8", 200, "OK", headers, getAssets().open(asset));
                } catch (IOException missing) { return emptyResponse(404); }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (isLocal(request.getUrl()) && request.getUrl().getPath().startsWith("/assets/web/")) return false;
                if (request.hasGesture() && isAttribution(request.getUrl())) { openAttribution(request.getUrl()); return true; }
                Toast.makeText(MainActivity.this, "Gunakan fitur peta di dalam Dualworld.", Toast.LENGTH_SHORT).show();
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (!isLocal(Uri.parse(origin))) { callback.invoke(origin, false, false); return; }
                if (hasLocationPermission()) { callback.invoke(origin, true, false); return; }
                locationOrigin = origin; locationCallback = callback;
                requestPermissions(new String[]{ Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION }, LOCATION_REQUEST);
            }
            @Override public void onGeolocationPermissionsHidePrompt() {
                locationCallback = null; locationOrigin = null;
            }
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() { @Override public void run() {
                    boolean audio=false;
                    for(String resource:request.getResources()) if(PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) audio=true;
                    if(!isLocal(request.getOrigin()) || !audio || microphoneRequest!=null){request.deny();return;}
                    if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED) request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    else {microphoneRequest=request;requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MICROPHONE_REQUEST);}
                }});
            }
            @Override public void onPermissionRequestCanceled(PermissionRequest request) { if(microphoneRequest==request)microphoneRequest=null; }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams parameters) {
                if(fileCallback!=null)fileCallback.onReceiveValue(null);
                fileCallback=callback;
                try { startActivityForResult(parameters.createIntent(),FILE_REQUEST); }
                catch(Exception unavailable){fileCallback=null;callback.onReceiveValue(null);Toast.makeText(MainActivity.this,"Pemilih berkas tidak tersedia.",Toast.LENGTH_SHORT).show();}
                return true;
            }

        });
        String invitation = invitationFrom(getIntent());
        web.loadUrl(invitation == null ? HOME : HOME + "?invite=" + Uri.encode(invitation));
    }

    private static String invitationFrom(Intent intent) {
        Uri uri = intent == null ? null : intent.getData();
        if (uri == null || !"dualworld".equals(uri.getScheme()) || !"join".equals(uri.getHost()) || uri.toString().length() > 4000) return null;
        String pair = uri.getQueryParameter("pair");
        return pair != null && pair.matches("[A-Za-z0-9_-]{32}") ? uri.toString() : null;
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent);
        String invitation = invitationFrom(intent);
        if (invitation != null) web.evaluateJavascript("window.dualworldReceiveInvitation && window.dualworldReceiveInvitation(" + JSONObject.quote(invitation) + ")", null);
    }

    private static boolean isLocal(Uri uri) {
        return "https".equals(uri.getScheme()) && "appassets.androidplatform.net".equals(uri.getHost()) && uri.getPort() == -1;
    }
    private static boolean isAttribution(Uri uri) {
        if (!"https".equals(uri.getScheme()) || uri.getUserInfo() != null || (uri.getPort() != -1 && uri.getPort() != 443)) return false;
        String host = uri.getHost(), path = uri.getPath();
        if (host == null || path == null) return false;
        return host.equals("commons.wikimedia.org") || host.equals("creativecommons.org")
            || host.equals("www.mapillary.com") || host.equals("mapillary.com")
            || host.equals("www.openstreetmap.org") || host.equals("openfreemap.org")
            || host.equals("www.mapzen.com") || host.equals("mapzen.com")
            || host.equals("www.esri.com") || host.equals("www.open-meteo.com") || host.equals("open-meteo.com")
            || (host.equals("www.google.com") && (path.startsWith("/maps") || path.startsWith("/intl")))
            || host.equals("maps.google.com") || host.equals("policies.google.com");
    }
    private void openAttribution(Uri uri) {
        if (!isAttribution(uri)) return;
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (Exception unavailable) { Toast.makeText(this, "Tidak ada browser untuk membuka sumber/lisensi.", Toast.LENGTH_SHORT).show(); }
    }
    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if(code==MICROPHONE_REQUEST && microphoneRequest!=null){
            if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)microphoneRequest.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});else microphoneRequest.deny();
            microphoneRequest=null;
        }
        if (code == LOCATION_REQUEST && locationCallback != null) {
            locationCallback.invoke(locationOrigin, hasLocationPermission(), false);
            locationCallback = null; locationOrigin = null;
        }
        if (code == SHARE_LOCATION_REQUEST) {
            if (LocationSharingService.precise(this)) continueSharingStart();
            else { pendingSharing = null; emitError("Berbagi memerlukan Lokasi akurat. Buka pengaturan izin Dualworld dan aktifkan Gunakan lokasi akurat."); }
        }
        if (code == NOTIFICATION_REQUEST) { notificationPending = false; continueSharingStart(); }
        if (code == PRIVATE_LOCATION_REQUEST) {
            if (hasLocationPermission()) { watchPrivateLocation(); initialNotifications(); }
            else { prepareInitialPermissions = false; pendingSharing = null; emitError("Izinkan lokasi Dualworld melalui pengaturan aplikasi."); }
        }
    }
    @Override protected void onActivityResult(int code,int result,Intent data) {
        super.onActivityResult(code,result,data);
        if(code==FILE_REQUEST && fileCallback!=null){fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));fileCallback=null;}
        if(code==SAVE_REQUEST){
            final byte[] bytes=attachmentBytes;attachmentBytes=null;
            if(result==RESULT_OK && data!=null && data.getData()!=null && bytes!=null){
                final Uri destination=data.getData();
                new Thread(new Runnable(){@Override public void run(){
                    boolean written=false;
                    try(OutputStream output=getContentResolver().openOutputStream(destination)){if(output!=null){output.write(bytes);written=true;}}
                    catch(Exception unavailable){}
                    final boolean ok=written;runOnUiThread(new Runnable(){@Override public void run(){Toast.makeText(MainActivity.this,ok?"Berkas disimpan.":"Berkas belum dapat disimpan.",Toast.LENGTH_SHORT).show();}});
                }}).start();
            }
        }
    }
    private void initialNotifications() {
        if (!prepareInitialPermissions) return;
        prepareInitialPermissions = false;
        if (Build.VERSION.SDK_INT >= 33 && !notificationAsked && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationAsked = true; notificationPending = true; requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
        } else continueSharingStart();
    }
    private void continueSharingStart() {
        if (pendingSharing == null || !resumed || prepareInitialPermissions || notificationPending) return;
        if (!LocationSharingService.precise(this)) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, SHARE_LOCATION_REQUEST); return;
        }
        if (Build.VERSION.SDK_INT >= 33 && !notificationAsked && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationAsked = true; notificationPending = true; requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST); return;
        }
        try {
            stopPrivateLocation(); privateLocation = null;
            LocationSharingService.enable(this, pendingSharing); pendingSharing = null; emitLocationState();
        } catch (Exception unavailable) { pendingSharing = null; emitError(unavailable instanceof IllegalStateException ? unavailable.getMessage() : "Layanan lokasi belum dapat dimulai. Coba lagi saat aplikasi terbuka."); }
    }
    private JSONObject locationState() {
        JSONObject state = LocationSharingService.snapshot(this);
        if (!state.optBoolean("enabled") && privateLocation != null) {
            try { state.put("position", LocationPolicy.json(privateLocation)); } catch (Exception ignored) { }
        }
        return state;
    }
    private void emitLocationState() {
        if (web != null) web.evaluateJavascript("window.dualworldNativeLocation && window.dualworldNativeLocation(" + locationState().toString() + ")", null);
    }
    private void emitError(String message) {
        if (web != null) web.evaluateJavascript("window.dualworldNativeError && window.dualworldNativeError(" + JSONObject.quote(message) + ")", null);
    }
    private void watchPrivateLocation() {
        if (!resumed) return;
        if (LocationSharingService.preferences(this).getBoolean("enabled", false)) { emitLocationState(); return; }
        if (!hasLocationPermission()) { requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, PRIVATE_LOCATION_REQUEST); return; }
        try {
            if (!LocationPolicy.enabled(privateGps)) emitError("Nyalakan Lokasi / GPS pada HP.");
            if (LocationSharingService.precise(this) && privateGps.getAllProviders().contains(LocationManager.GPS_PROVIDER)) privateGps.requestLocationUpdates(LocationManager.GPS_PROVIDER, LocationPolicy.GPS_INTERVAL_MS, 0, privateListener, Looper.getMainLooper());
            if (privateGps.getAllProviders().contains(LocationManager.NETWORK_PROVIDER)) privateGps.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, LocationPolicy.NETWORK_INTERVAL_MS, 0, privateListener, Looper.getMainLooper());
        } catch (SecurityException unavailable) { emitError("Periksa izin lokasi Dualworld di pengaturan aplikasi."); }
    }
    private void stopPrivateLocation() { if (privateGps != null) privateGps.removeUpdates(privateListener); }
    @Override public void onBackPressed() {
        if (web.canGoBack() && web.getUrl() != null && web.getUrl().contains("/privacy.html")) { web.goBack(); return; }
        web.evaluateJavascript("window.dualworldHandleBack ? window.dualworldHandleBack() : false", new ValueCallback<String>() {
            @Override public void onReceiveValue(String handled) {
                if (!"true".equals(handled)) moveTaskToBack(true);
            }
        });
    }
    @Override protected void onStop() {
        resumed = false; stopPrivateLocation();
        // Shared GPS belongs to the foreground service and survives closing this screen.
        web.evaluateJavascript("window.dispatchEvent(new Event('dualworld-native-stop'))", null);
        super.onStop();
    }
    @Override protected void onResume() {
        super.onResume();
        resumed = true; LocationSharingService.resume(this);
        if (pendingSharing != null) continueSharingStart();
        emitLocationState();
        if (web != null) web.evaluateJavascript("window.dispatchEvent(new Event('dualworld-native-resume'))", null);
    }
    @Override protected void onDestroy() {
        stopPrivateLocation(); unregisterReceiver(locationReceiver);
        if(microphoneRequest!=null)microphoneRequest.deny();
        if(fileCallback!=null)fileCallback.onReceiveValue(null);
        attachmentBytes=null;
        if (locationCallback != null) locationCallback.invoke(locationOrigin, false, false);
        web.removeJavascriptInterface("DualworldAndroid"); web.destroy();
        super.onDestroy();
    }
    private static WebResourceResponse emptyResponse(int code) {
        return new WebResourceResponse("text/plain", "UTF-8", code, "Not Found", new HashMap<>(), new ByteArrayInputStream(new byte[0]));
    }
    private static String mime(String path) {
        if (path.endsWith(".html")) return "text/html";
        if (path.endsWith(".js")) return "text/javascript";
        if (path.endsWith(".css")) return "text/css";
        if (path.endsWith(".json") || path.endsWith(".webmanifest")) return "application/json";
        if (path.endsWith(".svg")) return "image/svg+xml";
        if (path.endsWith(".png")) return "image/png";
        return "text/plain";
    }
    public final class NativeBridge {
        @JavascriptInterface public void saveAttachment(String value){
            if(value==null || value.length()>2801000)return;
            final byte[] bytes;final String name;
            try{JSONObject input=new JSONObject(value);bytes=Base64.decode(input.getString("data"),Base64.DEFAULT);if(bytes.length>2097152 || bytes.length==0)return;name=input.optString("name","berkas").replaceAll("[^a-zA-Z0-9._ -]","_");}
            catch(Exception invalid){return;}
            runOnUiThread(new Runnable(){@Override public void run(){
                if(attachmentBytes!=null)return;attachmentBytes=bytes;
                try{Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT);save.addCategory(Intent.CATEGORY_OPENABLE);save.setType("application/octet-stream");save.putExtra(Intent.EXTRA_TITLE,name.substring(0,Math.min(name.length(),100)));startActivityForResult(save,SAVE_REQUEST);}
                catch(Exception unavailable){attachmentBytes=null;Toast.makeText(MainActivity.this,"Tidak dapat membuka penyimpanan.",Toast.LENGTH_SHORT).show();}
            }});
        }

        @JavascriptInterface public void preparePermissions() {
            runOnUiThread(new Runnable() { @Override public void run() {
                prepareInitialPermissions = true;
                watchPrivateLocation();
                if (hasLocationPermission()) initialNotifications();
            } });
        }
        @JavascriptInterface public void openAttribution(String value) {
            if (value == null || value.length() > 3000) return;
            final Uri uri = Uri.parse(value);
            if (!isAttribution(uri)) return;
            runOnUiThread(new Runnable() { @Override public void run() { MainActivity.this.openAttribution(uri); } });
        }
        @JavascriptInterface public String getLocationState() { return locationState().toString(); }
        @JavascriptInterface public void startSharing(String value) {
            final JSONObject config;
            try { config = FirebaseTransport.validate(value); }
            catch (Exception invalid) { runOnUiThread(new Runnable() { @Override public void run() { emitError("Konfigurasi sesi lokasi belum valid. Hubungkan ulang ruang ini."); } }); return; }
            runOnUiThread(new Runnable() { @Override public void run() { pendingSharing = config; continueSharingStart(); } });
        }
        @JavascriptInterface public void stopSharing() {
            runOnUiThread(new Runnable() { @Override public void run() { pendingSharing = null; LocationSharingService.stop(MainActivity.this); emitLocationState(); } });
        }
        @JavascriptInterface public void forgetClosedRoom() {
            runOnUiThread(new Runnable() { @Override public void run() { pendingSharing = null; LocationSharingService.forgetClosedRoom(MainActivity.this); emitLocationState(); } });
        }
        @JavascriptInterface public void watchLocation() {
            runOnUiThread(new Runnable() { @Override public void run() { watchPrivateLocation(); } });
        }
        @JavascriptInterface public void openBackgroundSettings() {
            runOnUiThread(new Runnable() { @Override public void run() {
                new AlertDialog.Builder(MainActivity.this).setTitle("Lanjut setelah HP dinyalakan")
                    .setMessage("Di Izin → Lokasi, pilih Izinkan sepanjang waktu dan Lokasi akurat. Berbagi tetap terlihat lewat notifikasi dan dapat Anda hentikan kapan saja. Jika HP membatasi aplikasi latar, izinkan aktivitas latar / mulai otomatis pada pengaturan baterai Dualworld.")
                    .setNegativeButton("Kembali", null).setPositiveButton("Buka pengaturan", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface popup, int which) { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); }
                    }).show();
            } });
        }
        @JavascriptInterface public void copyInvite(String text) {
            if (text == null || text.trim().isEmpty() || text.length() > 4000) return;
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    clipboard.setPrimaryClip(ClipData.newPlainText("Undangan Dualworld", text));
                }
            });
        }
        @JavascriptInterface public void shareInvite(String text) {
            if (text == null || text.trim().isEmpty() || text.length() > 4000) return;
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain"); send.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(send, "Bagikan undangan Dualworld"));
                }
            });
        }
    }
}
