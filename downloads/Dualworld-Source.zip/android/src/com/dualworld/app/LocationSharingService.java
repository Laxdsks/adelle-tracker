package com.dualworld.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;

/** Explicitly enabled, visible foreground location service, independent of the WebView. */
public final class LocationSharingService extends Service implements LocationListener {
    static final String STATE_CHANGED = "com.dualworld.app.LOCATION_STATE_CHANGED";
    static final String STOP = "com.dualworld.app.STOP_SHARING";
    private static final String CHANNEL = "dualworld-location";
    private static final int NOTICE = 42;
    // Serialize writes and deletion even when an Activity or Service is recreated.
    private static final ExecutorService NETWORK = Executors.newSingleThreadExecutor();
    private final AtomicBoolean networkBusy = new AtomicBoolean(false);
    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private LocationManager gps;
    private volatile Location latestGood;
    private final LocationStabilizer stabilizer = new LocationStabilizer();
    private long lastPresenceElapsed;
    private long lastPublishedElapsedNanos;
    private long lastSendElapsed;
    private Location displayed;
    private long lastMemberCheck;
    private boolean listening;
    private boolean destroyed;
    private String lastNotice = "";

    static SharedPreferences preferences(Context context) { return context.getSharedPreferences("dualworld-sharing", Context.MODE_PRIVATE); }
    static boolean precise(Context context) { return context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED; }
    static boolean background(Context context) { return Build.VERSION.SDK_INT < 29 || context.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED; }
    static JSONObject snapshot(Context context) {
        SharedPreferences stored = preferences(context);
        JSONObject result = new JSONObject();
        try {
            result.put("enabled", stored.getBoolean("enabled", false));
            result.put("pairId", stored.getString("pairId", "")); result.put("uid", stored.getString("uid", ""));
            result.put("databaseURL", stored.getString("databaseURL", ""));
            result.put("phase", stored.getString("phase", "stopped"));
            result.put("publishedAt", stored.getLong("publishedAt", 0));
            result.put("deletePending", stored.getBoolean("deletePending", false));
            result.put("precisePermission", precise(context)); result.put("backgroundPermission", background(context));
            result.put("notificationsEnabled", ((NotificationManager) context.getSystemService(NOTIFICATION_SERVICE)).areNotificationsEnabled());
            // Prefer the qualified fix shown to the partner over a new coarse sample.
            String position = stored.getString("position", stored.getString("sample", ""));
            String sample = stored.getString("sample", "");
            if (!sample.isEmpty()) result.put("sampleAccuracy", new JSONObject(sample).optDouble("accuracy", 0));
            if (!position.isEmpty()) result.put("position", new JSONObject(position));
        } catch (Exception ignored) { }
        // Deliberately excludes auth and refresh tokens.
        return result;
    }
    static void broadcast(Context context) { context.sendBroadcast(new Intent(STATE_CHANGED).setPackage(context.getPackageName())); }
    static void resume(Context context) {
        SharedPreferences stored = preferences(context);
        if (!stored.getBoolean("enabled", false) && !stored.getBoolean("deletePending", false)) return;
        if (stored.getBoolean("deletePending", false)) cleanupWithoutGps(context);
        if (!precise(context)) {
            stored.edit().putString("phase", "permission").apply(); broadcast(context); return;
        }
        try { context.startForegroundService(new Intent(context, LocationSharingService.class)); }
        catch (RuntimeException blocked) {
            stored.edit().putString("phase", "resume_required").apply(); broadcast(context);
        }
    }
    static void enable(Context context, JSONObject config) throws Exception {
        SharedPreferences stored = preferences(context);
        if (stored.getBoolean("deletePending", false)) throw new IllegalStateException("Posisi lama masih menunggu dihapus. Hubungkan internet sebelum mulai lagi.");
        if (stored.getBoolean("enabled", false) && (!stored.getString("pairId", "").equals(config.getString("pairId"))
            || !stored.getString("uid", "").equals(config.getString("uid"))
            || !stored.getString("databaseURL", "").equals(config.getString("databaseURL")))) throw new IllegalStateException("Hentikan sesi berbagi lama sebelum mengganti ruang.");
        SharedPreferences.Editor edit = stored.edit();
        for (String key : new String[]{"apiKey", "databaseURL", "pairId", "uid", "idToken", "refreshToken"}) edit.putString(key, config.getString(key));
        edit.putLong("tokenUntil", System.currentTimeMillis() + 3000000).putBoolean("enabled", true).putString("phase", "searching").commit();
        resume(context);
    }
    static void stop(Context context) {
        SharedPreferences stored = preferences(context);
        if (!stored.getBoolean("enabled", false) && !stored.getBoolean("deletePending", false)) return;
        stored.edit().putBoolean("enabled", false).putBoolean("deletePending", true)
            .putString("phase", "cleanup").remove("sample").remove("position").commit();
        broadcast(context);
        cleanupWithoutGps(context);
        try { context.startForegroundService(new Intent(context, LocationSharingService.class).setAction(STOP)); }
        catch (RuntimeException unavailable) { /* Persisted deletion retries when the user opens the app. */ }
    }
    private static void cleanupWithoutGps(Context context) {
        final Context app = context.getApplicationContext();
        NETWORK.execute(new Runnable() {
            @Override public void run() {
                SharedPreferences stored = preferences(app);
                if (!stored.getBoolean("deletePending", false)) return;
                try {
                    FirebaseTransport.database(stored, "DELETE", "locations/" + stored.getString("uid", ""), null);
                    try { FirebaseTransport.database(stored, "DELETE", "presence/" + stored.getString("uid", ""), null); } catch (FirebaseTransport.Denied oldRules) { }
                    stored.edit().putBoolean("deletePending", false).putString("phase", "stopped")
                        .remove("idToken").remove("refreshToken").remove("position").remove("sample").commit();
                } catch (FirebaseTransport.Denied denied) { stored.edit().putString("phase", "delete_denied").commit(); }
                catch (Exception offline) { /* Retain the deletion for the next connection. */ }
                broadcast(app);
            }
        });
    }
    static void forgetClosedRoom(Context context) {
        final Context app = context.getApplicationContext();
        preferences(app).edit().putBoolean("enabled", false).commit();
        NETWORK.execute(new Runnable() { @Override public void run() {
            preferences(app).edit().clear().commit(); broadcast(app);
        } });
    }
    @Override public void onCreate() {
        super.onCreate(); prefs = preferences(this);
        gps = (LocationManager) getSystemService(LOCATION_SERVICE);
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Berbagi lokasi Dualworld", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Terlihat selama lokasi dibagikan, termasuk saat layar terkunci.");
        channel.setShowBadge(false);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && STOP.equals(intent.getAction())) {
            prefs.edit().putBoolean("enabled", false).putBoolean("deletePending", true).putString("phase", "cleanup").remove("sample").remove("position").commit();
        }
        if (!prefs.getBoolean("enabled", false) && !prefs.getBoolean("deletePending", false)) { stopSelf(); return START_NOT_STICKY; }
        lastNotice = "";
        try {
            Notification notification = notification(prefs.getBoolean("enabled", false) ? "Mencari GPS akurat…" : "Berbagi dihentikan · menghapus posisi…");
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTICE, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            else startForeground(NOTICE, notification);
        } catch (RuntimeException permission) {
            prefs.edit().putString("phase", "resume_required").commit(); broadcast(this); stopSelf(); return START_NOT_STICKY;
        }
        if (prefs.getBoolean("enabled", false)) startGps(); else stopGps();
        main.removeCallbacks(tick); main.post(tick);
        broadcast(this);
        return START_STICKY;
    }
    private void startGps() {
        if (listening) return;
        if (!precise(this)) { phase("permission"); return; }
        listening = true;
        try {
            // No getLastKnownLocation: an old fix must not become a new location.
            if (gps.getAllProviders().contains(LocationManager.GPS_PROVIDER)) gps.requestLocationUpdates(LocationManager.GPS_PROVIDER, LocationPolicy.GPS_INTERVAL_MS, 0, this, Looper.getMainLooper());
            if (gps.getAllProviders().contains(LocationManager.NETWORK_PROVIDER)) gps.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, LocationPolicy.NETWORK_INTERVAL_MS, 0, this, Looper.getMainLooper());
            if (!LocationPolicy.enabled(gps)) phase("gps_off");
        } catch (SecurityException denied) { listening = false; phase("permission"); }
    }
    private void stopGps() {
        if (gps != null) gps.removeUpdates(this);
        listening = false; latestGood = null; displayed = null; stabilizer.reset();
    }
    @Override public void onLocationChanged(Location location) {
        if (destroyed || !prefs.getBoolean("enabled", false) || !LocationPolicy.prefer(location, displayed)) return;
        displayed = new Location(location);
        try { prefs.edit().putString("sample", LocationPolicy.json(location).toString()).apply(); } catch (Exception ignored) { }
        if (location.getAccuracy() > LocationPolicy.MAX_SHARED_ACCURACY_METERS) {
            if (!LocationPolicy.fresh(latestGood)) phase("inaccurate");
        } else {
            Location stable = stabilizer.accept(location);
            if (stable == null) return;
            latestGood = stable;
            try { prefs.edit().putString("position", LocationPolicy.json(latestGood).toString()).apply(); } catch (Exception ignored) { }
            sync();
        }
        broadcast(this);
    }
    @Override public void onProviderEnabled(String provider) { if (prefs.getBoolean("enabled", false)) phase("searching"); }
    @Override public void onProviderDisabled(String provider) { if (!LocationPolicy.enabled(gps)) phase("gps_off"); }
    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (destroyed) return;
            if (!prefs.getBoolean("enabled", false) && !prefs.getBoolean("deletePending", false)) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return; }
            if (prefs.getBoolean("enabled", false) && !LocationPolicy.fresh(latestGood)) {
                phase(!precise(LocationSharingService.this) ? "permission" : !LocationPolicy.enabled(gps) ? "gps_off" : displayed != null && displayed.getAccuracy() > LocationPolicy.MAX_SHARED_ACCURACY_METERS ? "inaccurate" : "searching");
            }
            sync(); main.postDelayed(this, LocationPolicy.PUBLISH_INTERVAL_MS);
        }
    };
    private void sync() {
        if (!networkBusy.compareAndSet(false, true)) return;
        NETWORK.execute(new Runnable() {
            @Override public void run() {
                try {
                    String user = prefs.getString("uid", "");
                    if (prefs.getBoolean("deletePending", false)) {
                        FirebaseTransport.database(prefs, "DELETE", "locations/" + user, null);
                        try { FirebaseTransport.database(prefs, "DELETE", "presence/" + user, null); } catch (FirebaseTransport.Denied oldRules) { }
                        prefs.edit().putBoolean("deletePending", false).putString("phase", "stopped")
                            .remove("idToken").remove("refreshToken").remove("position").remove("sample").commit();
                        main.post(new Runnable() { @Override public void run() { if (!prefs.getBoolean("enabled", false)) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); } } });
                        return;
                    }
                    if (!prefs.getBoolean("enabled", false)) return;
                    if (System.currentTimeMillis() - lastMemberCheck > 60000) {
                        FirebaseTransport.Reply member = FirebaseTransport.database(prefs, "GET", "members/" + user, null);
                        if (!"true".equals(member.body.trim())) throw new FirebaseTransport.Denied();
                        lastMemberCheck = System.currentTimeMillis();
                    }
                    Location point = latestGood;
                    if (LocationPolicy.fresh(point) && point.getAccuracy() <= LocationPolicy.MAX_SHARED_ACCURACY_METERS
                        && point.getElapsedRealtimeNanos() > lastPublishedElapsedNanos
                        && SystemClock.elapsedRealtime() - lastSendElapsed >= LocationPolicy.PUBLISH_INTERVAL_MS
                        && prefs.getBoolean("enabled", false)) {
                        FirebaseTransport.database(prefs, "PUT", "locations/" + user, LocationPolicy.json(point).toString());
                        lastPublishedElapsedNanos = point.getElapsedRealtimeNanos(); lastSendElapsed = SystemClock.elapsedRealtime();
                        if (prefs.getBoolean("enabled", false)) prefs.edit().putLong("publishedAt", point.getTime()).putString("phase", "active").commit();
                    }
                    if (prefs.getBoolean("enabled", false) && SystemClock.elapsedRealtime() - lastPresenceElapsed >= 20000) {
                        // Presence is separate from measured coordinates: online never fabricates a fresh GPS fix.
                        try {
                            JSONObject presence = new JSONObject(); presence.put("sharing", true);
                            presence.put("lastSeen", new JSONObject().put(".sv", "timestamp"));
                            presence.put("phase", prefs.getString("phase", "searching"));
                            FirebaseTransport.database(prefs, "PUT", "presence/" + user, presence.toString());
                            lastPresenceElapsed = SystemClock.elapsedRealtime();
                        } catch (FirebaseTransport.Denied unavailable) {
                            // Older published rules may not support presence yet; keep location sharing alive.
                            lastPresenceElapsed = SystemClock.elapsedRealtime();
                        }
                    }
                } catch (FirebaseTransport.Denied revoked) {
                    if (prefs.getBoolean("deletePending", false)) prefs.edit().putString("phase", "delete_denied").commit();
                    else prefs.edit().putBoolean("enabled", false).putString("phase", "revoked").remove("idToken").remove("refreshToken").commit();
                    main.post(new Runnable() { @Override public void run() { stopGps(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); } });
                } catch (Exception offline) {
                    prefs.edit().putString("phase", prefs.getBoolean("enabled", false) ? "offline" : "cleanup").commit();
                } finally {
                    networkBusy.set(false);
                    main.post(new Runnable() { @Override public void run() { if (!destroyed) updateNotice(); broadcast(LocationSharingService.this); } });
                }
            }
        });
    }
    private void phase(String value) {
        if (!value.equals(prefs.getString("phase", ""))) {
            prefs.edit().putString("phase", value).apply(); updateNotice(); broadcast(this);
        }
    }
    private Notification notification(String copy) {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, LocationSharingService.class).setAction(STOP), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle(prefs.getBoolean("enabled", false) ? "Dualworld · lokasi dibagikan" : "Dualworld · berbagi dihentikan")
            .setContentText(copy).setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE).setVisibility(Notification.VISIBILITY_PRIVATE)
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Hentikan berbagi", stop).build()).build();
    }
    private void updateNotice() {
        if (destroyed) return;
        String state = prefs.getString("phase", "");
        if ((!prefs.getBoolean("enabled", false) && !prefs.getBoolean("deletePending", false)) || state.equals("delete_denied")) {
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(NOTICE); return;
        }
        String text = state.equals("active") ? "Tetap aktif saat layar terkunci · ketuk untuk membuka"
            : state.equals("offline") ? "Menunggu internet · posisi terakhir tetap tersimpan"
            : state.equals("gps_off") ? "Nyalakan Lokasi / GPS agar posisi diperbarui"
            : state.equals("permission") ? "Aktifkan izin lokasi akurat di pengaturan aplikasi"
            : state.equals("inaccurate") ? "Sinyal lokasi lemah · menunggu akurasi 35 m atau lebih baik"
            : state.equals("cleanup") ? "Menunggu internet untuk menghapus posisi terakhir"
            : "Mencari GPS akurat · posisi terakhir tetap tersimpan";
        if (!text.equals(lastNotice)) { lastNotice = text; ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTICE, notification(text)); }
    }
    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onDestroy() {
        destroyed = true; main.removeCallbacksAndMessages(null); stopGps();
        if (!prefs.getBoolean("enabled", false)) ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(NOTICE);
        // Losing the process never revokes consent and never deletes the last location.
        super.onDestroy();
    }
}
