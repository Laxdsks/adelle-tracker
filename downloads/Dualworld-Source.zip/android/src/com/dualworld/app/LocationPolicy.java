package com.dualworld.app;

import android.location.Location;
import android.location.LocationManager;
import android.os.SystemClock;
import android.os.Build;
import org.json.JSONException;
import org.json.JSONObject;

/** Fresh sensor fixes only: cached cell-tower fixes must not masquerade as live GPS. */
final class LocationPolicy {
    static final float MAX_SHARED_ACCURACY_METERS = 35f;
    static final long GPS_INTERVAL_MS = 1000;
    static final long NETWORK_INTERVAL_MS = 3000;
    static final long PUBLISH_INTERVAL_MS = 2000;
    static boolean enabled(LocationManager manager) {
        if (Build.VERSION.SDK_INT >= 28) return manager.isLocationEnabled();
        return (manager.getAllProviders().contains(LocationManager.GPS_PROVIDER) && manager.isProviderEnabled(LocationManager.GPS_PROVIDER))
            || (manager.getAllProviders().contains(LocationManager.NETWORK_PROVIDER) && manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER));
    }
    static boolean fresh(Location location) {
        if (location == null || !location.hasAccuracy() || location.getAccuracy() <= 0 || Float.isNaN(location.getAccuracy()) || Float.isInfinite(location.getAccuracy())
            || Double.isNaN(location.getLatitude()) || Double.isNaN(location.getLongitude())
            || Math.abs(location.getLatitude()) > 90 || Math.abs(location.getLongitude()) > 180) return false;
        long age = (SystemClock.elapsedRealtimeNanos() - location.getElapsedRealtimeNanos()) / 1000000;
        return age >= -1000 && age <= 30000;
    }
    static boolean prefer(Location next, Location previous) {
        if (!fresh(next)) return false;
        if (!fresh(previous)) return true;
        if (next.getElapsedRealtimeNanos() <= previous.getElapsedRealtimeNanos()) return false;
        if (LocationManager.GPS_PROVIDER.equals(next.getProvider()) && !LocationManager.GPS_PROVIDER.equals(previous.getProvider()) && next.getAccuracy() <= MAX_SHARED_ACCURACY_METERS) return true;
        long previousAge = (SystemClock.elapsedRealtimeNanos() - previous.getElapsedRealtimeNanos()) / 1000000;
        if (LocationManager.GPS_PROVIDER.equals(previous.getProvider()) && !LocationManager.GPS_PROVIDER.equals(next.getProvider()) && previous.getAccuracy() <= MAX_SHARED_ACCURACY_METERS && previousAge < 20000) return false;
        // Keep a recent accurate GPS fix when a less accurate network fix arrives.
        return next.getAccuracy() <= previous.getAccuracy() * 1.5f
            || next.getElapsedRealtimeNanos() - previous.getElapsedRealtimeNanos() > 20000000000L;
    }
    static JSONObject json(Location location) throws JSONException {
        JSONObject value = new JSONObject();
        value.put("lat", location.getLatitude()); value.put("lng", location.getLongitude());
        value.put("accuracy", Math.ceil(location.getAccuracy()));
        // Time of the measurement, never time of a reconnect or retransmission.
        value.put("updatedAt", location.getTime());
        return value;
    }
}
