// Use measurement time across every map, never reconnect/render time.
export const MAX_SHARED_ACCURACY = 35;
export const LOCATION_FRESH_MS = 30000;
export const LOCATION_PUBLISH_MS = 2000;
export function isFreshLocation(coords, now = Date.now()) {
  const age = now - coords?.updatedAt;
  return Number.isFinite(coords?.updatedAt) && age >= -5000 && age <= LOCATION_FRESH_MS;
}
export function validLocation(coords) {
  return Number.isFinite(coords?.lat) && Math.abs(coords.lat) <= 90
    && Number.isFinite(coords?.lng) && Math.abs(coords.lng) <= 180
    && Number.isFinite(coords?.accuracy) && coords.accuracy > 0
    && Number.isFinite(coords?.updatedAt);
}
