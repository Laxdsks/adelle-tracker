import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';

for (const file of ['app.js', 'people.js', 'friendships.js', 'communication.js', 'location-filter.js', 'map-explorer.js', 'map-3d.js', 'mapillary-explorer.js', 'invitations.js', 'satellite.js', 'sw.js', 'scripts/build-web.mjs']) {
  const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  assert.equal(result.status, 0, result.stderr);
}
for (const file of ['scripts/setup-cloud.sh', 'scripts/setup-android.sh', 'scripts/build-android.sh']) {
  const result = spawnSync('bash', ['-n', file], { encoding: 'utf8' });
  assert.equal(result.status, 0, result.stderr);
}
for (const file of ['manifest.webmanifest', 'database.rules.json', 'firebase-config.example.json', 'package.json']) {
  JSON.parse(await readFile(file, 'utf8'));
}
const html = await readFile('index.html', 'utf8');
const app = (await Promise.all(['app.js','friendships.js','communication.js'].map(file=>readFile(file,'utf8')))).join('\n');
const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
assert.equal(new Set(ids).size, ids.length, 'Duplikat ID halaman');
for (const match of app.matchAll(/\$\('([^']+)'\)/g)) assert(ids.includes(match[1]), 'Elemen hilang: ' + match[1]);
assert(!/window\.open\s*\(|google\.com\/maps|maps\.google\.com/.test(app + html), 'Navigasi peta luar ditemukan');
const built = await readFile('dist/web/index.html', 'utf8');
assert(!built.includes('__APP_VERSION__'), 'Versi build belum dimasukkan');
assert(!built.includes('cdn.jsdelivr.net'), 'Aset antarmuka masih bergantung CDN');
assert((await readFile('dist/web/vendor/maplibre/worker.js', 'utf8')).length > 10000, 'Worker MapLibre tidak dibundel');
console.log('Pemeriksaan sumber, skrip, konfigurasi, elemen UI, dan build web berhasil.');
