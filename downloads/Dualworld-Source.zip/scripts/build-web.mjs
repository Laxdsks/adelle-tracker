import { build } from 'esbuild';
import { mkdir, cp, readFile, writeFile, readdir, rm } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const output = path.join(root, 'dist/web');
await rm(output, { recursive: true, force: true });
await mkdir(output, { recursive: true });
for (const name of ['index.html', 'privacy.html', 'tracker.html', 'styles.css', 'manifest.webmanifest', 'icon.svg', 'icon-192.png', 'icon-512.png']) {
  await cp(path.join(root, name), path.join(output, name));
}
await mkdir(path.join(output, 'vendor/leaflet'), { recursive: true });
await cp(path.join(root, 'node_modules/leaflet/dist/leaflet.css'), path.join(output, 'vendor/leaflet/leaflet.css'));
await cp(path.join(root, 'node_modules/leaflet/dist/images'), path.join(output, 'vendor/leaflet/images'), { recursive: true });
await cp(path.join(root, 'node_modules/leaflet/LICENSE'), path.join(output, 'vendor/leaflet/LICENSE.txt'));
await mkdir(path.join(output, 'vendor/maplibre'), { recursive: true });
await cp(path.join(root, 'node_modules/maplibre-gl/dist/maplibre-gl.css'), path.join(output, 'vendor/maplibre/maplibre-gl.css'));
await cp(path.join(root, 'node_modules/maplibre-gl/LICENSE.txt'), path.join(output, 'vendor/maplibre/LICENSE.txt'));
// MapLibre 6 resolves its module worker beside import.meta.url; esbuild moves the main bundle.
await build({ absWorkingDir: root, entryPoints: ['node_modules/maplibre-gl/dist/maplibre-gl-worker.mjs'], outfile: path.join(output, 'vendor/maplibre/worker.js'), bundle: true, format: 'esm', target: ['chrome90'], minify: true, legalComments: 'linked' });
await mkdir(path.join(output, 'vendor/mapillary'), { recursive: true });
await cp(path.join(root, 'node_modules/mapillary-js/dist/mapillary.css'), path.join(output, 'vendor/mapillary/mapillary.css'));
await cp(path.join(root, 'node_modules/mapillary-js/LICENSE'), path.join(output, 'vendor/mapillary/LICENSE.txt'));
try {
  await cp(path.join(root, 'firebase-config.json'), path.join(output, 'firebase-config.json'));
} catch (error) {
  if (error.code !== 'ENOENT') throw error;
  console.log('Firebase belum diatur; GPS pribadi, pencarian, dan peta tetap tersedia.');
}
try { await cp(path.join(root, 'maps-config.json'), path.join(output, 'maps-config.json')); }
catch (error) { if (error.code !== 'ENOENT') throw error; }
await build({
  absWorkingDir: root, entryPoints: ['app.js'], outdir: output, bundle: true,
  splitting: true, format: 'esm', target: ['chrome90'], minify: true,
  chunkNames: 'chunks/[name]-[hash]', legalComments: 'linked'
});
async function files(directory, prefix = '') {
  const entries = await readdir(directory, { withFileTypes: true });
  const result = [];
  for (const entry of entries) {
    const relative = prefix + entry.name;
    if (entry.isDirectory()) result.push(...await files(path.join(directory, entry.name), relative + '/'));
    else result.push(relative);
  }
  return result.sort();
}
// Public Firebase config is intentionally fetched fresh and never put in the shell cache.
const assets = (await files(output)).filter(name => !['firebase-config.json', 'maps-config.json'].includes(name));
const hash = createHash('sha256');
for (const name of assets) { hash.update(name); hash.update(await readFile(path.join(output, name))); }
hash.update(await readFile(path.join(root, 'sw.js')));
const buildId = hash.digest('hex').slice(0, 12);
const { version } = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'));
const html = (await readFile(path.join(output, 'index.html'), 'utf8')).replace('__APP_VERSION__', `${version} · ${buildId}`);
await writeFile(path.join(output, 'index.html'), html);
const worker = (await readFile(path.join(root, 'sw.js'), 'utf8'))
  .replace("'dualworld-shell-v2'", `'dualworld-shell-${buildId}'`)
  .replace(/const SHELL = .*;/, `const SHELL = ${JSON.stringify(['./', ...assets.map(name => './' + name)])};`);
await writeFile(path.join(output, 'sw.js'), worker);
await writeFile(path.join(root, 'dist/build-info.json'), JSON.stringify({ version, buildId, assets: assets.length }, null, 2) + '\n');
console.log(`Dualworld ${version} (${buildId}): ${assets.length} aset lokal, siap di dist/web.`);
