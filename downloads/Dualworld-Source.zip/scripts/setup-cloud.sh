#!/usr/bin/env bash
set -euo pipefail
DUALWORLD_REPO="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$DUALWORLD_REPO"
for executable in node npm python3 java curl unzip; do
  command -v "$executable" >/dev/null || { echo "Alat yang diperlukan belum tersedia: $executable" >&2; exit 1; }
done
export npm_config_cache="${DUALWORLD_TOOLCHAIN_DIR:-$DUALWORLD_REPO/../.dualworld-toolchain}/npm-cache"
npm ci --no-audit --no-fund
npm run build
npm run android:setup
npm run android:build
npm run check
echo 'Setup selesai. Web: dist/web. APK: dist/dualworld-android.apk. Jalankan npm start untuk pengembangan.'
