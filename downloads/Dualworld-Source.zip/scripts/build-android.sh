#!/usr/bin/env bash
set -euo pipefail
DUALWORLD_REPO="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
DUALWORLD_TOOLCHAIN="${DUALWORLD_TOOLCHAIN_DIR:-$DUALWORLD_REPO/../.dualworld-toolchain}"
DUALWORLD_SDK="$DUALWORLD_TOOLCHAIN/android-sdk"
DUALWORLD_BUILD_TOOLS="$DUALWORLD_SDK/build-tools/35.0.0"
DUALWORLD_ANDROID_JAR="$DUALWORLD_SDK/platforms/android-35/android.jar"
DUALWORLD_BUILD="$DUALWORLD_REPO/dist/android-build"
DUALWORLD_APK="$DUALWORLD_REPO/dist/dualworld-android.apk"
DUALWORLD_JAVA_BIN="$(dirname -- "$(readlink -f -- "$(command -v java)")")"
test -f "$DUALWORLD_REPO/dist/web/index.html" || { echo 'Jalankan npm run build terlebih dahulu.' >&2; exit 1; }
test -f "$DUALWORLD_ANDROID_JAR" || { echo 'Jalankan npm run android:setup terlebih dahulu.' >&2; exit 1; }
rm -rf -- "$DUALWORLD_BUILD"
mkdir -p "$DUALWORLD_BUILD/classes" "$DUALWORLD_BUILD/dex" "$DUALWORLD_BUILD/res/drawable" "$DUALWORLD_BUILD/payload/assets/web"
cp "$DUALWORLD_REPO/icon-192.png" "$DUALWORLD_BUILD/res/drawable/icon.png"
python3 - "$DUALWORLD_REPO/dist/web" "$DUALWORLD_BUILD/payload/assets/web" <<'PY'
import shutil, sys
shutil.copytree(sys.argv[1], sys.argv[2], dirs_exist_ok=True, ignore=shutil.ignore_patterns('downloads'))
PY
"$DUALWORLD_BUILD_TOOLS/aapt2" compile --dir "$DUALWORLD_BUILD/res" -o "$DUALWORLD_BUILD/resources.zip"
"$DUALWORLD_BUILD_TOOLS/aapt2" link -o "$DUALWORLD_BUILD/unsigned.apk" -I "$DUALWORLD_ANDROID_JAR" --manifest "$DUALWORLD_REPO/android/AndroidManifest.xml" -R "$DUALWORLD_BUILD/resources.zip" --min-sdk-version 26 --target-sdk-version 35 --version-code 10 --version-name 1.6.1
mapfile -t DUALWORLD_JAVA_SOURCES < <(find "$DUALWORLD_REPO/android/src" -name '*.java' -type f)
java -m jdk.compiler/com.sun.tools.javac.Main -source 8 -target 8 -Xlint:-options -bootclasspath "$DUALWORLD_ANDROID_JAR" -d "$DUALWORLD_BUILD/classes" "${DUALWORLD_JAVA_SOURCES[@]}"
mapfile -t DUALWORLD_CLASS_FILES < <(find "$DUALWORLD_BUILD/classes" -name '*.class' -type f)
java -cp "$DUALWORLD_BUILD_TOOLS/lib/d8.jar" com.android.tools.r8.D8 --lib "$DUALWORLD_ANDROID_JAR" --min-api 26 --output "$DUALWORLD_BUILD/dex" "${DUALWORLD_CLASS_FILES[@]}"
cp "$DUALWORLD_BUILD/dex/classes.dex" "$DUALWORLD_BUILD/payload/classes.dex"
python3 - "$DUALWORLD_BUILD" <<'PY'
from pathlib import Path
import sys, zipfile
root = Path(sys.argv[1])
with zipfile.ZipFile(root / 'unsigned.apk', 'a', compression=zipfile.ZIP_DEFLATED) as apk:
    for entry in sorted((root / 'payload').rglob('*')):
        if entry.is_file(): apk.write(entry, str(entry.relative_to(root / 'payload')))
PY
"$DUALWORLD_BUILD_TOOLS/zipalign" -f -p 4 "$DUALWORLD_BUILD/unsigned.apk" "$DUALWORLD_BUILD/aligned.apk"
if [ ! -f "$DUALWORLD_TOOLCHAIN/dualworld-debug.keystore" ]; then
  "$DUALWORLD_JAVA_BIN/keytool" -genkeypair -keystore "$DUALWORLD_TOOLCHAIN/dualworld-debug.keystore" -alias dualworld-debug -storepass android -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=Dualworld Development' -noprompt
  chmod 600 "$DUALWORLD_TOOLCHAIN/dualworld-debug.keystore"
fi
"$DUALWORLD_BUILD_TOOLS/apksigner" sign --ks "$DUALWORLD_TOOLCHAIN/dualworld-debug.keystore" --ks-key-alias dualworld-debug --ks-pass pass:android --key-pass pass:android --out "$DUALWORLD_APK" "$DUALWORLD_BUILD/aligned.apk"
"$DUALWORLD_BUILD_TOOLS/apksigner" verify --verbose "$DUALWORLD_APK"
(cd "$DUALWORLD_REPO/dist" && sha256sum dualworld-android.apk > dualworld-android.apk.sha256)
mkdir -p "$DUALWORLD_REPO/dist/web/downloads"
cp "$DUALWORLD_APK" "$DUALWORLD_REPO/dist/web/downloads/dualworld-android.apk"
cp "$DUALWORLD_APK.sha256" "$DUALWORLD_REPO/dist/web/downloads/dualworld-android.apk.sha256"
echo "APK Android siap: $DUALWORLD_APK"
