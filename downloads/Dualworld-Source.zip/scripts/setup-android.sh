#!/usr/bin/env bash
set -euo pipefail
DUALWORLD_REPO="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
DUALWORLD_TOOLCHAIN="${DUALWORLD_TOOLCHAIN_DIR:-$DUALWORLD_REPO/../.dualworld-toolchain}"
mkdir -p "$DUALWORLD_TOOLCHAIN/downloads" "$DUALWORLD_TOOLCHAIN/android-sdk"
python3 - <<'PY'
import subprocess
modules = subprocess.check_output(['java', '--list-modules'], text=True)
if not any(line.startswith('jdk.compiler@') for line in modules.splitlines()):
    raise SystemExit('Java dengan modul jdk.compiler diperlukan.')
PY
python3 - "$DUALWORLD_TOOLCHAIN" <<'PY'
import hashlib, pathlib, subprocess, sys, tempfile, zipfile, shutil
root = pathlib.Path(sys.argv[1]).resolve()
packages = [
    ('build-tools_r35_linux.zip', 'bd3a4966912eb8b30ed0d00b0cda6b6543b949d5ffe00bea54c04c81e1561d88', 'build-tools/35.0.0'),
    ('platform-35_r02.zip', '0988cacad01b38a18a47bac14a0695f246bc76c1b06c0eeb8eb0dc825ab0c8e0', 'platforms/android-35'),
]
for name, expected, destination in packages:
    archive = root / 'downloads' / name
    if not archive.exists():
        partial = archive.with_suffix('.partial')
        subprocess.run(['curl', '--fail', '--location', '--silent', '--show-error', '--retry', '3',
                        'https://dl.google.com/android/repository/' + name, '-o', str(partial)], check=True)
        partial.rename(archive)
    actual = hashlib.sha256(archive.read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit('Checksum Android SDK tidak cocok: ' + name + '. Hapus arsip ini dan jalankan ulang.')
    target = root / 'android-sdk' / destination
    if target.exists():
        print('Android SDK tersedia:', destination)
        continue
    with tempfile.TemporaryDirectory(dir=root) as temporary:
        with zipfile.ZipFile(archive) as package:
            # Archives are pinned to a verified checksum before extraction.
            subprocess.run(['unzip', '-q', str(archive), '-d', temporary], check=True)
        directories = list(pathlib.Path(temporary).iterdir())
        if len(directories) != 1 or not directories[0].is_dir():
            raise SystemExit('Struktur Android SDK tidak dikenali: ' + name)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(directories[0]), str(target))
    print('Android SDK disiapkan:', destination)
PY
