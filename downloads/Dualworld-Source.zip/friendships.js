import { AVATARS, avatar, profileFields } from './people.js';
import { createCommunication } from './communication.js';
const $ = id => document.getElementById(id);
export const friendshipId = (a,b) => [a,b].sort().join('~');
export function createSocial({ session, name, consent, feedback, prepareRoom, startGps, stopGps, showFriend, getOwnPosition }) {
  let watches=[], friends=new Map(), selected=localStorage.getItem('dualworld-selected-friend'), selfPair='', syncing=false, enabled=true;
  const profile = () => ({ ...profileFields(name()), searchName:name().normalize('NFKC').toLowerCase(), handle:'dw-'+session().uid });
  const comm = createCommunication({ session, friends:()=>friends, consent, feedback, blockUser });
  const locateRef = (p,uid,kind='locations') => session().firebase.ref(session().db,`pairs/${p}/${kind}/${uid}`);
  async function save() {
    const {firebase:f,db,uid}=session(); if(!uid || !localStorage.getItem('dualworld-profile-complete')) return;
    try {
      if(localStorage.getItem('dualworld-discoverable')==='false') await f.remove(f.ref(db,`publicProfiles/${uid}`));
      else await f.set(f.ref(db,`publicProfiles/${uid}`),profile());
      await Promise.all([...friends.values()].map(friend=>f.set(f.ref(db,`friendships/${friend.edge}/profiles/${uid}`),profileFields(name()))));
      $('people-status').textContent='Cari nama atau ID teman. Pertemanan tetap tersimpan sampai dihapus.';
    } catch { $('people-status').textContent='Fitur teman/chat memerlukan aturan server versi terbaru. Pemilik aplikasi perlu menerbitkannya satu kali.'; }
  }
  function selectedView() {
    const friend=friends.get(selected);
    if(friend) showFriend({...friend.profile,uid:friend.uid},friend.location,friend.presence); else showFriend(null,null,null);
  }
  function select(target){selected=target;localStorage.setItem('dualworld-selected-friend',target||'');for(const friend of friends.values())friend.refreshPosition?.();selectedView();render();}
  function render() {
    const list=$('friends-list'); list.replaceChildren();
    const uid=session().uid;
    for(const friend of friends.values()) {
      const row=document.createElement('div');row.className='friend-row';
      const title=document.createElement('button');title.className='friend-title';title.textContent=`${friend.profile.avatar || '🌙'} ${friend.profile.name || 'Teman'}${selected===friend.uid?' · dipilih':''}`;
      title.onclick=()=>{select(friend.uid);$('people-dialog').close();};
      const id=document.createElement('small');id.textContent=friend.profile.handle || 'dw-'+friend.uid;
      const buttons=document.createElement('div');buttons.className='friend-actions';
      const chat=document.createElement('button');chat.className='secondary-button';chat.textContent='Chat';chat.onclick=()=>comm.open(friend);
      const sharing=document.createElement('button');sharing.className='secondary-button';sharing.textContent=friend.sharing[uid]?'Berhenti berbagi':'Bagikan lokasi';sharing.setAttribute('aria-pressed',String(Boolean(friend.sharing[uid])));sharing.onclick=()=>void toggle(friend.uid);
      const remove=document.createElement('button');remove.className='text-button';remove.textContent='Hapus teman';remove.onclick=()=>void removeFriend(friend);
      const block=document.createElement('button');block.className='text-button';block.textContent='Blokir';block.onclick=()=>void removeFriend(friend,true);
      buttons.append(chat,sharing,remove,block);row.append(title,id,buttons);list.append(row);
    }
    $('friends-empty').hidden=Boolean(friends.size);
    selectedView();
  }
  async function blockUser(target){
    const friend=friends.get(target);if(friend){await removeFriend(friend,true);return;}
    if(!await consent('Blokir pengguna ini?', 'Pesannya disembunyikan di chat global dan permintaan pertemanannya ditolak.', 'BLOKIR'))return;
    const {firebase:f,db,uid}=session();await f.set(f.ref(db,`blockedUsers/${uid}/${target}`),true).catch(()=>feedback('Belum dapat memblokir.'));
  }
  async function removeFriend(friend,block=false) {
    if(!await consent(block?'Blokir '+friend.profile.name+'?':'Hapus pertemanan?', 'Akses lokasi dan percakapan ini berakhir. Untuk berteman lagi diperlukan permintaan baru.',block?'BLOKIR':'HAPUS TEMAN'))return;
    const {firebase:f,db,uid}=session();
    try {
      if(block) await f.set(f.ref(db,`blockedUsers/${uid}/${friend.uid}`),true);
      await f.update(f.ref(db),{[`friendships/${friend.edge}`]:null,[`friendIndex/${uid}/${friend.uid}`]:null,[`friendIndex/${friend.uid}/${uid}`]:null});
      if(![...friends.values()].some(v=>v.uid!==friend.uid&&v.sharing[uid])) await stopGps();
    } catch { feedback('Belum dapat menghapus pertemanan. Periksa internet.'); }
  }
  async function toggle(target=selected) {
    const friend=friends.get(target);if(!friend){$('people-dialog').showModal();feedback('Pilih teman yang akan menerima lokasi.');return;}
    const {firebase:f,db,uid}=session();const next=!friend.sharing[uid];
    if(next && !await consent('Bagikan lokasi ke '+friend.profile.name+'?', 'Lokasi dapat diperbarui saat layar terkunci dengan notifikasi. Teman lain tidak otomatis mendapat izin.', 'BAGIKAN'))return;
    try {
      if(next) {
        localStorage.setItem('dualworld-sharing-consent','yes');
        await f.set(f.ref(db,`friendships/${friend.edge}/livePairId/${uid}`),selfPair);
        await f.set(f.ref(db,`friendships/${friend.edge}/sharing/${uid}`),true);
        localStorage.setItem('dualworld-sharing-consent','yes');await startGps();
      } else {
        if(![...friends.values()].some(v=>v.uid!==target&&v.sharing[uid])){localStorage.setItem('dualworld-sharing-consent','paused');void stopGps();}
        await f.set(f.ref(db,`friendships/${friend.edge}/sharing/${uid}`),false);
        if(![...friends.values()].some(v=>v.uid!==target&&v.sharing[uid]))await stopGps();
      }
      feedback(next?'Lokasi dibagikan hanya ke teman yang Anda pilih.':'Berbagi lokasi dihentikan; pertemanan tetap tersimpan.');
    }catch{feedback('Izin lokasi belum dapat diperbarui. Periksa internet.');}
  }
  async function stopAll() {
    const {firebase:f,db,uid}=session();
    localStorage.setItem('dualworld-sharing-consent','paused');
    const pause=stopGps();
    await Promise.all([pause,...[...friends.values()].filter(v=>v.sharing[uid]).map(v=>f.set(f.ref(db,`friendships/${v.edge}/sharing/${uid}`),false))]);
  }
  function watchFriend(target,edge) {
    const {firebase:f,db,uid}=session();const friend={uid:target,edge,profile:{name:'Teman',avatar:'🌙'},sharing:{},firstSharing:true,livePairs:{},watches:[],positionWatches:[]};friends.set(target,friend);
    f.get(f.ref(db,`publicProfiles/${target}`)).then(s=>{if(s.exists()){friend.profile=s.val();render();}}).catch(()=>{});
    const positions=()=>{
      const key=selected===target&&friend.sharing[target]&&friend.livePairs[target]?friend.livePairs[target]:'';
      if(friend.positionKey===key){render();return;}friend.positionKey=key;
      for(const close of friend.positionWatches)close();friend.positionWatches=[];friend.location=null;friend.presence=null;
      if(key) {
        friend.positionWatches.push(f.onValue(locateRef(friend.livePairs[target],target),s=>{friend.location=s.val();if(selected===target)selectedView();},()=>{friend.location=null;selectedView();}));
        friend.positionWatches.push(f.onValue(locateRef(friend.livePairs[target],target,'presence'),s=>{friend.presence=s.val();if(selected===target)selectedView();},()=>{friend.presence=null;selectedView();}));
      }
      render();
    };
    friend.refreshPosition=positions;
    friend.watches.push(f.onValue(f.ref(db,`friendships/${edge}/profiles/${target}`),s=>{if(s.exists()){friend.profile={...friend.profile,...s.val()};render();}},()=>{}));
    friend.watches.push(f.onValue(f.ref(db,`friendships/${edge}/livePairId`),s=>{friend.livePairs=s.val()||{};positions();},()=>{}));
    friend.watches.push(f.onValue(f.ref(db,`friendships/${edge}/sharing`),s=>{
      friend.sharing=s.val()||{};positions();
      if(friend.firstSharing){friend.firstSharing=false;if(friend.sharing[uid]&&localStorage.getItem('dualworld-sharing-consent')==='paused')void f.set(f.ref(db,`friendships/${edge}/sharing/${uid}`),false).catch(()=>{});}
      if(enabled&&friend.sharing[uid]&&localStorage.getItem('dualworld-sharing-consent')!=='paused')void startGps();
    },()=>{}));
    
    void f.set(f.ref(db,`friendships/${edge}/profiles/${uid}`),profileFields(name())).catch(()=>{});
    void f.set(f.ref(db,`friendships/${edge}/livePairId/${uid}`),selfPair).then(async()=>{if(localStorage.getItem('dualworld-migration-share-target')===target){if(localStorage.getItem('dualworld-sharing-consent')==='yes')await f.set(f.ref(db,`friendships/${edge}/sharing/${uid}`),true);localStorage.removeItem('dualworld-migration-share-target');}}).catch(()=>{});
    if(!selected)select(target);else render();
  }
  async function accept(target) {
    const {firebase:f,db,uid}=session(); const edge=friendshipId(uid,target);
    await f.update(f.ref(db),{[`friendships/${edge}`]:{a:uid,b:target,members:{[uid]:true,[target]:true},profiles:{[uid]:profileFields(name())},createdAt:f.serverTimestamp()},[`friendIndex/${uid}/${target}`]:edge,[`friendIndex/${target}/${uid}`]:edge,[`friendRequests/${uid}/${target}`]:null,[`friendOutbox/${target}/${uid}`]:null});
  }
  async function search() {
    const {firebase:f,db,uid}=session();if(!uid)return;
    const raw=$('people-query').value.trim();const prefix=raw.startsWith('dw-')?raw:raw.normalize('NFKC').toLowerCase();if(prefix.length<2){feedback('Ketik minimal dua karakter nama atau ID.');return;}
    $('people-results').replaceChildren();$('people-status').textContent='Mencari…';
    try {
      const snapshot=await f.get(f.query(f.ref(db,'publicProfiles'),f.orderByChild(prefix.startsWith('dw-')?'handle':'searchName'),f.startAt(prefix),f.endAt(prefix+'\uf8ff'),f.limitToFirst(12)));
      snapshot.forEach(child=>{
        if(child.key===uid)return;const p=child.val();const row=document.createElement('button');row.className='nearby-place-item';row.textContent=`${p.avatar} ${p.name} · ${p.handle}${friends.has(child.key)?' · SUDAH BERTEMAN':''}`;
        row.onclick=async()=>{
          if(friends.has(child.key)){select(child.key);return;}
          if(!await consent('Tambah '+p.name+' sebagai teman?', 'Ia perlu menerima permintaan Anda. Lokasi hanya dibagikan jika Anda menyalakannya.', 'TAMBAH TEMAN'))return;
          try{await f.update(f.ref(db),{[`friendRequests/${child.key}/${uid}`]:{createdAt:f.serverTimestamp()},[`friendOutbox/${uid}/${child.key}`]:f.serverTimestamp()});feedback('Permintaan pertemanan dikirim.');}catch{feedback('Permintaan tidak dapat dikirim. Periksa koneksi; pengguna mungkin membatasi permintaan.');}
        };$('people-results').append(row);
      });$('people-status').textContent=$('people-results').childElementCount?'Pilih teman yang Anda kenal; nama/ID bukan bukti identitas.':'Belum ditemukan. Coba nama atau ID lengkap.';
    }catch{feedback('Pencarian belum tersedia. Pemilik perlu menerbitkan aturan server terbaru.');}
  }
  async function start() {
    stop();enabled=true;const {firebase:f,db,uid}=session();if(!uid)return;
    $('people-search-button').disabled=false;$('own-user-id').textContent=profile().handle;
    $('copy-user-id').onclick=async()=>{try{if(window.DualworldAndroid?.copyInvite)window.DualworldAndroid.copyInvite(profile().handle);else await navigator.clipboard.writeText(profile().handle);feedback('ID disalin.');}catch{feedback('ID: '+profile().handle);}};
    selfPair=await prepareRoom(); if(!selfPair)return; await save();
    watches.push(f.onValue(f.ref(db,`friendIndex/${uid}`),s=>{
      const entries=s.val()||{};
      for(const [target,friend] of friends)if(entries[target]!==friend.edge){friend.watches.concat(friend.positionWatches).forEach(close=>close());friends.delete(target);if(selected===target)selected=null;comm.friendRemoved(friend.edge);}
      for(const [target,edge] of Object.entries(entries))if(!friends.has(target))watchFriend(target,edge);
      if(!friends.has(selected))select(friends.keys().next().value||null);else render();
    },()=>feedback('Daftar teman memerlukan aturan Firebase terbaru.')));
    watches.push(f.onValue(f.ref(db,`friendRequests/${uid}`),s=>{
      const list=$('people-inbox');list.replaceChildren();$('people-badge').hidden=!s.exists();
      s.forEach(child=>{
        const row=document.createElement('div');row.className='connection-request';const title=document.createElement('strong');title.textContent='Permintaan pertemanan';
        f.get(f.ref(db,`publicProfiles/${child.key}`)).then(p=>{if(p.exists())title.textContent=`${p.val().avatar} ${p.val().name}`;}).catch(()=>{});
        const yes=document.createElement('button');yes.className='secondary-button';yes.textContent='TERIMA';yes.onclick=async()=>{if(!await consent('Berteman dengan '+title.textContent+'?', 'Pertemanan tersimpan. Anda dapat memilih berbagi lokasi atau tetap pribadi.', 'TERIMA TEMAN'))return;try{await accept(child.key);feedback('Berteman. Pilih Bagikan lokasi jika ingin mengaktifkannya.');}catch{feedback('Permintaan belum dapat diterima.');}};
        const no=document.createElement('button');no.className='text-button';no.textContent='TOLAK';no.onclick=()=>f.update(f.ref(db),{[`friendRequests/${uid}/${child.key}`]:null,[`friendOutbox/${child.key}/${uid}`]:null}).catch(()=>feedback('Belum dapat menolak.'));row.append(title,yes,no);list.append(row);
      });
    },()=>{}));
    await comm.start();
  }
  function stop(){enabled=false;watches.forEach(close=>close());watches=[];for(const friend of friends.values())friend.watches.concat(friend.positionWatches).forEach(close=>close());friends.clear();comm.stop();}
  async function erase(){const {firebase:f,db,uid}=session();await stopAll();await comm.erase();for(const friend of [...friends.values()])await f.update(f.ref(db),{[`friendships/${friend.edge}`]:null,[`friendIndex/${uid}/${friend.uid}`]:null,[`friendIndex/${friend.uid}/${uid}`]:null});const outgoing=(await f.get(f.ref(db,`friendOutbox/${uid}`))).val()||{};for(const target of Object.keys(outgoing))await f.remove(f.ref(db,`friendRequests/${target}/${uid}`));await f.remove(f.ref(db,`friendOutbox/${uid}`));const incoming=(await f.get(f.ref(db,`friendRequests/${uid}`))).val()||{};for(const sender of Object.keys(incoming))await f.remove(f.ref(db,`friendOutbox/${sender}/${uid}`));await f.remove(f.ref(db,`friendRequests/${uid}`));await f.remove(f.ref(db,`blockedUsers/${uid}`));}
  $('people-search-button').onclick=()=>void search();$('people-query').onkeydown=e=>{if(e.key==='Enter')void search();};$('people-button').onclick=()=>$('people-dialog').showModal();
  return {start,save,stop,erase,toggle,begin:()=>friends.get(selected)?.sharing[session().uid]?startGps():toggle(),stopAll,hasFriends:()=>friends.size>0};
}
