import { isFreshLocation } from './location-quality.js';
import { osmDetails, elementName } from './map-data.js';
const $ = id => document.getElementById(id);
const rasterStyle = () => ({ version: 8, sources: {
  streets: { type: 'raster', tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'], tileSize: 256, maxzoom: 19, attribution: '© OpenStreetMap contributors' }
}, layers: [{ id: 'streets', type: 'raster', source: 'streets' }] });
export function createThreeD({ getLocations, onPlace }) {
  let view, library, generation = 0, timer, lastPoint, lastZoom;
  let terrain = true, buildings = true, terrainAvailable = true, fallback = false;
  const pins = new Map(), dialog = $('three-d-dialog');
  function syncLocations() {
    if (!view || !library || !dialog.open) return;
    const locations = getLocations();
    for (const kind of ['own', 'partner']) {
      const value = locations[kind]; let pin = pins.get(kind);
      if (!value?.coords) { pin?.remove(); pins.delete(kind); continue; }
      if (!pin) {
        const element = document.createElement('div'); element.className = `three-d-person ${kind}`;
        const title = document.createElement('span'); title.textContent = value.name; element.append(title);
        pin = new library.Marker({ element }).setLngLat([value.coords.lng, value.coords.lat]).addTo(view); pins.set(kind, pin);
      }
      pin.setLngLat([value.coords.lng, value.coords.lat]);
      pin.getElement().querySelector('span').textContent = value.name;
      pin.getElement().classList.toggle('location-stale-pin', !isFreshLocation(value.coords));
    }
  }
  function applyOptions() {
    if (!view?.getStyle()) return;
    for (const layer of ['building-3d', 'local-buildings']) if (view.getLayer(layer)) view.setLayoutProperty(layer, 'visibility', buildings ? 'visible' : 'none');
    if (view.getLayer('building')) view.setLayoutProperty('building', 'visibility', buildings ? 'none' : 'visible');
    if (view.getSource('dualworld-elevation')) view.setTerrain(terrain && terrainAvailable ? { source: 'dualworld-elevation', exaggeration: 1 } : null);
    $('three-d-terrain-button').textContent = terrain && terrainAvailable ? 'MEDAN AKTIF' : 'MEDAN MATI';
    $('three-d-terrain-button').setAttribute('aria-pressed', String(terrain && terrainAvailable));
    $('three-d-buildings-button').textContent = buildings ? 'BANGUNAN AKTIF' : 'BANGUNAN MATI';
    $('three-d-buildings-button').setAttribute('aria-pressed', String(buildings));
  }
  async function localBuildings(current) {
    try {
      const { elements } = await osmDetails(lastPoint, Math.max(17, lastZoom));
      if (current !== generation || !view || !fallback) return;
      const features = elements.filter(e => e.tags?.building && e.geometry?.length >= 3).slice(0, 600).map(e => {
        const points = e.geometry.filter(p => Number.isFinite(p.lat) && Number.isFinite(p.lon)).map(p => [p.lon, p.lat]);
        if (points.length < 3) return null;
        if (String(points[0]) !== String(points[points.length - 1])) points.push(points[0]);
        const height = Number.parseFloat(e.tags.height), levels = Number.parseFloat(e.tags['building:levels']);
        return { type: 'Feature', properties: { name: elementName(e), height: Math.min(300, Math.max(2, height || levels * 3 || 8)), estimated: !height }, geometry: { type: 'Polygon', coordinates: [points] } };
      }).filter(Boolean);
      view.addSource('local-buildings', { type: 'geojson', data: { type: 'FeatureCollection', features }, attribution: 'Buildings © OpenStreetMap contributors' });
      view.addLayer({ id: 'local-buildings', type: 'fill-extrusion', source: 'local-buildings', paint: { 'fill-extrusion-color': '#94c5bb', 'fill-extrusion-height': ['get', 'height'], 'fill-extrusion-opacity': .8 } });
      applyOptions();
    } catch { if (current === generation) $('three-d-status').textContent = 'Peta jalan tetap tersedia. Data bangunan tambahan belum dapat dimuat.'; }
  }
  async function open(point, zoom) {
    lastPoint = { lat: point.lat, lng: point.lng }; lastZoom = zoom;
    const current = ++generation; clearTimeout(timer);
    $('three-d-status').textContent = 'Memuat peta dan model bangunan…';
    try {
      if (!library) { const module = await import('maplibre-gl'); library = module.default || module; library.setWorkerUrl(new URL('./vendor/maplibre/worker.js', document.baseURI).href); library.setWorkerCount(2); }
      let style;
      const controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 8000);
      try {
        const response = await fetch('https://tiles.openfreemap.org/styles/liberty', { signal: controller.signal });
        if (!response.ok) throw new Error('Style unavailable');
        style = await response.json(); fallback = false;
      } catch { style = rasterStyle(); fallback = true; }
      finally { clearTimeout(timeout); }
      if (current !== generation || !dialog.open) return;
      view?.remove(); pins.clear(); $('three-d-canvas').replaceChildren(); terrainAvailable = true;
      view = new library.Map({ container: 'three-d-canvas', style, center: [point.lng, point.lat], zoom: Math.min(19, zoom), pitch: 55, bearing: -15, maxZoom: 20, maxPitch: 75, pixelRatio: Math.min(2, devicePixelRatio), attributionControl: { compact: true } });
      view.addControl(new library.NavigationControl({ visualizePitch: true }), 'top-right');
      const switchToRaster = () => {
        if (current !== generation || fallback || !view) return;
        fallback = true; terrainAvailable = true;
        $('three-d-status').textContent = 'Sumber model belum merespons. Memuat peta jalan cadangan…';
        view.setStyle(rasterStyle());
      };
      // A marker alone is not a loaded basemap. Recover if vector tiles never arrive.
      timer = setTimeout(() => {
        const sources = Object.entries(view?.getStyle()?.sources || {}).filter(([, s]) => s.type === 'vector');
        if (sources.length && !sources.some(([id]) => view.isSourceLoaded(id))) switchToRaster();
      }, 12000);
      view.on('style.load', () => {
        if (current !== generation) return;
        view.addSource('dualworld-elevation', { type: 'raster-dem', tiles: ['https://elevation-tiles-prod.s3.amazonaws.com/terrarium/{z}/{x}/{y}.png'], encoding: 'terrarium', tileSize: 256, maxzoom: 15, attribution: 'Elevation © AWS Terrain Tiles / Mapzen' });
        applyOptions(); syncLocations(); view.resize();
        if (fallback) void localBuildings(current);
        view.once('idle', () => { if (current === generation) $('three-d-status').textContent = fallback ? 'Peta cadangan aktif. Bentuk bangunan mengikuti data OSM; tinggi yang tidak tercatat diperkirakan.' : 'Model siap. Bangunan mengikuti data OpenStreetMap setempat.'; });
      });
      view.on('click', event => {
        const layers = ['building', 'building-3d', 'local-buildings'].filter(id => view.getLayer(id));
        const feature = layers.length ? view.queryRenderedFeatures(event.point, { layers })[0] : null;
        if (feature) onPlace({ lat: event.lngLat.lat, lng: event.lngLat.lng, name: feature.properties?.name || 'Bangunan pada model', note: 'Model OpenStreetMap; tinggi dapat berupa perkiraan. Foto dan panorama dicari terpisah.', tags: { building: 'yes' } });
      });
      view.on('error', event => {
        if (current !== generation) return;
        if (event.sourceId === 'dualworld-elevation' || /elevation-tiles/.test(event.error?.message || '')) {
          terrainAvailable = false; applyOptions(); if (view.getSource('dualworld-elevation')) view.removeSource('dualworld-elevation'); $('three-d-status').textContent = 'Elevasi belum tersedia. Peta dan bangunan tetap dapat digunakan.';
        } else if (!fallback) switchToRaster();
        else $('three-d-status').textContent = 'Peta belum dapat dimuat. Tekan Muat ulang atau kembali ke peta jalan.';
      });
      view.on('webglcontextlost', () => { $('three-d-status').textContent = 'Grafis 3D dihentikan oleh HP. Tekan Kembali ke peta jalan.'; });
    } catch { $('three-d-status').textContent = 'Grafis 3D belum didukung di HP ini. Tekan Kembali ke peta jalan untuk melanjutkan.'; }
  }
  $('three-d-terrain-button').addEventListener('click', () => { terrain = !terrain; applyOptions(); });
  $('three-d-buildings-button').addEventListener('click', () => { buildings = !buildings; applyOptions(); });
  $('three-d-reset-button').addEventListener('click', () => view?.easeTo({ pitch: 55, bearing: -15, duration: 500 }));
  $('three-d-retry-button').addEventListener('click', () => { if (lastPoint) void open(lastPoint, lastZoom); });
  $('three-d-back-button').addEventListener('click', () => dialog.close());
  dialog.addEventListener('close', () => { generation++; clearTimeout(timer); view?.remove(); view = null; pins.clear(); });
  return { open, syncLocations };
}
