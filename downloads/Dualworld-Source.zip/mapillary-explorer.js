// Mapillary street photographs are a separate data source from the live GPS pins.
import { publicJson } from './map-data.js';
const $ = id => document.getElementById(id);
function distance(a, b) {
  const rad = Math.PI / 180, dLat = (b.lat-a.lat)*rad, dLng = (b.lng-a.lng)*rad;
  const value = Math.sin(dLat/2)**2 + Math.cos(a.lat*rad)*Math.cos(b.lat*rad)*Math.sin(dLng/2)**2;
  return 6371000 * 2 * Math.atan2(Math.sqrt(value), Math.sqrt(Math.max(0, 1-value)));
}
export function createStreetExplorer({ onCoverage, onConfigure }) {
  const dialog = $('street-dialog');
  let viewer, library, config, point;
  let generation = 0, imageGeneration = 0;
  let panoOnly = true, images = [];
  let nextRequestAt = 0;
  function status(text) { $('street-status').textContent = text; }
  function destroyViewer() { viewer?.remove(); viewer = null; $('street-canvas').replaceChildren(); $('street-canvas').hidden = true; }
  function caption(image) {
    const pano = image.cameraType === 'spherical';
    status(`${pano ? 'Panorama 360°' : 'Foto jalan · sudut terbatas'} · ${image.capturedAt ? new Date(image.capturedAt).toLocaleDateString('id-ID') : 'Tanggal belum tersedia'} · ${image.creatorUsername || 'Kontributor Mapillary'} · Foto rekaman, bukan kondisi saat ini.`);
  }
  async function showImage(image, current = generation) {
    const request = ++imageGeneration;
    status('Membuka foto jalan…');
    try {
      if (!library) library = await import('mapillary-js');
      if (current !== generation || request !== imageGeneration || !dialog.open) return;
      if (!viewer) {
        $('street-canvas').hidden = false;
        viewer = new library.Viewer({ container: 'street-canvas', accessToken: config.mapillaryClientToken, component: { cover: false }, trackResize: true });
        viewer.on('image', event => { if (dialog.open && event.image) caption(event.image); });
      }
      await viewer.setFilter(panoOnly ? ['==', 'cameraType', 'spherical'] : null);
      if (current !== generation || request !== imageGeneration || !dialog.open) return;
      const photograph = await viewer.moveTo(image.id);
      if (current !== generation || request !== imageGeneration || !dialog.open) return;
      viewer.resize(); caption(photograph);
    } catch {
      if (current !== generation || request !== imageGeneration || !dialog.open) return;
      destroyViewer(); status('Foto belum dapat dimuat. Periksa token, internet, atau dukungan grafis HP. Pilih titik foto lain dari daftar.');
    }
  }
  function renderList() {
    const list = $('street-image-list'); list.replaceChildren();
    const visible = images.filter(image => !panoOnly || image.is_pano);
    for (const image of visible.slice(0, 20)) {
      const button = document.createElement('button'); button.className = 'nearby-place-item';
      const title = document.createElement('strong'); title.textContent = `${image.is_pano ? '360°' : 'FOTO'} · ${Math.round(image.distance)} m dari titik pilihan`;
      const detail = document.createElement('small'); detail.textContent = `Rekaman ${image.captured_at ? new Date(image.captured_at).toLocaleDateString('id-ID') : 'tanggal belum tersedia'} · ${image.creator?.username || 'Kontributor Mapillary'}`;
      button.append(title, detail); button.addEventListener('click', () => void showImage(image)); list.append(button);
    }
    $('street-pano-only').setAttribute('aria-pressed', String(panoOnly)); $('street-all-images').setAttribute('aria-pressed', String(!panoOnly));
    return visible;
  }
  function selectType(onlyPanoramas) {
    panoOnly = onlyPanoramas; imageGeneration++; destroyViewer();
    const visible = renderList();
    if (visible.length) void showImage(visible[0]);
    else status(panoOnly && images.length ? 'Belum ditemukan panorama 360° pada titik ini. Pilih Semua foto jalan untuk foto biasa yang tersedia.' : 'Belum ditemukan foto jalan dalam 500 m. Kembali ke peta, pilih jalan lain, lalu buka tampilan jalan lagi.');
  }
  async function search() {
    if (!config?.mapillaryClientToken || !point) return;
    if (Date.now() < nextRequestAt) { status('Tunggu beberapa detik sebelum mencari ulang agar layanan tidak dibanjiri.'); return; }
    nextRequestAt = Date.now() + 6000;
    const current = ++generation; imageGeneration++; destroyViewer(); images = []; renderList();
    status('Mencari foto jalan dan panorama dalam 500 m…');
    try {
      const latRadius = .0045, lngRadius = latRadius / Math.max(.2, Math.cos(point.lat*Math.PI/180));
      const bbox = [Math.max(-180,point.lng-lngRadius),Math.max(-85,point.lat-latRadius),Math.min(180,point.lng+lngRadius),Math.min(85,point.lat+latRadius)].join(',');
      const url = new URL('https://graph.mapillary.com/images');
      url.search = new URLSearchParams({ bbox, limit: '100', fields: 'id,geometry,computed_geometry,is_pano,captured_at,creator' });
      const data = await publicJson(url, { headers: { Authorization: 'OAuth ' + config.mapillaryClientToken } });
      if (current !== generation || !dialog.open) return;
      if (!Array.isArray(data.data)) throw new Error('Invalid image metadata');
      images = data.data.map(image => {
        const coordinates = (image.computed_geometry || image.geometry)?.coordinates;
        if (!coordinates || !Number.isFinite(coordinates[0]) || !Number.isFinite(coordinates[1])) return null;
        const position = { lat: coordinates[1], lng: coordinates[0] };
        return { ...image, point: position, distance: distance(point, position) };
      }).filter(image => image && image.distance <= 500).sort((a,b) => a.distance-b.distance);
      onCoverage(images.map(image => ({ ...image.point, id: image.id, pano: image.is_pano, capturedAt: image.captured_at })));
      const visible = renderList();
      if (visible.length) await showImage(visible[0], current);
      else status(images.length ? 'Foto jalan biasa tersedia, tetapi belum ditemukan panorama 360° pada hasil area ini. Pilih Semua foto jalan.' : 'Belum ditemukan foto jalan Mapillary dalam 500 m dari titik ini. Pilih jalan lain pada peta.');
    } catch {
      if (current === generation && dialog.open) status('Penyedia foto jalan belum dapat dihubungi atau token aplikasi ditolak. Periksa internet dan Client Access Token melalui Atur sumber.');
    }
  }
  $('street-pano-only').addEventListener('click', () => selectType(true));
  $('street-all-images').addEventListener('click', () => selectType(false));
  $('street-refresh-button').addEventListener('click', () => void search());
  $('street-settings-button').addEventListener('click', () => { dialog.close(); onConfigure(); });
  dialog.addEventListener('close', () => { generation++; imageGeneration++; destroyViewer(); images = []; $('street-image-list').replaceChildren(); });
  return {
    open: async (sourceConfig, selectedPoint, imageId) => {
      config = sourceConfig; point = { lat: selectedPoint.lat, lng: selectedPoint.lng }; nextRequestAt = 0;
      if (imageId && typeof selectedPoint.pano === 'boolean') panoOnly = selectedPoint.pano;
      if (imageId) { generation++; imageGeneration++; destroyViewer(); images = []; renderList(); await showImage({ id: imageId }); }
      else await search();
    }
  };
}
