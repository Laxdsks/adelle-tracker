# Dualworld 1.6

Dualworld adalah aplikasi web/Android untuk berbagi lokasi setelah koneksi disetujui. Banyak pengguna dapat membuat profil dengan nama/avatar sendiri; gender opsional disimpan di perangkat. Setiap profil dapat berteman dengan banyak orang. Izin lokasi dipilih per teman. Peta jalan, satelit, medan, bangunan, pencarian tempat, rute mobil, foto dan panorama berada dalam panel Dualworld.

## Instalasi dan penggunaan

APK: `dist/dualworld-android.apk`, Android 8+, versi 1.6.0/versionCode 9, tanda tangan pengembangan. Pasang di atas APK lama tanpa menghapus data untuk mempertahankan profil/ruang. Konfigurasi proyek Firebase dan token klien Mapillary sudah disertakan pada build yang disiapkan untuk pengguna ini; sumber konfigurasi lokal diabaikan Git.

1. Buat nama dan pilih avatar, lalu izinkan lokasi/notifikasi sesuai pilihan Anda.
2. Tekan **♡ Teman**, cari nama teman yang sudah membuat profil, lalu kirim permintaan.
3. Penerima menekan **Terima**. Pertemanan tersimpan. Tekan **Bagikan lokasi** pada teman yang boleh melihat posisi Anda; teman lain tetap tidak mendapat akses. Mematikan lokasi tidak menghapus teman.

Pembuat aplikasi perlu menerbitkan aturan `database.rules.json` versi 1.6 satu kali untuk mengaktifkan pencarian/permintaan/presence pada proyek yang sudah ada. Pengguna tidak perlu membuat proyek atau menyalin kode. Lihat [FIREBASE_SETUP.md](FIREBASE_SETUP.md). Aturan sudah diuji di emulator; belum diterbitkan otomatis ke server produksi. Ruang lama yang telah disetujui dimigrasikan menjadi pertemanan; pilihan berbagi yang tersimpan dipertahankan. Profil menggunakan identitas Firebase Anonymous yang tersimpan di instalasi, bukan login Google/lintas perangkat.

## GPS dan latar belakang

Android menggunakan LocationManager dan foreground service dengan notifikasi Hentikan berbagi. Pilihan berbagi tersimpan saat Activity ditutup; receiver mencoba memulihkan setelah reboot bila izin/batas sistem mengizinkan. Force stop dan pembatasan baterai produsen dapat menghentikan layanan. Web memerlukan halaman aktif untuk pembaruan.

GPS diminta tiap 1 detik dan publikasi pengukuran dibatasi tiap 2 detik; sensor/internet dapat lebih lambat. Hanya bacaan baru maksimal 30 detik dan radius akurasi ≤35 m dibagikan. Penyaring menahan perubahan kecil dalam ketidakpastian GPS; dua bacaan pergerakan konsisten atau kecepatan sensor melepaskan perpindahan. Tidak ada prediksi posisi atau pemaksaan pin ke jalan. Lingkaran menunjukkan ketidakpastian, bukan lokasi rumah yang pasti.

Heartbeat online terpisah sekitar tiap 20 detik tidak memperbarui waktu GPS. Posisi lama tetap dapat dibuka dengan umur pengukurannya; status online dan umur GPS ditampilkan terpisah. HP yang benar-benar mati tidak dapat mengirim posisi baru. Stop menghapus posisi ketika server dapat dihubungi; Android menyimpan retry penghapusan jika offline. **Hapus teman** mengakhiri akses lokasi dan percakapan pertemanan itu. **Hentikan berbagi** mematikan seluruh penerima; pertemanan tetap ada. **Hapus profil dan data** menghapus lokasi pribadi, seluruh pertemanan/chat terkait, media sendiri, pesan global sendiri, profil publik, permintaan dan identitas Firebase.

## Chat dan lampiran

Buka **♡ Teman → CHAT** untuk percakapan pribadi. Teks/emoji, foto JPG/PNG/WebP, berkas maksimum 2 MiB, dan VN maksimum 60 detik tersedia. Foto dikecilkan menjadi sisi maksimum 1280 px; lampiran hanya diunduh ketika diketuk. Android meminta mikrofon hanya saat merekam VN, memakai pemilih berkas sistem untuk foto/file dan dialog Simpan untuk unduhan. Menutup chat atau membawa aplikasi ke latar membatalkan rekaman yang belum dikirim dan melepaskan mikrofon. Fitur telepon/video call dikeluarkan sesuai permintaan; TURN tidak diperlukan.

**CHAT GLOBAL** hanya menyediakan teks/emoji (500 karakter), tanpa foto, file atau VN. Tampilan memuat 50 pesan terakhir, dengan batas kirim per identitas di aturan server. Pengguna dapat melaporkan dan memblokir pengirim; laporan masuk `reports` untuk ditinjau pemilik proyek, bukan layanan moderasi otomatis.

Chat/media memakai HTTPS/WSS dan aturan Firebase per pertemanan. Ini **bukan enkripsi end-to-end**: pemilik proyek Firebase memiliki akses administratif. File tidak dieksekusi/ditampilkan sebagai HTML; jenis gambar aktif seperti SVG ditolak. Pertemanan baru memiliki waktu pembuatan sendiri sehingga media lama tidak menjadi dapat dibaca setelah hubungan dihapus dan dibuat ulang. Lampiran disimpan terpisah dalam RTDB; server tidak melakukan pemindaian malware. Jangan membuka berkas dari pengirim yang tidak dipercaya.

Riwayat tersimpan di server sampai dihapus: menghapus teman menghapus percakapan tersebut dan mencabut akses media; media milik pengirim dihapus melalui Hapus profil. Data tidak otomatis dibersihkan karena hanya 50 pesan ditampilkan. Pemilik harus mengatur retensi, moderasi dan kuota sebelum rilis publik. Firebase Spark membatasi penyimpanan, bandwidth serta koneksi; penggunaan media ramai dapat melampaui kuota, meskipun tidak memakai billing Google Maps.

## Peta dan performa

Mapillary menyediakan foto jalan/panorama; peta dasar memakai OSM/Esri dan model OpenFreeMap/OSM. Model 3D bukan foto 360°. Panel 3D memiliki worker lokal yang dibundel, peta raster/ekstrusi bangunan cadangan jika sumber vektor gagal, dan mematikan elevasi gagal agar peta tetap dapat digunakan. Data rekaman/citra dan cakupannya mengikuti penyedia; area Dompu/Woja yang diperiksa belum menyediakan foto jalan. Tidak ada billing Google Maps pada konfigurasi ini. Lihat [MAPS_SETUP.md](MAPS_SETUP.md).

Panel layar sentuh menggunakan warna solid tanpa blur di atas peta. Geometri memakai renderer canvas; label tambahan diberi jarak dan dibatasi. Pemuatan detail ditunda sampai geser selesai, memakai cache area dan jeda permintaan. Pin diam tidak menjalankan animasi perpindahan. Pada versi teman, hanya lokasi teman yang dipilih di peta yang dilanggan; berpindah teman melepas langganan lokasi sebelumnya. Satelit memakai canvas retina 512 px bila detail tile anak tersedia dan zoom dibatasi saat mencapai resolusi asli. Ini tidak membuat citra baru atau meningkatkan detail yang tidak tersedia dari penyedia. Awalan Leaflet dihilangkan; atribusi sumber tetap tampil.

## Pengembangan cloud

```sh
bash scripts/setup-cloud.sh
npm start
```

Gunakan checkout ini tanpa worktree baru. Skrip memakai `npm ci` dari lockfile, aset lokal dan lisensi, Android SDK 35 yang diverifikasi checksum, compiler JDK, d8/aapt2, serta penandatanganan APK. Prasyarat: Node 20+, npm, JDK 17+, Python 3, curl, unzip. SDK/cache/keystore ada di `../.dualworld-toolchain`; jangan mengganti `dualworld-debug.keystore` agar pembaruan APK memakai sertifikat yang sama. Default cache npm dapat tidak writable; gunakan `npm --cache /workspace/.dualworld-toolchain/npm-cache`.

Web disajikan dari `dist/web` pada loopback untuk pengembangan. Proses server tidak bertahan setelah snapshot; mulai lagi dengan `npm start`. Publikasi lingkungan cloud bukan deploy website atau pembaruan APK pada HP.

```sh
npm run build
npm run check
npm run test:location
npm run test:rules
npm run test:pairing
npm test
npm run test:maps
npm run android:build
```

Tes GPS mencakup drift diam, spike, bacaan kasar/lama/masa depan dan gerakan konsisten. Tes aturan menggunakan RTDB emulator terverifikasi untuk isolasi lokasi/presence/ruang, direktori terbatas, undangan yang diterima dan penghapusan. Tes pairing memakai tiga storage browser, auth/GPS/provider fixture dengan RTDB/aturan asli, dua teman sekaligus, izin lokasi per teman, chat/file/foto/VN/global, laporan dan penghapusan; tes browser mencakup detail/rute internal, konfigurasi, cache/offline dan Back. Tes peta merender canvas WebGL, kegagalan sumber, geometri cadangan, retina dan batas permintaan/label pada simulasi CPU lambat. Kamera/gambar peta pada fixture bukan bukti detail daerah nyata.

Panorama Mapillary asli dan model vektor/medan OpenFreeMap di koordinat publik Singapura juga berhasil dirender melalui koneksi HTTPS terverifikasi tanpa akses Firebase produksi. GPS/latar Android dan performa di HP fisik belum diuji di lingkungan ini. Jangan klaim uji browser sebagai pengukuran ketepatan sensor fisik atau FPS HP tertentu.

## Distribusi dan Play Store

Build APK juga disalin ke `dist/web/downloads`; widget unduhan web tampil jika berkas tersedia. Web ZIP memuat antarmuka siap hosting; belum ada deploy website pada pekerjaan ini. Link APK GitHub dipatok ke commit dan diperiksa ulang checksum/signature untuk menghindari masalah unduhan artefak ChatGPT.

[privacy.html](privacy.html) menjelaskan perilaku privasi/penghapusan. [PLAY_STORE.md](PLAY_STORE.md) menjelaskan pekerjaan rilis, pemulihan akun, perlindungan penyalahgunaan dan monetisasi yang masih diperlukan. Versi pengembangan ini belum diterbitkan, belum menjadi AAB rilis, dan belum mengaktifkan iklan/pembelian.
