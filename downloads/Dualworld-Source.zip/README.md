# Dualworld 1.5

Dualworld adalah aplikasi web/Android untuk berbagi lokasi setelah koneksi disetujui. Banyak pengguna dapat membuat profil dengan nama/avatar sendiri; gender opsional disimpan di perangkat. Setiap ruang privat menghubungkan dua profil. Peta jalan, satelit, medan, bangunan, pencarian tempat, rute mobil, foto dan panorama berada dalam panel Dualworld.

## Instalasi dan penggunaan

APK: `dist/dualworld-android.apk`, Android 8+, versi 1.5.0/versionCode 8, tanda tangan pengembangan. Pasang di atas APK lama tanpa menghapus data untuk mempertahankan profil/ruang. Konfigurasi proyek Firebase dan token klien Mapillary sudah disertakan pada build yang disiapkan untuk pengguna ini; sumber konfigurasi lokal diabaikan Git.

1. Buat nama dan pilih avatar, lalu izinkan lokasi/notifikasi sesuai pilihan Anda.
2. Tekan **♡ Teman**, cari nama teman yang sudah membuat profil, lalu kirim permintaan.
3. Penerima menekan **Terima**. Lokasi mulai dibagikan sesuai persetujuan dan dapat dihentikan kapan saja.

Pembuat aplikasi perlu menerbitkan aturan `database.rules.json` versi 1.5 satu kali untuk mengaktifkan pencarian/permintaan/presence pada proyek yang sudah ada. Pengguna tidak perlu membuat proyek atau menyalin kode. Lihat [FIREBASE_SETUP.md](FIREBASE_SETUP.md). Aturan sudah diuji di emulator; belum diterbitkan otomatis ke server produksi. Undangan versi lama tetap tersedia dalam menu lanjutan. Profil menggunakan identitas Firebase Anonymous yang tersimpan di instalasi, bukan login Google/lintas perangkat.

## GPS dan latar belakang

Android menggunakan LocationManager dan foreground service dengan notifikasi Hentikan berbagi. Pilihan berbagi tersimpan saat Activity ditutup; receiver mencoba memulihkan setelah reboot bila izin/batas sistem mengizinkan. Force stop dan pembatasan baterai produsen dapat menghentikan layanan. Web memerlukan halaman aktif untuk pembaruan.

GPS diminta tiap 1 detik dan publikasi pengukuran dibatasi tiap 2 detik; sensor/internet dapat lebih lambat. Hanya bacaan baru maksimal 30 detik dan radius akurasi ≤35 m dibagikan. Penyaring menahan perubahan kecil dalam ketidakpastian GPS; dua bacaan pergerakan konsisten atau kecepatan sensor melepaskan perpindahan. Tidak ada prediksi posisi atau pemaksaan pin ke jalan. Lingkaran menunjukkan ketidakpastian, bukan lokasi rumah yang pasti.

Heartbeat online terpisah sekitar tiap 20 detik tidak memperbarui waktu GPS. Posisi lama tetap dapat dibuka dengan umur pengukurannya; status online dan umur GPS ditampilkan terpisah. HP yang benar-benar mati tidak dapat mengirim posisi baru. Stop menghapus posisi ketika server dapat dihubungi; Android menyimpan retry penghapusan jika offline. Putuskan ruang mengakhiri koneksi, dan Hapus profil dan data menghapus profil publik/permintaan/identitas Firebase.

## Peta dan performa

Mapillary menyediakan foto jalan/panorama; peta dasar memakai OSM/Esri dan model OpenFreeMap/OSM. Model 3D bukan foto 360°. Panel 3D memiliki worker lokal yang dibundel, peta raster/ekstrusi bangunan cadangan jika sumber vektor gagal, dan mematikan elevasi gagal agar peta tetap dapat digunakan. Data rekaman/citra dan cakupannya mengikuti penyedia; area Dompu/Woja yang diperiksa belum menyediakan foto jalan. Tidak ada billing Google Maps pada konfigurasi ini. Lihat [MAPS_SETUP.md](MAPS_SETUP.md).

Panel layar sentuh menggunakan warna solid tanpa blur di atas peta. Geometri memakai renderer canvas; label tambahan diberi jarak dan dibatasi. Pemuatan detail ditunda sampai geser selesai, memakai cache area dan jeda permintaan. Pin diam tidak menjalankan animasi perpindahan. Satelit memakai canvas retina 512 px bila detail tile anak tersedia dan zoom dibatasi saat mencapai resolusi asli. Ini tidak membuat citra baru atau meningkatkan detail yang tidak tersedia dari penyedia. Awalan Leaflet dihilangkan; atribusi sumber tetap tampil.

## Pengembangan cloud

```sh
bash scripts/setup-cloud.sh
npm start
```

Gunakan checkout ini tanpa worktree baru. Skrip memakai `npm ci` dari lockfile, aset lokal dan lisensi, Android SDK 35 yang diverifikasi checksum, compiler JDK, d8/aapt2, serta penandatanganan APK. Prasyarat: Node 20+, npm, JDK 17+, Python 3, curl, unzip. SDK/cache/keystore ada di `../.dualworld-toolchain`; jangan mengganti `dualworld-debug.keystore` agar pembaruan APK memakai sertifikat yang sama. Default cache npm dapat tidak writable; gunakan `npm --cache /workspace/.dualworld-toolchain/npm-cache`.

Web disajikan dari `dist/web` pada loopback untuk pengembangan. Proses server tidak bertahan setelah snapshot; mulai lagi dengan `npm start`. Publikasi lingkungan cloud bukan deploy website atau pembaruan APK pada HP.

```sh
npm run build
npm run check
npm run test:location
npm run test:rules
npm run test:pairing
npm test
npm run test:maps
npm run android:build
```

Tes GPS mencakup drift diam, spike, bacaan kasar/lama/masa depan dan gerakan konsisten. Tes aturan menggunakan RTDB emulator terverifikasi untuk isolasi lokasi/presence/ruang, direktori terbatas, undangan yang diterima dan penghapusan. Tes pairing memakai dua storage browser, auth/GPS/provider fixture dengan RTDB/aturan asli; tes browser mencakup detail/rute internal, konfigurasi, cache/offline dan Back. Tes peta merender canvas WebGL, kegagalan sumber, geometri cadangan, retina dan batas permintaan/label pada simulasi CPU lambat. Kamera/gambar peta pada fixture bukan bukti detail daerah nyata.

Panorama Mapillary asli dan model vektor/medan OpenFreeMap di koordinat publik Singapura juga berhasil dirender melalui koneksi HTTPS terverifikasi tanpa akses Firebase produksi. GPS/latar Android dan performa di HP fisik belum diuji di lingkungan ini. Jangan klaim uji browser sebagai pengukuran ketepatan sensor fisik atau FPS HP tertentu.

## Distribusi dan Play Store

Build APK juga disalin ke `dist/web/downloads`; widget unduhan web tampil jika berkas tersedia. Web ZIP memuat antarmuka siap hosting; belum ada deploy website pada pekerjaan ini. Link APK GitHub dipatok ke commit dan diperiksa ulang checksum/signature untuk menghindari masalah unduhan artefak ChatGPT.

[privacy.html](privacy.html) menjelaskan perilaku privasi/penghapusan. [PLAY_STORE.md](PLAY_STORE.md) menjelaskan pekerjaan rilis, pemulihan akun, perlindungan penyalahgunaan dan monetisasi yang masih diperlukan. Versi pengembangan ini belum diterbitkan, belum menjadi AAB rilis, dan belum mengaktifkan iklan/pembelian.
