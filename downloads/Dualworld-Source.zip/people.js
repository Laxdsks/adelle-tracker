const $ = id => document.getElementById(id);
export const AVATARS = ['🌙', '🦊', '🐼', '🦋', '🐱', '🌸', '🌊', '🚀'];
export function avatar() { const value = localStorage.getItem('dualworld-avatar'); return AVATARS.includes(value) ? value : '🌙'; }
export function profileFields(name) { return { name, avatar: avatar() }; }

export function createPeople({ session, name, createRoom, enterRoom, consent, feedback }) {
  let inboxWatch, generation = 0;
  function controls() { $('people-search-button').disabled = !session().uid; }
  async function save() {
    const { firebase: f, db, uid } = session(); if (!f || !db || !uid || !localStorage.getItem('dualworld-profile-complete')) return;
    const profile = { name: name(), searchName: name().normalize('NFKC').toLowerCase(), avatar: avatar(), handle: 'dw-' + uid.slice(-8).toLowerCase() };
    try {
      if (localStorage.getItem('dualworld-discoverable') === 'false') await f.remove(f.ref(db, `publicProfiles/${uid}`));
      else await f.set(f.ref(db, `publicProfiles/${uid}`), profile);
      $('people-status').textContent = 'Cari nama teman atau pasangan, lalu kirim permintaan koneksi.';
    } catch { $('people-status').textContent = 'Pencarian pengguna belum aktif di server. Pembuat aplikasi perlu menerbitkan aturan versi ini satu kali; koneksi yang sudah ada tetap dapat digunakan.'; }
    controls();
  }
  async function connect(target, profile) {
    const { firebase: f, db, uid, pairId, owner, approved, members } = session();
    if (!uid || target === uid) return;
    if (pairId && (!owner || (approved && members > 1))) { feedback('Putuskan koneksi sekarang sebelum menghubungkan orang lain.'); return; }
    if (!(await consent('Hubungkan dengan ' + profile.name + '?', 'Hanya setelah ia menerima, Anda berdua dapat melihat lokasi yang disetujui. Lokasi dapat dihentikan kapan saja.', 'KIRIM PERMINTAAN'))) return;
    try {
      const room = await createRoom(); if (!room) return;
      const slot = await f.runTransaction(f.ref(db, `pairs/${room}/partnerUid`), value => value === null || value === target ? target : undefined);
      if (!slot.committed) throw new Error('slot');
      await f.set(f.ref(db, `connectionInvites/${target}/${uid}`), { pairId: room, createdAt: f.serverTimestamp() });
      localStorage.setItem('dualworld-sharing-consent', 'yes');
      feedback('Permintaan dikirim ke ' + profile.name + '. Buka menu Teman di HP penerima, lalu tekan Terima.');
    } catch { feedback('Permintaan belum dapat dikirim. Periksa koneksi dan pastikan aturan server terbaru sudah aktif.'); }
  }
  async function search() {
    const { firebase: f, db, uid } = session(); if (!uid) return;
    const prefix = $('people-query').value.trim().normalize('NFKC').toLowerCase();
    if (prefix.length < 2) { $('people-status').textContent = 'Ketik minimal dua huruf nama.'; return; }
    const current = ++generation; const list = $('people-results'); list.replaceChildren(); $('people-status').textContent = 'Mencari profil…';
    try {
      const result = await f.get(f.query(f.ref(db, 'publicProfiles'), f.orderByChild('searchName'), f.startAt(prefix), f.endAt(prefix + '\uf8ff'), f.limitToFirst(12)));
      if (current !== generation) return;
      result.forEach(child => {
        if (child.key === uid) return;
        const profile = child.val(); const row = document.createElement('button'); row.className = 'nearby-place-item';
        const title = document.createElement('strong'); title.textContent = `${AVATARS.includes(profile.avatar) ? profile.avatar : '🌙'} ${profile.name}`;
        const handle = document.createElement('small'); handle.textContent = profile.handle + ' · Kirim permintaan'; row.append(title, handle);
        row.addEventListener('click', () => void connect(child.key, profile)); list.append(row);
      });
      $('people-status').textContent = list.childElementCount ? 'Pilih orang yang Anda kenal. Nama/avatar tidak membuktikan identitas; pastikan dengan teman Anda.' : 'Belum ditemukan. Pastikan teman sudah membuat profil dan mengizinkan pencarian.';
    } catch { $('people-status').textContent = 'Pencarian belum tersedia. Periksa internet; pembuat aplikasi perlu mengaktifkan aturan pengguna terbaru.'; }
  }
  async function start() {
    const { firebase: f, db, uid } = session(); if (!uid) return;
    inboxWatch?.(); controls(); await save();
    inboxWatch = f.onValue(f.ref(db, `connectionInvites/${uid}`), snapshot => {
      const list = $('people-inbox'); list.replaceChildren();
      $('people-badge').hidden = !snapshot.exists();
      snapshot.forEach(child => {
        const invite = child.val(); const row = document.createElement('div'); row.className = 'connection-request';
        const title = document.createElement('strong'); title.textContent = 'Permintaan koneksi';
        f.get(f.ref(db, `publicProfiles/${child.key}`)).then(value => { const p = value.val(); title.textContent = p ? `${p.avatar || '🌙'} ${p.name}` : 'Pengguna Dualworld'; }).catch(() => {});
        const yes = document.createElement('button'); yes.className = 'secondary-button'; yes.textContent = 'TERIMA';
        yes.addEventListener('click', async () => {
          if (session().pairId && session().pairId !== invite.pairId) { feedback('Putuskan koneksi sekarang sebelum menerima orang lain.'); return; }
          if (!(await consent('Terima ' + title.textContent + '?', 'Anda berdua dapat melihat lokasi setelah Anda mengizinkannya. Gunakan Hentikan berbagi kapan saja.', 'TERIMA & HUBUNGKAN'))) return;
          try {
            await f.set(f.ref(db, `pairs/${invite.pairId}/members/${uid}`), true);
            localStorage.setItem('dualworld-sharing-consent', 'yes');
            await enterRoom(invite.pairId);
            await f.remove(f.ref(db, `connectionInvites/${uid}/${child.key}`));
            $('people-dialog').close(); feedback('Terhubung. Lokasi aktif sesuai izin Anda.');
          } catch { feedback('Permintaan sudah berakhir atau belum dapat diterima. Coba lagi ketika terhubung internet.'); }
        });
        const no = document.createElement('button'); no.className = 'text-button'; no.textContent = 'TOLAK'; no.addEventListener('click', async () => { try { await f.remove(child.ref); await f.remove(f.ref(db, `pairs/${invite.pairId}/partnerUid`)).catch(() => {}); } catch { feedback('Belum dapat menolak permintaan.'); } });
        row.append(title, yes, no); list.append(row);
      });
    }, () => { $('people-status').textContent = 'Pencarian dan permintaan profil belum diaktifkan oleh pembuat aplikasi.'; });
  }
  $('people-search-button').addEventListener('click', () => void search());
  $('people-query').addEventListener('keydown', e => { if (e.key === 'Enter') void search(); });
  $('people-button').addEventListener('click', () => $('people-dialog').showModal());
  return { start, save, stop() { inboxWatch?.(); inboxWatch = null; } };
}
