// Optional licensed provider. All mapping/panorama UI stays in this Dualworld dialog.
// Places content is displayed with the Google map, never painted onto the OSM map.
import { isFreshLocation } from './location-quality.js';
const $ = id => document.getElementById(id);
let sdkLoading;
let loadedKey = '';
function loadGoogle(config) {
  if (loadedKey && loadedKey !== config.googleMapsApiKey) throw new Error('Kunci layanan berubah. Muat ulang Dualworld untuk memakai kunci yang baru.');
  if (sdkLoading) return sdkLoading;
  loadedKey = config.googleMapsApiKey;
  sdkLoading = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    const timer = setTimeout(() => { reject(new Error('Layanan peta terlalu lama merespons. Periksa internet dan aktivasi API.')); }, 25000);
    window.dualworldGoogleLoaded = () => { clearTimeout(timer); resolve(window.google.maps); };
    window.gm_authFailure = () => {
      clearTimeout(timer); $('licensed-status').textContent = 'Google menolak konfigurasi Maps. Periksa API aktif, billing, kuota, serta pembatasan kunci browser.';
      reject(new Error('Konfigurasi Maps belum dapat dipakai.'));
    };
    const url = new URL('https://maps.googleapis.com/maps/api/js');
    url.search = new URLSearchParams({ key: config.googleMapsApiKey, callback: 'dualworldGoogleLoaded', v: 'weekly', loading: 'async', language: 'id', region: 'ID', libraries: 'places' });
    script.src = url.href; script.async = true;
    script.onerror = () => { clearTimeout(timer); sdkLoading = null; script.remove(); reject(new Error('SDK peta belum dapat diunduh. Periksa koneksi.')); };
    document.head.append(script);
  });
  return sdkLoading;
}
export function createGoogleExplorer({ getLocations }) {
  let maps;
  let view;
  let panorama;
  let cover;
  let marker;
  let chosenPoint;
  let panoramaActive = false;
  let generation = 0;
  let requestGeneration = 0;
  let panoGeneration = 0;
  const layers = {};
  const people = new Map();
  const dialog = $('licensed-map-dialog');
  function status(message) { $('licensed-status').textContent = message; }
  function displayMap() {
    panoramaActive = false; panorama?.setVisible(false);
    $('licensed-panorama-canvas').hidden = true; $('licensed-map-canvas').hidden = false; $('licensed-back').hidden = true;
    $('licensed-search-button').disabled = !view;
    if (view && maps) maps.event.trigger(view, 'resize');
  }
  function syncLocations() {
    if (!view || !maps || !dialog.open) return;
    const locations = getLocations();
    for (const kind of ['own', 'partner']) {
      const value = locations[kind]; let pin = people.get(kind);
      if (!value?.coords) { pin?.setMap(null); people.delete(kind); continue; }
      const coords = { lat: value.coords.lat, lng: value.coords.lng };
      if (!pin) {
        pin = new maps.Marker({ map: view, position: coords, title: value.name, label: { text: value.name, color: '#101c16', fontSize: '11px' }, icon: { path: maps.SymbolPath.CIRCLE, fillColor: kind === 'own' ? '#bcf27c' : '#77ddd1', fillOpacity: 1, strokeColor: '#ffffff', strokeWeight: 2, scale: 9 } });
        people.set(kind, pin);
      }
      pin.setPosition(coords); pin.setOpacity(isFreshLocation(value.coords) ? 1 : .55);
    }
  }
  function toggleLayer(kind, force) {
    if (!view) return;
    const active = force === undefined ? !layers[kind].getMap() : force;
    layers[kind].setMap(active ? view : null);
    $(`licensed-${kind}`).setAttribute('aria-pressed', String(active)); $(`licensed-${kind}`).classList.toggle('selected', active);
  }
  async function showStreet(point = chosenPoint || view?.getCenter()?.toJSON()) {
    if (!view || !point) return;
    const current = generation, request = ++requestGeneration; status('Mencari panorama jalan terdekat…');
    try {
      const data = await new Promise((resolve, reject) => new maps.StreetViewService().getPanorama({ location: point, radius: 100, preference: maps.StreetViewPreference.NEAREST, source: maps.StreetViewSource.OUTDOOR }, (data, state) => state === maps.StreetViewStatus.OK && data?.location?.pano ? resolve(data) : reject(new Error('no-panorama'))));
      if (current !== generation || request !== requestGeneration || !dialog.open) return;
      if (!panorama) {
        panorama = new maps.StreetViewPanorama($('licensed-panorama-canvas'), { addressControl: false, fullscreenControl: false, enableCloseButton: false, linksControl: true, panControl: true, zoomControl: true, motionTracking: false });
        panorama.addListener('pano_changed', () => {
          const pano = panorama.getPano(), latest = ++panoGeneration;
          new maps.StreetViewService().getPanorama({ pano }, (result, state) => {
            if (latest !== panoGeneration || !panoramaActive || !dialog.open || state !== maps.StreetViewStatus.OK) return;
            status(`${result.location?.description || 'Panorama jalan'} · ${result.imageDate ? `Rekaman ${result.imageDate}` : 'Tanggal mengikuti penyedia'} · Foto rekaman, bukan siaran langsung.`);
          });
        });
      }
      $('licensed-panorama-canvas').hidden = false; $('licensed-map-canvas').hidden = true; $('licensed-back').hidden = false; $('licensed-search-button').disabled = true;
      panoramaActive = true; panorama.setPano(data.location.pano); panorama.setPov({ heading: 0, pitch: 0 }); panorama.setVisible(true);
      maps.event.trigger(panorama, 'resize');
      status(`${data.location.description || 'Panorama jalan terdekat'} · ${data.imageDate ? `Rekaman ${data.imageDate}` : 'Tanggal rekaman mengikuti keterangan penyedia'} · Foto rekaman, bukan siaran langsung.`);
    } catch {
      if (current !== generation || request !== requestGeneration || !dialog.open) return;
      displayMap(); cover?.setMap(view);
      status('Belum ada panorama luar ruang dalam 100 m dari titik ini, atau layanan belum aktif. Geser peta lalu pilih titik di jalan; garis biru menunjukkan cakupan yang disediakan Google.');
    }
  }
  async function search() {
    const text = $('licensed-query').value.trim();
    if (text.length < 3 || !view) { status('Ketik minimal tiga huruf untuk mencari tempat.'); return; }
    const current = generation, request = ++requestGeneration; $('licensed-search-button').disabled = true; status('Mencari tempat…'); $('licensed-places').replaceChildren();
    try {
      const { Place } = await maps.importLibrary('places');
      const { places } = await Place.searchByText({ textQuery: text, fields: ['id', 'displayName', 'formattedAddress', 'location'], locationBias: view.getCenter(), maxResultCount: 8, language: 'id', region: 'id' });
      if (current !== generation || request !== requestGeneration || !dialog.open) return;
      if (!places.length) { status('Tempat belum ditemukan. Coba nama yang lebih lengkap.'); return; }
      for (const place of places) {
        const button = document.createElement('button'); button.className = 'nearby-place-item';
        const title = document.createElement('strong'); title.textContent = place.displayName || 'Tempat';
        const address = document.createElement('small'); address.textContent = place.formattedAddress || '';
        button.append(title, address); button.addEventListener('click', () => void inspectPlace(place)); $('licensed-places').append(button);
      }
      status(`${places.length} tempat ditemukan · Google Maps`);
    } catch { if (current === generation && request === requestGeneration) status('Pencarian Google belum tersedia. Aktifkan Places API (New) dan periksa kuota/billing proyek.'); }
    finally { if (current === generation && request === requestGeneration) $('licensed-search-button').disabled = panoramaActive; }
  }
  async function inspectPlace(place) {
    const current = generation, request = ++requestGeneration;
    displayMap(); status('Mengambil detail dan foto tempat…');
    try {
      await place.fetchFields({ fields: ['displayName', 'formattedAddress', 'location', 'photos', 'attributions', 'regularOpeningHours'] });
      if (current !== generation || request !== requestGeneration || !dialog.open) return;
      chosenPoint = place.location.toJSON(); view.panTo(chosenPoint); view.setZoom(18);
      if (!marker) marker = new maps.Marker({ map: view }); marker.setPosition(chosenPoint); marker.setTitle(place.displayName || 'Tempat');
      const list = $('licensed-places'); list.replaceChildren();
      const title = document.createElement('h3'); title.textContent = place.displayName;
      const address = document.createElement('p'); address.textContent = place.formattedAddress || ''; list.append(title, address);
      if (place.regularOpeningHours?.weekdayDescriptions) {
        const hours = document.createElement('p'); hours.textContent = place.regularOpeningHours.weekdayDescriptions.join(' · '); list.append(hours);
      }
      for (const photo of (place.photos || []).slice(0, 4)) {
        const figure = document.createElement('figure'), image = document.createElement('img');
        image.src = photo.getURI({ maxWidth: 1200, maxHeight: 900 }); image.alt = `Foto ${place.displayName}`; image.loading = 'lazy';
        const caption = document.createElement('figcaption'); caption.textContent = 'Foto tempat · Google Maps';
        for (const author of photo.authorAttributions || []) {
          const link = document.createElement('a'); link.textContent = author.displayName || 'Kontributor';
          if (/^https:\/\//.test(author.uri || '')) { link.href = author.uri; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.dataset.attribution = 'true'; }
          caption.append(link);
        }
        figure.append(image, caption); list.append(figure);
      }
      for (const attribution of place.attributions || []) {
        const credit = document.createElement('a'); credit.textContent = attribution.provider || '';
        if (/^https:\/\//.test(attribution.providerURI || '')) { credit.href = attribution.providerURI; credit.target = '_blank'; credit.rel = 'noopener noreferrer'; credit.dataset.attribution = 'true'; }
        list.append(credit);
      }
      status(place.photos?.length ? 'Foto tempat tersedia. Pilih Jalan 360° untuk mencari panorama di dekat titik ini.' : 'Penyedia belum memiliki foto untuk tempat ini. Anda tetap dapat menjelajahi petanya.');
    } catch { if (current === generation && request === requestGeneration) status('Detail/foto tempat belum dapat diambil. Periksa Places API (New), billing, kuota, dan internet.'); }
  }
  async function open(config, point, mode) {
    const current = ++generation; requestGeneration++; chosenPoint = { lat: point.lat, lng: point.lng };
    marker?.setMap(null); marker = null;
    maps = await loadGoogle(config);
    if (current !== generation || !dialog.open) return;
    if (!view) {
      view = new maps.Map($('licensed-map-canvas'), { center: chosenPoint, zoom: 17, mapTypeId: 'hybrid', disableDefaultUI: true, zoomControl: true, clickableIcons: false, ...(config.googleMapsMapId ? { mapId: config.googleMapsMapId } : {}) });
      layers.traffic = new maps.TrafficLayer({ autoRefresh: true }); layers.transit = new maps.TransitLayer(); layers.cycling = new maps.BicyclingLayer();
      cover = new maps.StreetViewCoverageLayer();
      view.addListener('click', event => { chosenPoint = event.latLng.toJSON(); if (cover.getMap()) void showStreet(chosenPoint); else status('Titik dipilih. Tekan Jalan 360° untuk melihat panorama terdekat.'); });
    }
    displayMap(); view.setCenter(chosenPoint); $('licensed-base').value = view.getMapTypeId(); syncLocations();
    if (mode === 'traffic') { toggleLayer('traffic', true); status('Lapisan lalu lintas langsung aktif. Warna muncul pada jalan yang memiliki data.'); }
    else if (mode === 'street') { cover.setMap(view); await showStreet(chosenPoint); }
    else status('Jelajahi peta, cari tempat, atau pilih Jalan 360°. Cakupan detail mengikuti penyedia.');
  }
  $('licensed-base').addEventListener('change', () => { displayMap(); view?.setMapTypeId($('licensed-base').value); });
  for (const kind of ['traffic', 'transit', 'cycling']) $(`licensed-${kind}`).addEventListener('click', () => { displayMap(); toggleLayer(kind); });
  $('licensed-street').addEventListener('click', () => { cover?.setMap(view); void showStreet(); });
  $('licensed-back').addEventListener('click', () => { displayMap(); status('Kembali ke peta. Pilih titik lain untuk menjelajahi jalan.'); });
  $('licensed-search-button').addEventListener('click', () => void search());
  $('licensed-query').addEventListener('keydown', event => { if (event.key === 'Enter') void search(); });
  dialog.addEventListener('close', () => { generation++; requestGeneration++; panoGeneration++; panorama?.setVisible(false); $('licensed-places').replaceChildren(); });
  return { open, syncLocations };
}
