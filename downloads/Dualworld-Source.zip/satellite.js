// Esri returns a successful grey image for missing imagery. Check coverage before
// requesting a tile, then crop its nearest available ancestor at the same position.
const base = 'https://server.arcgisonline.com/ArcGIS/rest/services/';
export function coveredSatelliteLayer(L, service, options, onFallback = () => {}) {
  const coverage = new Map();
  async function available(z, x, y) {
    const left = Math.floor(x / 8) * 8, top = Math.floor(y / 8) * 8;
    const size = Math.min(8, 2 ** z);
    const key = `${z}/${top}/${left}`;
    if (!coverage.has(key)) {
      if (coverage.size >= 256) coverage.delete(coverage.keys().next().value);
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8000);
      coverage.set(key, fetch(`${base}${service}/MapServer/tilemap/${z}/${top}/${left}/${size}/${size}?f=json`, { signal: controller.signal })
        .then(async response => {
          if (!response.ok) throw new Error('Coverage unavailable');
          const result = await response.json();
          if (!Array.isArray(result.data) || !result.location) throw new Error('Coverage unavailable');
          return result;
        }).catch(() => { coverage.delete(key); return null; }).finally(() => clearTimeout(timer)));
    }
    const result = await coverage.get(key);
    if (!result) return null;
    const { left: l, top: t, width, height } = result.location;
    if (x < l || x >= l + width || y < t || y >= t + height) return false;
    return result.data[(y - t) * width + x - l] === 1;
  }
  return new (L.GridLayer.extend({
    createTile(coords, done) {
      const canvas = document.createElement('canvas');
      const ratio = window.devicePixelRatio > 1 ? 2 : 1;
      canvas.width = canvas.height = 256 * ratio;
      (async () => {
        if (ratio === 2 && await available(coords.z + 1, coords.x * 2, coords.y * 2) === true
            && await available(coords.z + 1, coords.x * 2 + 1, coords.y * 2) === true
            && await available(coords.z + 1, coords.x * 2, coords.y * 2 + 1) === true
            && await available(coords.z + 1, coords.x * 2 + 1, coords.y * 2 + 1) === true) {
          const context = canvas.getContext('2d');
          await Promise.all([0, 1, 2, 3].map(async index => {
            const image = new Image(); image.crossOrigin = 'anonymous';
            await new Promise((resolve, reject) => {
              const timer = setTimeout(() => reject(new Error('Tile timeout')), 15000);
              image.onload = () => { clearTimeout(timer); resolve(); }; image.onerror = () => { clearTimeout(timer); reject(new Error('Tile unavailable')); };
              image.src = `${base}${service}/MapServer/tile/${coords.z + 1}/${coords.y * 2 + Math.floor(index / 2)}/${coords.x * 2 + index % 2}`;
            });
            context.drawImage(image, index % 2 * 256, Math.floor(index / 2) * 256, 256, 256);
          }));
          done(null, canvas); return;
        }
        let z = coords.z, x = coords.x, y = coords.y;
        for (;;) {
          const exists = await available(z, x, y);
          if (exists === true) break;
                    if (exists === null) break;
          if (z === 0) throw new Error('No imagery available');
          z--; x = Math.floor(x / 2); y = Math.floor(y / 2);
        }
        const source = new Image();
        source.crossOrigin = 'anonymous';
        await new Promise((resolve, reject) => {
          const timer = setTimeout(() => reject(new Error('Tile timeout')), 15000);
          source.onload = () => { clearTimeout(timer); resolve(); }; source.onerror = () => { clearTimeout(timer); reject(new Error('Tile unavailable')); };
          source.src = `${base}${service}/MapServer/tile/${z}/${y}/${x}`;
        });
        const scale = 2 ** (coords.z - z);
        const width = source.naturalWidth / scale, height = source.naturalHeight / scale;
        canvas.getContext('2d').drawImage(source, (coords.x % scale) * width, (coords.y % scale) * height, width, height, 0, 0, canvas.width, canvas.height);
        if (z < coords.z) onFallback(z, coords.z);
        done(null, canvas);
      })().catch(error => done(error, canvas));
      return canvas;
    }
  }))(options);
}
