export function publicFirebaseConfig(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || value.private_key || value.client_email || value.type === 'service_account') throw new Error('Gunakan konfigurasi aplikasi Web, bukan kunci admin.');
  const databaseURL = new URL(value.databaseURL);
  if (!['apiKey', 'projectId', 'appId'].every(key => typeof value[key] === 'string' && value[key].trim() && !value[key].includes('ISI_')) || databaseURL.protocol !== 'https:' || databaseURL.port || databaseURL.username || databaseURL.password || databaseURL.search || databaseURL.hash || databaseURL.pathname !== '/' || !/\.(firebaseio\.com|firebasedatabase\.app)$/.test(databaseURL.hostname)) throw new Error('Konfigurasi Web harus berisi apiKey, projectId, appId, dan databaseURL Firebase HTTPS.');
  return Object.fromEntries(['apiKey', 'projectId', 'appId', 'databaseURL', 'authDomain', 'storageBucket', 'messagingSenderId'].filter(key => typeof value[key] === 'string').map(key => [key, value[key]]));
}
export function parseFirebaseConfigInput(text) {
  // Accept the object copied from Firebase Console without executing JavaScript.
  const object = text.trim().replace(/^(?:const|let|var)\s+firebaseConfig\s*=\s*/, '').replace(/;\s*$/, '')
    .replace(/([,{]\s*)([A-Za-z_$][\w$]*)\s*:/g, '$1"$2":').replace(/,\s*}/g, '}');
  const config = JSON.parse(object);
  if (config.projectId === 'dualworld-tracker' && !config.databaseURL) config.databaseURL = 'https://dualworld-tracker-default-rtdb.asia-southeast1.firebasedatabase.app';
  return publicFirebaseConfig(config);
}
function encode(config) {
  return btoa(JSON.stringify(publicFirebaseConfig(config))).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '');
}
export function readInvitation(value) {
  const text = value.trim();
  if (/^[A-Za-z0-9_-]{32}$/.test(text)) return { pairId: text, config: null };
  const link = text.match(/(?:dualworld:\/\/join|https?:\/\/)[^\s<>"']+/i)?.[0] || text;
  let url;
  try { url = new URL(link, 'https://dualworld.invalid/'); } catch { return null; }
  if (!['https:', 'http:', 'dualworld:'].includes(url.protocol) || (url.protocol === 'dualworld:' && url.hostname !== 'join')) return null;
  const pairId = url.searchParams.get('pair');
  if (!/^[A-Za-z0-9_-]{32}$/.test(pairId || '')) return null;
  const encoded = new URLSearchParams(url.hash.slice(1)).get('config') || url.searchParams.get('config');
  let config = null;
  if (encoded) {
    if (encoded.length > 3000) throw new Error('Konfigurasi undangan terlalu panjang.');
    config = publicFirebaseConfig(JSON.parse(atob(encoded.replaceAll('-', '+').replaceAll('_', '/'))));
  }
  return { pairId, config };
}
export function makeInvitation(pairId, config, webUrl, native) {
  if (!/^[A-Za-z0-9_-]{32}$/.test(pairId)) return '';
  const url = new URL(native ? 'dualworld://join' : webUrl);
  url.search = new URLSearchParams({ pair: pairId }).toString();
  url.hash = new URLSearchParams({ config: encode(config) }).toString();
  return url.toString();
}
