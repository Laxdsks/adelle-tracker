import { avatar } from './people.js';
const $=id=>document.getElementById(id);
const MAX_FILE=2*1024*1024;
export function createCommunication({session,friends,consent,feedback,blockUser}) {
  let current=null,chatWatch,blockedWatch,blocked=new Set(),global=false,urls=[],recorder,recordStream,recordTimer,recording=false,recordGeneration=0,sending=false;
  const author=()=>({uid:session().uid,name:localStorage.getItem('dualworld-name')||'Pengguna',avatar:avatar()});
  const path=()=>global?'globalChat/messages':`friendships/${current.edge}/messages`;
  const api=()=>session();
  function releaseMedia(){for(const element of $('chat-messages').querySelectorAll('audio')){element.pause();element.removeAttribute('src');element.load();}for(const img of $('chat-messages').querySelectorAll('img'))img.removeAttribute('src');for(const url of urls)URL.revokeObjectURL(url);urls=[];}
  function open(friend) {
    if(!$('chat-dialog').open)$('chat-dialog').showModal();current=friend;global=false;$('chat-title').textContent=friend.profile.name;listen();
  }
  function openGlobal(){if(!api().uid){feedback('Hubungkan internet dahulu.');return;}if(!$('chat-dialog').open)$('chat-dialog').showModal();global=true;current=null;$('chat-title').textContent='Chat global';listen();}
  function listen(){
    chatWatch?.();releaseMedia();const {firebase:f,db,uid}=api();if(!uid){feedback('Hubungkan internet dahulu.');return;}
    $('chat-attachments').hidden=global;$('chat-notice').textContent=global?'Global: teks dan emoji saja. Jangan bagikan informasi pribadi.':'Pribadi: hanya anggota pertemanan ini. Maksimum berkas 2 MB; VN 60 detik.';
    const list=$('chat-messages');list.replaceChildren();
    chatWatch=f.onValue(f.query(f.ref(db,path()),f.orderByChild('createdAt'),f.limitToLast(50)),snapshot=>{
      const bottom=list.scrollHeight-list.scrollTop-list.clientHeight<80;const existing=new Map([...list.children].map(n=>[n.dataset.id,n]));
      snapshot.forEach(child=>{
        const message=child.val();if(blocked.has(message.uid)){existing.get(child.key)?.remove();existing.delete(child.key);return;}
        if(existing.has(child.key)){existing.delete(child.key);return;}
        const row=document.createElement('article');row.dataset.id=child.key;row.className='chat-message'+(message.uid===uid?' own':'');
        const title=document.createElement('small');title.textContent=`${message.avatar||'🌙'} ${message.name||'Pengguna'} · ${new Date(message.createdAt).toLocaleTimeString('id',{hour:'2-digit',minute:'2-digit'})}`;
        const body=document.createElement('p');body.textContent=message.text||'';row.append(title,body);
        if(!global&&message.mediaId){const button=document.createElement('button');button.className='text-button';button.textContent=message.kind==='audio'?'▶ PUTAR VN':message.kind==='image'?'LIHAT FOTO':'UNDUH '+(message.fileName||'BERKAS');button.onclick=()=>void attachment(message,button,row);row.append(button);}
        if(message.uid!==uid){const report=document.createElement('button');report.className='text-button report-message';report.textContent='LAPORKAN';report.onclick=()=>void reportMessage(message,child.key);row.append(report);const block=document.createElement('button');block.className='text-button report-message';block.textContent='BLOKIR';block.onclick=()=>void blockUser(message.uid);row.append(block);}
        list.append(row);
      });for(const node of existing.values())node.remove();if(bottom)list.scrollTop=list.scrollHeight;
    },()=>{$('chat-notice').textContent='Percakapan belum tersedia atau pertemanan telah berakhir.';});
  }
  async function reportMessage(message,messageId){
    if(!await consent('Laporkan pesan ini?', 'Pesan dan identitas pengirim diteruskan ke pemilik aplikasi untuk ditinjau. Pengirim juga dapat Anda blokir.', 'LAPORKAN'))return;
    const {firebase:f,db,uid}=api();try{await f.push(f.ref(db,`reports/${uid}`),{targetUid:message.uid,messageId,scope:global?'global':current.edge,reason:'Pesan yang dilaporkan pengguna',text:(message.text||'Lampiran').slice(0,500),createdAt:f.serverTimestamp()});feedback('Laporan tersimpan untuk ditinjau pemilik aplikasi.');}catch{feedback('Laporan belum terkirim.');}
  }
  async function send(text,extra={}) {
    const {firebase:f,db,uid}=api();if(!uid||(!global&&!current)||sending)return;
    sending=true;
    const message={...author(),kind:'text',text:text.trim().slice(0,2000),createdAt:f.serverTimestamp(),...extra};
    if(!message.text&&!message.mediaId){sending=false;return;}
    $('chat-send-button').disabled=true;
    try{
      const key=f.push(f.ref(db,path())).key;
      if(global){message.text=message.text.slice(0,500);await f.update(f.ref(db),{[`globalChat/messages/${key}`]:message,[`globalChat/rate/${uid}`]:{messageId:key,time:f.serverTimestamp()}});}
      else await f.set(f.ref(db,`${path()}/${key}`),message);
      $('chat-text').value='';
    }catch{feedback('Pesan belum terkirim. Periksa internet atau tunggu sejenak sebelum mengirim lagi.');throw new Error('send failed');}
    finally{sending=false;$('chat-send-button').disabled=false;}
  }
  const base64=blob=>new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=reject;reader.readAsDataURL(blob);});
  async function upload(blob,kind,fileName){
    if(global||!current)return;if(blob.size>MAX_FILE){feedback('Berkas maksimum 2 MB agar aplikasi tetap ringan.');return;}
    const {firebase:f,db,uid}=api();const edge=current.edge;const mediaRef=f.push(f.ref(db,`media/${uid}`));
    try{
      $('chat-notice').textContent='Mengirim berkas…';
      const friendshipCreatedAt=(await f.get(f.ref(db,`friendships/${edge}/createdAt`))).val();
      await f.set(mediaRef,{edge,friendshipCreatedAt,kind,name:fileName.slice(0,100),mime:(blob.type||'application/octet-stream').slice(0,100),bytes:blob.size,data:await base64(blob),createdAt:f.serverTimestamp()});
      if(current?.edge!==edge||global){await f.remove(mediaRef);return;}
      try{await send('',{kind,mediaId:mediaRef.key,fileName:fileName.slice(0,100)});}catch{await f.remove(mediaRef);}
    }catch{feedback('Berkas belum dapat dikirim.');}finally{$('chat-notice').textContent='Pribadi · maksimum berkas 2 MB, VN 60 detik.';}
  }
  async function photo(file){
    if(!/^image\/(jpeg|png|webp)$/.test(file.type)){feedback('Foto harus JPG, PNG, atau WebP.');return;}
    if(file.size>12*1024*1024){feedback('Pilih foto di bawah 12 MB.');return;}
    const bitmap=await createImageBitmap(file);if(bitmap.width*bitmap.height>25000000){bitmap.close();feedback('Foto terlalu besar. Pilih foto dengan resolusi lebih kecil.');return;}const ratio=Math.min(1,1280/Math.max(bitmap.width,bitmap.height));const canvas=document.createElement('canvas');canvas.width=Math.round(bitmap.width*ratio);canvas.height=Math.round(bitmap.height*ratio);canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();
    const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',.82));if(blob)await upload(blob,'image',file.name.replace(/\.[^.]+$/,'.jpg'));
  }
  async function attachment(message,button,row){
    const {firebase:f,db}=api();button.disabled=true;
    try{
      const data=(await f.get(f.ref(db,`media/${message.uid}/${message.mediaId}`))).val();if(!data||data.bytes>MAX_FILE||data.data.length>2800000)throw new Error('Unavailable');
      const bytes=Uint8Array.from(atob(data.data),c=>c.charCodeAt(0));if(bytes.length!==data.bytes)throw new Error('Invalid file');
      const safeImage=/^image\/(jpeg|png|webp)$/.test(data.mime),safeAudio=/^audio\/(webm|ogg|mp4)(;.*)?$/.test(data.mime);
      const blob=new Blob([bytes],{type:data.kind==='image'&&safeImage?data.mime:data.kind==='audio'&&safeAudio?data.mime:'application/octet-stream'});const url=URL.createObjectURL(blob);urls.push(url);
      if(data.kind==='image'&&safeImage){const img=document.createElement('img');img.src=url;img.alt=data.name;img.className='chat-photo';row.append(img);}
      else if(data.kind==='audio'&&safeAudio){const audio=document.createElement('audio');audio.controls=true;audio.src=url;audio.preload='metadata';row.append(audio);}
      else if(window.DualworldAndroid?.saveAttachment)window.DualworldAndroid.saveAttachment(JSON.stringify({name:data.name,mime:data.mime,data:data.data}));
      else {const link=document.createElement('a');link.href=url;link.download=data.name;link.click();}
      button.hidden=data.kind==='image'||data.kind==='audio';
    }catch{feedback('Berkas tidak tersedia atau akses pertemanan telah berakhir.');}finally{button.disabled=false;}
  }
  function cancelRecording(){recordGeneration++;clearTimeout(recordTimer);if(recording&&recorder?.state==='recording')recorder.stop();recordStream?.getTracks().forEach(t=>t.stop());recording=false;$('chat-vn-button').textContent='VN';}
  async function record(){
    if(global||!current)return;
    if(recording){recorder?.stop();return;}
    if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){feedback('VN memerlukan WebView terbaru dan izin mikrofon.');return;}
    const target=current.edge;const generation=++recordGeneration;
    $('chat-vn-button').disabled=true;
    try{
      const stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
      recordStream=stream;
      if(generation!==recordGeneration||current?.edge!==target||global||!$('chat-dialog').open){stream.getTracks().forEach(t=>t.stop());return;}
      const mime=['audio/webm;codecs=opus','audio/ogg;codecs=opus','audio/mp4'].find(type=>MediaRecorder.isTypeSupported(type));
      const parts=[];const recordingInstance=new MediaRecorder(recordStream,{...(mime?{mimeType:mime}:{}),audioBitsPerSecond:32000});recorder=recordingInstance;
      recorder.ondataavailable=e=>{if(e.data.size)parts.push(e.data);};recorder.onstop=()=>{clearTimeout(recordTimer);stream.getTracks().forEach(t=>t.stop());recording=false;$('chat-vn-button').textContent='VN';if(generation===recordGeneration&&current?.edge===target&&$('chat-dialog').open)void upload(new Blob(parts,{type:recordingInstance.mimeType}),'audio','Pesan-suara.'+(recordingInstance.mimeType.includes('mp4')?'m4a':'webm'));};
      recorder.start();recording=true;$('chat-vn-button').textContent='■ KIRIM VN';recordTimer=setTimeout(()=>{if(recordingInstance.state==='recording')recordingInstance.stop();},60000);
    }catch{feedback('Mikrofon belum diizinkan atau sedang digunakan aplikasi lain.');recordStream?.getTracks().forEach(t=>t.stop());}finally{$('chat-vn-button').disabled=false;}
  }
  async function start(){const {firebase:f,db,uid}=api();blockedWatch?.();blockedWatch=f.onValue(f.ref(db,`blockedUsers/${uid}`),s=>{blocked=new Set(Object.keys(s.val()||{}));const list=$('blocked-list');list.replaceChildren();for(const target of blocked){const button=document.createElement('button');button.className='text-button wide-button';button.textContent='BUKA BLOKIR · dw-'+target;button.onclick=()=>f.remove(f.ref(db,`blockedUsers/${uid}/${target}`)).catch(()=>feedback('Belum dapat membuka blokir.'));list.append(button);}if($('chat-dialog').open)listen();},()=>{});}
  async function erase(){const {firebase:f,db,uid}=api();current=null;cancelRecording();await f.remove(f.ref(db,`media/${uid}`));let mine;do{mine=await f.get(f.query(f.ref(db,'globalChat/messages'),f.orderByChild('uid'),f.equalTo(uid),f.limitToFirst(1000)));await Promise.all(Object.keys(mine.val()||{}).map(key=>f.remove(f.ref(db,`globalChat/messages/${key}`))));}while(mine.size===1000);await f.remove(f.ref(db,`globalChat/rate/${uid}`)).catch(()=>{});await f.remove(f.ref(db,`reports/${uid}`));}
  function stop(){if($('chat-dialog').open)$('chat-dialog').close();chatWatch?.();blockedWatch?.();current=null;cancelRecording();releaseMedia();}
  $('chat-send-button').onclick=()=>void send($('chat-text').value).catch(()=>{});$('chat-text').onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('chat-send-button').click();}};
  $('global-chat-button').onclick=openGlobal;$('chat-photo-button').onclick=()=>$('chat-photo-input').click();$('chat-file-button').onclick=()=>$('chat-file-input').click();$('chat-photo-input').onchange=e=>{if(e.target.files[0])void photo(e.target.files[0]).catch(()=>feedback('Foto belum dapat dibuka.'));e.target.value='';};$('chat-file-input').onchange=e=>{if(e.target.files[0])void upload(e.target.files[0],'file',e.target.files[0].name);e.target.value='';};$('chat-vn-button').onclick=()=>void record();
  for(const button of document.querySelectorAll('[data-emote]'))button.onclick=()=>{$('chat-text').value+=button.dataset.emote;$('chat-text').focus();};
  $('chat-dialog').addEventListener('close',()=>{current=null;chatWatch?.();cancelRecording();releaseMedia();});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)cancelRecording();});
  return {open,openGlobal,start,stop,erase,friendRemoved(edge){if(current?.edge===edge)$('chat-dialog').close();}};
}
