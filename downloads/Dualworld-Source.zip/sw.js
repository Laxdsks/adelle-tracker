const CACHE = 'dualworld-shell-v2';
const SHELL = ['./', './index.html', './styles.css', './app.js', './manifest.webmanifest', './icon.svg', './icon-192.png', './icon-512.png'];
const shellURLs = new Set(SHELL.map(asset => new URL(asset, self.registration.scope).href));
self.addEventListener('install', event => event.waitUntil((async () => {
  const cache = await caches.open(CACHE);
  await cache.addAll(SHELL.map(asset => new Request(asset, { cache: 'reload' })));
  await self.skipWaiting();
})()));
self.addEventListener('activate', event => event.waitUntil((async () => {
  const keys = await caches.keys();
  await Promise.all(keys.filter(key => key.startsWith('dualworld-') && key !== CACHE).map(key => caches.delete(key)));
  await self.clients.claim();
})()));
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== self.location.origin) return;
  // User config, tiles, coordinates, API replies, and invitation query strings are never cached.
  if (url.pathname.endsWith('/firebase-config.json') || url.pathname.endsWith('/maps-config.json')) return;
  const canonicalURL = url.origin + url.pathname;
  const navigation = event.request.mode === 'navigate';
  if (!navigation && !shellURLs.has(canonicalURL)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    try {
      const response = await fetch(event.request, { cache: 'no-cache' });
      if (response.ok && shellURLs.has(canonicalURL)) await cache.put(canonicalURL, response.clone());
      return response;
    } catch (error) {
      const cached = await cache.match(canonicalURL);
      if (cached) return cached;
      if (navigation) return await cache.match(new URL('./index.html', self.registration.scope).href)
        || new Response('Dualworld belum tersedia offline. Hubungkan internet dan buka kembali.', { status: 503 });
      throw error;
    }
  })());
});
