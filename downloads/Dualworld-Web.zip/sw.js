const CACHE = 'dualworld-shell-00070d575441';
const SHELL = ["./","./app.js","./app.js.LEGAL.txt","./chunks/chunk-ATEMMI65.js","./chunks/chunk-DLJ3SW6X.js","./chunks/chunk-LVVHK6GB.js","./chunks/chunk-LVVHK6GB.js.LEGAL.txt","./chunks/chunk-Y6SLVHK3.js","./chunks/google-explorer-X6PUZUNH.js","./chunks/index.esm-5M2ZCEHF.js","./chunks/index.esm-5M2ZCEHF.js.LEGAL.txt","./chunks/index.esm-BCDZUETR.js","./chunks/index.esm-BCDZUETR.js.LEGAL.txt","./chunks/index.esm-QVZZPF7Z.js","./chunks/index.esm-QVZZPF7Z.js.LEGAL.txt","./chunks/map-3d-LFKM5CIJ.js","./chunks/mapillary-explorer-YIUSWPTU.js","./chunks/mapillary.module-PE7ZN3QL.js","./chunks/mapillary.module-PE7ZN3QL.js.LEGAL.txt","./chunks/maplibre-gl-C247EEE4.js","./chunks/maplibre-gl-C247EEE4.js.LEGAL.txt","./icon-192.png","./icon-512.png","./icon.svg","./index.html","./manifest.webmanifest","./privacy.html","./styles.css","./tracker.html","./vendor/leaflet/LICENSE.txt","./vendor/leaflet/images/layers-2x.png","./vendor/leaflet/images/layers.png","./vendor/leaflet/images/marker-icon-2x.png","./vendor/leaflet/images/marker-icon.png","./vendor/leaflet/images/marker-shadow.png","./vendor/leaflet/leaflet.css","./vendor/mapillary/LICENSE.txt","./vendor/mapillary/mapillary.css","./vendor/maplibre/LICENSE.txt","./vendor/maplibre/maplibre-gl.css","./vendor/maplibre/worker.js","./vendor/maplibre/worker.js.LEGAL.txt"];
const shellURLs = new Set(SHELL.map(asset => new URL(asset, self.registration.scope).href));
self.addEventListener('install', event => event.waitUntil((async () => {
  const cache = await caches.open(CACHE);
  await cache.addAll(SHELL.map(asset => new Request(asset, { cache: 'reload' })));
  await self.skipWaiting();
})()));
self.addEventListener('activate', event => event.waitUntil((async () => {
  const keys = await caches.keys();
  await Promise.all(keys.filter(key => key.startsWith('dualworld-') && key !== CACHE).map(key => caches.delete(key)));
  await self.clients.claim();
})()));
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== self.location.origin) return;
  // User config, tiles, coordinates, API replies, and invitation query strings are never cached.
  if (url.pathname.endsWith('/firebase-config.json') || url.pathname.endsWith('/maps-config.json')) return;
  const canonicalURL = url.origin + url.pathname;
  const navigation = event.request.mode === 'navigate';
  if (!navigation && !shellURLs.has(canonicalURL)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    try {
      const response = await fetch(event.request, { cache: 'no-cache' });
      if (response.ok && shellURLs.has(canonicalURL)) await cache.put(canonicalURL, response.clone());
      return response;
    } catch (error) {
      const cached = await cache.match(canonicalURL);
      if (cached) return cached;
      if (navigation) return await cache.match(new URL('./index.html', self.registration.scope).href)
        || new Response('Dualworld belum tersedia offline. Hubungkan internet dan buka kembali.', { status: 503 });
      throw error;
    }
  })());
});
